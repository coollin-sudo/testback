export const TX_DATA = 
[
  {
    "date": "1998-07-21",
    "close": 8045.0,
    "volume": 208,
    "contract": "199809"
  },
  {
    "date": "1998-07-22",
    "close": 7870.0,
    "volume": 360,
    "contract": "199809"
  },
  {
    "date": "1998-07-23",
    "close": 7825.0,
    "volume": 190,
    "contract": "199809"
  },
  {
    "date": "1998-07-24",
    "close": 7835.0,
    "volume": 340,
    "contract": "199809"
  },
  {
    "date": "1998-07-27",
    "close": 7786.0,
    "volume": 150,
    "contract": "199809"
  },
  {
    "date": "1998-07-28",
    "close": 7742.0,
    "volume": 264,
    "contract": "199809"
  },
  {
    "date": "1998-07-29",
    "close": 7680.0,
    "volume": 323,
    "contract": "199809"
  },
  {
    "date": "1998-07-30",
    "close": 7638.0,
    "volume": 222,
    "contract": "199809"
  },
  {
    "date": "1998-07-31",
    "close": 7600.0,
    "volume": 257,
    "contract": "199809"
  },
  {
    "date": "1998-08-01",
    "close": 7609.0,
    "volume": 378,
    "contract": "199809"
  },
  {
    "date": "1998-08-03",
    "close": 7552.0,
    "volume": 293,
    "contract": "199809"
  },
  {
    "date": "1998-08-04",
    "close": 7560.0,
    "volume": 302,
    "contract": "199809"
  },
  {
    "date": "1998-08-05",
    "close": 7487.0,
    "volume": 455,
    "contract": "199809"
  },
  {
    "date": "1998-08-06",
    "close": 7462.0,
    "volume": 270,
    "contract": "199809"
  },
  {
    "date": "1998-08-07",
    "close": 7515.0,
    "volume": 453,
    "contract": "199809"
  },
  {
    "date": "1998-08-10",
    "close": 7365.0,
    "volume": 345,
    "contract": "199809"
  },
  {
    "date": "1998-08-11",
    "close": 7360.0,
    "volume": 386,
    "contract": "199809"
  },
  {
    "date": "1998-08-12",
    "close": 7330.0,
    "volume": 384,
    "contract": "199809"
  },
  {
    "date": "1998-08-13",
    "close": 7291.0,
    "volume": 496,
    "contract": "199809"
  },
  {
    "date": "1998-08-14",
    "close": 7320.0,
    "volume": 528,
    "contract": "199809"
  },
  {
    "date": "1998-08-15",
    "close": 7300.0,
    "volume": 361,
    "contract": "199809"
  },
  {
    "date": "1998-08-17",
    "close": 7219.0,
    "volume": 308,
    "contract": "199809"
  },
  {
    "date": "1998-08-18",
    "close": 7220.0,
    "volume": 574,
    "contract": "199809"
  },
  {
    "date": "1998-08-19",
    "close": 7285.0,
    "volume": 543,
    "contract": "199809"
  },
  {
    "date": "1998-08-20",
    "close": 7274.0,
    "volume": 322,
    "contract": "199809"
  },
  {
    "date": "1998-08-21",
    "close": 7225.0,
    "volume": 301,
    "contract": "199809"
  },
  {
    "date": "1998-08-24",
    "close": 6955.0,
    "volume": 919,
    "contract": "199809"
  },
  {
    "date": "1998-08-25",
    "close": 6949.0,
    "volume": 780,
    "contract": "199809"
  },
  {
    "date": "1998-08-26",
    "close": 6790.0,
    "volume": 839,
    "contract": "199809"
  },
  {
    "date": "1998-08-27",
    "close": 6835.0,
    "volume": 1137,
    "contract": "199809"
  },
  {
    "date": "1998-08-28",
    "close": 6695.0,
    "volume": 1285,
    "contract": "199809"
  },
  {
    "date": "1998-08-29",
    "close": 6728.0,
    "volume": 698,
    "contract": "199809"
  },
  {
    "date": "1998-08-31",
    "close": 6566.0,
    "volume": 922,
    "contract": "199809"
  },
  {
    "date": "1998-09-01",
    "close": 6410.0,
    "volume": 1584,
    "contract": "199809"
  },
  {
    "date": "1998-09-02",
    "close": 6430.0,
    "volume": 1417,
    "contract": "199809"
  },
  {
    "date": "1998-09-03",
    "close": 6200.0,
    "volume": 1459,
    "contract": "199809"
  },
  {
    "date": "1998-09-04",
    "close": 6399.0,
    "volume": 1789,
    "contract": "199809"
  },
  {
    "date": "1998-09-05",
    "close": 6700.0,
    "volume": 2198,
    "contract": "199809"
  },
  {
    "date": "1998-09-07",
    "close": 6719.0,
    "volume": 1632,
    "contract": "199809"
  },
  {
    "date": "1998-09-08",
    "close": 6865.0,
    "volume": 1410,
    "contract": "199809"
  },
  {
    "date": "1998-09-09",
    "close": 6770.0,
    "volume": 1901,
    "contract": "199809"
  },
  {
    "date": "1998-09-10",
    "close": 6730.0,
    "volume": 1371,
    "contract": "199809"
  },
  {
    "date": "1998-09-11",
    "close": 6769.0,
    "volume": 1804,
    "contract": "199809"
  },
  {
    "date": "1998-09-14",
    "close": 6818.0,
    "volume": 871,
    "contract": "199809"
  },
  {
    "date": "1998-09-15",
    "close": 6825.0,
    "volume": 612,
    "contract": "199809"
  },
  {
    "date": "1998-09-16",
    "close": 6995.0,
    "volume": 732,
    "contract": "199809"
  },
  {
    "date": "1998-09-17",
    "close": 6906.0,
    "volume": 1979,
    "contract": "199810"
  },
  {
    "date": "1998-09-18",
    "close": 6842.0,
    "volume": 1470,
    "contract": "199810"
  },
  {
    "date": "1998-09-19",
    "close": 7039.0,
    "volume": 2339,
    "contract": "199810"
  },
  {
    "date": "1998-09-21",
    "close": 6861.0,
    "volume": 2307,
    "contract": "199810"
  },
  {
    "date": "1998-09-22",
    "close": 6926.0,
    "volume": 1715,
    "contract": "199810"
  },
  {
    "date": "1998-09-23",
    "close": 6852.0,
    "volume": 1773,
    "contract": "199810"
  },
  {
    "date": "1998-09-24",
    "close": 6890.0,
    "volume": 1403,
    "contract": "199810"
  },
  {
    "date": "1998-09-25",
    "close": 6871.0,
    "volume": 1928,
    "contract": "199810"
  },
  {
    "date": "1998-09-28",
    "close": 6840.0,
    "volume": 1132,
    "contract": "199810"
  },
  {
    "date": "1998-09-29",
    "close": 6806.0,
    "volume": 1389,
    "contract": "199810"
  },
  {
    "date": "1998-09-30",
    "close": 6787.0,
    "volume": 1239,
    "contract": "199810"
  },
  {
    "date": "1998-10-01",
    "close": 6620.0,
    "volume": 2073,
    "contract": "199810"
  },
  {
    "date": "1998-10-02",
    "close": 6398.0,
    "volume": 2532,
    "contract": "199810"
  },
  {
    "date": "1998-10-03",
    "close": 6550.0,
    "volume": 2383,
    "contract": "199810"
  },
  {
    "date": "1998-10-06",
    "close": 6450.0,
    "volume": 2007,
    "contract": "199810"
  },
  {
    "date": "1998-10-07",
    "close": 6639.0,
    "volume": 2348,
    "contract": "199810"
  },
  {
    "date": "1998-10-08",
    "close": 6981.0,
    "volume": 3281,
    "contract": "199810"
  },
  {
    "date": "1998-10-09",
    "close": 6900.0,
    "volume": 3290,
    "contract": "199810"
  },
  {
    "date": "1998-10-12",
    "close": 6935.0,
    "volume": 1613,
    "contract": "199810"
  },
  {
    "date": "1998-10-13",
    "close": 6852.0,
    "volume": 2387,
    "contract": "199810"
  },
  {
    "date": "1998-10-14",
    "close": 6775.0,
    "volume": 2224,
    "contract": "199810"
  },
  {
    "date": "1998-10-15",
    "close": 6760.0,
    "volume": 1188,
    "contract": "199810"
  },
  {
    "date": "1998-10-17",
    "close": 6908.0,
    "volume": 1592,
    "contract": "199810"
  },
  {
    "date": "1998-10-19",
    "close": 6900.0,
    "volume": 641,
    "contract": "199810"
  },
  {
    "date": "1998-10-20",
    "close": 6812.0,
    "volume": 777,
    "contract": "199810"
  },
  {
    "date": "1998-10-21",
    "close": 7054.0,
    "volume": 926,
    "contract": "199810"
  },
  {
    "date": "1998-10-22",
    "close": 6955.0,
    "volume": 2243,
    "contract": "199811"
  },
  {
    "date": "1998-10-23",
    "close": 7015.0,
    "volume": 2586,
    "contract": "199811"
  },
  {
    "date": "1998-10-26",
    "close": 7010.0,
    "volume": 1463,
    "contract": "199811"
  },
  {
    "date": "1998-10-27",
    "close": 7014.0,
    "volume": 2071,
    "contract": "199811"
  },
  {
    "date": "1998-10-28",
    "close": 6914.0,
    "volume": 2947,
    "contract": "199811"
  },
  {
    "date": "1998-10-29",
    "close": 6965.0,
    "volume": 1515,
    "contract": "199811"
  },
  {
    "date": "1998-10-30",
    "close": 7035.0,
    "volume": 2302,
    "contract": "199811"
  },
  {
    "date": "1998-10-31",
    "close": 7118.0,
    "volume": 2753,
    "contract": "199811"
  },
  {
    "date": "1998-11-02",
    "close": 7181.0,
    "volume": 2530,
    "contract": "199811"
  },
  {
    "date": "1998-11-03",
    "close": 7080.0,
    "volume": 2876,
    "contract": "199811"
  },
  {
    "date": "1998-11-04",
    "close": 6958.0,
    "volume": 3434,
    "contract": "199811"
  },
  {
    "date": "1998-11-05",
    "close": 7015.0,
    "volume": 2888,
    "contract": "199811"
  },
  {
    "date": "1998-11-06",
    "close": 6921.0,
    "volume": 3000,
    "contract": "199811"
  },
  {
    "date": "1998-11-07",
    "close": 7000.0,
    "volume": 2117,
    "contract": "199811"
  },
  {
    "date": "1998-11-09",
    "close": 6965.0,
    "volume": 1374,
    "contract": "199811"
  },
  {
    "date": "1998-11-10",
    "close": 6831.0,
    "volume": 2496,
    "contract": "199811"
  },
  {
    "date": "1998-11-11",
    "close": 6710.0,
    "volume": 2317,
    "contract": "199811"
  },
  {
    "date": "1998-11-13",
    "close": 6894.0,
    "volume": 2411,
    "contract": "199811"
  },
  {
    "date": "1998-11-16",
    "close": 7070.0,
    "volume": 1784,
    "contract": "199811"
  },
  {
    "date": "1998-11-17",
    "close": 7165.0,
    "volume": 1252,
    "contract": "199811"
  },
  {
    "date": "1998-11-18",
    "close": 7110.0,
    "volume": 940,
    "contract": "199811"
  },
  {
    "date": "1998-11-19",
    "close": 7350.0,
    "volume": 3567,
    "contract": "199812"
  },
  {
    "date": "1998-11-20",
    "close": 7390.0,
    "volume": 2989,
    "contract": "199812"
  },
  {
    "date": "1998-11-21",
    "close": 7380.0,
    "volume": 3385,
    "contract": "199812"
  },
  {
    "date": "1998-11-23",
    "close": 7344.0,
    "volume": 1636,
    "contract": "199812"
  },
  {
    "date": "1998-11-24",
    "close": 7525.0,
    "volume": 3250,
    "contract": "199812"
  },
  {
    "date": "1998-11-25",
    "close": 7366.0,
    "volume": 4222,
    "contract": "199812"
  },
  {
    "date": "1998-11-26",
    "close": 7529.0,
    "volume": 3485,
    "contract": "199812"
  },
  {
    "date": "1998-11-27",
    "close": 7490.0,
    "volume": 2598,
    "contract": "199812"
  },
  {
    "date": "1998-11-30",
    "close": 7413.0,
    "volume": 2194,
    "contract": "199812"
  },
  {
    "date": "1998-12-01",
    "close": 7336.0,
    "volume": 2815,
    "contract": "199812"
  },
  {
    "date": "1998-12-02",
    "close": 7380.0,
    "volume": 2268,
    "contract": "199812"
  },
  {
    "date": "1998-12-03",
    "close": 7321.0,
    "volume": 1844,
    "contract": "199812"
  },
  {
    "date": "1998-12-04",
    "close": 7384.0,
    "volume": 2017,
    "contract": "199812"
  },
  {
    "date": "1998-12-07",
    "close": 7470.0,
    "volume": 2958,
    "contract": "199812"
  },
  {
    "date": "1998-12-08",
    "close": 7352.0,
    "volume": 2678,
    "contract": "199812"
  },
  {
    "date": "1998-12-09",
    "close": 7226.0,
    "volume": 2646,
    "contract": "199812"
  },
  {
    "date": "1998-12-10",
    "close": 7186.0,
    "volume": 2171,
    "contract": "199812"
  },
  {
    "date": "1998-12-11",
    "close": 6965.0,
    "volume": 2886,
    "contract": "199812"
  },
  {
    "date": "1998-12-14",
    "close": 6959.0,
    "volume": 1576,
    "contract": "199812"
  },
  {
    "date": "1998-12-15",
    "close": 7000.0,
    "volume": 2067,
    "contract": "199812"
  },
  {
    "date": "1998-12-16",
    "close": 6760.0,
    "volume": 1701,
    "contract": "199812"
  },
  {
    "date": "1998-12-17",
    "close": 6691.0,
    "volume": 5263,
    "contract": "199901"
  },
  {
    "date": "1998-12-18",
    "close": 6769.0,
    "volume": 5258,
    "contract": "199901"
  },
  {
    "date": "1998-12-19",
    "close": 6612.0,
    "volume": 4491,
    "contract": "199901"
  },
  {
    "date": "1998-12-21",
    "close": 6705.0,
    "volume": 3869,
    "contract": "199901"
  },
  {
    "date": "1998-12-22",
    "close": 6940.0,
    "volume": 4617,
    "contract": "199901"
  },
  {
    "date": "1998-12-23",
    "close": 6835.0,
    "volume": 3868,
    "contract": "199901"
  },
  {
    "date": "1998-12-24",
    "close": 6840.0,
    "volume": 3801,
    "contract": "199901"
  },
  {
    "date": "1998-12-28",
    "close": 6591.0,
    "volume": 4403,
    "contract": "199901"
  },
  {
    "date": "1998-12-29",
    "close": 6630.0,
    "volume": 3876,
    "contract": "199901"
  },
  {
    "date": "1998-12-30",
    "close": 6608.0,
    "volume": 4600,
    "contract": "199901"
  },
  {
    "date": "1998-12-31",
    "close": 6531.0,
    "volume": 3173,
    "contract": "199901"
  },
  {
    "date": "1999-01-05",
    "close": 6120.0,
    "volume": 5058,
    "contract": "199901"
  },
  {
    "date": "1999-01-06",
    "close": 6245.0,
    "volume": 5903,
    "contract": "199901"
  },
  {
    "date": "1999-01-07",
    "close": 6510.0,
    "volume": 5515,
    "contract": "199901"
  },
  {
    "date": "1999-01-08",
    "close": 6452.0,
    "volume": 4385,
    "contract": "199901"
  },
  {
    "date": "1999-01-11",
    "close": 6435.0,
    "volume": 2558,
    "contract": "199901"
  },
  {
    "date": "1999-01-12",
    "close": 6390.0,
    "volume": 3195,
    "contract": "199901"
  },
  {
    "date": "1999-01-13",
    "close": 6352.0,
    "volume": 2693,
    "contract": "199901"
  },
  {
    "date": "1999-01-14",
    "close": 6280.0,
    "volume": 2775,
    "contract": "199901"
  },
  {
    "date": "1999-01-15",
    "close": 6600.0,
    "volume": 3923,
    "contract": "199901"
  },
  {
    "date": "1999-01-16",
    "close": 6530.0,
    "volume": 2442,
    "contract": "199901"
  },
  {
    "date": "1999-01-18",
    "close": 6412.0,
    "volume": 885,
    "contract": "199901"
  },
  {
    "date": "1999-01-19",
    "close": 6385.0,
    "volume": 932,
    "contract": "199901"
  },
  {
    "date": "1999-01-20",
    "close": 6321.0,
    "volume": 1015,
    "contract": "199901"
  },
  {
    "date": "1999-01-21",
    "close": 6417.0,
    "volume": 4800,
    "contract": "199902"
  },
  {
    "date": "1999-01-22",
    "close": 6285.0,
    "volume": 3985,
    "contract": "199902"
  },
  {
    "date": "1999-01-25",
    "close": 6040.0,
    "volume": 3424,
    "contract": "199902"
  },
  {
    "date": "1999-01-26",
    "close": 6220.0,
    "volume": 5115,
    "contract": "199902"
  },
  {
    "date": "1999-01-27",
    "close": 6145.0,
    "volume": 3969,
    "contract": "199902"
  },
  {
    "date": "1999-01-28",
    "close": 6070.0,
    "volume": 3359,
    "contract": "199902"
  },
  {
    "date": "1999-01-29",
    "close": 6080.0,
    "volume": 3691,
    "contract": "199902"
  },
  {
    "date": "1999-01-30",
    "close": 6110.0,
    "volume": 5084,
    "contract": "199902"
  },
  {
    "date": "1999-02-01",
    "close": 5954.0,
    "volume": 3284,
    "contract": "199902"
  },
  {
    "date": "1999-02-02",
    "close": 5880.0,
    "volume": 3803,
    "contract": "199902"
  },
  {
    "date": "1999-02-03",
    "close": 5890.0,
    "volume": 5641,
    "contract": "199902"
  },
  {
    "date": "1999-02-04",
    "close": 5558.0,
    "volume": 5240,
    "contract": "199902"
  },
  {
    "date": "1999-02-05",
    "close": 5580.0,
    "volume": 5807,
    "contract": "199902"
  },
  {
    "date": "1999-02-06",
    "close": 5767.0,
    "volume": 5022,
    "contract": "199902"
  },
  {
    "date": "1999-02-08",
    "close": 5835.0,
    "volume": 3572,
    "contract": "199902"
  },
  {
    "date": "1999-02-09",
    "close": 5770.0,
    "volume": 1545,
    "contract": "199902"
  },
  {
    "date": "1999-02-10",
    "close": 5840.0,
    "volume": 1373,
    "contract": "199902"
  },
  {
    "date": "1999-02-20",
    "close": 6140.0,
    "volume": 1197,
    "contract": "199902"
  },
  {
    "date": "1999-02-22",
    "close": 6530.0,
    "volume": 5356,
    "contract": "199903"
  },
  {
    "date": "1999-02-23",
    "close": 6315.0,
    "volume": 5973,
    "contract": "199903"
  },
  {
    "date": "1999-02-24",
    "close": 6425.0,
    "volume": 5943,
    "contract": "199903"
  },
  {
    "date": "1999-02-25",
    "close": 6380.0,
    "volume": 5210,
    "contract": "199903"
  },
  {
    "date": "1999-02-26",
    "close": 6469.0,
    "volume": 4658,
    "contract": "199903"
  },
  {
    "date": "1999-03-01",
    "close": 6419.0,
    "volume": 3787,
    "contract": "199903"
  },
  {
    "date": "1999-03-02",
    "close": 6345.0,
    "volume": 4189,
    "contract": "199903"
  },
  {
    "date": "1999-03-03",
    "close": 6450.0,
    "volume": 5452,
    "contract": "199903"
  },
  {
    "date": "1999-03-04",
    "close": 6388.0,
    "volume": 5499,
    "contract": "199903"
  },
  {
    "date": "1999-03-05",
    "close": 6425.0,
    "volume": 4459,
    "contract": "199903"
  },
  {
    "date": "1999-03-06",
    "close": 6440.0,
    "volume": 4710,
    "contract": "199903"
  },
  {
    "date": "1999-03-08",
    "close": 6465.0,
    "volume": 2462,
    "contract": "199903"
  },
  {
    "date": "1999-03-09",
    "close": 6489.0,
    "volume": 4157,
    "contract": "199903"
  },
  {
    "date": "1999-03-10",
    "close": 6520.0,
    "volume": 2695,
    "contract": "199903"
  },
  {
    "date": "1999-03-11",
    "close": 6451.0,
    "volume": 2635,
    "contract": "199903"
  },
  {
    "date": "1999-03-12",
    "close": 6489.0,
    "volume": 1699,
    "contract": "199903"
  },
  {
    "date": "1999-03-15",
    "close": 6619.0,
    "volume": 2078,
    "contract": "199903"
  },
  {
    "date": "1999-03-16",
    "close": 6659.0,
    "volume": 1487,
    "contract": "199903"
  },
  {
    "date": "1999-03-17",
    "close": 6776.0,
    "volume": 1484,
    "contract": "199903"
  },
  {
    "date": "1999-03-18",
    "close": 6934.0,
    "volume": 4144,
    "contract": "199904"
  },
  {
    "date": "1999-03-19",
    "close": 7070.0,
    "volume": 4410,
    "contract": "199904"
  },
  {
    "date": "1999-03-20",
    "close": 7075.0,
    "volume": 3769,
    "contract": "199904"
  },
  {
    "date": "1999-03-22",
    "close": 7100.0,
    "volume": 2710,
    "contract": "199904"
  },
  {
    "date": "1999-03-23",
    "close": 7005.0,
    "volume": 4342,
    "contract": "199904"
  },
  {
    "date": "1999-03-24",
    "close": 6981.0,
    "volume": 4683,
    "contract": "199904"
  },
  {
    "date": "1999-03-25",
    "close": 7010.0,
    "volume": 2906,
    "contract": "199904"
  },
  {
    "date": "1999-03-26",
    "close": 7095.0,
    "volume": 3784,
    "contract": "199904"
  },
  {
    "date": "1999-03-29",
    "close": 6947.0,
    "volume": 3684,
    "contract": "199904"
  },
  {
    "date": "1999-03-30",
    "close": 6984.0,
    "volume": 3603,
    "contract": "199904"
  },
  {
    "date": "1999-03-31",
    "close": 6935.0,
    "volume": 3602,
    "contract": "199904"
  },
  {
    "date": "1999-04-01",
    "close": 7110.0,
    "volume": 4887,
    "contract": "199904"
  },
  {
    "date": "1999-04-02",
    "close": 7366.0,
    "volume": 5807,
    "contract": "199904"
  },
  {
    "date": "1999-04-03",
    "close": 7305.0,
    "volume": 4636,
    "contract": "199904"
  },
  {
    "date": "1999-04-06",
    "close": 7314.0,
    "volume": 2770,
    "contract": "199904"
  },
  {
    "date": "1999-04-07",
    "close": 7274.0,
    "volume": 3160,
    "contract": "199904"
  },
  {
    "date": "1999-04-08",
    "close": 7380.0,
    "volume": 4669,
    "contract": "199904"
  },
  {
    "date": "1999-04-09",
    "close": 7330.0,
    "volume": 4024,
    "contract": "199904"
  },
  {
    "date": "1999-04-12",
    "close": 7275.0,
    "volume": 3680,
    "contract": "199904"
  },
  {
    "date": "1999-04-13",
    "close": 7377.0,
    "volume": 3347,
    "contract": "199904"
  },
  {
    "date": "1999-04-14",
    "close": 7365.0,
    "volume": 3501,
    "contract": "199904"
  },
  {
    "date": "1999-04-15",
    "close": 7480.0,
    "volume": 3417,
    "contract": "199904"
  },
  {
    "date": "1999-04-16",
    "close": 7460.0,
    "volume": 2774,
    "contract": "199904"
  },
  {
    "date": "1999-04-17",
    "close": 7570.0,
    "volume": 1899,
    "contract": "199904"
  },
  {
    "date": "1999-04-19",
    "close": 7620.0,
    "volume": 1296,
    "contract": "199904"
  },
  {
    "date": "1999-04-20",
    "close": 7640.0,
    "volume": 901,
    "contract": "199904"
  },
  {
    "date": "1999-04-21",
    "close": 7490.0,
    "volume": 1798,
    "contract": "199904"
  },
  {
    "date": "1999-04-22",
    "close": 7590.0,
    "volume": 4262,
    "contract": "199905"
  },
  {
    "date": "1999-04-23",
    "close": 7653.0,
    "volume": 4592,
    "contract": "199905"
  },
  {
    "date": "1999-04-26",
    "close": 7630.0,
    "volume": 3108,
    "contract": "199905"
  },
  {
    "date": "1999-04-27",
    "close": 7575.0,
    "volume": 3256,
    "contract": "199905"
  },
  {
    "date": "1999-04-28",
    "close": 7559.0,
    "volume": 2636,
    "contract": "199905"
  },
  {
    "date": "1999-04-29",
    "close": 7381.0,
    "volume": 5961,
    "contract": "199905"
  },
  {
    "date": "1999-04-30",
    "close": 7440.0,
    "volume": 4727,
    "contract": "199905"
  },
  {
    "date": "1999-05-03",
    "close": 7436.0,
    "volume": 2622,
    "contract": "199905"
  },
  {
    "date": "1999-05-04",
    "close": 7625.0,
    "volume": 5721,
    "contract": "199905"
  },
  {
    "date": "1999-05-05",
    "close": 7599.0,
    "volume": 3291,
    "contract": "199905"
  },
  {
    "date": "1999-05-06",
    "close": 7603.0,
    "volume": 3294,
    "contract": "199905"
  },
  {
    "date": "1999-05-07",
    "close": 7519.0,
    "volume": 3685,
    "contract": "199905"
  },
  {
    "date": "1999-05-10",
    "close": 7560.0,
    "volume": 2902,
    "contract": "199905"
  },
  {
    "date": "1999-05-11",
    "close": 7470.0,
    "volume": 4013,
    "contract": "199905"
  },
  {
    "date": "1999-05-12",
    "close": 7470.0,
    "volume": 2694,
    "contract": "199905"
  },
  {
    "date": "1999-05-13",
    "close": 7469.0,
    "volume": 2389,
    "contract": "199905"
  },
  {
    "date": "1999-05-14",
    "close": 7610.0,
    "volume": 3525,
    "contract": "199905"
  },
  {
    "date": "1999-05-15",
    "close": 7610.0,
    "volume": 1700,
    "contract": "199905"
  },
  {
    "date": "1999-05-17",
    "close": 7600.0,
    "volume": 1811,
    "contract": "199905"
  },
  {
    "date": "1999-05-18",
    "close": 7600.0,
    "volume": 1095,
    "contract": "199905"
  },
  {
    "date": "1999-05-19",
    "close": 7609.0,
    "volume": 1753,
    "contract": "199905"
  },
  {
    "date": "1999-05-20",
    "close": 7610.0,
    "volume": 3978,
    "contract": "199906"
  },
  {
    "date": "1999-05-21",
    "close": 7625.0,
    "volume": 2195,
    "contract": "199906"
  },
  {
    "date": "1999-05-24",
    "close": 7628.0,
    "volume": 2455,
    "contract": "199906"
  },
  {
    "date": "1999-05-25",
    "close": 7509.0,
    "volume": 4904,
    "contract": "199906"
  },
  {
    "date": "1999-05-26",
    "close": 7500.0,
    "volume": 4280,
    "contract": "199906"
  },
  {
    "date": "1999-05-27",
    "close": 7480.0,
    "volume": 2901,
    "contract": "199906"
  },
  {
    "date": "1999-05-28",
    "close": 7418.0,
    "volume": 3395,
    "contract": "199906"
  },
  {
    "date": "1999-05-29",
    "close": 7439.0,
    "volume": 2123,
    "contract": "199906"
  },
  {
    "date": "1999-05-31",
    "close": 7321.0,
    "volume": 2891,
    "contract": "199906"
  },
  {
    "date": "1999-06-01",
    "close": 7408.0,
    "volume": 2952,
    "contract": "199906"
  },
  {
    "date": "1999-06-02",
    "close": 7452.0,
    "volume": 3163,
    "contract": "199906"
  },
  {
    "date": "1999-06-03",
    "close": 7510.0,
    "volume": 3292,
    "contract": "199906"
  },
  {
    "date": "1999-06-04",
    "close": 7535.0,
    "volume": 1614,
    "contract": "199906"
  },
  {
    "date": "1999-06-05",
    "close": 7584.0,
    "volume": 2194,
    "contract": "199906"
  },
  {
    "date": "1999-06-07",
    "close": 7795.0,
    "volume": 4588,
    "contract": "199906"
  },
  {
    "date": "1999-06-08",
    "close": 7894.0,
    "volume": 2870,
    "contract": "199906"
  },
  {
    "date": "1999-06-09",
    "close": 7925.0,
    "volume": 2287,
    "contract": "199906"
  },
  {
    "date": "1999-06-10",
    "close": 7960.0,
    "volume": 2548,
    "contract": "199906"
  },
  {
    "date": "1999-06-11",
    "close": 7960.0,
    "volume": 1857,
    "contract": "199906"
  },
  {
    "date": "1999-06-14",
    "close": 7975.0,
    "volume": 1284,
    "contract": "199906"
  },
  {
    "date": "1999-06-15",
    "close": 7943.0,
    "volume": 1714,
    "contract": "199906"
  },
  {
    "date": "1999-06-16",
    "close": 8090.0,
    "volume": 2128,
    "contract": "199906"
  },
  {
    "date": "1999-06-17",
    "close": 8349.0,
    "volume": 4654,
    "contract": "199907"
  },
  {
    "date": "1999-06-21",
    "close": 8439.0,
    "volume": 3935,
    "contract": "199907"
  },
  {
    "date": "1999-06-22",
    "close": 8690.0,
    "volume": 4372,
    "contract": "199907"
  },
  {
    "date": "1999-06-23",
    "close": 8527.0,
    "volume": 5303,
    "contract": "199907"
  },
  {
    "date": "1999-06-24",
    "close": 8697.0,
    "volume": 4819,
    "contract": "199907"
  },
  {
    "date": "1999-06-25",
    "close": 8434.0,
    "volume": 5512,
    "contract": "199907"
  },
  {
    "date": "1999-06-28",
    "close": 8447.0,
    "volume": 2883,
    "contract": "199907"
  },
  {
    "date": "1999-06-29",
    "close": 8618.0,
    "volume": 3720,
    "contract": "199907"
  },
  {
    "date": "1999-06-30",
    "close": 8559.0,
    "volume": 2884,
    "contract": "199907"
  },
  {
    "date": "1999-07-02",
    "close": 8631.0,
    "volume": 3213,
    "contract": "199907"
  },
  {
    "date": "1999-07-03",
    "close": 8616.0,
    "volume": 2856,
    "contract": "199907"
  },
  {
    "date": "1999-07-05",
    "close": 8608.0,
    "volume": 2068,
    "contract": "199907"
  },
  {
    "date": "1999-07-06",
    "close": 8526.0,
    "volume": 2582,
    "contract": "199907"
  },
  {
    "date": "1999-07-07",
    "close": 8560.0,
    "volume": 2970,
    "contract": "199907"
  },
  {
    "date": "1999-07-08",
    "close": 8615.0,
    "volume": 2519,
    "contract": "199907"
  },
  {
    "date": "1999-07-09",
    "close": 8565.0,
    "volume": 1759,
    "contract": "199907"
  },
  {
    "date": "1999-07-12",
    "close": 8550.0,
    "volume": 1704,
    "contract": "199907"
  },
  {
    "date": "1999-07-13",
    "close": 8280.0,
    "volume": 4296,
    "contract": "199907"
  },
  {
    "date": "1999-07-14",
    "close": 7985.0,
    "volume": 4794,
    "contract": "199907"
  },
  {
    "date": "1999-07-15",
    "close": 8030.0,
    "volume": 3510,
    "contract": "199907"
  },
  {
    "date": "1999-07-16",
    "close": 7468.0,
    "volume": 3767,
    "contract": "199907"
  },
  {
    "date": "1999-07-17",
    "close": 7418.0,
    "volume": 3694,
    "contract": "199907"
  },
  {
    "date": "1999-07-19",
    "close": 7395.0,
    "volume": 1156,
    "contract": "199907"
  },
  {
    "date": "1999-07-20",
    "close": 7815.0,
    "volume": 1332,
    "contract": "199907"
  },
  {
    "date": "1999-07-21",
    "close": 7790.0,
    "volume": 608,
    "contract": "199907"
  },
  {
    "date": "1999-07-22",
    "close": 7623.0,
    "volume": 2847,
    "contract": "199908"
  },
  {
    "date": "1999-07-23",
    "close": 7749.0,
    "volume": 2902,
    "contract": "199908"
  },
  {
    "date": "1999-07-26",
    "close": 7567.0,
    "volume": 2455,
    "contract": "199908"
  },
  {
    "date": "1999-07-27",
    "close": 7395.0,
    "volume": 3713,
    "contract": "199908"
  },
  {
    "date": "1999-07-28",
    "close": 7479.0,
    "volume": 2685,
    "contract": "199908"
  },
  {
    "date": "1999-07-29",
    "close": 7329.0,
    "volume": 2787,
    "contract": "199908"
  },
  {
    "date": "1999-07-30",
    "close": 7329.0,
    "volume": 3284,
    "contract": "199908"
  },
  {
    "date": "1999-07-31",
    "close": 7268.0,
    "volume": 2716,
    "contract": "199908"
  },
  {
    "date": "1999-08-02",
    "close": 7210.0,
    "volume": 3083,
    "contract": "199908"
  },
  {
    "date": "1999-08-03",
    "close": 7195.0,
    "volume": 4199,
    "contract": "199908"
  },
  {
    "date": "1999-08-04",
    "close": 7095.0,
    "volume": 3077,
    "contract": "199908"
  },
  {
    "date": "1999-08-05",
    "close": 6958.0,
    "volume": 3977,
    "contract": "199908"
  },
  {
    "date": "1999-08-06",
    "close": 6870.0,
    "volume": 3809,
    "contract": "199908"
  },
  {
    "date": "1999-08-07",
    "close": 7035.0,
    "volume": 4337,
    "contract": "199908"
  },
  {
    "date": "1999-08-09",
    "close": 7015.0,
    "volume": 2494,
    "contract": "199908"
  },
  {
    "date": "1999-08-10",
    "close": 7290.0,
    "volume": 4111,
    "contract": "199908"
  },
  {
    "date": "1999-08-11",
    "close": 7230.0,
    "volume": 3604,
    "contract": "199908"
  },
  {
    "date": "1999-08-12",
    "close": 7316.0,
    "volume": 3264,
    "contract": "199908"
  },
  {
    "date": "1999-08-13",
    "close": 7685.0,
    "volume": 3592,
    "contract": "199908"
  },
  {
    "date": "1999-08-16",
    "close": 8195.0,
    "volume": 2938,
    "contract": "199908"
  },
  {
    "date": "1999-08-17",
    "close": 8130.0,
    "volume": 1503,
    "contract": "199908"
  },
  {
    "date": "1999-08-18",
    "close": 8000.0,
    "volume": 695,
    "contract": "199908"
  },
  {
    "date": "1999-08-19",
    "close": 8074.0,
    "volume": 2673,
    "contract": "199909"
  },
  {
    "date": "1999-08-20",
    "close": 8219.0,
    "volume": 3446,
    "contract": "199909"
  },
  {
    "date": "1999-08-21",
    "close": 8261.0,
    "volume": 3329,
    "contract": "199909"
  },
  {
    "date": "1999-08-23",
    "close": 8265.0,
    "volume": 2056,
    "contract": "199909"
  },
  {
    "date": "1999-08-24",
    "close": 8001.0,
    "volume": 3708,
    "contract": "199909"
  },
  {
    "date": "1999-08-25",
    "close": 8230.0,
    "volume": 3643,
    "contract": "199909"
  },
  {
    "date": "1999-08-26",
    "close": 8134.0,
    "volume": 3108,
    "contract": "199909"
  },
  {
    "date": "1999-08-27",
    "close": 8145.0,
    "volume": 2626,
    "contract": "199909"
  },
  {
    "date": "1999-08-30",
    "close": 8190.0,
    "volume": 2748,
    "contract": "199909"
  },
  {
    "date": "1999-08-31",
    "close": 8248.0,
    "volume": 2852,
    "contract": "199909"
  },
  {
    "date": "1999-09-01",
    "close": 8426.0,
    "volume": 4238,
    "contract": "199909"
  },
  {
    "date": "1999-09-02",
    "close": 8352.0,
    "volume": 3228,
    "contract": "199909"
  },
  {
    "date": "1999-09-03",
    "close": 8132.0,
    "volume": 3542,
    "contract": "199909"
  },
  {
    "date": "1999-09-04",
    "close": 8137.0,
    "volume": 3514,
    "contract": "199909"
  },
  {
    "date": "1999-09-06",
    "close": 8215.0,
    "volume": 2251,
    "contract": "199909"
  },
  {
    "date": "1999-09-07",
    "close": 7930.0,
    "volume": 3275,
    "contract": "199909"
  },
  {
    "date": "1999-09-08",
    "close": 7970.0,
    "volume": 3716,
    "contract": "199909"
  },
  {
    "date": "1999-09-09",
    "close": 8010.0,
    "volume": 2531,
    "contract": "199909"
  },
  {
    "date": "1999-09-10",
    "close": 8190.0,
    "volume": 2345,
    "contract": "199909"
  },
  {
    "date": "1999-09-13",
    "close": 8189.0,
    "volume": 1380,
    "contract": "199909"
  },
  {
    "date": "1999-09-14",
    "close": 8119.0,
    "volume": 989,
    "contract": "199909"
  },
  {
    "date": "1999-09-15",
    "close": 7983.0,
    "volume": 1187,
    "contract": "199909"
  },
  {
    "date": "1999-09-16",
    "close": 7975.0,
    "volume": 2503,
    "contract": "199910"
  },
  {
    "date": "1999-09-17",
    "close": 7921.0,
    "volume": 2618,
    "contract": "199910"
  },
  {
    "date": "1999-09-18",
    "close": 8018.0,
    "volume": 2295,
    "contract": "199910"
  },
  {
    "date": "1999-09-20",
    "close": 7987.0,
    "volume": 1569,
    "contract": "199910"
  },
  {
    "date": "1999-09-27",
    "close": 7708.0,
    "volume": 103,
    "contract": "199910"
  },
  {
    "date": "1999-09-28",
    "close": 7439.0,
    "volume": 1005,
    "contract": "199910"
  },
  {
    "date": "1999-09-29",
    "close": 7589.0,
    "volume": 3666,
    "contract": "199910"
  },
  {
    "date": "1999-09-30",
    "close": 7540.0,
    "volume": 2448,
    "contract": "199910"
  },
  {
    "date": "1999-10-01",
    "close": 7648.0,
    "volume": 2507,
    "contract": "199910"
  },
  {
    "date": "1999-10-02",
    "close": 7599.0,
    "volume": 2083,
    "contract": "199910"
  },
  {
    "date": "1999-10-04",
    "close": 7618.0,
    "volume": 1787,
    "contract": "199910"
  },
  {
    "date": "1999-10-05",
    "close": 7510.0,
    "volume": 1889,
    "contract": "199910"
  },
  {
    "date": "1999-10-06",
    "close": 7535.0,
    "volume": 1781,
    "contract": "199910"
  },
  {
    "date": "1999-10-07",
    "close": 7580.0,
    "volume": 1790,
    "contract": "199910"
  },
  {
    "date": "1999-10-08",
    "close": 7520.0,
    "volume": 1178,
    "contract": "199910"
  },
  {
    "date": "1999-10-11",
    "close": 7586.0,
    "volume": 1242,
    "contract": "199910"
  },
  {
    "date": "1999-10-12",
    "close": 7599.0,
    "volume": 2914,
    "contract": "199910"
  },
  {
    "date": "1999-10-13",
    "close": 7828.0,
    "volume": 1723,
    "contract": "199910"
  },
  {
    "date": "1999-10-14",
    "close": 7900.0,
    "volume": 1646,
    "contract": "199910"
  },
  {
    "date": "1999-10-15",
    "close": 7810.0,
    "volume": 1296,
    "contract": "199910"
  },
  {
    "date": "1999-10-16",
    "close": 7812.0,
    "volume": 1191,
    "contract": "199910"
  },
  {
    "date": "1999-10-18",
    "close": 7735.0,
    "volume": 728,
    "contract": "199910"
  },
  {
    "date": "1999-10-19",
    "close": 7690.0,
    "volume": 759,
    "contract": "199910"
  },
  {
    "date": "1999-10-20",
    "close": 7678.0,
    "volume": 841,
    "contract": "199910"
  },
  {
    "date": "1999-10-21",
    "close": 7683.0,
    "volume": 2301,
    "contract": "199911"
  },
  {
    "date": "1999-10-22",
    "close": 7597.0,
    "volume": 3094,
    "contract": "199911"
  },
  {
    "date": "1999-10-25",
    "close": 7688.0,
    "volume": 2024,
    "contract": "199911"
  },
  {
    "date": "1999-10-26",
    "close": 7736.0,
    "volume": 2695,
    "contract": "199911"
  },
  {
    "date": "1999-10-27",
    "close": 7737.0,
    "volume": 1811,
    "contract": "199911"
  },
  {
    "date": "1999-10-28",
    "close": 7727.0,
    "volume": 1150,
    "contract": "199911"
  },
  {
    "date": "1999-10-29",
    "close": 7776.0,
    "volume": 2154,
    "contract": "199911"
  },
  {
    "date": "1999-10-30",
    "close": 7948.0,
    "volume": 3262,
    "contract": "199911"
  },
  {
    "date": "1999-11-01",
    "close": 7911.0,
    "volume": 1356,
    "contract": "199911"
  },
  {
    "date": "1999-11-02",
    "close": 7820.0,
    "volume": 2096,
    "contract": "199911"
  },
  {
    "date": "1999-11-03",
    "close": 7678.0,
    "volume": 2297,
    "contract": "199911"
  },
  {
    "date": "1999-11-04",
    "close": 7565.0,
    "volume": 2733,
    "contract": "199911"
  },
  {
    "date": "1999-11-05",
    "close": 7619.0,
    "volume": 2847,
    "contract": "199911"
  },
  {
    "date": "1999-11-06",
    "close": 7619.0,
    "volume": 3358,
    "contract": "199911"
  },
  {
    "date": "1999-11-08",
    "close": 7441.0,
    "volume": 2993,
    "contract": "199911"
  },
  {
    "date": "1999-11-09",
    "close": 7382.0,
    "volume": 1925,
    "contract": "199911"
  },
  {
    "date": "1999-11-10",
    "close": 7443.0,
    "volume": 2612,
    "contract": "199911"
  },
  {
    "date": "1999-11-11",
    "close": 7575.0,
    "volume": 2172,
    "contract": "199911"
  },
  {
    "date": "1999-11-15",
    "close": 7582.0,
    "volume": 874,
    "contract": "199911"
  },
  {
    "date": "1999-11-16",
    "close": 7629.0,
    "volume": 1176,
    "contract": "199911"
  },
  {
    "date": "1999-11-17",
    "close": 7669.0,
    "volume": 1374,
    "contract": "199911"
  },
  {
    "date": "1999-11-18",
    "close": 7741.0,
    "volume": 2557,
    "contract": "199912"
  },
  {
    "date": "1999-11-19",
    "close": 7800.0,
    "volume": 2221,
    "contract": "199912"
  },
  {
    "date": "1999-11-20",
    "close": 7980.0,
    "volume": 2507,
    "contract": "199912"
  },
  {
    "date": "1999-11-22",
    "close": 8139.0,
    "volume": 2716,
    "contract": "199912"
  },
  {
    "date": "1999-11-23",
    "close": 8130.0,
    "volume": 2358,
    "contract": "199912"
  },
  {
    "date": "1999-11-24",
    "close": 7965.0,
    "volume": 2736,
    "contract": "199912"
  },
  {
    "date": "1999-11-25",
    "close": 8016.0,
    "volume": 2677,
    "contract": "199912"
  },
  {
    "date": "1999-11-26",
    "close": 7700.0,
    "volume": 4559,
    "contract": "199912"
  },
  {
    "date": "1999-11-29",
    "close": 7855.0,
    "volume": 2862,
    "contract": "199912"
  },
  {
    "date": "1999-11-30",
    "close": 7764.0,
    "volume": 2492,
    "contract": "199912"
  },
  {
    "date": "1999-12-01",
    "close": 7820.0,
    "volume": 1408,
    "contract": "199912"
  },
  {
    "date": "1999-12-02",
    "close": 7848.0,
    "volume": 2085,
    "contract": "199912"
  },
  {
    "date": "1999-12-03",
    "close": 7974.0,
    "volume": 2320,
    "contract": "199912"
  },
  {
    "date": "1999-12-04",
    "close": 8022.0,
    "volume": 2012,
    "contract": "199912"
  },
  {
    "date": "1999-12-06",
    "close": 7929.0,
    "volume": 1850,
    "contract": "199912"
  },
  {
    "date": "1999-12-07",
    "close": 7870.0,
    "volume": 1719,
    "contract": "199912"
  },
  {
    "date": "1999-12-08",
    "close": 7840.0,
    "volume": 1352,
    "contract": "199912"
  },
  {
    "date": "1999-12-09",
    "close": 7770.0,
    "volume": 1570,
    "contract": "199912"
  },
  {
    "date": "1999-12-10",
    "close": 7800.0,
    "volume": 1326,
    "contract": "199912"
  },
  {
    "date": "1999-12-13",
    "close": 7950.0,
    "volume": 1247,
    "contract": "199912"
  },
  {
    "date": "1999-12-14",
    "close": 7872.0,
    "volume": 765,
    "contract": "199912"
  },
  {
    "date": "1999-12-15",
    "close": 7883.0,
    "volume": 1011,
    "contract": "199912"
  },
  {
    "date": "1999-12-16",
    "close": 7795.0,
    "volume": 2224,
    "contract": "200001"
  },
  {
    "date": "1999-12-17",
    "close": 7816.0,
    "volume": 1533,
    "contract": "200001"
  },
  {
    "date": "1999-12-18",
    "close": 7860.0,
    "volume": 1496,
    "contract": "200001"
  },
  {
    "date": "1999-12-20",
    "close": 7841.0,
    "volume": 1010,
    "contract": "200001"
  },
  {
    "date": "1999-12-21",
    "close": 7970.0,
    "volume": 1884,
    "contract": "200001"
  },
  {
    "date": "1999-12-22",
    "close": 8020.0,
    "volume": 1763,
    "contract": "200001"
  },
  {
    "date": "1999-12-23",
    "close": 8106.0,
    "volume": 1721,
    "contract": "200001"
  },
  {
    "date": "1999-12-24",
    "close": 8329.0,
    "volume": 2207,
    "contract": "200001"
  },
  {
    "date": "1999-12-27",
    "close": 8560.0,
    "volume": 2234,
    "contract": "200001"
  },
  {
    "date": "1999-12-28",
    "close": 8564.0,
    "volume": 1990,
    "contract": "200001"
  },
  {
    "date": "2000-01-04",
    "close": 8843.0,
    "volume": 2800,
    "contract": "200001"
  },
  {
    "date": "2000-01-05",
    "close": 8810.0,
    "volume": 2854,
    "contract": "200001"
  },
  {
    "date": "2000-01-06",
    "close": 8850.0,
    "volume": 2501,
    "contract": "200001"
  },
  {
    "date": "2000-01-07",
    "close": 8829.0,
    "volume": 2409,
    "contract": "200001"
  },
  {
    "date": "2000-01-10",
    "close": 9200.0,
    "volume": 2638,
    "contract": "200001"
  },
  {
    "date": "2000-01-11",
    "close": 8951.0,
    "volume": 3367,
    "contract": "200001"
  },
  {
    "date": "2000-01-12",
    "close": 9190.0,
    "volume": 2028,
    "contract": "200001"
  },
  {
    "date": "2000-01-13",
    "close": 9115.0,
    "volume": 1796,
    "contract": "200001"
  },
  {
    "date": "2000-01-14",
    "close": 9073.0,
    "volume": 2198,
    "contract": "200001"
  },
  {
    "date": "2000-01-15",
    "close": 9230.0,
    "volume": 1556,
    "contract": "200001"
  },
  {
    "date": "2000-01-17",
    "close": 9300.0,
    "volume": 1264,
    "contract": "200001"
  },
  {
    "date": "2000-01-18",
    "close": 9278.0,
    "volume": 607,
    "contract": "200001"
  },
  {
    "date": "2000-01-19",
    "close": 9185.0,
    "volume": 993,
    "contract": "200001"
  },
  {
    "date": "2000-01-20",
    "close": 9269.0,
    "volume": 2124,
    "contract": "200002"
  },
  {
    "date": "2000-01-21",
    "close": 9350.0,
    "volume": 2278,
    "contract": "200002"
  },
  {
    "date": "2000-01-24",
    "close": 9498.0,
    "volume": 2128,
    "contract": "200002"
  },
  {
    "date": "2000-01-25",
    "close": 9452.0,
    "volume": 1735,
    "contract": "200002"
  },
  {
    "date": "2000-01-26",
    "close": 9722.0,
    "volume": 2952,
    "contract": "200002"
  },
  {
    "date": "2000-01-27",
    "close": 9730.0,
    "volume": 2234,
    "contract": "200002"
  },
  {
    "date": "2000-01-28",
    "close": 9800.0,
    "volume": 1935,
    "contract": "200002"
  },
  {
    "date": "2000-01-29",
    "close": 9759.0,
    "volume": 1907,
    "contract": "200002"
  },
  {
    "date": "2000-01-31",
    "close": 9867.0,
    "volume": 1525,
    "contract": "200002"
  },
  {
    "date": "2000-02-01",
    "close": 10030.0,
    "volume": 2075,
    "contract": "200002"
  },
  {
    "date": "2000-02-09",
    "close": 10149.0,
    "volume": 1838,
    "contract": "200002"
  },
  {
    "date": "2000-02-10",
    "close": 10145.0,
    "volume": 1336,
    "contract": "200002"
  },
  {
    "date": "2000-02-11",
    "close": 10167.0,
    "volume": 1463,
    "contract": "200002"
  },
  {
    "date": "2000-02-14",
    "close": 9980.0,
    "volume": 1107,
    "contract": "200002"
  },
  {
    "date": "2000-02-15",
    "close": 9988.0,
    "volume": 979,
    "contract": "200002"
  },
  {
    "date": "2000-02-16",
    "close": 10090.0,
    "volume": 636,
    "contract": "200002"
  },
  {
    "date": "2000-02-17",
    "close": 10293.0,
    "volume": 2132,
    "contract": "200003"
  },
  {
    "date": "2000-02-18",
    "close": 10160.0,
    "volume": 2899,
    "contract": "200003"
  },
  {
    "date": "2000-02-19",
    "close": 10286.0,
    "volume": 2357,
    "contract": "200003"
  },
  {
    "date": "2000-02-21",
    "close": 10020.0,
    "volume": 2472,
    "contract": "200003"
  },
  {
    "date": "2000-02-22",
    "close": 9875.0,
    "volume": 4247,
    "contract": "200003"
  },
  {
    "date": "2000-02-23",
    "close": 9701.0,
    "volume": 2429,
    "contract": "200003"
  },
  {
    "date": "2000-02-24",
    "close": 9740.0,
    "volume": 2448,
    "contract": "200003"
  },
  {
    "date": "2000-02-25",
    "close": 9602.0,
    "volume": 2380,
    "contract": "200003"
  },
  {
    "date": "2000-02-29",
    "close": 9630.0,
    "volume": 1910,
    "contract": "200003"
  },
  {
    "date": "2000-03-01",
    "close": 9845.0,
    "volume": 2459,
    "contract": "200003"
  },
  {
    "date": "2000-03-02",
    "close": 9693.0,
    "volume": 2159,
    "contract": "200003"
  },
  {
    "date": "2000-03-03",
    "close": 9760.0,
    "volume": 1589,
    "contract": "200003"
  },
  {
    "date": "2000-03-04",
    "close": 9675.0,
    "volume": 1682,
    "contract": "200003"
  },
  {
    "date": "2000-03-06",
    "close": 9525.0,
    "volume": 1956,
    "contract": "200003"
  },
  {
    "date": "2000-03-07",
    "close": 9565.0,
    "volume": 2067,
    "contract": "200003"
  },
  {
    "date": "2000-03-08",
    "close": 9520.0,
    "volume": 1853,
    "contract": "200003"
  },
  {
    "date": "2000-03-09",
    "close": 9687.0,
    "volume": 1936,
    "contract": "200003"
  },
  {
    "date": "2000-03-10",
    "close": 9520.0,
    "volume": 1837,
    "contract": "200003"
  },
  {
    "date": "2000-03-13",
    "close": 8854.0,
    "volume": 1938,
    "contract": "200003"
  },
  {
    "date": "2000-03-14",
    "close": 8848.0,
    "volume": 1870,
    "contract": "200003"
  },
  {
    "date": "2000-03-15",
    "close": 8590.0,
    "volume": 1152,
    "contract": "200003"
  },
  {
    "date": "2000-03-16",
    "close": 8664.0,
    "volume": 3350,
    "contract": "200004"
  },
  {
    "date": "2000-03-17",
    "close": 8564.0,
    "volume": 3625,
    "contract": "200004"
  },
  {
    "date": "2000-03-20",
    "close": 8265.0,
    "volume": 274,
    "contract": "200004"
  },
  {
    "date": "2000-03-21",
    "close": 8843.0,
    "volume": 2840,
    "contract": "200004"
  },
  {
    "date": "2000-03-22",
    "close": 9075.0,
    "volume": 4516,
    "contract": "200004"
  },
  {
    "date": "2000-03-23",
    "close": 9636.0,
    "volume": 4070,
    "contract": "200004"
  },
  {
    "date": "2000-03-24",
    "close": 9545.0,
    "volume": 3047,
    "contract": "200004"
  },
  {
    "date": "2000-03-27",
    "close": 9835.0,
    "volume": 2883,
    "contract": "200004"
  },
  {
    "date": "2000-03-28",
    "close": 9866.0,
    "volume": 2887,
    "contract": "200004"
  },
  {
    "date": "2000-03-29",
    "close": 9848.0,
    "volume": 1948,
    "contract": "200004"
  },
  {
    "date": "2000-03-30",
    "close": 9983.0,
    "volume": 2724,
    "contract": "200004"
  },
  {
    "date": "2000-03-31",
    "close": 9915.0,
    "volume": 2047,
    "contract": "200004"
  },
  {
    "date": "2000-04-01",
    "close": 10149.0,
    "volume": 2487,
    "contract": "200004"
  },
  {
    "date": "2000-04-05",
    "close": 10352.0,
    "volume": 2820,
    "contract": "200004"
  },
  {
    "date": "2000-04-06",
    "close": 10010.0,
    "volume": 3023,
    "contract": "200004"
  },
  {
    "date": "2000-04-07",
    "close": 10079.0,
    "volume": 2387,
    "contract": "200004"
  },
  {
    "date": "2000-04-08",
    "close": 10044.0,
    "volume": 1689,
    "contract": "200004"
  },
  {
    "date": "2000-04-10",
    "close": 10262.0,
    "volume": 2374,
    "contract": "200004"
  },
  {
    "date": "2000-04-11",
    "close": 10181.0,
    "volume": 1692,
    "contract": "200004"
  },
  {
    "date": "2000-04-12",
    "close": 9950.0,
    "volume": 2169,
    "contract": "200004"
  },
  {
    "date": "2000-04-13",
    "close": 9720.0,
    "volume": 2516,
    "contract": "200004"
  },
  {
    "date": "2000-04-14",
    "close": 9318.0,
    "volume": 1467,
    "contract": "200004"
  },
  {
    "date": "2000-04-15",
    "close": 8700.0,
    "volume": 2118,
    "contract": "200004"
  },
  {
    "date": "2000-04-17",
    "close": 9003.0,
    "volume": 1287,
    "contract": "200004"
  },
  {
    "date": "2000-04-18",
    "close": 9302.0,
    "volume": 612,
    "contract": "200004"
  },
  {
    "date": "2000-04-19",
    "close": 9090.0,
    "volume": 502,
    "contract": "200004"
  },
  {
    "date": "2000-04-20",
    "close": 9209.0,
    "volume": 4011,
    "contract": "200005"
  },
  {
    "date": "2000-04-21",
    "close": 9132.0,
    "volume": 3008,
    "contract": "200005"
  },
  {
    "date": "2000-04-24",
    "close": 8816.0,
    "volume": 2759,
    "contract": "200005"
  },
  {
    "date": "2000-04-25",
    "close": 9000.0,
    "volume": 4218,
    "contract": "200005"
  },
  {
    "date": "2000-04-26",
    "close": 8480.0,
    "volume": 4792,
    "contract": "200005"
  },
  {
    "date": "2000-04-27",
    "close": 8629.0,
    "volume": 3742,
    "contract": "200005"
  },
  {
    "date": "2000-04-28",
    "close": 8850.0,
    "volume": 4001,
    "contract": "200005"
  },
  {
    "date": "2000-04-29",
    "close": 8828.0,
    "volume": 3126,
    "contract": "200005"
  },
  {
    "date": "2000-05-02",
    "close": 8684.0,
    "volume": 2907,
    "contract": "200005"
  },
  {
    "date": "2000-05-03",
    "close": 8518.0,
    "volume": 3082,
    "contract": "200005"
  },
  {
    "date": "2000-05-04",
    "close": 8509.0,
    "volume": 4394,
    "contract": "200005"
  },
  {
    "date": "2000-05-05",
    "close": 8800.0,
    "volume": 4091,
    "contract": "200005"
  },
  {
    "date": "2000-05-06",
    "close": 8760.0,
    "volume": 3538,
    "contract": "200005"
  },
  {
    "date": "2000-05-08",
    "close": 8710.0,
    "volume": 3044,
    "contract": "200005"
  },
  {
    "date": "2000-05-09",
    "close": 8758.0,
    "volume": 2838,
    "contract": "200005"
  },
  {
    "date": "2000-05-10",
    "close": 8601.0,
    "volume": 4565,
    "contract": "200005"
  },
  {
    "date": "2000-05-11",
    "close": 8447.0,
    "volume": 3849,
    "contract": "200005"
  },
  {
    "date": "2000-05-12",
    "close": 8600.0,
    "volume": 3028,
    "contract": "200005"
  },
  {
    "date": "2000-05-15",
    "close": 8520.0,
    "volume": 1884,
    "contract": "200005"
  },
  {
    "date": "2000-05-16",
    "close": 8775.0,
    "volume": 1703,
    "contract": "200005"
  },
  {
    "date": "2000-05-17",
    "close": 9090.0,
    "volume": 1477,
    "contract": "200005"
  },
  {
    "date": "2000-05-18",
    "close": 9105.0,
    "volume": 3903,
    "contract": "200006"
  },
  {
    "date": "2000-05-19",
    "close": 9235.0,
    "volume": 3472,
    "contract": "200006"
  },
  {
    "date": "2000-05-20",
    "close": 8842.0,
    "volume": 5085,
    "contract": "200006"
  },
  {
    "date": "2000-05-22",
    "close": 8828.0,
    "volume": 3876,
    "contract": "200006"
  },
  {
    "date": "2000-05-23",
    "close": 8748.0,
    "volume": 4128,
    "contract": "200006"
  },
  {
    "date": "2000-05-24",
    "close": 8577.0,
    "volume": 3393,
    "contract": "200006"
  },
  {
    "date": "2000-05-25",
    "close": 8565.0,
    "volume": 4097,
    "contract": "200006"
  },
  {
    "date": "2000-05-26",
    "close": 8628.0,
    "volume": 4555,
    "contract": "200006"
  },
  {
    "date": "2000-05-29",
    "close": 8636.0,
    "volume": 3209,
    "contract": "200006"
  },
  {
    "date": "2000-05-30",
    "close": 8815.0,
    "volume": 4415,
    "contract": "200006"
  },
  {
    "date": "2000-05-31",
    "close": 8970.0,
    "volume": 3959,
    "contract": "200006"
  },
  {
    "date": "2000-06-01",
    "close": 8915.0,
    "volume": 2801,
    "contract": "200006"
  },
  {
    "date": "2000-06-02",
    "close": 8920.0,
    "volume": 3570,
    "contract": "200006"
  },
  {
    "date": "2000-06-03",
    "close": 9033.0,
    "volume": 3366,
    "contract": "200006"
  },
  {
    "date": "2000-06-05",
    "close": 9041.0,
    "volume": 2513,
    "contract": "200006"
  },
  {
    "date": "2000-06-07",
    "close": 9175.0,
    "volume": 3484,
    "contract": "200006"
  },
  {
    "date": "2000-06-08",
    "close": 9114.0,
    "volume": 2896,
    "contract": "200006"
  },
  {
    "date": "2000-06-09",
    "close": 9088.0,
    "volume": 2565,
    "contract": "200006"
  },
  {
    "date": "2000-06-12",
    "close": 9008.0,
    "volume": 2488,
    "contract": "200006"
  },
  {
    "date": "2000-06-13",
    "close": 8889.0,
    "volume": 3019,
    "contract": "200006"
  },
  {
    "date": "2000-06-14",
    "close": 8965.0,
    "volume": 2335,
    "contract": "200006"
  },
  {
    "date": "2000-06-15",
    "close": 8880.0,
    "volume": 2219,
    "contract": "200006"
  },
  {
    "date": "2000-06-16",
    "close": 8904.0,
    "volume": 1930,
    "contract": "200006"
  },
  {
    "date": "2000-06-17",
    "close": 8849.0,
    "volume": 1674,
    "contract": "200006"
  },
  {
    "date": "2000-06-19",
    "close": 8814.0,
    "volume": 2107,
    "contract": "200006"
  },
  {
    "date": "2000-06-20",
    "close": 8700.0,
    "volume": 1339,
    "contract": "200006"
  },
  {
    "date": "2000-06-21",
    "close": 8670.0,
    "volume": 1552,
    "contract": "200006"
  },
  {
    "date": "2000-06-22",
    "close": 8920.0,
    "volume": 4391,
    "contract": "200007"
  },
  {
    "date": "2000-06-23",
    "close": 8820.0,
    "volume": 2820,
    "contract": "200007"
  },
  {
    "date": "2000-06-26",
    "close": 8660.0,
    "volume": 3392,
    "contract": "200007"
  },
  {
    "date": "2000-06-27",
    "close": 8595.0,
    "volume": 3514,
    "contract": "200007"
  },
  {
    "date": "2000-06-28",
    "close": 8539.0,
    "volume": 5110,
    "contract": "200007"
  },
  {
    "date": "2000-06-29",
    "close": 8190.0,
    "volume": 5039,
    "contract": "200007"
  },
  {
    "date": "2000-06-30",
    "close": 8250.0,
    "volume": 5048,
    "contract": "200007"
  },
  {
    "date": "2000-07-03",
    "close": 8300.0,
    "volume": 4640,
    "contract": "200007"
  },
  {
    "date": "2000-07-04",
    "close": 8066.0,
    "volume": 4511,
    "contract": "200007"
  },
  {
    "date": "2000-07-05",
    "close": 8389.0,
    "volume": 5687,
    "contract": "200007"
  },
  {
    "date": "2000-07-06",
    "close": 8270.0,
    "volume": 3843,
    "contract": "200007"
  },
  {
    "date": "2000-07-07",
    "close": 8181.0,
    "volume": 4163,
    "contract": "200007"
  },
  {
    "date": "2000-07-10",
    "close": 8173.0,
    "volume": 3976,
    "contract": "200007"
  },
  {
    "date": "2000-07-11",
    "close": 8190.0,
    "volume": 4449,
    "contract": "200007"
  },
  {
    "date": "2000-07-12",
    "close": 8120.0,
    "volume": 3832,
    "contract": "200007"
  },
  {
    "date": "2000-07-13",
    "close": 8318.0,
    "volume": 4745,
    "contract": "200007"
  },
  {
    "date": "2000-07-14",
    "close": 8479.0,
    "volume": 4728,
    "contract": "200007"
  },
  {
    "date": "2000-07-15",
    "close": 8490.0,
    "volume": 2891,
    "contract": "200007"
  },
  {
    "date": "2000-07-17",
    "close": 8530.0,
    "volume": 1866,
    "contract": "200007"
  },
  {
    "date": "2000-07-18",
    "close": 8360.0,
    "volume": 1800,
    "contract": "200007"
  },
  {
    "date": "2000-07-19",
    "close": 8425.0,
    "volume": 1214,
    "contract": "200007"
  },
  {
    "date": "2000-07-20",
    "close": 8255.0,
    "volume": 3784,
    "contract": "200008"
  },
  {
    "date": "2000-07-21",
    "close": 8260.0,
    "volume": 4247,
    "contract": "200008"
  },
  {
    "date": "2000-07-24",
    "close": 8158.0,
    "volume": 2678,
    "contract": "200008"
  },
  {
    "date": "2000-07-25",
    "close": 7930.0,
    "volume": 4712,
    "contract": "200008"
  },
  {
    "date": "2000-07-26",
    "close": 7997.0,
    "volume": 4894,
    "contract": "200008"
  },
  {
    "date": "2000-07-27",
    "close": 7998.0,
    "volume": 4846,
    "contract": "200008"
  },
  {
    "date": "2000-07-28",
    "close": 8148.0,
    "volume": 5394,
    "contract": "200008"
  },
  {
    "date": "2000-07-29",
    "close": 8103.0,
    "volume": 4089,
    "contract": "200008"
  },
  {
    "date": "2000-07-31",
    "close": 8072.0,
    "volume": 2734,
    "contract": "200008"
  },
  {
    "date": "2000-08-01",
    "close": 7992.0,
    "volume": 3849,
    "contract": "200008"
  },
  {
    "date": "2000-08-02",
    "close": 7983.0,
    "volume": 3654,
    "contract": "200008"
  },
  {
    "date": "2000-08-03",
    "close": 7915.0,
    "volume": 4271,
    "contract": "200008"
  },
  {
    "date": "2000-08-04",
    "close": 7970.0,
    "volume": 4030,
    "contract": "200008"
  },
  {
    "date": "2000-08-05",
    "close": 7879.0,
    "volume": 3062,
    "contract": "200008"
  },
  {
    "date": "2000-08-07",
    "close": 7805.0,
    "volume": 3235,
    "contract": "200008"
  },
  {
    "date": "2000-08-08",
    "close": 7857.0,
    "volume": 4391,
    "contract": "200008"
  },
  {
    "date": "2000-08-09",
    "close": 8090.0,
    "volume": 5303,
    "contract": "200008"
  },
  {
    "date": "2000-08-10",
    "close": 8067.0,
    "volume": 3874,
    "contract": "200008"
  },
  {
    "date": "2000-08-11",
    "close": 8000.0,
    "volume": 3256,
    "contract": "200008"
  },
  {
    "date": "2000-08-14",
    "close": 7881.0,
    "volume": 2542,
    "contract": "200008"
  },
  {
    "date": "2000-08-15",
    "close": 7900.0,
    "volume": 1869,
    "contract": "200008"
  },
  {
    "date": "2000-08-16",
    "close": 8020.0,
    "volume": 1960,
    "contract": "200008"
  },
  {
    "date": "2000-08-17",
    "close": 8215.0,
    "volume": 4998,
    "contract": "200009"
  },
  {
    "date": "2000-08-18",
    "close": 8183.0,
    "volume": 4574,
    "contract": "200009"
  },
  {
    "date": "2000-08-19",
    "close": 8281.0,
    "volume": 3951,
    "contract": "200009"
  },
  {
    "date": "2000-08-21",
    "close": 8275.0,
    "volume": 3623,
    "contract": "200009"
  },
  {
    "date": "2000-08-22",
    "close": 8180.0,
    "volume": 3670,
    "contract": "200009"
  },
  {
    "date": "2000-08-24",
    "close": 8190.0,
    "volume": 3705,
    "contract": "200009"
  },
  {
    "date": "2000-08-25",
    "close": 8117.0,
    "volume": 3772,
    "contract": "200009"
  },
  {
    "date": "2000-08-28",
    "close": 7926.0,
    "volume": 3278,
    "contract": "200009"
  },
  {
    "date": "2000-08-29",
    "close": 7913.0,
    "volume": 5160,
    "contract": "200009"
  },
  {
    "date": "2000-08-30",
    "close": 7600.0,
    "volume": 5629,
    "contract": "200009"
  },
  {
    "date": "2000-08-31",
    "close": 7660.0,
    "volume": 5611,
    "contract": "200009"
  },
  {
    "date": "2000-09-01",
    "close": 7475.0,
    "volume": 5272,
    "contract": "200009"
  },
  {
    "date": "2000-09-02",
    "close": 7750.0,
    "volume": 5570,
    "contract": "200009"
  },
  {
    "date": "2000-09-04",
    "close": 7825.0,
    "volume": 4864,
    "contract": "200009"
  },
  {
    "date": "2000-09-05",
    "close": 7800.0,
    "volume": 3907,
    "contract": "200009"
  },
  {
    "date": "2000-09-06",
    "close": 7630.0,
    "volume": 4168,
    "contract": "200009"
  },
  {
    "date": "2000-09-07",
    "close": 7515.0,
    "volume": 4579,
    "contract": "200009"
  },
  {
    "date": "2000-09-08",
    "close": 7483.0,
    "volume": 4077,
    "contract": "200009"
  },
  {
    "date": "2000-09-11",
    "close": 7425.0,
    "volume": 3135,
    "contract": "200009"
  },
  {
    "date": "2000-09-13",
    "close": 7465.0,
    "volume": 5137,
    "contract": "200009"
  },
  {
    "date": "2000-09-14",
    "close": 7181.0,
    "volume": 4698,
    "contract": "200009"
  },
  {
    "date": "2000-09-15",
    "close": 7230.0,
    "volume": 6579,
    "contract": "200009"
  },
  {
    "date": "2000-09-16",
    "close": 7096.0,
    "volume": 4888,
    "contract": "200009"
  },
  {
    "date": "2000-09-18",
    "close": 6955.0,
    "volume": 2627,
    "contract": "200009"
  },
  {
    "date": "2000-09-19",
    "close": 6779.0,
    "volume": 2694,
    "contract": "200009"
  },
  {
    "date": "2000-09-20",
    "close": 6890.0,
    "volume": 1951,
    "contract": "200009"
  },
  {
    "date": "2000-09-21",
    "close": 6951.0,
    "volume": 6408,
    "contract": "200010"
  },
  {
    "date": "2000-09-22",
    "close": 6540.0,
    "volume": 6854,
    "contract": "200010"
  },
  {
    "date": "2000-09-25",
    "close": 6684.0,
    "volume": 5780,
    "contract": "200010"
  },
  {
    "date": "2000-09-26",
    "close": 6831.0,
    "volume": 7464,
    "contract": "200010"
  },
  {
    "date": "2000-09-27",
    "close": 6798.0,
    "volume": 6807,
    "contract": "200010"
  },
  {
    "date": "2000-09-28",
    "close": 6639.0,
    "volume": 6257,
    "contract": "200010"
  },
  {
    "date": "2000-09-29",
    "close": 6500.0,
    "volume": 6482,
    "contract": "200010"
  },
  {
    "date": "2000-09-30",
    "close": 6250.0,
    "volume": 6632,
    "contract": "200010"
  },
  {
    "date": "2000-10-02",
    "close": 6149.0,
    "volume": 5963,
    "contract": "200010"
  },
  {
    "date": "2000-10-03",
    "close": 6262.0,
    "volume": 7243,
    "contract": "200010"
  },
  {
    "date": "2000-10-04",
    "close": 6043.0,
    "volume": 839,
    "contract": "200010"
  },
  {
    "date": "2000-10-05",
    "close": 6105.0,
    "volume": 5727,
    "contract": "200010"
  },
  {
    "date": "2000-10-06",
    "close": 6509.0,
    "volume": 7781,
    "contract": "200010"
  },
  {
    "date": "2000-10-07",
    "close": 6430.0,
    "volume": 6343,
    "contract": "200010"
  },
  {
    "date": "2000-10-09",
    "close": 6205.0,
    "volume": 5777,
    "contract": "200010"
  },
  {
    "date": "2000-10-11",
    "close": 5988.0,
    "volume": 1488,
    "contract": "200010"
  },
  {
    "date": "2000-10-12",
    "close": 5715.0,
    "volume": 9062,
    "contract": "200010"
  },
  {
    "date": "2000-10-13",
    "close": 5898.0,
    "volume": 6578,
    "contract": "200010"
  },
  {
    "date": "2000-10-16",
    "close": 5486.0,
    "volume": 4687,
    "contract": "200010"
  },
  {
    "date": "2000-10-17",
    "close": 5728.0,
    "volume": 3094,
    "contract": "200010"
  },
  {
    "date": "2000-10-18",
    "close": 5328.0,
    "volume": 1633,
    "contract": "200010"
  },
  {
    "date": "2000-10-19",
    "close": 5199.0,
    "volume": 9086,
    "contract": "200011"
  },
  {
    "date": "2000-10-20",
    "close": 5562.0,
    "volume": 6484,
    "contract": "200011"
  },
  {
    "date": "2000-10-21",
    "close": 5660.0,
    "volume": 9111,
    "contract": "200011"
  },
  {
    "date": "2000-10-23",
    "close": 5670.0,
    "volume": 8971,
    "contract": "200011"
  },
  {
    "date": "2000-10-24",
    "close": 5920.0,
    "volume": 10886,
    "contract": "200011"
  },
  {
    "date": "2000-10-25",
    "close": 5972.0,
    "volume": 7669,
    "contract": "200011"
  },
  {
    "date": "2000-10-26",
    "close": 5875.0,
    "volume": 6700,
    "contract": "200011"
  },
  {
    "date": "2000-10-27",
    "close": 5700.0,
    "volume": 8535,
    "contract": "200011"
  },
  {
    "date": "2000-10-30",
    "close": 5600.0,
    "volume": 6715,
    "contract": "200011"
  },
  {
    "date": "2000-10-31",
    "close": 5555.0,
    "volume": 9419,
    "contract": "200011"
  },
  {
    "date": "2000-11-01",
    "close": 5460.0,
    "volume": 6892,
    "contract": "200011"
  },
  {
    "date": "2000-11-02",
    "close": 5775.0,
    "volume": 8871,
    "contract": "200011"
  },
  {
    "date": "2000-11-03",
    "close": 5895.0,
    "volume": 8650,
    "contract": "200011"
  },
  {
    "date": "2000-11-04",
    "close": 5690.0,
    "volume": 7629,
    "contract": "200011"
  },
  {
    "date": "2000-11-06",
    "close": 5720.0,
    "volume": 6951,
    "contract": "200011"
  },
  {
    "date": "2000-11-07",
    "close": 5960.0,
    "volume": 8310,
    "contract": "200011"
  },
  {
    "date": "2000-11-08",
    "close": 6122.0,
    "volume": 10561,
    "contract": "200011"
  },
  {
    "date": "2000-11-09",
    "close": 6200.0,
    "volume": 11481,
    "contract": "200011"
  },
  {
    "date": "2000-11-10",
    "close": 6210.0,
    "volume": 7020,
    "contract": "200011"
  },
  {
    "date": "2000-11-13",
    "close": 5855.0,
    "volume": 5988,
    "contract": "200011"
  },
  {
    "date": "2000-11-14",
    "close": 5895.0,
    "volume": 2578,
    "contract": "200011"
  },
  {
    "date": "2000-11-15",
    "close": 5830.0,
    "volume": 3272,
    "contract": "200011"
  },
  {
    "date": "2000-11-16",
    "close": 5374.0,
    "volume": 7263,
    "contract": "200012"
  },
  {
    "date": "2000-11-17",
    "close": 5330.0,
    "volume": 9578,
    "contract": "200012"
  },
  {
    "date": "2000-11-18",
    "close": 5130.0,
    "volume": 7375,
    "contract": "200012"
  },
  {
    "date": "2000-11-20",
    "close": 4771.0,
    "volume": 7002,
    "contract": "200012"
  },
  {
    "date": "2000-11-21",
    "close": 5104.0,
    "volume": 9702,
    "contract": "200012"
  },
  {
    "date": "2000-11-22",
    "close": 5039.0,
    "volume": 12896,
    "contract": "200012"
  },
  {
    "date": "2000-11-23",
    "close": 5224.0,
    "volume": 9434,
    "contract": "200012"
  },
  {
    "date": "2000-11-24",
    "close": 5510.0,
    "volume": 11318,
    "contract": "200012"
  },
  {
    "date": "2000-11-27",
    "close": 5480.0,
    "volume": 9851,
    "contract": "200012"
  },
  {
    "date": "2000-11-28",
    "close": 5305.0,
    "volume": 6808,
    "contract": "200012"
  },
  {
    "date": "2000-11-29",
    "close": 5338.0,
    "volume": 10183,
    "contract": "200012"
  },
  {
    "date": "2000-11-30",
    "close": 5191.0,
    "volume": 9217,
    "contract": "200012"
  },
  {
    "date": "2000-12-01",
    "close": 5450.0,
    "volume": 10597,
    "contract": "200012"
  },
  {
    "date": "2000-12-02",
    "close": 5271.0,
    "volume": 9165,
    "contract": "200012"
  },
  {
    "date": "2000-12-04",
    "close": 5225.0,
    "volume": 7515,
    "contract": "200012"
  },
  {
    "date": "2000-12-05",
    "close": 5259.0,
    "volume": 11687,
    "contract": "200012"
  },
  {
    "date": "2000-12-06",
    "close": 5175.0,
    "volume": 11206,
    "contract": "200012"
  },
  {
    "date": "2000-12-07",
    "close": 5245.0,
    "volume": 9257,
    "contract": "200012"
  },
  {
    "date": "2000-12-08",
    "close": 5310.0,
    "volume": 9282,
    "contract": "200012"
  },
  {
    "date": "2000-12-11",
    "close": 5330.0,
    "volume": 6389,
    "contract": "200012"
  },
  {
    "date": "2000-12-12",
    "close": 5390.0,
    "volume": 8519,
    "contract": "200012"
  },
  {
    "date": "2000-12-13",
    "close": 5430.0,
    "volume": 6673,
    "contract": "200012"
  },
  {
    "date": "2000-12-14",
    "close": 5325.0,
    "volume": 6133,
    "contract": "200012"
  },
  {
    "date": "2000-12-15",
    "close": 5201.0,
    "volume": 5532,
    "contract": "200012"
  },
  {
    "date": "2000-12-16",
    "close": 5136.0,
    "volume": 4951,
    "contract": "200012"
  },
  {
    "date": "2000-12-18",
    "close": 5098.0,
    "volume": 3548,
    "contract": "200012"
  },
  {
    "date": "2000-12-19",
    "close": 5050.0,
    "volume": 2737,
    "contract": "200012"
  },
  {
    "date": "2000-12-20",
    "close": 4883.0,
    "volume": 1954,
    "contract": "200012"
  },
  {
    "date": "2000-12-21",
    "close": 4687.0,
    "volume": 4357,
    "contract": "200101"
  },
  {
    "date": "2000-12-22",
    "close": 4857.0,
    "volume": 10453,
    "contract": "200101"
  },
  {
    "date": "2000-12-26",
    "close": 4688.0,
    "volume": 7223,
    "contract": "200101"
  },
  {
    "date": "2000-12-27",
    "close": 4565.0,
    "volume": 6420,
    "contract": "200101"
  },
  {
    "date": "2000-12-28",
    "close": 4867.0,
    "volume": 11954,
    "contract": "200101"
  },
  {
    "date": "2000-12-29",
    "close": 4707.0,
    "volume": 9409,
    "contract": "200101"
  },
  {
    "date": "2000-12-30",
    "close": 4770.0,
    "volume": 10126,
    "contract": "200101"
  },
  {
    "date": "2001-01-02",
    "close": 4892.0,
    "volume": 14824,
    "contract": "200101"
  },
  {
    "date": "2001-01-03",
    "close": 4870.0,
    "volume": 11137,
    "contract": "200101"
  },
  {
    "date": "2001-01-04",
    "close": 5121.0,
    "volume": 11684,
    "contract": "200101"
  },
  {
    "date": "2001-01-05",
    "close": 5340.0,
    "volume": 12317,
    "contract": "200101"
  },
  {
    "date": "2001-01-08",
    "close": 5196.0,
    "volume": 12391,
    "contract": "200101"
  },
  {
    "date": "2001-01-09",
    "close": 5400.0,
    "volume": 14564,
    "contract": "200101"
  },
  {
    "date": "2001-01-10",
    "close": 5408.0,
    "volume": 12587,
    "contract": "200101"
  },
  {
    "date": "2001-01-11",
    "close": 5340.0,
    "volume": 12990,
    "contract": "200101"
  },
  {
    "date": "2001-01-12",
    "close": 5378.0,
    "volume": 9240,
    "contract": "200101"
  },
  {
    "date": "2001-01-15",
    "close": 5407.0,
    "volume": 6109,
    "contract": "200101"
  },
  {
    "date": "2001-01-16",
    "close": 5746.0,
    "volume": 6858,
    "contract": "200101"
  },
  {
    "date": "2001-01-17",
    "close": 5802.0,
    "volume": 2909,
    "contract": "200101"
  },
  {
    "date": "2001-01-18",
    "close": 5949.0,
    "volume": 11801,
    "contract": "200102"
  },
  {
    "date": "2001-01-29",
    "close": 5658.0,
    "volume": 8619,
    "contract": "200102"
  },
  {
    "date": "2001-01-30",
    "close": 5819.0,
    "volume": 12512,
    "contract": "200102"
  },
  {
    "date": "2001-01-31",
    "close": 5951.0,
    "volume": 11771,
    "contract": "200102"
  },
  {
    "date": "2001-02-01",
    "close": 5900.0,
    "volume": 10269,
    "contract": "200102"
  },
  {
    "date": "2001-02-02",
    "close": 6019.0,
    "volume": 10699,
    "contract": "200102"
  },
  {
    "date": "2001-02-05",
    "close": 5911.0,
    "volume": 8344,
    "contract": "200102"
  },
  {
    "date": "2001-02-06",
    "close": 5837.0,
    "volume": 12783,
    "contract": "200102"
  },
  {
    "date": "2001-02-07",
    "close": 5683.0,
    "volume": 8696,
    "contract": "200102"
  },
  {
    "date": "2001-02-08",
    "close": 5776.0,
    "volume": 9623,
    "contract": "200102"
  },
  {
    "date": "2001-02-09",
    "close": 5755.0,
    "volume": 10982,
    "contract": "200102"
  },
  {
    "date": "2001-02-12",
    "close": 5820.0,
    "volume": 8648,
    "contract": "200102"
  },
  {
    "date": "2001-02-13",
    "close": 6040.0,
    "volume": 9951,
    "contract": "200102"
  },
  {
    "date": "2001-02-14",
    "close": 5840.0,
    "volume": 10090,
    "contract": "200102"
  },
  {
    "date": "2001-02-15",
    "close": 6095.0,
    "volume": 12299,
    "contract": "200102"
  },
  {
    "date": "2001-02-16",
    "close": 6025.0,
    "volume": 11266,
    "contract": "200102"
  },
  {
    "date": "2001-02-19",
    "close": 5943.0,
    "volume": 5479,
    "contract": "200102"
  },
  {
    "date": "2001-02-20",
    "close": 5956.0,
    "volume": 2906,
    "contract": "200102"
  },
  {
    "date": "2001-02-21",
    "close": 5981.0,
    "volume": 1913,
    "contract": "200102"
  },
  {
    "date": "2001-02-22",
    "close": 5769.0,
    "volume": 10047,
    "contract": "200103"
  },
  {
    "date": "2001-02-23",
    "close": 5746.0,
    "volume": 7119,
    "contract": "200103"
  },
  {
    "date": "2001-02-26",
    "close": 5760.0,
    "volume": 4901,
    "contract": "200103"
  },
  {
    "date": "2001-02-27",
    "close": 5665.0,
    "volume": 7503,
    "contract": "200103"
  },
  {
    "date": "2001-03-01",
    "close": 5536.0,
    "volume": 6112,
    "contract": "200103"
  },
  {
    "date": "2001-03-02",
    "close": 5505.0,
    "volume": 6384,
    "contract": "200103"
  },
  {
    "date": "2001-03-05",
    "close": 5619.0,
    "volume": 6094,
    "contract": "200103"
  },
  {
    "date": "2001-03-06",
    "close": 5632.0,
    "volume": 9225,
    "contract": "200103"
  },
  {
    "date": "2001-03-07",
    "close": 5733.0,
    "volume": 8713,
    "contract": "200103"
  },
  {
    "date": "2001-03-08",
    "close": 5710.0,
    "volume": 5521,
    "contract": "200103"
  },
  {
    "date": "2001-03-09",
    "close": 5630.0,
    "volume": 5131,
    "contract": "200103"
  },
  {
    "date": "2001-03-12",
    "close": 5535.0,
    "volume": 4661,
    "contract": "200103"
  },
  {
    "date": "2001-03-13",
    "close": 5631.0,
    "volume": 8597,
    "contract": "200103"
  },
  {
    "date": "2001-03-14",
    "close": 5651.0,
    "volume": 5461,
    "contract": "200103"
  },
  {
    "date": "2001-03-15",
    "close": 5780.0,
    "volume": 8840,
    "contract": "200103"
  },
  {
    "date": "2001-03-16",
    "close": 5760.0,
    "volume": 5089,
    "contract": "200103"
  },
  {
    "date": "2001-03-19",
    "close": 5640.0,
    "volume": 4032,
    "contract": "200103"
  },
  {
    "date": "2001-03-20",
    "close": 5675.0,
    "volume": 2164,
    "contract": "200103"
  },
  {
    "date": "2001-03-21",
    "close": 5632.0,
    "volume": 1913,
    "contract": "200103"
  },
  {
    "date": "2001-03-22",
    "close": 5750.0,
    "volume": 8533,
    "contract": "200104"
  },
  {
    "date": "2001-03-23",
    "close": 5813.0,
    "volume": 7092,
    "contract": "200104"
  },
  {
    "date": "2001-03-26",
    "close": 5899.0,
    "volume": 7244,
    "contract": "200104"
  },
  {
    "date": "2001-03-27",
    "close": 5868.0,
    "volume": 7309,
    "contract": "200104"
  },
  {
    "date": "2001-03-28",
    "close": 5830.0,
    "volume": 5935,
    "contract": "200104"
  },
  {
    "date": "2001-03-29",
    "close": 5870.0,
    "volume": 5366,
    "contract": "200104"
  },
  {
    "date": "2001-03-30",
    "close": 5795.0,
    "volume": 5774,
    "contract": "200104"
  },
  {
    "date": "2001-04-02",
    "close": 5621.0,
    "volume": 5925,
    "contract": "200104"
  },
  {
    "date": "2001-04-03",
    "close": 5470.0,
    "volume": 7816,
    "contract": "200104"
  },
  {
    "date": "2001-04-04",
    "close": 5469.0,
    "volume": 7103,
    "contract": "200104"
  },
  {
    "date": "2001-04-06",
    "close": 5530.0,
    "volume": 6445,
    "contract": "200104"
  },
  {
    "date": "2001-04-09",
    "close": 5419.0,
    "volume": 4960,
    "contract": "200104"
  },
  {
    "date": "2001-04-10",
    "close": 5321.0,
    "volume": 8005,
    "contract": "200104"
  },
  {
    "date": "2001-04-11",
    "close": 5495.0,
    "volume": 11170,
    "contract": "200104"
  },
  {
    "date": "2001-04-12",
    "close": 5520.0,
    "volume": 6825,
    "contract": "200104"
  },
  {
    "date": "2001-04-13",
    "close": 5461.0,
    "volume": 5827,
    "contract": "200104"
  },
  {
    "date": "2001-04-16",
    "close": 5423.0,
    "volume": 3169,
    "contract": "200104"
  },
  {
    "date": "2001-04-17",
    "close": 5440.0,
    "volume": 3150,
    "contract": "200104"
  },
  {
    "date": "2001-04-18",
    "close": 5527.0,
    "volume": 2374,
    "contract": "200104"
  },
  {
    "date": "2001-04-19",
    "close": 5628.0,
    "volume": 8593,
    "contract": "200105"
  },
  {
    "date": "2001-04-20",
    "close": 5588.0,
    "volume": 5301,
    "contract": "200105"
  },
  {
    "date": "2001-04-23",
    "close": 5644.0,
    "volume": 4994,
    "contract": "200105"
  },
  {
    "date": "2001-04-24",
    "close": 5621.0,
    "volume": 6945,
    "contract": "200105"
  },
  {
    "date": "2001-04-25",
    "close": 5525.0,
    "volume": 7221,
    "contract": "200105"
  },
  {
    "date": "2001-04-26",
    "close": 5560.0,
    "volume": 7604,
    "contract": "200105"
  },
  {
    "date": "2001-04-27",
    "close": 5439.0,
    "volume": 6664,
    "contract": "200105"
  },
  {
    "date": "2001-04-30",
    "close": 5430.0,
    "volume": 6616,
    "contract": "200105"
  },
  {
    "date": "2001-05-02",
    "close": 5349.0,
    "volume": 8831,
    "contract": "200105"
  },
  {
    "date": "2001-05-03",
    "close": 5431.0,
    "volume": 7757,
    "contract": "200105"
  },
  {
    "date": "2001-05-04",
    "close": 5227.0,
    "volume": 8663,
    "contract": "200105"
  },
  {
    "date": "2001-05-07",
    "close": 5268.0,
    "volume": 9984,
    "contract": "200105"
  },
  {
    "date": "2001-05-08",
    "close": 5229.0,
    "volume": 9282,
    "contract": "200105"
  },
  {
    "date": "2001-05-09",
    "close": 5223.0,
    "volume": 8393,
    "contract": "200105"
  },
  {
    "date": "2001-05-10",
    "close": 5162.0,
    "volume": 5719,
    "contract": "200105"
  },
  {
    "date": "2001-05-11",
    "close": 5240.0,
    "volume": 10167,
    "contract": "200105"
  },
  {
    "date": "2001-05-14",
    "close": 5205.0,
    "volume": 4409,
    "contract": "200105"
  },
  {
    "date": "2001-05-15",
    "close": 5185.0,
    "volume": 2832,
    "contract": "200105"
  },
  {
    "date": "2001-05-16",
    "close": 5080.0,
    "volume": 3977,
    "contract": "200105"
  },
  {
    "date": "2001-05-17",
    "close": 5150.0,
    "volume": 8972,
    "contract": "200106"
  },
  {
    "date": "2001-05-18",
    "close": 5089.0,
    "volume": 8860,
    "contract": "200106"
  },
  {
    "date": "2001-05-21",
    "close": 4982.0,
    "volume": 8173,
    "contract": "200106"
  },
  {
    "date": "2001-05-22",
    "close": 4993.0,
    "volume": 8301,
    "contract": "200106"
  },
  {
    "date": "2001-05-23",
    "close": 5225.0,
    "volume": 13619,
    "contract": "200106"
  },
  {
    "date": "2001-05-24",
    "close": 5223.0,
    "volume": 7561,
    "contract": "200106"
  },
  {
    "date": "2001-05-25",
    "close": 5182.0,
    "volume": 5605,
    "contract": "200106"
  },
  {
    "date": "2001-05-28",
    "close": 5110.0,
    "volume": 6652,
    "contract": "200106"
  },
  {
    "date": "2001-05-29",
    "close": 5112.0,
    "volume": 9207,
    "contract": "200106"
  },
  {
    "date": "2001-05-30",
    "close": 5102.0,
    "volume": 6981,
    "contract": "200106"
  },
  {
    "date": "2001-05-31",
    "close": 5085.0,
    "volume": 6268,
    "contract": "200106"
  },
  {
    "date": "2001-06-01",
    "close": 5031.0,
    "volume": 7559,
    "contract": "200106"
  },
  {
    "date": "2001-06-04",
    "close": 5030.0,
    "volume": 4319,
    "contract": "200106"
  },
  {
    "date": "2001-06-05",
    "close": 5094.0,
    "volume": 6625,
    "contract": "200106"
  },
  {
    "date": "2001-06-06",
    "close": 5194.0,
    "volume": 8866,
    "contract": "200106"
  },
  {
    "date": "2001-06-07",
    "close": 5155.0,
    "volume": 5343,
    "contract": "200106"
  },
  {
    "date": "2001-06-08",
    "close": 5240.0,
    "volume": 8605,
    "contract": "200106"
  },
  {
    "date": "2001-06-11",
    "close": 5289.0,
    "volume": 5595,
    "contract": "200106"
  },
  {
    "date": "2001-06-12",
    "close": 5245.0,
    "volume": 6312,
    "contract": "200106"
  },
  {
    "date": "2001-06-13",
    "close": 5193.0,
    "volume": 8148,
    "contract": "200106"
  },
  {
    "date": "2001-06-14",
    "close": 5140.0,
    "volume": 6542,
    "contract": "200106"
  },
  {
    "date": "2001-06-15",
    "close": 5149.0,
    "volume": 4086,
    "contract": "200106"
  },
  {
    "date": "2001-06-18",
    "close": 5088.0,
    "volume": 3352,
    "contract": "200106"
  },
  {
    "date": "2001-06-19",
    "close": 5082.0,
    "volume": 2393,
    "contract": "200106"
  },
  {
    "date": "2001-06-20",
    "close": 5036.0,
    "volume": 3533,
    "contract": "200106"
  },
  {
    "date": "2001-06-21",
    "close": 4990.0,
    "volume": 7865,
    "contract": "200107"
  },
  {
    "date": "2001-06-22",
    "close": 4965.0,
    "volume": 5636,
    "contract": "200107"
  },
  {
    "date": "2001-06-26",
    "close": 4834.0,
    "volume": 5601,
    "contract": "200107"
  },
  {
    "date": "2001-06-27",
    "close": 4890.0,
    "volume": 7552,
    "contract": "200107"
  },
  {
    "date": "2001-06-28",
    "close": 4839.0,
    "volume": 6273,
    "contract": "200107"
  },
  {
    "date": "2001-06-29",
    "close": 4891.0,
    "volume": 7092,
    "contract": "200107"
  },
  {
    "date": "2001-07-02",
    "close": 4935.0,
    "volume": 8089,
    "contract": "200107"
  },
  {
    "date": "2001-07-03",
    "close": 4845.0,
    "volume": 7356,
    "contract": "200107"
  },
  {
    "date": "2001-07-04",
    "close": 4770.0,
    "volume": 6614,
    "contract": "200107"
  },
  {
    "date": "2001-07-05",
    "close": 4743.0,
    "volume": 6802,
    "contract": "200107"
  },
  {
    "date": "2001-07-06",
    "close": 4766.0,
    "volume": 8329,
    "contract": "200107"
  },
  {
    "date": "2001-07-09",
    "close": 4721.0,
    "volume": 5954,
    "contract": "200107"
  },
  {
    "date": "2001-07-10",
    "close": 4668.0,
    "volume": 6315,
    "contract": "200107"
  },
  {
    "date": "2001-07-11",
    "close": 4577.0,
    "volume": 6365,
    "contract": "200107"
  },
  {
    "date": "2001-07-12",
    "close": 4679.0,
    "volume": 7551,
    "contract": "200107"
  },
  {
    "date": "2001-07-13",
    "close": 4490.0,
    "volume": 10719,
    "contract": "200107"
  },
  {
    "date": "2001-07-16",
    "close": 4394.0,
    "volume": 6252,
    "contract": "200107"
  },
  {
    "date": "2001-07-17",
    "close": 4353.0,
    "volume": 2901,
    "contract": "200107"
  },
  {
    "date": "2001-07-18",
    "close": 4176.0,
    "volume": 2970,
    "contract": "200107"
  },
  {
    "date": "2001-07-19",
    "close": 4175.0,
    "volume": 16640,
    "contract": "200108"
  },
  {
    "date": "2001-07-20",
    "close": 4160.0,
    "volume": 12515,
    "contract": "200108"
  },
  {
    "date": "2001-07-23",
    "close": 4118.0,
    "volume": 9226,
    "contract": "200108"
  },
  {
    "date": "2001-07-24",
    "close": 4062.0,
    "volume": 9491,
    "contract": "200108"
  },
  {
    "date": "2001-07-25",
    "close": 4138.0,
    "volume": 10670,
    "contract": "200108"
  },
  {
    "date": "2001-07-26",
    "close": 4255.0,
    "volume": 15667,
    "contract": "200108"
  },
  {
    "date": "2001-07-27",
    "close": 4242.0,
    "volume": 13902,
    "contract": "200108"
  },
  {
    "date": "2001-07-31",
    "close": 4291.0,
    "volume": 8451,
    "contract": "200108"
  },
  {
    "date": "2001-08-01",
    "close": 4267.0,
    "volume": 9995,
    "contract": "200108"
  },
  {
    "date": "2001-08-02",
    "close": 4455.0,
    "volume": 15925,
    "contract": "200108"
  },
  {
    "date": "2001-08-03",
    "close": 4495.0,
    "volume": 10484,
    "contract": "200108"
  },
  {
    "date": "2001-08-06",
    "close": 4420.0,
    "volume": 7225,
    "contract": "200108"
  },
  {
    "date": "2001-08-07",
    "close": 4395.0,
    "volume": 11081,
    "contract": "200108"
  },
  {
    "date": "2001-08-08",
    "close": 4516.0,
    "volume": 15466,
    "contract": "200108"
  },
  {
    "date": "2001-08-09",
    "close": 4405.0,
    "volume": 13186,
    "contract": "200108"
  },
  {
    "date": "2001-08-10",
    "close": 4469.0,
    "volume": 13585,
    "contract": "200108"
  },
  {
    "date": "2001-08-13",
    "close": 4490.0,
    "volume": 6211,
    "contract": "200108"
  },
  {
    "date": "2001-08-14",
    "close": 4619.0,
    "volume": 4329,
    "contract": "200108"
  },
  {
    "date": "2001-08-15",
    "close": 4620.0,
    "volume": 3633,
    "contract": "200108"
  },
  {
    "date": "2001-08-16",
    "close": 4649.0,
    "volume": 11838,
    "contract": "200109"
  },
  {
    "date": "2001-08-17",
    "close": 4630.0,
    "volume": 10522,
    "contract": "200109"
  },
  {
    "date": "2001-08-20",
    "close": 4542.0,
    "volume": 9508,
    "contract": "200109"
  },
  {
    "date": "2001-08-21",
    "close": 4566.0,
    "volume": 10098,
    "contract": "200109"
  },
  {
    "date": "2001-08-22",
    "close": 4460.0,
    "volume": 12233,
    "contract": "200109"
  },
  {
    "date": "2001-08-23",
    "close": 4468.0,
    "volume": 11043,
    "contract": "200109"
  },
  {
    "date": "2001-08-24",
    "close": 4303.0,
    "volume": 12146,
    "contract": "200109"
  },
  {
    "date": "2001-08-27",
    "close": 4341.0,
    "volume": 11706,
    "contract": "200109"
  },
  {
    "date": "2001-08-28",
    "close": 4311.0,
    "volume": 10190,
    "contract": "200109"
  },
  {
    "date": "2001-08-29",
    "close": 4485.0,
    "volume": 16524,
    "contract": "200109"
  },
  {
    "date": "2001-08-30",
    "close": 4457.0,
    "volume": 12555,
    "contract": "200109"
  },
  {
    "date": "2001-08-31",
    "close": 4442.0,
    "volume": 11832,
    "contract": "200109"
  },
  {
    "date": "2001-09-03",
    "close": 4378.0,
    "volume": 9974,
    "contract": "200109"
  },
  {
    "date": "2001-09-04",
    "close": 4479.0,
    "volume": 13366,
    "contract": "200109"
  },
  {
    "date": "2001-09-05",
    "close": 4376.0,
    "volume": 12011,
    "contract": "200109"
  },
  {
    "date": "2001-09-06",
    "close": 4330.0,
    "volume": 11239,
    "contract": "200109"
  },
  {
    "date": "2001-09-07",
    "close": 4284.0,
    "volume": 9213,
    "contract": "200109"
  },
  {
    "date": "2001-09-10",
    "close": 4280.0,
    "volume": 9007,
    "contract": "200109"
  },
  {
    "date": "2001-09-11",
    "close": 4152.0,
    "volume": 12075,
    "contract": "200109"
  },
  {
    "date": "2001-09-13",
    "close": 3862.0,
    "volume": 8221,
    "contract": "200109"
  },
  {
    "date": "2001-09-14",
    "close": 3705.0,
    "volume": 13085,
    "contract": "200109"
  },
  {
    "date": "2001-09-19",
    "close": 3737.0,
    "volume": 6457,
    "contract": "200109"
  },
  {
    "date": "2001-09-20",
    "close": 3551.0,
    "volume": 11743,
    "contract": "200110"
  },
  {
    "date": "2001-09-21",
    "close": 3427.0,
    "volume": 5129,
    "contract": "200110"
  },
  {
    "date": "2001-09-24",
    "close": 3510.0,
    "volume": 19229,
    "contract": "200110"
  },
  {
    "date": "2001-09-25",
    "close": 3430.0,
    "volume": 20387,
    "contract": "200110"
  },
  {
    "date": "2001-09-26",
    "close": 3625.0,
    "volume": 27493,
    "contract": "200110"
  },
  {
    "date": "2001-09-27",
    "close": 3560.0,
    "volume": 19145,
    "contract": "200110"
  },
  {
    "date": "2001-09-28",
    "close": 3616.0,
    "volume": 21736,
    "contract": "200110"
  },
  {
    "date": "2001-10-02",
    "close": 3427.0,
    "volume": 16367,
    "contract": "200110"
  },
  {
    "date": "2001-10-03",
    "close": 3430.0,
    "volume": 16320,
    "contract": "200110"
  },
  {
    "date": "2001-10-04",
    "close": 3473.0,
    "volume": 17518,
    "contract": "200110"
  },
  {
    "date": "2001-10-05",
    "close": 3553.0,
    "volume": 19351,
    "contract": "200110"
  },
  {
    "date": "2001-10-08",
    "close": 3512.0,
    "volume": 11818,
    "contract": "200110"
  },
  {
    "date": "2001-10-09",
    "close": 3615.0,
    "volume": 14637,
    "contract": "200110"
  },
  {
    "date": "2001-10-11",
    "close": 3845.0,
    "volume": 15502,
    "contract": "200110"
  },
  {
    "date": "2001-10-12",
    "close": 3825.0,
    "volume": 18317,
    "contract": "200110"
  },
  {
    "date": "2001-10-15",
    "close": 3731.0,
    "volume": 7961,
    "contract": "200110"
  },
  {
    "date": "2001-10-16",
    "close": 3810.0,
    "volume": 4642,
    "contract": "200110"
  },
  {
    "date": "2001-10-17",
    "close": 3820.0,
    "volume": 3523,
    "contract": "200110"
  },
  {
    "date": "2001-10-18",
    "close": 3770.0,
    "volume": 12810,
    "contract": "200111"
  },
  {
    "date": "2001-10-19",
    "close": 3820.0,
    "volume": 18513,
    "contract": "200111"
  },
  {
    "date": "2001-10-22",
    "close": 3906.0,
    "volume": 15013,
    "contract": "200111"
  },
  {
    "date": "2001-10-23",
    "close": 3850.0,
    "volume": 15964,
    "contract": "200111"
  },
  {
    "date": "2001-10-24",
    "close": 3956.0,
    "volume": 20573,
    "contract": "200111"
  },
  {
    "date": "2001-10-25",
    "close": 3988.0,
    "volume": 17294,
    "contract": "200111"
  },
  {
    "date": "2001-10-26",
    "close": 3988.0,
    "volume": 17898,
    "contract": "200111"
  },
  {
    "date": "2001-10-29",
    "close": 3990.0,
    "volume": 10957,
    "contract": "200111"
  },
  {
    "date": "2001-10-30",
    "close": 3850.0,
    "volume": 14943,
    "contract": "200111"
  },
  {
    "date": "2001-10-31",
    "close": 3866.0,
    "volume": 13964,
    "contract": "200111"
  },
  {
    "date": "2001-11-01",
    "close": 3870.0,
    "volume": 10495,
    "contract": "200111"
  },
  {
    "date": "2001-11-02",
    "close": 3931.0,
    "volume": 15183,
    "contract": "200111"
  },
  {
    "date": "2001-11-05",
    "close": 4030.0,
    "volume": 14282,
    "contract": "200111"
  },
  {
    "date": "2001-11-06",
    "close": 3990.0,
    "volume": 16440,
    "contract": "200111"
  },
  {
    "date": "2001-11-07",
    "close": 4060.0,
    "volume": 15674,
    "contract": "200111"
  },
  {
    "date": "2001-11-08",
    "close": 4040.0,
    "volume": 13753,
    "contract": "200111"
  },
  {
    "date": "2001-11-09",
    "close": 4020.0,
    "volume": 10665,
    "contract": "200111"
  },
  {
    "date": "2001-11-12",
    "close": 4105.0,
    "volume": 11415,
    "contract": "200111"
  },
  {
    "date": "2001-11-13",
    "close": 4060.0,
    "volume": 9986,
    "contract": "200111"
  },
  {
    "date": "2001-11-14",
    "close": 4230.0,
    "volume": 16826,
    "contract": "200111"
  },
  {
    "date": "2001-11-15",
    "close": 4350.0,
    "volume": 15520,
    "contract": "200111"
  },
  {
    "date": "2001-11-16",
    "close": 4433.0,
    "volume": 15235,
    "contract": "200111"
  },
  {
    "date": "2001-11-19",
    "close": 4585.0,
    "volume": 10122,
    "contract": "200111"
  },
  {
    "date": "2001-11-20",
    "close": 4444.0,
    "volume": 6987,
    "contract": "200111"
  },
  {
    "date": "2001-11-21",
    "close": 4560.0,
    "volume": 4576,
    "contract": "200111"
  },
  {
    "date": "2001-11-22",
    "close": 4429.0,
    "volume": 15738,
    "contract": "200112"
  },
  {
    "date": "2001-11-23",
    "close": 4499.0,
    "volume": 15000,
    "contract": "200112"
  },
  {
    "date": "2001-11-26",
    "close": 4612.0,
    "volume": 14532,
    "contract": "200112"
  },
  {
    "date": "2001-11-27",
    "close": 4535.0,
    "volume": 21840,
    "contract": "200112"
  },
  {
    "date": "2001-11-28",
    "close": 4390.0,
    "volume": 18062,
    "contract": "200112"
  },
  {
    "date": "2001-11-29",
    "close": 4407.0,
    "volume": 15103,
    "contract": "200112"
  },
  {
    "date": "2001-11-30",
    "close": 4390.0,
    "volume": 15659,
    "contract": "200112"
  },
  {
    "date": "2001-12-03",
    "close": 4589.0,
    "volume": 15554,
    "contract": "200112"
  },
  {
    "date": "2001-12-04",
    "close": 4741.0,
    "volume": 19985,
    "contract": "200112"
  },
  {
    "date": "2001-12-05",
    "close": 4910.0,
    "volume": 23573,
    "contract": "200112"
  },
  {
    "date": "2001-12-06",
    "close": 5253.0,
    "volume": 19182,
    "contract": "200112"
  },
  {
    "date": "2001-12-07",
    "close": 5368.0,
    "volume": 23852,
    "contract": "200112"
  },
  {
    "date": "2001-12-10",
    "close": 5292.0,
    "volume": 20885,
    "contract": "200112"
  },
  {
    "date": "2001-12-11",
    "close": 5298.0,
    "volume": 17907,
    "contract": "200112"
  },
  {
    "date": "2001-12-12",
    "close": 5649.0,
    "volume": 21496,
    "contract": "200112"
  },
  {
    "date": "2001-12-13",
    "close": 5425.0,
    "volume": 27507,
    "contract": "200112"
  },
  {
    "date": "2001-12-14",
    "close": 5550.0,
    "volume": 23316,
    "contract": "200112"
  },
  {
    "date": "2001-12-17",
    "close": 5453.0,
    "volume": 15351,
    "contract": "200112"
  },
  {
    "date": "2001-12-18",
    "close": 5360.0,
    "volume": 10630,
    "contract": "200112"
  },
  {
    "date": "2001-12-19",
    "close": 5203.0,
    "volume": 4716,
    "contract": "200112"
  },
  {
    "date": "2001-12-20",
    "close": 5285.0,
    "volume": 18097,
    "contract": "200201"
  },
  {
    "date": "2001-12-21",
    "close": 5045.0,
    "volume": 16309,
    "contract": "200201"
  },
  {
    "date": "2001-12-24",
    "close": 5111.0,
    "volume": 12684,
    "contract": "200201"
  },
  {
    "date": "2001-12-25",
    "close": 5400.0,
    "volume": 18227,
    "contract": "200201"
  },
  {
    "date": "2001-12-26",
    "close": 5375.0,
    "volume": 21540,
    "contract": "200201"
  },
  {
    "date": "2001-12-27",
    "close": 5282.0,
    "volume": 21482,
    "contract": "200201"
  },
  {
    "date": "2001-12-28",
    "close": 5400.0,
    "volume": 19487,
    "contract": "200201"
  },
  {
    "date": "2001-12-31",
    "close": 5598.0,
    "volume": 14945,
    "contract": "200201"
  },
  {
    "date": "2002-01-02",
    "close": 5585.0,
    "volume": 17435,
    "contract": "200201"
  },
  {
    "date": "2002-01-03",
    "close": 5463.0,
    "volume": 18526,
    "contract": "200201"
  },
  {
    "date": "2002-01-04",
    "close": 5635.0,
    "volume": 16709,
    "contract": "200201"
  },
  {
    "date": "2002-01-07",
    "close": 5817.0,
    "volume": 14454,
    "contract": "200201"
  },
  {
    "date": "2002-01-08",
    "close": 5815.0,
    "volume": 16170,
    "contract": "200201"
  },
  {
    "date": "2002-01-09",
    "close": 5859.0,
    "volume": 17683,
    "contract": "200201"
  },
  {
    "date": "2002-01-10",
    "close": 5829.0,
    "volume": 16821,
    "contract": "200201"
  },
  {
    "date": "2002-01-11",
    "close": 5640.0,
    "volume": 20219,
    "contract": "200201"
  },
  {
    "date": "2002-01-14",
    "close": 5590.0,
    "volume": 9126,
    "contract": "200201"
  },
  {
    "date": "2002-01-15",
    "close": 5590.0,
    "volume": 8890,
    "contract": "200201"
  },
  {
    "date": "2002-01-16",
    "close": 5460.0,
    "volume": 4463,
    "contract": "200201"
  },
  {
    "date": "2002-01-17",
    "close": 5450.0,
    "volume": 14222,
    "contract": "200202"
  },
  {
    "date": "2002-01-18",
    "close": 5443.0,
    "volume": 18983,
    "contract": "200202"
  },
  {
    "date": "2002-01-21",
    "close": 5824.0,
    "volume": 18490,
    "contract": "200202"
  },
  {
    "date": "2002-01-22",
    "close": 5804.0,
    "volume": 18058,
    "contract": "200202"
  },
  {
    "date": "2002-01-23",
    "close": 5775.0,
    "volume": 23471,
    "contract": "200202"
  },
  {
    "date": "2002-01-24",
    "close": 5800.0,
    "volume": 18275,
    "contract": "200202"
  },
  {
    "date": "2002-01-25",
    "close": 5954.0,
    "volume": 18584,
    "contract": "200202"
  },
  {
    "date": "2002-01-28",
    "close": 6029.0,
    "volume": 11702,
    "contract": "200202"
  },
  {
    "date": "2002-01-29",
    "close": 5820.0,
    "volume": 15328,
    "contract": "200202"
  },
  {
    "date": "2002-01-30",
    "close": 5815.0,
    "volume": 13052,
    "contract": "200202"
  },
  {
    "date": "2002-01-31",
    "close": 5831.0,
    "volume": 14614,
    "contract": "200202"
  },
  {
    "date": "2002-02-01",
    "close": 5858.0,
    "volume": 13574,
    "contract": "200202"
  },
  {
    "date": "2002-02-04",
    "close": 5838.0,
    "volume": 10370,
    "contract": "200202"
  },
  {
    "date": "2002-02-05",
    "close": 5884.0,
    "volume": 8991,
    "contract": "200202"
  },
  {
    "date": "2002-02-06",
    "close": 5969.0,
    "volume": 12373,
    "contract": "200202"
  },
  {
    "date": "2002-02-18",
    "close": 5956.0,
    "volume": 6555,
    "contract": "200202"
  },
  {
    "date": "2002-02-19",
    "close": 5825.0,
    "volume": 5563,
    "contract": "200202"
  },
  {
    "date": "2002-02-20",
    "close": 5685.0,
    "volume": 3461,
    "contract": "200202"
  },
  {
    "date": "2002-02-21",
    "close": 5656.0,
    "volume": 12795,
    "contract": "200203"
  },
  {
    "date": "2002-02-22",
    "close": 5620.0,
    "volume": 11520,
    "contract": "200203"
  },
  {
    "date": "2002-02-25",
    "close": 5522.0,
    "volume": 10776,
    "contract": "200203"
  },
  {
    "date": "2002-02-26",
    "close": 5529.0,
    "volume": 13586,
    "contract": "200203"
  },
  {
    "date": "2002-02-27",
    "close": 5700.0,
    "volume": 15385,
    "contract": "200203"
  },
  {
    "date": "2002-03-01",
    "close": 5650.0,
    "volume": 13275,
    "contract": "200203"
  },
  {
    "date": "2002-03-04",
    "close": 5910.0,
    "volume": 17472,
    "contract": "200203"
  },
  {
    "date": "2002-03-05",
    "close": 5964.0,
    "volume": 15421,
    "contract": "200203"
  },
  {
    "date": "2002-03-06",
    "close": 6120.0,
    "volume": 17052,
    "contract": "200203"
  },
  {
    "date": "2002-03-07",
    "close": 6080.0,
    "volume": 14191,
    "contract": "200203"
  },
  {
    "date": "2002-03-08",
    "close": 6041.0,
    "volume": 16795,
    "contract": "200203"
  },
  {
    "date": "2002-03-11",
    "close": 6190.0,
    "volume": 17026,
    "contract": "200203"
  },
  {
    "date": "2002-03-12",
    "close": 6120.0,
    "volume": 13902,
    "contract": "200203"
  },
  {
    "date": "2002-03-13",
    "close": 6080.0,
    "volume": 19541,
    "contract": "200203"
  },
  {
    "date": "2002-03-14",
    "close": 6105.0,
    "volume": 14467,
    "contract": "200203"
  },
  {
    "date": "2002-03-15",
    "close": 5904.0,
    "volume": 17941,
    "contract": "200203"
  },
  {
    "date": "2002-03-18",
    "close": 5948.0,
    "volume": 9746,
    "contract": "200203"
  },
  {
    "date": "2002-03-19",
    "close": 5902.0,
    "volume": 5843,
    "contract": "200203"
  },
  {
    "date": "2002-03-20",
    "close": 6074.0,
    "volume": 4264,
    "contract": "200203"
  },
  {
    "date": "2002-03-21",
    "close": 6049.0,
    "volume": 16203,
    "contract": "200204"
  },
  {
    "date": "2002-03-22",
    "close": 6155.0,
    "volume": 14993,
    "contract": "200204"
  },
  {
    "date": "2002-03-25",
    "close": 6170.0,
    "volume": 14498,
    "contract": "200204"
  },
  {
    "date": "2002-03-26",
    "close": 6208.0,
    "volume": 13230,
    "contract": "200204"
  },
  {
    "date": "2002-03-27",
    "close": 6085.0,
    "volume": 19066,
    "contract": "200204"
  },
  {
    "date": "2002-03-28",
    "close": 6130.0,
    "volume": 15698,
    "contract": "200204"
  },
  {
    "date": "2002-03-29",
    "close": 6145.0,
    "volume": 14768,
    "contract": "200204"
  },
  {
    "date": "2002-04-01",
    "close": 6105.0,
    "volume": 9355,
    "contract": "200204"
  },
  {
    "date": "2002-04-02",
    "close": 6223.0,
    "volume": 16303,
    "contract": "200204"
  },
  {
    "date": "2002-04-03",
    "close": 6261.0,
    "volume": 13517,
    "contract": "200204"
  },
  {
    "date": "2002-04-04",
    "close": 6152.0,
    "volume": 15779,
    "contract": "200204"
  },
  {
    "date": "2002-04-08",
    "close": 6119.0,
    "volume": 10674,
    "contract": "200204"
  },
  {
    "date": "2002-04-09",
    "close": 6041.0,
    "volume": 16217,
    "contract": "200204"
  },
  {
    "date": "2002-04-10",
    "close": 6025.0,
    "volume": 10820,
    "contract": "200204"
  },
  {
    "date": "2002-04-11",
    "close": 6032.0,
    "volume": 10377,
    "contract": "200204"
  },
  {
    "date": "2002-04-12",
    "close": 6158.0,
    "volume": 14989,
    "contract": "200204"
  },
  {
    "date": "2002-04-15",
    "close": 6179.0,
    "volume": 8364,
    "contract": "200204"
  },
  {
    "date": "2002-04-16",
    "close": 6231.0,
    "volume": 5304,
    "contract": "200204"
  },
  {
    "date": "2002-04-17",
    "close": 6450.0,
    "volume": 4979,
    "contract": "200204"
  },
  {
    "date": "2002-04-18",
    "close": 6360.0,
    "volume": 9143,
    "contract": "200205"
  },
  {
    "date": "2002-04-19",
    "close": 6398.0,
    "volume": 10000,
    "contract": "200205"
  },
  {
    "date": "2002-04-22",
    "close": 6410.0,
    "volume": 7571,
    "contract": "200205"
  },
  {
    "date": "2002-04-23",
    "close": 6345.0,
    "volume": 9960,
    "contract": "200205"
  },
  {
    "date": "2002-04-24",
    "close": 6420.0,
    "volume": 12285,
    "contract": "200205"
  },
  {
    "date": "2002-04-25",
    "close": 6318.0,
    "volume": 13900,
    "contract": "200205"
  },
  {
    "date": "2002-04-26",
    "close": 6308.0,
    "volume": 9162,
    "contract": "200205"
  },
  {
    "date": "2002-04-29",
    "close": 6172.0,
    "volume": 11462,
    "contract": "200205"
  },
  {
    "date": "2002-04-30",
    "close": 6100.0,
    "volume": 10990,
    "contract": "200205"
  },
  {
    "date": "2002-05-02",
    "close": 5883.0,
    "volume": 14670,
    "contract": "200205"
  },
  {
    "date": "2002-05-03",
    "close": 5916.0,
    "volume": 15333,
    "contract": "200205"
  },
  {
    "date": "2002-05-06",
    "close": 5615.0,
    "volume": 14821,
    "contract": "200205"
  },
  {
    "date": "2002-05-07",
    "close": 5662.0,
    "volume": 14862,
    "contract": "200205"
  },
  {
    "date": "2002-05-08",
    "close": 5750.0,
    "volume": 14136,
    "contract": "200205"
  },
  {
    "date": "2002-05-09",
    "close": 5758.0,
    "volume": 15933,
    "contract": "200205"
  },
  {
    "date": "2002-05-10",
    "close": 5855.0,
    "volume": 17718,
    "contract": "200205"
  },
  {
    "date": "2002-05-13",
    "close": 5796.0,
    "volume": 9311,
    "contract": "200205"
  },
  {
    "date": "2002-05-14",
    "close": 5774.0,
    "volume": 6048,
    "contract": "200205"
  },
  {
    "date": "2002-05-15",
    "close": 5891.0,
    "volume": 6527,
    "contract": "200205"
  },
  {
    "date": "2002-05-16",
    "close": 5742.0,
    "volume": 14373,
    "contract": "200206"
  },
  {
    "date": "2002-05-17",
    "close": 5805.0,
    "volume": 16087,
    "contract": "200206"
  },
  {
    "date": "2002-05-20",
    "close": 5518.0,
    "volume": 17176,
    "contract": "200206"
  },
  {
    "date": "2002-05-21",
    "close": 5410.0,
    "volume": 16996,
    "contract": "200206"
  },
  {
    "date": "2002-05-22",
    "close": 5503.0,
    "volume": 17880,
    "contract": "200206"
  },
  {
    "date": "2002-05-23",
    "close": 5504.0,
    "volume": 14536,
    "contract": "200206"
  },
  {
    "date": "2002-05-24",
    "close": 5698.0,
    "volume": 16556,
    "contract": "200206"
  },
  {
    "date": "2002-05-27",
    "close": 5716.0,
    "volume": 9903,
    "contract": "200206"
  },
  {
    "date": "2002-05-28",
    "close": 5650.0,
    "volume": 16936,
    "contract": "200206"
  },
  {
    "date": "2002-05-29",
    "close": 5555.0,
    "volume": 13443,
    "contract": "200206"
  },
  {
    "date": "2002-05-30",
    "close": 5675.0,
    "volume": 20349,
    "contract": "200206"
  },
  {
    "date": "2002-05-31",
    "close": 5632.0,
    "volume": 13003,
    "contract": "200206"
  },
  {
    "date": "2002-06-03",
    "close": 5520.0,
    "volume": 13742,
    "contract": "200206"
  },
  {
    "date": "2002-06-04",
    "close": 5500.0,
    "volume": 12014,
    "contract": "200206"
  },
  {
    "date": "2002-06-05",
    "close": 5615.0,
    "volume": 13733,
    "contract": "200206"
  },
  {
    "date": "2002-06-06",
    "close": 5561.0,
    "volume": 13815,
    "contract": "200206"
  },
  {
    "date": "2002-06-07",
    "close": 5358.0,
    "volume": 15341,
    "contract": "200206"
  },
  {
    "date": "2002-06-10",
    "close": 5470.0,
    "volume": 10938,
    "contract": "200206"
  },
  {
    "date": "2002-06-11",
    "close": 5390.0,
    "volume": 16118,
    "contract": "200206"
  },
  {
    "date": "2002-06-12",
    "close": 5431.0,
    "volume": 12031,
    "contract": "200206"
  },
  {
    "date": "2002-06-13",
    "close": 5580.0,
    "volume": 16029,
    "contract": "200206"
  },
  {
    "date": "2002-06-14",
    "close": 5600.0,
    "volume": 9387,
    "contract": "200206"
  },
  {
    "date": "2002-06-17",
    "close": 5560.0,
    "volume": 8093,
    "contract": "200206"
  },
  {
    "date": "2002-06-18",
    "close": 5600.0,
    "volume": 5768,
    "contract": "200206"
  },
  {
    "date": "2002-06-19",
    "close": 5370.0,
    "volume": 5469,
    "contract": "200206"
  },
  {
    "date": "2002-06-20",
    "close": 5410.0,
    "volume": 15062,
    "contract": "200207"
  },
  {
    "date": "2002-06-21",
    "close": 5440.0,
    "volume": 21121,
    "contract": "200207"
  },
  {
    "date": "2002-06-24",
    "close": 5415.0,
    "volume": 17214,
    "contract": "200207"
  },
  {
    "date": "2002-06-25",
    "close": 5341.0,
    "volume": 20902,
    "contract": "200207"
  },
  {
    "date": "2002-06-26",
    "close": 5083.0,
    "volume": 19106,
    "contract": "200207"
  },
  {
    "date": "2002-06-27",
    "close": 5095.0,
    "volume": 18222,
    "contract": "200207"
  },
  {
    "date": "2002-06-28",
    "close": 5147.0,
    "volume": 13262,
    "contract": "200207"
  },
  {
    "date": "2002-07-01",
    "close": 4926.0,
    "volume": 12779,
    "contract": "200207"
  },
  {
    "date": "2002-07-02",
    "close": 4950.0,
    "volume": 14198,
    "contract": "200207"
  },
  {
    "date": "2002-07-03",
    "close": 5058.0,
    "volume": 22802,
    "contract": "200207"
  },
  {
    "date": "2002-07-04",
    "close": 5080.0,
    "volume": 15766,
    "contract": "200207"
  },
  {
    "date": "2002-07-05",
    "close": 5170.0,
    "volume": 18970,
    "contract": "200207"
  },
  {
    "date": "2002-07-08",
    "close": 5270.0,
    "volume": 16577,
    "contract": "200207"
  },
  {
    "date": "2002-07-09",
    "close": 5307.0,
    "volume": 11773,
    "contract": "200207"
  },
  {
    "date": "2002-07-10",
    "close": 5200.0,
    "volume": 13867,
    "contract": "200207"
  },
  {
    "date": "2002-07-11",
    "close": 5130.0,
    "volume": 16549,
    "contract": "200207"
  },
  {
    "date": "2002-07-12",
    "close": 5415.0,
    "volume": 18070,
    "contract": "200207"
  },
  {
    "date": "2002-07-15",
    "close": 5370.0,
    "volume": 9956,
    "contract": "200207"
  },
  {
    "date": "2002-07-16",
    "close": 5318.0,
    "volume": 8263,
    "contract": "200207"
  },
  {
    "date": "2002-07-17",
    "close": 5240.0,
    "volume": 4881,
    "contract": "200207"
  },
  {
    "date": "2002-07-18",
    "close": 5199.0,
    "volume": 19780,
    "contract": "200208"
  },
  {
    "date": "2002-07-19",
    "close": 5124.0,
    "volume": 14418,
    "contract": "200208"
  },
  {
    "date": "2002-07-22",
    "close": 5025.0,
    "volume": 11457,
    "contract": "200208"
  },
  {
    "date": "2002-07-23",
    "close": 5190.0,
    "volume": 20121,
    "contract": "200208"
  },
  {
    "date": "2002-07-24",
    "close": 5042.0,
    "volume": 19132,
    "contract": "200208"
  },
  {
    "date": "2002-07-25",
    "close": 5057.0,
    "volume": 19257,
    "contract": "200208"
  },
  {
    "date": "2002-07-26",
    "close": 4745.0,
    "volume": 18810,
    "contract": "200208"
  },
  {
    "date": "2002-07-29",
    "close": 4833.0,
    "volume": 16069,
    "contract": "200208"
  },
  {
    "date": "2002-07-30",
    "close": 4946.0,
    "volume": 19243,
    "contract": "200208"
  },
  {
    "date": "2002-07-31",
    "close": 4895.0,
    "volume": 14840,
    "contract": "200208"
  },
  {
    "date": "2002-08-01",
    "close": 4892.0,
    "volume": 14453,
    "contract": "200208"
  },
  {
    "date": "2002-08-02",
    "close": 4920.0,
    "volume": 15189,
    "contract": "200208"
  },
  {
    "date": "2002-08-05",
    "close": 4576.0,
    "volume": 17328,
    "contract": "200208"
  },
  {
    "date": "2002-08-06",
    "close": 4530.0,
    "volume": 19542,
    "contract": "200208"
  },
  {
    "date": "2002-08-07",
    "close": 4669.0,
    "volume": 15984,
    "contract": "200208"
  },
  {
    "date": "2002-08-08",
    "close": 4632.0,
    "volume": 20687,
    "contract": "200208"
  },
  {
    "date": "2002-08-09",
    "close": 4769.0,
    "volume": 18914,
    "contract": "200208"
  },
  {
    "date": "2002-08-12",
    "close": 4773.0,
    "volume": 10567,
    "contract": "200208"
  },
  {
    "date": "2002-08-13",
    "close": 4771.0,
    "volume": 7608,
    "contract": "200208"
  },
  {
    "date": "2002-08-14",
    "close": 4847.0,
    "volume": 17841,
    "contract": "200208"
  },
  {
    "date": "2002-08-15",
    "close": 4907.0,
    "volume": 15322,
    "contract": "200208"
  },
  {
    "date": "2002-08-16",
    "close": 4882.0,
    "volume": 11910,
    "contract": "200208"
  },
  {
    "date": "2002-08-19",
    "close": 4854.0,
    "volume": 7634,
    "contract": "200208"
  },
  {
    "date": "2002-08-20",
    "close": 4900.0,
    "volume": 7410,
    "contract": "200208"
  },
  {
    "date": "2002-08-21",
    "close": 4894.0,
    "volume": 5949,
    "contract": "200208"
  },
  {
    "date": "2002-08-22",
    "close": 4946.0,
    "volume": 17868,
    "contract": "200209"
  },
  {
    "date": "2002-08-23",
    "close": 4935.0,
    "volume": 13185,
    "contract": "200209"
  },
  {
    "date": "2002-08-26",
    "close": 4948.0,
    "volume": 11617,
    "contract": "200209"
  },
  {
    "date": "2002-08-27",
    "close": 4851.0,
    "volume": 13651,
    "contract": "200209"
  },
  {
    "date": "2002-08-28",
    "close": 4785.0,
    "volume": 13650,
    "contract": "200209"
  },
  {
    "date": "2002-08-29",
    "close": 4785.0,
    "volume": 14247,
    "contract": "200209"
  },
  {
    "date": "2002-08-30",
    "close": 4746.0,
    "volume": 12073,
    "contract": "200209"
  },
  {
    "date": "2002-09-02",
    "close": 4617.0,
    "volume": 12654,
    "contract": "200209"
  },
  {
    "date": "2002-09-03",
    "close": 4600.0,
    "volume": 16800,
    "contract": "200209"
  },
  {
    "date": "2002-09-04",
    "close": 4557.0,
    "volume": 19471,
    "contract": "200209"
  },
  {
    "date": "2002-09-05",
    "close": 4442.0,
    "volume": 15890,
    "contract": "200209"
  },
  {
    "date": "2002-09-09",
    "close": 4501.0,
    "volume": 15222,
    "contract": "200209"
  },
  {
    "date": "2002-09-10",
    "close": 4648.0,
    "volume": 22962,
    "contract": "200209"
  },
  {
    "date": "2002-09-11",
    "close": 4660.0,
    "volume": 13512,
    "contract": "200209"
  },
  {
    "date": "2002-09-12",
    "close": 4631.0,
    "volume": 16918,
    "contract": "200209"
  },
  {
    "date": "2002-09-13",
    "close": 4540.0,
    "volume": 12761,
    "contract": "200209"
  },
  {
    "date": "2002-09-16",
    "close": 4422.0,
    "volume": 12862,
    "contract": "200209"
  },
  {
    "date": "2002-09-17",
    "close": 4640.0,
    "volume": 11185,
    "contract": "200209"
  },
  {
    "date": "2002-09-18",
    "close": 4475.0,
    "volume": 4821,
    "contract": "200209"
  },
  {
    "date": "2002-09-19",
    "close": 4441.0,
    "volume": 23713,
    "contract": "200210"
  },
  {
    "date": "2002-09-20",
    "close": 4365.0,
    "volume": 17765,
    "contract": "200210"
  },
  {
    "date": "2002-09-23",
    "close": 4314.0,
    "volume": 16838,
    "contract": "200210"
  },
  {
    "date": "2002-09-24",
    "close": 4291.0,
    "volume": 21309,
    "contract": "200210"
  },
  {
    "date": "2002-09-25",
    "close": 4175.0,
    "volume": 20813,
    "contract": "200210"
  },
  {
    "date": "2002-09-26",
    "close": 4205.0,
    "volume": 19621,
    "contract": "200210"
  },
  {
    "date": "2002-09-27",
    "close": 4190.0,
    "volume": 21991,
    "contract": "200210"
  },
  {
    "date": "2002-09-30",
    "close": 4123.0,
    "volume": 17725,
    "contract": "200210"
  },
  {
    "date": "2002-10-01",
    "close": 4120.0,
    "volume": 23445,
    "contract": "200210"
  },
  {
    "date": "2002-10-02",
    "close": 4113.0,
    "volume": 22807,
    "contract": "200210"
  },
  {
    "date": "2002-10-03",
    "close": 4044.0,
    "volume": 16284,
    "contract": "200210"
  },
  {
    "date": "2002-10-04",
    "close": 4049.0,
    "volume": 21704,
    "contract": "200210"
  },
  {
    "date": "2002-10-07",
    "close": 3896.0,
    "volume": 17828,
    "contract": "200210"
  },
  {
    "date": "2002-10-08",
    "close": 3965.0,
    "volume": 20347,
    "contract": "200210"
  },
  {
    "date": "2002-10-09",
    "close": 3872.0,
    "volume": 22206,
    "contract": "200210"
  },
  {
    "date": "2002-10-11",
    "close": 3818.0,
    "volume": 22001,
    "contract": "200210"
  },
  {
    "date": "2002-10-14",
    "close": 3880.0,
    "volume": 18598,
    "contract": "200210"
  },
  {
    "date": "2002-10-15",
    "close": 4151.0,
    "volume": 12044,
    "contract": "200210"
  },
  {
    "date": "2002-10-16",
    "close": 4198.0,
    "volume": 6178,
    "contract": "200210"
  },
  {
    "date": "2002-10-17",
    "close": 4266.0,
    "volume": 28328,
    "contract": "200211"
  },
  {
    "date": "2002-10-18",
    "close": 4400.0,
    "volume": 27901,
    "contract": "200211"
  },
  {
    "date": "2002-10-21",
    "close": 4360.0,
    "volume": 17426,
    "contract": "200211"
  },
  {
    "date": "2002-10-22",
    "close": 4292.0,
    "volume": 26720,
    "contract": "200211"
  },
  {
    "date": "2002-10-23",
    "close": 4592.0,
    "volume": 34992,
    "contract": "200211"
  },
  {
    "date": "2002-10-24",
    "close": 4543.0,
    "volume": 27494,
    "contract": "200211"
  },
  {
    "date": "2002-10-25",
    "close": 4520.0,
    "volume": 25386,
    "contract": "200211"
  },
  {
    "date": "2002-10-28",
    "close": 4539.0,
    "volume": 23648,
    "contract": "200211"
  },
  {
    "date": "2002-10-29",
    "close": 4521.0,
    "volume": 16395,
    "contract": "200211"
  },
  {
    "date": "2002-10-30",
    "close": 4440.0,
    "volume": 26769,
    "contract": "200211"
  },
  {
    "date": "2002-10-31",
    "close": 4549.0,
    "volume": 24793,
    "contract": "200211"
  },
  {
    "date": "2002-11-01",
    "close": 4466.0,
    "volume": 22457,
    "contract": "200211"
  },
  {
    "date": "2002-11-04",
    "close": 4595.0,
    "volume": 22066,
    "contract": "200211"
  },
  {
    "date": "2002-11-05",
    "close": 4548.0,
    "volume": 19679,
    "contract": "200211"
  },
  {
    "date": "2002-11-06",
    "close": 4720.0,
    "volume": 32593,
    "contract": "200211"
  },
  {
    "date": "2002-11-07",
    "close": 4748.0,
    "volume": 21177,
    "contract": "200211"
  },
  {
    "date": "2002-11-08",
    "close": 4783.0,
    "volume": 21916,
    "contract": "200211"
  },
  {
    "date": "2002-11-11",
    "close": 4680.0,
    "volume": 18773,
    "contract": "200211"
  },
  {
    "date": "2002-11-12",
    "close": 4673.0,
    "volume": 18946,
    "contract": "200211"
  },
  {
    "date": "2002-11-13",
    "close": 4657.0,
    "volume": 18427,
    "contract": "200211"
  },
  {
    "date": "2002-11-14",
    "close": 4662.0,
    "volume": 20954,
    "contract": "200211"
  },
  {
    "date": "2002-11-15",
    "close": 4815.0,
    "volume": 19786,
    "contract": "200211"
  },
  {
    "date": "2002-11-18",
    "close": 4790.0,
    "volume": 9950,
    "contract": "200211"
  },
  {
    "date": "2002-11-19",
    "close": 4740.0,
    "volume": 7152,
    "contract": "200211"
  },
  {
    "date": "2002-11-20",
    "close": 4661.0,
    "volume": 5248,
    "contract": "200211"
  },
  {
    "date": "2002-11-21",
    "close": 4631.0,
    "volume": 22223,
    "contract": "200212"
  },
  {
    "date": "2002-11-22",
    "close": 4710.0,
    "volume": 20197,
    "contract": "200212"
  },
  {
    "date": "2002-11-25",
    "close": 4748.0,
    "volume": 16619,
    "contract": "200212"
  },
  {
    "date": "2002-11-26",
    "close": 4681.0,
    "volume": 16031,
    "contract": "200212"
  },
  {
    "date": "2002-11-27",
    "close": 4655.0,
    "volume": 17410,
    "contract": "200212"
  },
  {
    "date": "2002-11-28",
    "close": 4640.0,
    "volume": 21260,
    "contract": "200212"
  },
  {
    "date": "2002-11-29",
    "close": 4670.0,
    "volume": 14076,
    "contract": "200212"
  },
  {
    "date": "2002-12-02",
    "close": 4713.0,
    "volume": 13998,
    "contract": "200212"
  },
  {
    "date": "2002-12-03",
    "close": 4776.0,
    "volume": 22769,
    "contract": "200212"
  },
  {
    "date": "2002-12-04",
    "close": 4745.0,
    "volume": 10322,
    "contract": "200212"
  },
  {
    "date": "2002-12-05",
    "close": 4763.0,
    "volume": 11363,
    "contract": "200212"
  },
  {
    "date": "2002-12-06",
    "close": 4744.0,
    "volume": 7694,
    "contract": "200212"
  },
  {
    "date": "2002-12-09",
    "close": 4790.0,
    "volume": 17733,
    "contract": "200212"
  },
  {
    "date": "2002-12-10",
    "close": 4755.0,
    "volume": 14054,
    "contract": "200212"
  },
  {
    "date": "2002-12-11",
    "close": 4686.0,
    "volume": 18523,
    "contract": "200212"
  },
  {
    "date": "2002-12-12",
    "close": 4687.0,
    "volume": 14773,
    "contract": "200212"
  },
  {
    "date": "2002-12-13",
    "close": 4623.0,
    "volume": 13890,
    "contract": "200212"
  },
  {
    "date": "2002-12-16",
    "close": 4600.0,
    "volume": 10435,
    "contract": "200212"
  },
  {
    "date": "2002-12-17",
    "close": 4576.0,
    "volume": 7423,
    "contract": "200212"
  },
  {
    "date": "2002-12-18",
    "close": 4550.0,
    "volume": 6121,
    "contract": "200212"
  },
  {
    "date": "2002-12-19",
    "close": 4550.0,
    "volume": 16366,
    "contract": "200301"
  },
  {
    "date": "2002-12-20",
    "close": 4573.0,
    "volume": 18771,
    "contract": "200301"
  },
  {
    "date": "2002-12-23",
    "close": 4536.0,
    "volume": 8241,
    "contract": "200301"
  },
  {
    "date": "2002-12-24",
    "close": 4530.0,
    "volume": 9859,
    "contract": "200301"
  },
  {
    "date": "2002-12-25",
    "close": 4488.0,
    "volume": 12247,
    "contract": "200301"
  },
  {
    "date": "2002-12-26",
    "close": 4531.0,
    "volume": 12472,
    "contract": "200301"
  },
  {
    "date": "2002-12-27",
    "close": 4501.0,
    "volume": 9300,
    "contract": "200301"
  },
  {
    "date": "2002-12-30",
    "close": 4416.0,
    "volume": 11333,
    "contract": "200301"
  },
  {
    "date": "2002-12-31",
    "close": 4405.0,
    "volume": 8319,
    "contract": "200301"
  },
  {
    "date": "2003-01-02",
    "close": 4452.0,
    "volume": 15261,
    "contract": "200301"
  },
  {
    "date": "2003-01-03",
    "close": 4571.0,
    "volume": 17261,
    "contract": "200301"
  },
  {
    "date": "2003-01-06",
    "close": 4635.0,
    "volume": 14621,
    "contract": "200301"
  },
  {
    "date": "2003-01-07",
    "close": 4641.0,
    "volume": 14614,
    "contract": "200301"
  },
  {
    "date": "2003-01-08",
    "close": 4771.0,
    "volume": 21966,
    "contract": "200301"
  },
  {
    "date": "2003-01-09",
    "close": 4785.0,
    "volume": 14067,
    "contract": "200301"
  },
  {
    "date": "2003-01-10",
    "close": 4828.0,
    "volume": 14899,
    "contract": "200301"
  },
  {
    "date": "2003-01-13",
    "close": 5025.0,
    "volume": 15346,
    "contract": "200301"
  },
  {
    "date": "2003-01-14",
    "close": 5009.0,
    "volume": 7170,
    "contract": "200301"
  },
  {
    "date": "2003-01-15",
    "close": 5044.0,
    "volume": 5639,
    "contract": "200301"
  },
  {
    "date": "2003-01-16",
    "close": 4940.0,
    "volume": 15161,
    "contract": "200302"
  },
  {
    "date": "2003-01-17",
    "close": 4925.0,
    "volume": 15063,
    "contract": "200302"
  },
  {
    "date": "2003-01-20",
    "close": 4968.0,
    "volume": 11749,
    "contract": "200302"
  },
  {
    "date": "2003-01-21",
    "close": 4939.0,
    "volume": 19910,
    "contract": "200302"
  },
  {
    "date": "2003-01-22",
    "close": 5002.0,
    "volume": 15667,
    "contract": "200302"
  },
  {
    "date": "2003-01-23",
    "close": 5085.0,
    "volume": 19929,
    "contract": "200302"
  },
  {
    "date": "2003-01-24",
    "close": 5063.0,
    "volume": 14151,
    "contract": "200302"
  },
  {
    "date": "2003-01-27",
    "close": 4956.0,
    "volume": 14373,
    "contract": "200302"
  },
  {
    "date": "2003-01-28",
    "close": 5022.0,
    "volume": 11264,
    "contract": "200302"
  },
  {
    "date": "2003-02-06",
    "close": 4775.0,
    "volume": 14078,
    "contract": "200302"
  },
  {
    "date": "2003-02-07",
    "close": 4699.0,
    "volume": 18975,
    "contract": "200302"
  },
  {
    "date": "2003-02-10",
    "close": 4640.0,
    "volume": 12415,
    "contract": "200302"
  },
  {
    "date": "2003-02-11",
    "close": 4635.0,
    "volume": 13808,
    "contract": "200302"
  },
  {
    "date": "2003-02-12",
    "close": 4637.0,
    "volume": 15989,
    "contract": "200302"
  },
  {
    "date": "2003-02-13",
    "close": 4485.0,
    "volume": 17777,
    "contract": "200302"
  },
  {
    "date": "2003-02-14",
    "close": 4489.0,
    "volume": 14580,
    "contract": "200302"
  },
  {
    "date": "2003-02-17",
    "close": 4690.0,
    "volume": 15292,
    "contract": "200302"
  },
  {
    "date": "2003-02-18",
    "close": 4636.0,
    "volume": 6717,
    "contract": "200302"
  },
  {
    "date": "2003-02-19",
    "close": 4545.0,
    "volume": 5247,
    "contract": "200302"
  },
  {
    "date": "2003-02-20",
    "close": 4560.0,
    "volume": 16371,
    "contract": "200303"
  },
  {
    "date": "2003-02-21",
    "close": 4540.0,
    "volume": 11619,
    "contract": "200303"
  },
  {
    "date": "2003-02-24",
    "close": 4601.0,
    "volume": 15680,
    "contract": "200303"
  },
  {
    "date": "2003-02-25",
    "close": 4450.0,
    "volume": 18875,
    "contract": "200303"
  },
  {
    "date": "2003-02-26",
    "close": 4451.0,
    "volume": 14991,
    "contract": "200303"
  },
  {
    "date": "2003-02-27",
    "close": 4408.0,
    "volume": 18702,
    "contract": "200303"
  },
  {
    "date": "2003-03-03",
    "close": 4515.0,
    "volume": 15329,
    "contract": "200303"
  },
  {
    "date": "2003-03-04",
    "close": 4469.0,
    "volume": 12700,
    "contract": "200303"
  },
  {
    "date": "2003-03-05",
    "close": 4389.0,
    "volume": 13660,
    "contract": "200303"
  },
  {
    "date": "2003-03-06",
    "close": 4397.0,
    "volume": 10631,
    "contract": "200303"
  },
  {
    "date": "2003-03-07",
    "close": 4355.0,
    "volume": 16370,
    "contract": "200303"
  },
  {
    "date": "2003-03-10",
    "close": 4335.0,
    "volume": 11452,
    "contract": "200303"
  },
  {
    "date": "2003-03-11",
    "close": 4250.0,
    "volume": 18339,
    "contract": "200303"
  },
  {
    "date": "2003-03-12",
    "close": 4305.0,
    "volume": 14060,
    "contract": "200303"
  },
  {
    "date": "2003-03-13",
    "close": 4353.0,
    "volume": 21864,
    "contract": "200303"
  },
  {
    "date": "2003-03-14",
    "close": 4479.0,
    "volume": 18010,
    "contract": "200303"
  },
  {
    "date": "2003-03-17",
    "close": 4318.0,
    "volume": 11793,
    "contract": "200303"
  },
  {
    "date": "2003-03-18",
    "close": 4538.0,
    "volume": 10169,
    "contract": "200303"
  },
  {
    "date": "2003-03-19",
    "close": 4520.0,
    "volume": 3633,
    "contract": "200303"
  },
  {
    "date": "2003-03-20",
    "close": 4588.0,
    "volume": 29044,
    "contract": "200304"
  },
  {
    "date": "2003-03-21",
    "close": 4580.0,
    "volume": 10606,
    "contract": "200304"
  },
  {
    "date": "2003-03-24",
    "close": 4541.0,
    "volume": 12321,
    "contract": "200304"
  },
  {
    "date": "2003-03-25",
    "close": 4475.0,
    "volume": 14577,
    "contract": "200304"
  },
  {
    "date": "2003-03-26",
    "close": 4470.0,
    "volume": 10055,
    "contract": "200304"
  },
  {
    "date": "2003-03-27",
    "close": 4496.0,
    "volume": 13049,
    "contract": "200304"
  },
  {
    "date": "2003-03-28",
    "close": 4453.0,
    "volume": 13304,
    "contract": "200304"
  },
  {
    "date": "2003-03-31",
    "close": 4286.0,
    "volume": 20548,
    "contract": "200304"
  },
  {
    "date": "2003-04-01",
    "close": 4301.0,
    "volume": 11775,
    "contract": "200304"
  },
  {
    "date": "2003-04-02",
    "close": 4295.0,
    "volume": 19249,
    "contract": "200304"
  },
  {
    "date": "2003-04-03",
    "close": 4338.0,
    "volume": 16437,
    "contract": "200304"
  },
  {
    "date": "2003-04-04",
    "close": 4469.0,
    "volume": 29045,
    "contract": "200304"
  },
  {
    "date": "2003-04-07",
    "close": 4572.0,
    "volume": 24867,
    "contract": "200304"
  },
  {
    "date": "2003-04-08",
    "close": 4547.0,
    "volume": 23023,
    "contract": "200304"
  },
  {
    "date": "2003-04-09",
    "close": 4505.0,
    "volume": 13516,
    "contract": "200304"
  },
  {
    "date": "2003-04-10",
    "close": 4511.0,
    "volume": 23910,
    "contract": "200304"
  },
  {
    "date": "2003-04-11",
    "close": 4516.0,
    "volume": 15063,
    "contract": "200304"
  },
  {
    "date": "2003-04-14",
    "close": 4449.0,
    "volume": 17140,
    "contract": "200304"
  },
  {
    "date": "2003-04-15",
    "close": 4475.0,
    "volume": 6617,
    "contract": "200304"
  },
  {
    "date": "2003-04-16",
    "close": 4625.0,
    "volume": 9014,
    "contract": "200304"
  },
  {
    "date": "2003-04-17",
    "close": 4557.0,
    "volume": 15212,
    "contract": "200305"
  },
  {
    "date": "2003-04-18",
    "close": 4660.0,
    "volume": 19087,
    "contract": "200305"
  },
  {
    "date": "2003-04-21",
    "close": 4657.0,
    "volume": 14028,
    "contract": "200305"
  },
  {
    "date": "2003-04-22",
    "close": 4571.0,
    "volume": 18082,
    "contract": "200305"
  },
  {
    "date": "2003-04-23",
    "close": 4570.0,
    "volume": 18575,
    "contract": "200305"
  },
  {
    "date": "2003-04-24",
    "close": 4356.0,
    "volume": 33455,
    "contract": "200305"
  },
  {
    "date": "2003-04-25",
    "close": 4211.0,
    "volume": 29308,
    "contract": "200305"
  },
  {
    "date": "2003-04-28",
    "close": 4125.0,
    "volume": 29743,
    "contract": "200305"
  },
  {
    "date": "2003-04-29",
    "close": 4195.0,
    "volume": 27083,
    "contract": "200305"
  },
  {
    "date": "2003-04-30",
    "close": 4135.0,
    "volume": 30524,
    "contract": "200305"
  },
  {
    "date": "2003-05-02",
    "close": 4189.0,
    "volume": 23191,
    "contract": "200305"
  },
  {
    "date": "2003-05-05",
    "close": 4190.0,
    "volume": 21100,
    "contract": "200305"
  },
  {
    "date": "2003-05-06",
    "close": 4185.0,
    "volume": 19165,
    "contract": "200305"
  },
  {
    "date": "2003-05-07",
    "close": 4245.0,
    "volume": 21544,
    "contract": "200305"
  },
  {
    "date": "2003-05-08",
    "close": 4165.0,
    "volume": 19440,
    "contract": "200305"
  },
  {
    "date": "2003-05-09",
    "close": 4224.0,
    "volume": 26441,
    "contract": "200305"
  },
  {
    "date": "2003-05-12",
    "close": 4245.0,
    "volume": 20059,
    "contract": "200305"
  },
  {
    "date": "2003-05-13",
    "close": 4316.0,
    "volume": 22869,
    "contract": "200305"
  },
  {
    "date": "2003-05-14",
    "close": 4338.0,
    "volume": 15351,
    "contract": "200305"
  },
  {
    "date": "2003-05-15",
    "close": 4324.0,
    "volume": 22175,
    "contract": "200305"
  },
  {
    "date": "2003-05-16",
    "close": 4260.0,
    "volume": 20307,
    "contract": "200305"
  },
  {
    "date": "2003-05-19",
    "close": 4239.0,
    "volume": 14174,
    "contract": "200305"
  },
  {
    "date": "2003-05-20",
    "close": 4226.0,
    "volume": 8411,
    "contract": "200305"
  },
  {
    "date": "2003-05-21",
    "close": 4240.0,
    "volume": 7374,
    "contract": "200305"
  },
  {
    "date": "2003-05-22",
    "close": 4241.0,
    "volume": 26811,
    "contract": "200306"
  },
  {
    "date": "2003-05-23",
    "close": 4340.0,
    "volume": 28441,
    "contract": "200306"
  },
  {
    "date": "2003-05-26",
    "close": 4444.0,
    "volume": 24793,
    "contract": "200306"
  },
  {
    "date": "2003-05-27",
    "close": 4434.0,
    "volume": 16470,
    "contract": "200306"
  },
  {
    "date": "2003-05-28",
    "close": 4485.0,
    "volume": 29381,
    "contract": "200306"
  },
  {
    "date": "2003-05-29",
    "close": 4453.0,
    "volume": 19267,
    "contract": "200306"
  },
  {
    "date": "2003-05-30",
    "close": 4510.0,
    "volume": 46576,
    "contract": "200306"
  },
  {
    "date": "2003-06-02",
    "close": 4665.0,
    "volume": 35509,
    "contract": "200306"
  },
  {
    "date": "2003-06-03",
    "close": 4658.0,
    "volume": 19168,
    "contract": "200306"
  },
  {
    "date": "2003-06-05",
    "close": 4725.0,
    "volume": 25384,
    "contract": "200306"
  },
  {
    "date": "2003-06-06",
    "close": 4732.0,
    "volume": 23064,
    "contract": "200306"
  },
  {
    "date": "2003-06-09",
    "close": 4800.0,
    "volume": 34328,
    "contract": "200306"
  },
  {
    "date": "2003-06-10",
    "close": 4821.0,
    "volume": 21787,
    "contract": "200306"
  },
  {
    "date": "2003-06-11",
    "close": 4795.0,
    "volume": 25452,
    "contract": "200306"
  },
  {
    "date": "2003-06-12",
    "close": 4881.0,
    "volume": 28640,
    "contract": "200306"
  },
  {
    "date": "2003-06-13",
    "close": 4890.0,
    "volume": 18023,
    "contract": "200306"
  },
  {
    "date": "2003-06-16",
    "close": 4903.0,
    "volume": 17057,
    "contract": "200306"
  },
  {
    "date": "2003-06-17",
    "close": 5037.0,
    "volume": 14696,
    "contract": "200306"
  },
  {
    "date": "2003-06-18",
    "close": 5015.0,
    "volume": 11388,
    "contract": "200306"
  },
  {
    "date": "2003-06-19",
    "close": 5069.0,
    "volume": 30375,
    "contract": "200307"
  },
  {
    "date": "2003-06-20",
    "close": 5019.0,
    "volume": 26260,
    "contract": "200307"
  },
  {
    "date": "2003-06-23",
    "close": 4925.0,
    "volume": 23320,
    "contract": "200307"
  },
  {
    "date": "2003-06-24",
    "close": 4906.0,
    "volume": 25968,
    "contract": "200307"
  },
  {
    "date": "2003-06-25",
    "close": 4940.0,
    "volume": 22986,
    "contract": "200307"
  },
  {
    "date": "2003-06-26",
    "close": 4885.0,
    "volume": 20537,
    "contract": "200307"
  },
  {
    "date": "2003-06-27",
    "close": 4861.0,
    "volume": 28394,
    "contract": "200307"
  },
  {
    "date": "2003-06-30",
    "close": 4885.0,
    "volume": 21109,
    "contract": "200307"
  },
  {
    "date": "2003-07-01",
    "close": 5038.0,
    "volume": 36268,
    "contract": "200307"
  },
  {
    "date": "2003-07-02",
    "close": 5140.0,
    "volume": 33444,
    "contract": "200307"
  },
  {
    "date": "2003-07-03",
    "close": 5122.0,
    "volume": 38945,
    "contract": "200307"
  },
  {
    "date": "2003-07-04",
    "close": 5191.0,
    "volume": 30814,
    "contract": "200307"
  },
  {
    "date": "2003-07-07",
    "close": 5370.0,
    "volume": 37537,
    "contract": "200307"
  },
  {
    "date": "2003-07-08",
    "close": 5382.0,
    "volume": 39375,
    "contract": "200307"
  },
  {
    "date": "2003-07-09",
    "close": 5375.0,
    "volume": 29772,
    "contract": "200307"
  },
  {
    "date": "2003-07-10",
    "close": 5250.0,
    "volume": 39431,
    "contract": "200307"
  },
  {
    "date": "2003-07-11",
    "close": 5265.0,
    "volume": 30216,
    "contract": "200307"
  },
  {
    "date": "2003-07-14",
    "close": 5412.0,
    "volume": 34274,
    "contract": "200307"
  },
  {
    "date": "2003-07-15",
    "close": 5328.0,
    "volume": 18194,
    "contract": "200307"
  },
  {
    "date": "2003-07-16",
    "close": 5429.0,
    "volume": 12426,
    "contract": "200307"
  },
  {
    "date": "2003-07-17",
    "close": 5251.0,
    "volume": 46382,
    "contract": "200308"
  },
  {
    "date": "2003-07-18",
    "close": 5255.0,
    "volume": 35944,
    "contract": "200308"
  },
  {
    "date": "2003-07-21",
    "close": 5239.0,
    "volume": 33340,
    "contract": "200308"
  },
  {
    "date": "2003-07-22",
    "close": 5293.0,
    "volume": 38330,
    "contract": "200308"
  },
  {
    "date": "2003-07-23",
    "close": 5307.0,
    "volume": 37156,
    "contract": "200308"
  },
  {
    "date": "2003-07-24",
    "close": 5415.0,
    "volume": 40588,
    "contract": "200308"
  },
  {
    "date": "2003-07-25",
    "close": 5384.0,
    "volume": 24846,
    "contract": "200308"
  },
  {
    "date": "2003-07-28",
    "close": 5475.0,
    "volume": 26930,
    "contract": "200308"
  },
  {
    "date": "2003-07-29",
    "close": 5355.0,
    "volume": 39263,
    "contract": "200308"
  },
  {
    "date": "2003-07-30",
    "close": 5308.0,
    "volume": 30831,
    "contract": "200308"
  },
  {
    "date": "2003-07-31",
    "close": 5330.0,
    "volume": 32566,
    "contract": "200308"
  },
  {
    "date": "2003-08-01",
    "close": 5390.0,
    "volume": 32894,
    "contract": "200308"
  },
  {
    "date": "2003-08-04",
    "close": 5370.0,
    "volume": 21245,
    "contract": "200308"
  },
  {
    "date": "2003-08-05",
    "close": 5269.0,
    "volume": 37518,
    "contract": "200308"
  },
  {
    "date": "2003-08-06",
    "close": 5242.0,
    "volume": 20192,
    "contract": "200308"
  },
  {
    "date": "2003-08-07",
    "close": 5281.0,
    "volume": 40112,
    "contract": "200308"
  },
  {
    "date": "2003-08-08",
    "close": 5206.0,
    "volume": 28657,
    "contract": "200308"
  },
  {
    "date": "2003-08-11",
    "close": 5251.0,
    "volume": 23654,
    "contract": "200308"
  },
  {
    "date": "2003-08-12",
    "close": 5265.0,
    "volume": 25446,
    "contract": "200308"
  },
  {
    "date": "2003-08-13",
    "close": 5471.0,
    "volume": 45988,
    "contract": "200308"
  },
  {
    "date": "2003-08-14",
    "close": 5466.0,
    "volume": 33203,
    "contract": "200308"
  },
  {
    "date": "2003-08-15",
    "close": 5490.0,
    "volume": 35813,
    "contract": "200308"
  },
  {
    "date": "2003-08-18",
    "close": 5539.0,
    "volume": 22042,
    "contract": "200308"
  },
  {
    "date": "2003-08-19",
    "close": 5555.0,
    "volume": 17228,
    "contract": "200308"
  },
  {
    "date": "2003-08-20",
    "close": 5520.0,
    "volume": 8073,
    "contract": "200308"
  },
  {
    "date": "2003-08-21",
    "close": 5611.0,
    "volume": 45103,
    "contract": "200309"
  },
  {
    "date": "2003-08-22",
    "close": 5613.0,
    "volume": 35146,
    "contract": "200309"
  },
  {
    "date": "2003-08-25",
    "close": 5665.0,
    "volume": 34143,
    "contract": "200309"
  },
  {
    "date": "2003-08-26",
    "close": 5580.0,
    "volume": 38891,
    "contract": "200309"
  },
  {
    "date": "2003-08-27",
    "close": 5548.0,
    "volume": 28153,
    "contract": "200309"
  },
  {
    "date": "2003-08-28",
    "close": 5548.0,
    "volume": 30378,
    "contract": "200309"
  },
  {
    "date": "2003-08-29",
    "close": 5668.0,
    "volume": 45483,
    "contract": "200309"
  },
  {
    "date": "2003-09-01",
    "close": 5717.0,
    "volume": 29607,
    "contract": "200309"
  },
  {
    "date": "2003-09-02",
    "close": 5755.0,
    "volume": 29132,
    "contract": "200309"
  },
  {
    "date": "2003-09-03",
    "close": 5675.0,
    "volume": 34696,
    "contract": "200309"
  },
  {
    "date": "2003-09-04",
    "close": 5654.0,
    "volume": 33084,
    "contract": "200309"
  },
  {
    "date": "2003-09-05",
    "close": 5683.0,
    "volume": 41855,
    "contract": "200309"
  },
  {
    "date": "2003-09-08",
    "close": 5753.0,
    "volume": 46555,
    "contract": "200309"
  },
  {
    "date": "2003-09-09",
    "close": 5709.0,
    "volume": 39280,
    "contract": "200309"
  },
  {
    "date": "2003-09-10",
    "close": 5652.0,
    "volume": 36115,
    "contract": "200309"
  },
  {
    "date": "2003-09-12",
    "close": 5666.0,
    "volume": 27882,
    "contract": "200309"
  },
  {
    "date": "2003-09-15",
    "close": 5652.0,
    "volume": 20867,
    "contract": "200309"
  },
  {
    "date": "2003-09-16",
    "close": 5716.0,
    "volume": 26867,
    "contract": "200309"
  },
  {
    "date": "2003-09-17",
    "close": 5761.0,
    "volume": 12218,
    "contract": "200309"
  },
  {
    "date": "2003-09-18",
    "close": 5759.0,
    "volume": 38489,
    "contract": "200310"
  },
  {
    "date": "2003-09-19",
    "close": 5749.0,
    "volume": 36541,
    "contract": "200310"
  },
  {
    "date": "2003-09-22",
    "close": 5695.0,
    "volume": 31598,
    "contract": "200310"
  },
  {
    "date": "2003-09-23",
    "close": 5714.0,
    "volume": 24963,
    "contract": "200310"
  },
  {
    "date": "2003-09-24",
    "close": 5745.0,
    "volume": 33699,
    "contract": "200310"
  },
  {
    "date": "2003-09-25",
    "close": 5688.0,
    "volume": 29744,
    "contract": "200310"
  },
  {
    "date": "2003-09-26",
    "close": 5687.0,
    "volume": 29079,
    "contract": "200310"
  },
  {
    "date": "2003-09-29",
    "close": 5665.0,
    "volume": 18730,
    "contract": "200310"
  },
  {
    "date": "2003-09-30",
    "close": 5641.0,
    "volume": 21027,
    "contract": "200310"
  },
  {
    "date": "2003-10-01",
    "close": 5630.0,
    "volume": 25554,
    "contract": "200310"
  },
  {
    "date": "2003-10-02",
    "close": 5720.0,
    "volume": 37651,
    "contract": "200310"
  },
  {
    "date": "2003-10-03",
    "close": 5742.0,
    "volume": 26731,
    "contract": "200310"
  },
  {
    "date": "2003-10-06",
    "close": 5829.0,
    "volume": 36776,
    "contract": "200310"
  },
  {
    "date": "2003-10-07",
    "close": 5855.0,
    "volume": 20644,
    "contract": "200310"
  },
  {
    "date": "2003-10-08",
    "close": 5834.0,
    "volume": 23988,
    "contract": "200310"
  },
  {
    "date": "2003-10-09",
    "close": 5894.0,
    "volume": 25171,
    "contract": "200310"
  },
  {
    "date": "2003-10-13",
    "close": 6028.0,
    "volume": 25046,
    "contract": "200310"
  },
  {
    "date": "2003-10-14",
    "close": 5979.0,
    "volume": 18614,
    "contract": "200310"
  },
  {
    "date": "2003-10-15",
    "close": 5950.0,
    "volume": 11557,
    "contract": "200310"
  },
  {
    "date": "2003-10-16",
    "close": 6060.0,
    "volume": 34726,
    "contract": "200311"
  },
  {
    "date": "2003-10-17",
    "close": 6080.0,
    "volume": 16856,
    "contract": "200311"
  },
  {
    "date": "2003-10-20",
    "close": 6072.0,
    "volume": 23732,
    "contract": "200311"
  },
  {
    "date": "2003-10-21",
    "close": 6074.0,
    "volume": 33613,
    "contract": "200311"
  },
  {
    "date": "2003-10-22",
    "close": 6051.0,
    "volume": 23581,
    "contract": "200311"
  },
  {
    "date": "2003-10-23",
    "close": 5945.0,
    "volume": 31507,
    "contract": "200311"
  },
  {
    "date": "2003-10-24",
    "close": 5958.0,
    "volume": 17701,
    "contract": "200311"
  },
  {
    "date": "2003-10-27",
    "close": 6000.0,
    "volume": 16969,
    "contract": "200311"
  },
  {
    "date": "2003-10-28",
    "close": 6130.0,
    "volume": 40875,
    "contract": "200311"
  },
  {
    "date": "2003-10-29",
    "close": 6160.0,
    "volume": 27984,
    "contract": "200311"
  },
  {
    "date": "2003-10-30",
    "close": 6134.0,
    "volume": 26265,
    "contract": "200311"
  },
  {
    "date": "2003-10-31",
    "close": 6068.0,
    "volume": 32532,
    "contract": "200311"
  },
  {
    "date": "2003-11-03",
    "close": 6150.0,
    "volume": 31714,
    "contract": "200311"
  },
  {
    "date": "2003-11-04",
    "close": 6144.0,
    "volume": 26749,
    "contract": "200311"
  },
  {
    "date": "2003-11-05",
    "close": 6165.0,
    "volume": 29556,
    "contract": "200311"
  },
  {
    "date": "2003-11-06",
    "close": 5975.0,
    "volume": 45340,
    "contract": "200311"
  },
  {
    "date": "2003-11-07",
    "close": 6059.0,
    "volume": 30177,
    "contract": "200311"
  },
  {
    "date": "2003-11-10",
    "close": 6049.0,
    "volume": 28387,
    "contract": "200311"
  },
  {
    "date": "2003-11-11",
    "close": 6040.0,
    "volume": 30237,
    "contract": "200311"
  },
  {
    "date": "2003-11-12",
    "close": 6009.0,
    "volume": 23476,
    "contract": "200311"
  },
  {
    "date": "2003-11-13",
    "close": 6072.0,
    "volume": 25553,
    "contract": "200311"
  },
  {
    "date": "2003-11-14",
    "close": 6058.0,
    "volume": 22455,
    "contract": "200311"
  },
  {
    "date": "2003-11-17",
    "close": 5978.0,
    "volume": 24092,
    "contract": "200311"
  },
  {
    "date": "2003-11-18",
    "close": 5985.0,
    "volume": 19621,
    "contract": "200311"
  },
  {
    "date": "2003-11-19",
    "close": 5865.0,
    "volume": 19592,
    "contract": "200311"
  },
  {
    "date": "2003-11-20",
    "close": 5898.0,
    "volume": 28598,
    "contract": "200312"
  },
  {
    "date": "2003-11-21",
    "close": 5862.0,
    "volume": 28997,
    "contract": "200312"
  },
  {
    "date": "2003-11-24",
    "close": 5850.0,
    "volume": 15635,
    "contract": "200312"
  },
  {
    "date": "2003-11-25",
    "close": 5888.0,
    "volume": 26658,
    "contract": "200312"
  },
  {
    "date": "2003-11-26",
    "close": 5904.0,
    "volume": 14552,
    "contract": "200312"
  },
  {
    "date": "2003-11-27",
    "close": 5818.0,
    "volume": 31806,
    "contract": "200312"
  },
  {
    "date": "2003-11-28",
    "close": 5808.0,
    "volume": 23855,
    "contract": "200312"
  },
  {
    "date": "2003-12-01",
    "close": 5914.0,
    "volume": 35120,
    "contract": "200312"
  },
  {
    "date": "2003-12-02",
    "close": 5930.0,
    "volume": 22367,
    "contract": "200312"
  },
  {
    "date": "2003-12-03",
    "close": 5908.0,
    "volume": 19160,
    "contract": "200312"
  },
  {
    "date": "2003-12-04",
    "close": 5934.0,
    "volume": 24327,
    "contract": "200312"
  },
  {
    "date": "2003-12-05",
    "close": 5904.0,
    "volume": 20587,
    "contract": "200312"
  },
  {
    "date": "2003-12-08",
    "close": 5847.0,
    "volume": 17369,
    "contract": "200312"
  },
  {
    "date": "2003-12-09",
    "close": 5873.0,
    "volume": 18817,
    "contract": "200312"
  },
  {
    "date": "2003-12-10",
    "close": 5830.0,
    "volume": 19837,
    "contract": "200312"
  },
  {
    "date": "2003-12-11",
    "close": 5890.0,
    "volume": 19516,
    "contract": "200312"
  },
  {
    "date": "2003-12-12",
    "close": 5885.0,
    "volume": 23749,
    "contract": "200312"
  },
  {
    "date": "2003-12-15",
    "close": 5968.0,
    "volume": 22083,
    "contract": "200312"
  },
  {
    "date": "2003-12-16",
    "close": 5901.0,
    "volume": 15626,
    "contract": "200312"
  },
  {
    "date": "2003-12-17",
    "close": 5750.0,
    "volume": 18191,
    "contract": "200312"
  },
  {
    "date": "2003-12-18",
    "close": 5780.0,
    "volume": 19273,
    "contract": "200401"
  },
  {
    "date": "2003-12-19",
    "close": 5800.0,
    "volume": 24275,
    "contract": "200401"
  },
  {
    "date": "2003-12-22",
    "close": 5838.0,
    "volume": 28628,
    "contract": "200401"
  },
  {
    "date": "2003-12-23",
    "close": 5838.0,
    "volume": 14754,
    "contract": "200401"
  },
  {
    "date": "2003-12-24",
    "close": 5864.0,
    "volume": 28125,
    "contract": "200401"
  },
  {
    "date": "2003-12-25",
    "close": 5860.0,
    "volume": 17483,
    "contract": "200401"
  },
  {
    "date": "2003-12-26",
    "close": 5867.0,
    "volume": 17939,
    "contract": "200401"
  },
  {
    "date": "2003-12-29",
    "close": 5836.0,
    "volume": 19041,
    "contract": "200401"
  },
  {
    "date": "2003-12-30",
    "close": 5890.0,
    "volume": 31899,
    "contract": "200401"
  },
  {
    "date": "2003-12-31",
    "close": 5903.0,
    "volume": 16173,
    "contract": "200401"
  },
  {
    "date": "2004-01-02",
    "close": 6056.0,
    "volume": 40341,
    "contract": "200401"
  },
  {
    "date": "2004-01-05",
    "close": 6144.0,
    "volume": 32441,
    "contract": "200401"
  },
  {
    "date": "2004-01-06",
    "close": 6160.0,
    "volume": 27231,
    "contract": "200401"
  },
  {
    "date": "2004-01-07",
    "close": 6174.0,
    "volume": 44226,
    "contract": "200401"
  },
  {
    "date": "2004-01-08",
    "close": 6211.0,
    "volume": 26881,
    "contract": "200401"
  },
  {
    "date": "2004-01-09",
    "close": 6270.0,
    "volume": 32733,
    "contract": "200401"
  },
  {
    "date": "2004-01-12",
    "close": 6275.0,
    "volume": 16269,
    "contract": "200401"
  },
  {
    "date": "2004-01-13",
    "close": 6254.0,
    "volume": 24588,
    "contract": "200401"
  },
  {
    "date": "2004-01-14",
    "close": 6325.0,
    "volume": 33201,
    "contract": "200401"
  },
  {
    "date": "2004-01-15",
    "close": 6300.0,
    "volume": 18597,
    "contract": "200401"
  },
  {
    "date": "2004-01-16",
    "close": 6285.0,
    "volume": 17175,
    "contract": "200401"
  },
  {
    "date": "2004-01-27",
    "close": 6370.0,
    "volume": 15780,
    "contract": "200401"
  },
  {
    "date": "2004-01-28",
    "close": 6367.0,
    "volume": 24206,
    "contract": "200402"
  },
  {
    "date": "2004-01-29",
    "close": 6331.0,
    "volume": 29565,
    "contract": "200402"
  },
  {
    "date": "2004-01-30",
    "close": 6381.0,
    "volume": 24340,
    "contract": "200402"
  },
  {
    "date": "2004-02-02",
    "close": 6330.0,
    "volume": 24702,
    "contract": "200402"
  },
  {
    "date": "2004-02-03",
    "close": 6259.0,
    "volume": 28982,
    "contract": "200402"
  },
  {
    "date": "2004-02-04",
    "close": 6235.0,
    "volume": 20372,
    "contract": "200402"
  },
  {
    "date": "2004-02-05",
    "close": 6285.0,
    "volume": 33174,
    "contract": "200402"
  },
  {
    "date": "2004-02-06",
    "close": 6365.0,
    "volume": 38274,
    "contract": "200402"
  },
  {
    "date": "2004-02-09",
    "close": 6470.0,
    "volume": 28973,
    "contract": "200402"
  },
  {
    "date": "2004-02-10",
    "close": 6475.0,
    "volume": 27112,
    "contract": "200402"
  },
  {
    "date": "2004-02-11",
    "close": 6458.0,
    "volume": 29140,
    "contract": "200402"
  },
  {
    "date": "2004-02-12",
    "close": 6440.0,
    "volume": 70687,
    "contract": "200402"
  },
  {
    "date": "2004-02-13",
    "close": 6565.0,
    "volume": 41895,
    "contract": "200402"
  },
  {
    "date": "2004-02-16",
    "close": 6571.0,
    "volume": 22088,
    "contract": "200402"
  },
  {
    "date": "2004-02-17",
    "close": 6615.0,
    "volume": 18516,
    "contract": "200402"
  },
  {
    "date": "2004-02-18",
    "close": 6615.0,
    "volume": 12416,
    "contract": "200402"
  },
  {
    "date": "2004-02-19",
    "close": 6716.0,
    "volume": 33803,
    "contract": "200403"
  },
  {
    "date": "2004-02-20",
    "close": 6696.0,
    "volume": 20909,
    "contract": "200403"
  },
  {
    "date": "2004-02-23",
    "close": 6703.0,
    "volume": 28061,
    "contract": "200403"
  },
  {
    "date": "2004-02-24",
    "close": 6643.0,
    "volume": 30466,
    "contract": "200403"
  },
  {
    "date": "2004-02-25",
    "close": 6685.0,
    "volume": 25952,
    "contract": "200403"
  },
  {
    "date": "2004-02-26",
    "close": 6735.0,
    "volume": 29217,
    "contract": "200403"
  },
  {
    "date": "2004-02-27",
    "close": 6802.0,
    "volume": 27525,
    "contract": "200403"
  },
  {
    "date": "2004-03-01",
    "close": 6968.0,
    "volume": 38023,
    "contract": "200403"
  },
  {
    "date": "2004-03-02",
    "close": 7055.0,
    "volume": 40357,
    "contract": "200403"
  },
  {
    "date": "2004-03-03",
    "close": 7012.0,
    "volume": 31199,
    "contract": "200403"
  },
  {
    "date": "2004-03-04",
    "close": 7150.0,
    "volume": 43307,
    "contract": "200403"
  },
  {
    "date": "2004-03-05",
    "close": 7075.0,
    "volume": 61841,
    "contract": "200403"
  },
  {
    "date": "2004-03-08",
    "close": 6979.0,
    "volume": 42972,
    "contract": "200403"
  },
  {
    "date": "2004-03-09",
    "close": 7051.0,
    "volume": 35888,
    "contract": "200403"
  },
  {
    "date": "2004-03-10",
    "close": 6930.0,
    "volume": 45940,
    "contract": "200403"
  },
  {
    "date": "2004-03-11",
    "close": 6922.0,
    "volume": 37322,
    "contract": "200403"
  },
  {
    "date": "2004-03-12",
    "close": 6807.0,
    "volume": 32126,
    "contract": "200403"
  },
  {
    "date": "2004-03-15",
    "close": 6563.0,
    "volume": 43871,
    "contract": "200403"
  },
  {
    "date": "2004-03-16",
    "close": 6555.0,
    "volume": 39641,
    "contract": "200403"
  },
  {
    "date": "2004-03-17",
    "close": 6565.0,
    "volume": 17802,
    "contract": "200403"
  },
  {
    "date": "2004-03-18",
    "close": 6845.0,
    "volume": 55474,
    "contract": "200404"
  },
  {
    "date": "2004-03-19",
    "close": 6830.0,
    "volume": 39241,
    "contract": "200404"
  },
  {
    "date": "2004-03-22",
    "close": 6352.0,
    "volume": 4625,
    "contract": "200404"
  },
  {
    "date": "2004-03-23",
    "close": 6055.0,
    "volume": 87984,
    "contract": "200404"
  },
  {
    "date": "2004-03-24",
    "close": 6180.0,
    "volume": 52641,
    "contract": "200404"
  },
  {
    "date": "2004-03-25",
    "close": 6135.0,
    "volume": 36784,
    "contract": "200404"
  },
  {
    "date": "2004-03-26",
    "close": 6125.0,
    "volume": 43009,
    "contract": "200404"
  },
  {
    "date": "2004-03-29",
    "close": 6471.0,
    "volume": 42481,
    "contract": "200404"
  },
  {
    "date": "2004-03-30",
    "close": 6487.0,
    "volume": 33745,
    "contract": "200404"
  },
  {
    "date": "2004-03-31",
    "close": 6480.0,
    "volume": 42089,
    "contract": "200404"
  },
  {
    "date": "2004-04-01",
    "close": 6471.0,
    "volume": 30174,
    "contract": "200404"
  },
  {
    "date": "2004-04-02",
    "close": 6493.0,
    "volume": 28722,
    "contract": "200404"
  },
  {
    "date": "2004-04-05",
    "close": 6692.0,
    "volume": 49188,
    "contract": "200404"
  },
  {
    "date": "2004-04-06",
    "close": 6660.0,
    "volume": 35139,
    "contract": "200404"
  },
  {
    "date": "2004-04-07",
    "close": 6665.0,
    "volume": 21235,
    "contract": "200404"
  },
  {
    "date": "2004-04-08",
    "close": 6681.0,
    "volume": 19851,
    "contract": "200404"
  },
  {
    "date": "2004-04-09",
    "close": 6625.0,
    "volume": 27819,
    "contract": "200404"
  },
  {
    "date": "2004-04-12",
    "close": 6800.0,
    "volume": 39532,
    "contract": "200404"
  },
  {
    "date": "2004-04-13",
    "close": 6823.0,
    "volume": 27464,
    "contract": "200404"
  },
  {
    "date": "2004-04-14",
    "close": 6920.0,
    "volume": 41317,
    "contract": "200404"
  },
  {
    "date": "2004-04-15",
    "close": 6749.0,
    "volume": 50877,
    "contract": "200404"
  },
  {
    "date": "2004-04-16",
    "close": 6828.0,
    "volume": 38826,
    "contract": "200404"
  },
  {
    "date": "2004-04-19",
    "close": 6809.0,
    "volume": 27262,
    "contract": "200404"
  },
  {
    "date": "2004-04-20",
    "close": 6839.0,
    "volume": 21650,
    "contract": "200404"
  },
  {
    "date": "2004-04-21",
    "close": 6824.0,
    "volume": 10577,
    "contract": "200404"
  },
  {
    "date": "2004-04-22",
    "close": 6718.0,
    "volume": 65604,
    "contract": "200405"
  },
  {
    "date": "2004-04-23",
    "close": 6750.0,
    "volume": 30451,
    "contract": "200405"
  },
  {
    "date": "2004-04-26",
    "close": 6720.0,
    "volume": 21922,
    "contract": "200405"
  },
  {
    "date": "2004-04-27",
    "close": 6680.0,
    "volume": 40628,
    "contract": "200405"
  },
  {
    "date": "2004-04-28",
    "close": 6605.0,
    "volume": 33440,
    "contract": "200405"
  },
  {
    "date": "2004-04-29",
    "close": 6399.0,
    "volume": 55098,
    "contract": "200405"
  },
  {
    "date": "2004-04-30",
    "close": 6020.0,
    "volume": 73743,
    "contract": "200405"
  },
  {
    "date": "2004-05-03",
    "close": 6017.0,
    "volume": 40742,
    "contract": "200405"
  },
  {
    "date": "2004-05-04",
    "close": 6133.0,
    "volume": 39031,
    "contract": "200405"
  },
  {
    "date": "2004-05-05",
    "close": 5725.0,
    "volume": 64666,
    "contract": "200405"
  },
  {
    "date": "2004-05-06",
    "close": 5849.0,
    "volume": 61689,
    "contract": "200405"
  },
  {
    "date": "2004-05-07",
    "close": 5979.0,
    "volume": 43348,
    "contract": "200405"
  },
  {
    "date": "2004-05-10",
    "close": 5751.0,
    "volume": 40211,
    "contract": "200405"
  },
  {
    "date": "2004-05-11",
    "close": 5858.0,
    "volume": 55208,
    "contract": "200405"
  },
  {
    "date": "2004-05-12",
    "close": 5942.0,
    "volume": 38234,
    "contract": "200405"
  },
  {
    "date": "2004-05-13",
    "close": 5890.0,
    "volume": 38907,
    "contract": "200405"
  },
  {
    "date": "2004-05-14",
    "close": 5745.0,
    "volume": 45489,
    "contract": "200405"
  },
  {
    "date": "2004-05-17",
    "close": 5358.0,
    "volume": 45298,
    "contract": "200405"
  },
  {
    "date": "2004-05-18",
    "close": 5523.0,
    "volume": 31290,
    "contract": "200405"
  },
  {
    "date": "2004-05-19",
    "close": 5891.0,
    "volume": 17440,
    "contract": "200405"
  },
  {
    "date": "2004-05-20",
    "close": 5685.0,
    "volume": 64609,
    "contract": "200406"
  },
  {
    "date": "2004-05-21",
    "close": 5840.0,
    "volume": 53127,
    "contract": "200406"
  },
  {
    "date": "2004-05-24",
    "close": 5871.0,
    "volume": 46743,
    "contract": "200406"
  },
  {
    "date": "2004-05-25",
    "close": 5841.0,
    "volume": 38556,
    "contract": "200406"
  },
  {
    "date": "2004-05-26",
    "close": 5990.0,
    "volume": 39341,
    "contract": "200406"
  },
  {
    "date": "2004-05-27",
    "close": 6001.0,
    "volume": 26676,
    "contract": "200406"
  },
  {
    "date": "2004-05-28",
    "close": 6043.0,
    "volume": 29754,
    "contract": "200406"
  },
  {
    "date": "2004-05-31",
    "close": 5928.0,
    "volume": 35231,
    "contract": "200406"
  },
  {
    "date": "2004-06-01",
    "close": 5906.0,
    "volume": 41623,
    "contract": "200406"
  },
  {
    "date": "2004-06-02",
    "close": 5790.0,
    "volume": 32455,
    "contract": "200406"
  },
  {
    "date": "2004-06-03",
    "close": 5580.0,
    "volume": 47982,
    "contract": "200406"
  },
  {
    "date": "2004-06-04",
    "close": 5607.0,
    "volume": 39913,
    "contract": "200406"
  },
  {
    "date": "2004-06-07",
    "close": 5890.0,
    "volume": 45734,
    "contract": "200406"
  },
  {
    "date": "2004-06-08",
    "close": 5981.0,
    "volume": 39146,
    "contract": "200406"
  },
  {
    "date": "2004-06-09",
    "close": 5960.0,
    "volume": 25188,
    "contract": "200406"
  },
  {
    "date": "2004-06-10",
    "close": 5840.0,
    "volume": 43557,
    "contract": "200406"
  },
  {
    "date": "2004-06-11",
    "close": 5715.0,
    "volume": 33329,
    "contract": "200406"
  },
  {
    "date": "2004-06-14",
    "close": 5540.0,
    "volume": 38014,
    "contract": "200406"
  },
  {
    "date": "2004-06-15",
    "close": 5604.0,
    "volume": 30121,
    "contract": "200406"
  },
  {
    "date": "2004-06-16",
    "close": 5560.0,
    "volume": 17950,
    "contract": "200406"
  },
  {
    "date": "2004-06-17",
    "close": 5607.0,
    "volume": 62878,
    "contract": "200407"
  },
  {
    "date": "2004-06-18",
    "close": 5463.0,
    "volume": 45800,
    "contract": "200407"
  },
  {
    "date": "2004-06-21",
    "close": 5538.0,
    "volume": 43530,
    "contract": "200407"
  },
  {
    "date": "2004-06-23",
    "close": 5660.0,
    "volume": 46538,
    "contract": "200407"
  },
  {
    "date": "2004-06-24",
    "close": 5712.0,
    "volume": 33947,
    "contract": "200407"
  },
  {
    "date": "2004-06-25",
    "close": 5735.0,
    "volume": 35556,
    "contract": "200407"
  },
  {
    "date": "2004-06-28",
    "close": 5615.0,
    "volume": 35960,
    "contract": "200407"
  },
  {
    "date": "2004-06-29",
    "close": 5644.0,
    "volume": 29181,
    "contract": "200407"
  },
  {
    "date": "2004-06-30",
    "close": 5750.0,
    "volume": 40247,
    "contract": "200407"
  },
  {
    "date": "2004-07-01",
    "close": 5765.0,
    "volume": 26725,
    "contract": "200407"
  },
  {
    "date": "2004-07-02",
    "close": 5655.0,
    "volume": 25931,
    "contract": "200407"
  },
  {
    "date": "2004-07-05",
    "close": 5597.0,
    "volume": 24339,
    "contract": "200407"
  },
  {
    "date": "2004-07-06",
    "close": 5667.0,
    "volume": 27542,
    "contract": "200407"
  },
  {
    "date": "2004-07-07",
    "close": 5650.0,
    "volume": 37028,
    "contract": "200407"
  },
  {
    "date": "2004-07-08",
    "close": 5634.0,
    "volume": 26283,
    "contract": "200407"
  },
  {
    "date": "2004-07-09",
    "close": 5707.0,
    "volume": 38772,
    "contract": "200407"
  },
  {
    "date": "2004-07-12",
    "close": 5707.0,
    "volume": 22358,
    "contract": "200407"
  },
  {
    "date": "2004-07-13",
    "close": 5661.0,
    "volume": 19661,
    "contract": "200407"
  },
  {
    "date": "2004-07-14",
    "close": 5608.0,
    "volume": 32520,
    "contract": "200407"
  },
  {
    "date": "2004-07-15",
    "close": 5550.0,
    "volume": 33895,
    "contract": "200407"
  },
  {
    "date": "2004-07-16",
    "close": 5505.0,
    "volume": 28871,
    "contract": "200407"
  },
  {
    "date": "2004-07-19",
    "close": 5511.0,
    "volume": 27613,
    "contract": "200407"
  },
  {
    "date": "2004-07-20",
    "close": 5300.0,
    "volume": 25758,
    "contract": "200407"
  },
  {
    "date": "2004-07-21",
    "close": 5418.0,
    "volume": 13849,
    "contract": "200407"
  },
  {
    "date": "2004-07-22",
    "close": 5291.0,
    "volume": 34720,
    "contract": "200408"
  },
  {
    "date": "2004-07-23",
    "close": 5285.0,
    "volume": 29972,
    "contract": "200408"
  },
  {
    "date": "2004-07-26",
    "close": 5275.0,
    "volume": 19390,
    "contract": "200408"
  },
  {
    "date": "2004-07-27",
    "close": 5353.0,
    "volume": 44806,
    "contract": "200408"
  },
  {
    "date": "2004-07-28",
    "close": 5360.0,
    "volume": 27778,
    "contract": "200408"
  },
  {
    "date": "2004-07-29",
    "close": 5297.0,
    "volume": 29294,
    "contract": "200408"
  },
  {
    "date": "2004-07-30",
    "close": 5356.0,
    "volume": 33673,
    "contract": "200408"
  },
  {
    "date": "2004-08-02",
    "close": 5280.0,
    "volume": 25760,
    "contract": "200408"
  },
  {
    "date": "2004-08-03",
    "close": 5282.0,
    "volume": 23697,
    "contract": "200408"
  },
  {
    "date": "2004-08-04",
    "close": 5254.0,
    "volume": 25644,
    "contract": "200408"
  },
  {
    "date": "2004-08-05",
    "close": 5399.0,
    "volume": 51427,
    "contract": "200408"
  },
  {
    "date": "2004-08-06",
    "close": 5369.0,
    "volume": 30009,
    "contract": "200408"
  },
  {
    "date": "2004-08-09",
    "close": 5380.0,
    "volume": 27565,
    "contract": "200408"
  },
  {
    "date": "2004-08-10",
    "close": 5364.0,
    "volume": 23213,
    "contract": "200408"
  },
  {
    "date": "2004-08-11",
    "close": 5325.0,
    "volume": 33885,
    "contract": "200408"
  },
  {
    "date": "2004-08-12",
    "close": 5348.0,
    "volume": 19967,
    "contract": "200408"
  },
  {
    "date": "2004-08-13",
    "close": 5356.0,
    "volume": 34742,
    "contract": "200408"
  },
  {
    "date": "2004-08-16",
    "close": 5331.0,
    "volume": 14680,
    "contract": "200408"
  },
  {
    "date": "2004-08-17",
    "close": 5339.0,
    "volume": 18196,
    "contract": "200408"
  },
  {
    "date": "2004-08-18",
    "close": 5423.0,
    "volume": 18011,
    "contract": "200408"
  },
  {
    "date": "2004-08-19",
    "close": 5528.0,
    "volume": 40525,
    "contract": "200409"
  },
  {
    "date": "2004-08-20",
    "close": 5583.0,
    "volume": 36137,
    "contract": "200409"
  },
  {
    "date": "2004-08-23",
    "close": 5606.0,
    "volume": 23079,
    "contract": "200409"
  },
  {
    "date": "2004-08-26",
    "close": 5783.0,
    "volume": 35392,
    "contract": "200409"
  },
  {
    "date": "2004-08-27",
    "close": 5810.0,
    "volume": 23284,
    "contract": "200409"
  },
  {
    "date": "2004-08-30",
    "close": 5785.0,
    "volume": 18023,
    "contract": "200409"
  },
  {
    "date": "2004-08-31",
    "close": 5763.0,
    "volume": 52609,
    "contract": "200409"
  },
  {
    "date": "2004-09-01",
    "close": 5856.0,
    "volume": 34567,
    "contract": "200409"
  },
  {
    "date": "2004-09-02",
    "close": 5840.0,
    "volume": 26755,
    "contract": "200409"
  },
  {
    "date": "2004-09-03",
    "close": 5762.0,
    "volume": 45361,
    "contract": "200409"
  },
  {
    "date": "2004-09-06",
    "close": 5780.0,
    "volume": 28759,
    "contract": "200409"
  },
  {
    "date": "2004-09-07",
    "close": 5840.0,
    "volume": 33963,
    "contract": "200409"
  },
  {
    "date": "2004-09-08",
    "close": 5828.0,
    "volume": 31458,
    "contract": "200409"
  },
  {
    "date": "2004-09-09",
    "close": 5843.0,
    "volume": 23185,
    "contract": "200409"
  },
  {
    "date": "2004-09-10",
    "close": 5841.0,
    "volume": 28530,
    "contract": "200409"
  },
  {
    "date": "2004-09-13",
    "close": 5930.0,
    "volume": 24950,
    "contract": "200409"
  },
  {
    "date": "2004-09-14",
    "close": 5935.0,
    "volume": 19073,
    "contract": "200409"
  },
  {
    "date": "2004-09-15",
    "close": 5879.0,
    "volume": 13081,
    "contract": "200409"
  },
  {
    "date": "2004-09-16",
    "close": 5868.0,
    "volume": 27198,
    "contract": "200410"
  },
  {
    "date": "2004-09-17",
    "close": 5797.0,
    "volume": 26662,
    "contract": "200410"
  },
  {
    "date": "2004-09-20",
    "close": 5840.0,
    "volume": 27601,
    "contract": "200410"
  },
  {
    "date": "2004-09-21",
    "close": 5945.0,
    "volume": 37292,
    "contract": "200410"
  },
  {
    "date": "2004-09-22",
    "close": 5936.0,
    "volume": 19250,
    "contract": "200410"
  },
  {
    "date": "2004-09-23",
    "close": 5917.0,
    "volume": 19885,
    "contract": "200410"
  },
  {
    "date": "2004-09-24",
    "close": 5888.0,
    "volume": 27518,
    "contract": "200410"
  },
  {
    "date": "2004-09-27",
    "close": 5870.0,
    "volume": 16317,
    "contract": "200410"
  },
  {
    "date": "2004-09-29",
    "close": 5857.0,
    "volume": 21886,
    "contract": "200410"
  },
  {
    "date": "2004-09-30",
    "close": 5889.0,
    "volume": 27124,
    "contract": "200410"
  },
  {
    "date": "2004-10-01",
    "close": 5947.0,
    "volume": 33218,
    "contract": "200410"
  },
  {
    "date": "2004-10-04",
    "close": 6105.0,
    "volume": 31836,
    "contract": "200410"
  },
  {
    "date": "2004-10-05",
    "close": 6123.0,
    "volume": 15690,
    "contract": "200410"
  },
  {
    "date": "2004-10-06",
    "close": 6088.0,
    "volume": 39947,
    "contract": "200410"
  },
  {
    "date": "2004-10-07",
    "close": 6134.0,
    "volume": 25574,
    "contract": "200410"
  },
  {
    "date": "2004-10-08",
    "close": 6135.0,
    "volume": 18294,
    "contract": "200410"
  },
  {
    "date": "2004-10-11",
    "close": 6118.0,
    "volume": 25498,
    "contract": "200410"
  },
  {
    "date": "2004-10-12",
    "close": 5991.0,
    "volume": 32982,
    "contract": "200410"
  },
  {
    "date": "2004-10-13",
    "close": 5994.0,
    "volume": 23959,
    "contract": "200410"
  },
  {
    "date": "2004-10-14",
    "close": 5850.0,
    "volume": 40855,
    "contract": "200410"
  },
  {
    "date": "2004-10-15",
    "close": 5816.0,
    "volume": 29951,
    "contract": "200410"
  },
  {
    "date": "2004-10-18",
    "close": 5779.0,
    "volume": 18174,
    "contract": "200410"
  },
  {
    "date": "2004-10-19",
    "close": 5837.0,
    "volume": 23608,
    "contract": "200410"
  },
  {
    "date": "2004-10-20",
    "close": 5775.0,
    "volume": 15247,
    "contract": "200410"
  },
  {
    "date": "2004-10-21",
    "close": 5779.0,
    "volume": 34435,
    "contract": "200411"
  },
  {
    "date": "2004-10-22",
    "close": 5796.0,
    "volume": 25199,
    "contract": "200411"
  },
  {
    "date": "2004-10-26",
    "close": 5660.0,
    "volume": 26563,
    "contract": "200411"
  },
  {
    "date": "2004-10-27",
    "close": 5616.0,
    "volume": 30301,
    "contract": "200411"
  },
  {
    "date": "2004-10-28",
    "close": 5729.0,
    "volume": 31206,
    "contract": "200411"
  },
  {
    "date": "2004-10-29",
    "close": 5691.0,
    "volume": 21774,
    "contract": "200411"
  },
  {
    "date": "2004-11-01",
    "close": 5617.0,
    "volume": 24525,
    "contract": "200411"
  },
  {
    "date": "2004-11-02",
    "close": 5751.0,
    "volume": 31618,
    "contract": "200411"
  },
  {
    "date": "2004-11-03",
    "close": 5830.0,
    "volume": 43060,
    "contract": "200411"
  },
  {
    "date": "2004-11-04",
    "close": 5836.0,
    "volume": 26726,
    "contract": "200411"
  },
  {
    "date": "2004-11-05",
    "close": 5920.0,
    "volume": 30446,
    "contract": "200411"
  },
  {
    "date": "2004-11-08",
    "close": 5909.0,
    "volume": 17358,
    "contract": "200411"
  },
  {
    "date": "2004-11-09",
    "close": 5943.0,
    "volume": 27268,
    "contract": "200411"
  },
  {
    "date": "2004-11-10",
    "close": 5960.0,
    "volume": 31408,
    "contract": "200411"
  },
  {
    "date": "2004-11-11",
    "close": 5868.0,
    "volume": 29323,
    "contract": "200411"
  },
  {
    "date": "2004-11-12",
    "close": 5935.0,
    "volume": 29339,
    "contract": "200411"
  },
  {
    "date": "2004-11-15",
    "close": 5941.0,
    "volume": 24579,
    "contract": "200411"
  },
  {
    "date": "2004-11-16",
    "close": 5929.0,
    "volume": 19583,
    "contract": "200411"
  },
  {
    "date": "2004-11-17",
    "close": 6040.0,
    "volume": 18339,
    "contract": "200411"
  },
  {
    "date": "2004-11-18",
    "close": 6072.0,
    "volume": 29707,
    "contract": "200412"
  },
  {
    "date": "2004-11-19",
    "close": 6056.0,
    "volume": 22611,
    "contract": "200412"
  },
  {
    "date": "2004-11-22",
    "close": 5835.0,
    "volume": 44598,
    "contract": "200412"
  },
  {
    "date": "2004-11-23",
    "close": 5842.0,
    "volume": 33263,
    "contract": "200412"
  },
  {
    "date": "2004-11-24",
    "close": 5905.0,
    "volume": 31576,
    "contract": "200412"
  },
  {
    "date": "2004-11-25",
    "close": 5870.0,
    "volume": 28150,
    "contract": "200412"
  },
  {
    "date": "2004-11-26",
    "close": 5740.0,
    "volume": 53585,
    "contract": "200412"
  },
  {
    "date": "2004-11-29",
    "close": 5810.0,
    "volume": 25406,
    "contract": "200412"
  },
  {
    "date": "2004-11-30",
    "close": 5809.0,
    "volume": 44352,
    "contract": "200412"
  },
  {
    "date": "2004-12-01",
    "close": 5770.0,
    "volume": 32051,
    "contract": "200412"
  },
  {
    "date": "2004-12-02",
    "close": 5855.0,
    "volume": 28912,
    "contract": "200412"
  },
  {
    "date": "2004-12-03",
    "close": 5880.0,
    "volume": 26316,
    "contract": "200412"
  },
  {
    "date": "2004-12-06",
    "close": 5883.0,
    "volume": 25694,
    "contract": "200412"
  },
  {
    "date": "2004-12-07",
    "close": 5890.0,
    "volume": 15602,
    "contract": "200412"
  },
  {
    "date": "2004-12-08",
    "close": 5880.0,
    "volume": 17107,
    "contract": "200412"
  },
  {
    "date": "2004-12-09",
    "close": 5880.0,
    "volume": 17047,
    "contract": "200412"
  },
  {
    "date": "2004-12-10",
    "close": 5850.0,
    "volume": 16740,
    "contract": "200412"
  },
  {
    "date": "2004-12-13",
    "close": 5871.0,
    "volume": 51128,
    "contract": "200412"
  },
  {
    "date": "2004-12-14",
    "close": 5901.0,
    "volume": 14177,
    "contract": "200412"
  },
  {
    "date": "2004-12-15",
    "close": 6017.0,
    "volume": 14600,
    "contract": "200412"
  },
  {
    "date": "2004-12-16",
    "close": 6020.0,
    "volume": 21458,
    "contract": "200501"
  },
  {
    "date": "2004-12-17",
    "close": 6019.0,
    "volume": 13086,
    "contract": "200501"
  },
  {
    "date": "2004-12-20",
    "close": 5962.0,
    "volume": 25321,
    "contract": "200501"
  },
  {
    "date": "2004-12-21",
    "close": 5978.0,
    "volume": 13598,
    "contract": "200501"
  },
  {
    "date": "2004-12-22",
    "close": 6025.0,
    "volume": 30431,
    "contract": "200501"
  },
  {
    "date": "2004-12-23",
    "close": 6002.0,
    "volume": 23284,
    "contract": "200501"
  },
  {
    "date": "2004-12-24",
    "close": 6032.0,
    "volume": 23814,
    "contract": "200501"
  },
  {
    "date": "2004-12-27",
    "close": 6016.0,
    "volume": 16581,
    "contract": "200501"
  },
  {
    "date": "2004-12-28",
    "close": 6020.0,
    "volume": 13824,
    "contract": "200501"
  },
  {
    "date": "2004-12-29",
    "close": 6118.0,
    "volume": 29184,
    "contract": "200501"
  },
  {
    "date": "2004-12-30",
    "close": 6115.0,
    "volume": 12968,
    "contract": "200501"
  },
  {
    "date": "2004-12-31",
    "close": 6188.0,
    "volume": 29454,
    "contract": "200501"
  },
  {
    "date": "2005-01-03",
    "close": 6174.0,
    "volume": 20319,
    "contract": "200501"
  },
  {
    "date": "2005-01-04",
    "close": 6080.0,
    "volume": 38182,
    "contract": "200501"
  },
  {
    "date": "2005-01-05",
    "close": 6013.0,
    "volume": 25857,
    "contract": "200501"
  },
  {
    "date": "2005-01-06",
    "close": 6017.0,
    "volume": 14673,
    "contract": "200501"
  },
  {
    "date": "2005-01-07",
    "close": 5965.0,
    "volume": 37209,
    "contract": "200501"
  },
  {
    "date": "2005-01-10",
    "close": 5987.0,
    "volume": 14801,
    "contract": "200501"
  },
  {
    "date": "2005-01-11",
    "close": 6003.0,
    "volume": 22853,
    "contract": "200501"
  },
  {
    "date": "2005-01-12",
    "close": 5901.0,
    "volume": 38093,
    "contract": "200501"
  },
  {
    "date": "2005-01-13",
    "close": 5880.0,
    "volume": 33987,
    "contract": "200501"
  },
  {
    "date": "2005-01-14",
    "close": 5893.0,
    "volume": 31644,
    "contract": "200501"
  },
  {
    "date": "2005-01-17",
    "close": 5954.0,
    "volume": 25354,
    "contract": "200501"
  },
  {
    "date": "2005-01-18",
    "close": 5945.0,
    "volume": 16502,
    "contract": "200501"
  },
  {
    "date": "2005-01-19",
    "close": 5885.0,
    "volume": 19517,
    "contract": "200501"
  },
  {
    "date": "2005-01-20",
    "close": 5879.0,
    "volume": 39970,
    "contract": "200502"
  },
  {
    "date": "2005-01-21",
    "close": 5869.0,
    "volume": 28331,
    "contract": "200502"
  },
  {
    "date": "2005-01-24",
    "close": 5805.0,
    "volume": 31954,
    "contract": "200502"
  },
  {
    "date": "2005-01-25",
    "close": 5810.0,
    "volume": 33540,
    "contract": "200502"
  },
  {
    "date": "2005-01-26",
    "close": 5840.0,
    "volume": 25518,
    "contract": "200502"
  },
  {
    "date": "2005-01-27",
    "close": 5834.0,
    "volume": 18149,
    "contract": "200502"
  },
  {
    "date": "2005-01-28",
    "close": 5874.0,
    "volume": 32141,
    "contract": "200502"
  },
  {
    "date": "2005-01-31",
    "close": 5982.0,
    "volume": 41876,
    "contract": "200502"
  },
  {
    "date": "2005-02-01",
    "close": 5980.0,
    "volume": 18624,
    "contract": "200502"
  },
  {
    "date": "2005-02-02",
    "close": 6023.0,
    "volume": 35326,
    "contract": "200502"
  },
  {
    "date": "2005-02-03",
    "close": 6045.0,
    "volume": 14887,
    "contract": "200502"
  },
  {
    "date": "2005-02-14",
    "close": 6129.0,
    "volume": 22508,
    "contract": "200502"
  },
  {
    "date": "2005-02-15",
    "close": 6123.0,
    "volume": 11655,
    "contract": "200502"
  },
  {
    "date": "2005-02-16",
    "close": 6128.0,
    "volume": 14578,
    "contract": "200502"
  },
  {
    "date": "2005-02-17",
    "close": 6078.0,
    "volume": 31930,
    "contract": "200503"
  },
  {
    "date": "2005-02-18",
    "close": 6120.0,
    "volume": 24824,
    "contract": "200503"
  },
  {
    "date": "2005-02-21",
    "close": 6144.0,
    "volume": 21839,
    "contract": "200503"
  },
  {
    "date": "2005-02-22",
    "close": 6097.0,
    "volume": 23003,
    "contract": "200503"
  },
  {
    "date": "2005-02-23",
    "close": 6114.0,
    "volume": 30573,
    "contract": "200503"
  },
  {
    "date": "2005-02-24",
    "close": 6120.0,
    "volume": 31205,
    "contract": "200503"
  },
  {
    "date": "2005-02-25",
    "close": 6219.0,
    "volume": 34658,
    "contract": "200503"
  },
  {
    "date": "2005-03-01",
    "close": 6250.0,
    "volume": 21190,
    "contract": "200503"
  },
  {
    "date": "2005-03-02",
    "close": 6200.0,
    "volume": 27486,
    "contract": "200503"
  },
  {
    "date": "2005-03-03",
    "close": 6204.0,
    "volume": 32997,
    "contract": "200503"
  },
  {
    "date": "2005-03-04",
    "close": 6198.0,
    "volume": 21080,
    "contract": "200503"
  },
  {
    "date": "2005-03-07",
    "close": 6231.0,
    "volume": 22438,
    "contract": "200503"
  },
  {
    "date": "2005-03-08",
    "close": 6155.0,
    "volume": 37801,
    "contract": "200503"
  },
  {
    "date": "2005-03-09",
    "close": 6198.0,
    "volume": 21598,
    "contract": "200503"
  },
  {
    "date": "2005-03-10",
    "close": 6167.0,
    "volume": 26861,
    "contract": "200503"
  },
  {
    "date": "2005-03-11",
    "close": 6207.0,
    "volume": 26378,
    "contract": "200503"
  },
  {
    "date": "2005-03-14",
    "close": 6160.0,
    "volume": 21332,
    "contract": "200503"
  },
  {
    "date": "2005-03-15",
    "close": 6076.0,
    "volume": 30887,
    "contract": "200503"
  },
  {
    "date": "2005-03-16",
    "close": 6068.0,
    "volume": 8474,
    "contract": "200503"
  },
  {
    "date": "2005-03-17",
    "close": 6015.0,
    "volume": 27887,
    "contract": "200504"
  },
  {
    "date": "2005-03-18",
    "close": 6027.0,
    "volume": 23502,
    "contract": "200504"
  },
  {
    "date": "2005-03-21",
    "close": 6040.0,
    "volume": 20102,
    "contract": "200504"
  },
  {
    "date": "2005-03-22",
    "close": 6008.0,
    "volume": 32667,
    "contract": "200504"
  },
  {
    "date": "2005-03-23",
    "close": 6010.0,
    "volume": 30170,
    "contract": "200504"
  },
  {
    "date": "2005-03-24",
    "close": 6012.0,
    "volume": 23312,
    "contract": "200504"
  },
  {
    "date": "2005-03-25",
    "close": 6050.0,
    "volume": 18475,
    "contract": "200504"
  },
  {
    "date": "2005-03-28",
    "close": 6054.0,
    "volume": 17906,
    "contract": "200504"
  },
  {
    "date": "2005-03-29",
    "close": 5973.0,
    "volume": 34733,
    "contract": "200504"
  },
  {
    "date": "2005-03-30",
    "close": 5975.0,
    "volume": 19723,
    "contract": "200504"
  },
  {
    "date": "2005-03-31",
    "close": 6010.0,
    "volume": 17500,
    "contract": "200504"
  },
  {
    "date": "2005-04-01",
    "close": 6045.0,
    "volume": 31130,
    "contract": "200504"
  },
  {
    "date": "2005-04-04",
    "close": 6025.0,
    "volume": 14928,
    "contract": "200504"
  },
  {
    "date": "2005-04-06",
    "close": 6011.0,
    "volume": 19640,
    "contract": "200504"
  },
  {
    "date": "2005-04-07",
    "close": 5985.0,
    "volume": 25693,
    "contract": "200504"
  },
  {
    "date": "2005-04-08",
    "close": 6010.0,
    "volume": 13226,
    "contract": "200504"
  },
  {
    "date": "2005-04-11",
    "close": 5980.0,
    "volume": 13780,
    "contract": "200504"
  },
  {
    "date": "2005-04-12",
    "close": 5990.0,
    "volume": 14469,
    "contract": "200504"
  },
  {
    "date": "2005-04-13",
    "close": 6007.0,
    "volume": 11354,
    "contract": "200504"
  },
  {
    "date": "2005-04-14",
    "close": 5975.0,
    "volume": 16115,
    "contract": "200504"
  },
  {
    "date": "2005-04-15",
    "close": 5892.0,
    "volume": 23431,
    "contract": "200504"
  },
  {
    "date": "2005-04-18",
    "close": 5707.0,
    "volume": 30992,
    "contract": "200504"
  },
  {
    "date": "2005-04-19",
    "close": 5754.0,
    "volume": 14912,
    "contract": "200504"
  },
  {
    "date": "2005-04-20",
    "close": 5701.0,
    "volume": 12443,
    "contract": "200504"
  },
  {
    "date": "2005-04-21",
    "close": 5688.0,
    "volume": 44013,
    "contract": "200505"
  },
  {
    "date": "2005-04-22",
    "close": 5725.0,
    "volume": 28450,
    "contract": "200505"
  },
  {
    "date": "2005-04-25",
    "close": 5728.0,
    "volume": 13763,
    "contract": "200505"
  },
  {
    "date": "2005-04-26",
    "close": 5765.0,
    "volume": 26541,
    "contract": "200505"
  },
  {
    "date": "2005-04-27",
    "close": 5745.0,
    "volume": 15266,
    "contract": "200505"
  },
  {
    "date": "2005-04-28",
    "close": 5780.0,
    "volume": 29571,
    "contract": "200505"
  },
  {
    "date": "2005-04-29",
    "close": 5770.0,
    "volume": 18029,
    "contract": "200505"
  },
  {
    "date": "2005-05-03",
    "close": 5800.0,
    "volume": 22478,
    "contract": "200505"
  },
  {
    "date": "2005-05-04",
    "close": 5806.0,
    "volume": 19001,
    "contract": "200505"
  },
  {
    "date": "2005-05-05",
    "close": 5902.0,
    "volume": 45967,
    "contract": "200505"
  },
  {
    "date": "2005-05-06",
    "close": 5948.0,
    "volume": 21016,
    "contract": "200505"
  },
  {
    "date": "2005-05-09",
    "close": 5947.0,
    "volume": 16570,
    "contract": "200505"
  },
  {
    "date": "2005-05-10",
    "close": 5925.0,
    "volume": 17027,
    "contract": "200505"
  },
  {
    "date": "2005-05-11",
    "close": 5898.0,
    "volume": 19109,
    "contract": "200505"
  },
  {
    "date": "2005-05-12",
    "close": 5929.0,
    "volume": 15760,
    "contract": "200505"
  },
  {
    "date": "2005-05-13",
    "close": 5986.0,
    "volume": 32107,
    "contract": "200505"
  },
  {
    "date": "2005-05-16",
    "close": 5931.0,
    "volume": 21380,
    "contract": "200505"
  },
  {
    "date": "2005-05-17",
    "close": 5877.0,
    "volume": 20846,
    "contract": "200505"
  },
  {
    "date": "2005-05-18",
    "close": 5880.0,
    "volume": 11369,
    "contract": "200505"
  },
  {
    "date": "2005-05-19",
    "close": 5947.0,
    "volume": 31786,
    "contract": "200506"
  },
  {
    "date": "2005-05-20",
    "close": 5920.0,
    "volume": 18680,
    "contract": "200506"
  },
  {
    "date": "2005-05-23",
    "close": 5878.0,
    "volume": 26949,
    "contract": "200506"
  },
  {
    "date": "2005-05-24",
    "close": 5875.0,
    "volume": 13417,
    "contract": "200506"
  },
  {
    "date": "2005-05-25",
    "close": 5849.0,
    "volume": 38079,
    "contract": "200506"
  },
  {
    "date": "2005-05-26",
    "close": 5899.0,
    "volume": 21920,
    "contract": "200506"
  },
  {
    "date": "2005-05-27",
    "close": 5950.0,
    "volume": 30254,
    "contract": "200506"
  },
  {
    "date": "2005-05-30",
    "close": 5952.0,
    "volume": 17054,
    "contract": "200506"
  },
  {
    "date": "2005-05-31",
    "close": 5943.0,
    "volume": 29235,
    "contract": "200506"
  },
  {
    "date": "2005-06-01",
    "close": 5935.0,
    "volume": 26542,
    "contract": "200506"
  },
  {
    "date": "2005-06-02",
    "close": 5973.0,
    "volume": 30796,
    "contract": "200506"
  },
  {
    "date": "2005-06-03",
    "close": 6038.0,
    "volume": 35747,
    "contract": "200506"
  },
  {
    "date": "2005-06-06",
    "close": 6069.0,
    "volume": 21953,
    "contract": "200506"
  },
  {
    "date": "2005-06-07",
    "close": 6060.0,
    "volume": 17739,
    "contract": "200506"
  },
  {
    "date": "2005-06-08",
    "close": 6131.0,
    "volume": 29611,
    "contract": "200506"
  },
  {
    "date": "2005-06-09",
    "close": 6125.0,
    "volume": 18592,
    "contract": "200506"
  },
  {
    "date": "2005-06-10",
    "close": 6175.0,
    "volume": 23085,
    "contract": "200506"
  },
  {
    "date": "2005-06-13",
    "close": 6240.0,
    "volume": 21861,
    "contract": "200506"
  },
  {
    "date": "2005-06-14",
    "close": 6221.0,
    "volume": 21001,
    "contract": "200506"
  },
  {
    "date": "2005-06-15",
    "close": 6266.0,
    "volume": 13629,
    "contract": "200506"
  },
  {
    "date": "2005-06-16",
    "close": 6180.0,
    "volume": 33246,
    "contract": "200507"
  },
  {
    "date": "2005-06-17",
    "close": 6189.0,
    "volume": 39792,
    "contract": "200507"
  },
  {
    "date": "2005-06-20",
    "close": 6188.0,
    "volume": 15910,
    "contract": "200507"
  },
  {
    "date": "2005-06-21",
    "close": 6197.0,
    "volume": 18478,
    "contract": "200507"
  },
  {
    "date": "2005-06-22",
    "close": 6330.0,
    "volume": 43369,
    "contract": "200507"
  },
  {
    "date": "2005-06-23",
    "close": 6350.0,
    "volume": 24590,
    "contract": "200507"
  },
  {
    "date": "2005-06-24",
    "close": 6297.0,
    "volume": 30307,
    "contract": "200507"
  },
  {
    "date": "2005-06-27",
    "close": 6257.0,
    "volume": 25588,
    "contract": "200507"
  },
  {
    "date": "2005-06-28",
    "close": 6284.0,
    "volume": 18132,
    "contract": "200507"
  },
  {
    "date": "2005-06-29",
    "close": 6199.0,
    "volume": 54328,
    "contract": "200507"
  },
  {
    "date": "2005-06-30",
    "close": 6199.0,
    "volume": 20191,
    "contract": "200507"
  },
  {
    "date": "2005-07-01",
    "close": 6227.0,
    "volume": 36513,
    "contract": "200507"
  },
  {
    "date": "2005-07-04",
    "close": 6211.0,
    "volume": 19030,
    "contract": "200507"
  },
  {
    "date": "2005-07-05",
    "close": 6163.0,
    "volume": 26316,
    "contract": "200507"
  },
  {
    "date": "2005-07-06",
    "close": 6182.0,
    "volume": 25189,
    "contract": "200507"
  },
  {
    "date": "2005-07-07",
    "close": 6166.0,
    "volume": 25910,
    "contract": "200507"
  },
  {
    "date": "2005-07-08",
    "close": 6181.0,
    "volume": 23599,
    "contract": "200507"
  },
  {
    "date": "2005-07-11",
    "close": 6302.0,
    "volume": 29881,
    "contract": "200507"
  },
  {
    "date": "2005-07-12",
    "close": 6340.0,
    "volume": 25968,
    "contract": "200507"
  },
  {
    "date": "2005-07-13",
    "close": 6376.0,
    "volume": 30454,
    "contract": "200507"
  },
  {
    "date": "2005-07-14",
    "close": 6435.0,
    "volume": 28388,
    "contract": "200507"
  },
  {
    "date": "2005-07-15",
    "close": 6411.0,
    "volume": 17808,
    "contract": "200507"
  },
  {
    "date": "2005-07-19",
    "close": 6430.0,
    "volume": 16251,
    "contract": "200507"
  },
  {
    "date": "2005-07-20",
    "close": 6413.0,
    "volume": 20687,
    "contract": "200507"
  },
  {
    "date": "2005-07-21",
    "close": 6365.0,
    "volume": 49551,
    "contract": "200508"
  },
  {
    "date": "2005-07-22",
    "close": 6342.0,
    "volume": 25061,
    "contract": "200508"
  },
  {
    "date": "2005-07-25",
    "close": 6406.0,
    "volume": 19120,
    "contract": "200508"
  },
  {
    "date": "2005-07-26",
    "close": 6330.0,
    "volume": 27117,
    "contract": "200508"
  },
  {
    "date": "2005-07-27",
    "close": 6310.0,
    "volume": 25424,
    "contract": "200508"
  },
  {
    "date": "2005-07-28",
    "close": 6350.0,
    "volume": 20253,
    "contract": "200508"
  },
  {
    "date": "2005-07-29",
    "close": 6277.0,
    "volume": 38776,
    "contract": "200508"
  },
  {
    "date": "2005-08-01",
    "close": 6297.0,
    "volume": 13495,
    "contract": "200508"
  },
  {
    "date": "2005-08-02",
    "close": 6340.0,
    "volume": 27076,
    "contract": "200508"
  },
  {
    "date": "2005-08-03",
    "close": 6431.0,
    "volume": 38357,
    "contract": "200508"
  },
  {
    "date": "2005-08-04",
    "close": 6445.0,
    "volume": 23870,
    "contract": "200508"
  },
  {
    "date": "2005-08-08",
    "close": 6370.0,
    "volume": 21271,
    "contract": "200508"
  },
  {
    "date": "2005-08-09",
    "close": 6394.0,
    "volume": 16014,
    "contract": "200508"
  },
  {
    "date": "2005-08-10",
    "close": 6345.0,
    "volume": 33301,
    "contract": "200508"
  },
  {
    "date": "2005-08-11",
    "close": 6389.0,
    "volume": 20506,
    "contract": "200508"
  },
  {
    "date": "2005-08-12",
    "close": 6352.0,
    "volume": 22653,
    "contract": "200508"
  },
  {
    "date": "2005-08-15",
    "close": 6240.0,
    "volume": 32474,
    "contract": "200508"
  },
  {
    "date": "2005-08-16",
    "close": 6235.0,
    "volume": 22290,
    "contract": "200508"
  },
  {
    "date": "2005-08-17",
    "close": 6220.0,
    "volume": 16042,
    "contract": "200508"
  },
  {
    "date": "2005-08-18",
    "close": 6190.0,
    "volume": 29121,
    "contract": "200509"
  },
  {
    "date": "2005-08-19",
    "close": 6164.0,
    "volume": 25114,
    "contract": "200509"
  },
  {
    "date": "2005-08-22",
    "close": 6215.0,
    "volume": 16456,
    "contract": "200509"
  },
  {
    "date": "2005-08-23",
    "close": 6185.0,
    "volume": 14278,
    "contract": "200509"
  },
  {
    "date": "2005-08-24",
    "close": 6147.0,
    "volume": 21670,
    "contract": "200509"
  },
  {
    "date": "2005-08-25",
    "close": 6126.0,
    "volume": 23469,
    "contract": "200509"
  },
  {
    "date": "2005-08-26",
    "close": 6150.0,
    "volume": 16495,
    "contract": "200509"
  },
  {
    "date": "2005-08-29",
    "close": 6046.0,
    "volume": 26818,
    "contract": "200509"
  },
  {
    "date": "2005-08-30",
    "close": 6055.0,
    "volume": 16584,
    "contract": "200509"
  },
  {
    "date": "2005-08-31",
    "close": 6050.0,
    "volume": 29590,
    "contract": "200509"
  },
  {
    "date": "2005-09-02",
    "close": 6119.0,
    "volume": 20860,
    "contract": "200509"
  },
  {
    "date": "2005-09-05",
    "close": 6108.0,
    "volume": 9383,
    "contract": "200509"
  },
  {
    "date": "2005-09-06",
    "close": 6150.0,
    "volume": 17250,
    "contract": "200509"
  },
  {
    "date": "2005-09-07",
    "close": 6164.0,
    "volume": 21421,
    "contract": "200509"
  },
  {
    "date": "2005-09-08",
    "close": 6154.0,
    "volume": 11634,
    "contract": "200509"
  },
  {
    "date": "2005-09-09",
    "close": 6114.0,
    "volume": 22338,
    "contract": "200509"
  },
  {
    "date": "2005-09-12",
    "close": 6165.0,
    "volume": 18912,
    "contract": "200509"
  },
  {
    "date": "2005-09-13",
    "close": 6164.0,
    "volume": 18755,
    "contract": "200509"
  },
  {
    "date": "2005-09-14",
    "close": 6155.0,
    "volume": 15568,
    "contract": "200509"
  },
  {
    "date": "2005-09-15",
    "close": 6080.0,
    "volume": 23987,
    "contract": "200509"
  },
  {
    "date": "2005-09-16",
    "close": 6045.0,
    "volume": 25257,
    "contract": "200509"
  },
  {
    "date": "2005-09-19",
    "close": 6030.0,
    "volume": 9602,
    "contract": "200509"
  },
  {
    "date": "2005-09-20",
    "close": 6106.0,
    "volume": 26876,
    "contract": "200509"
  },
  {
    "date": "2005-09-21",
    "close": 6059.0,
    "volume": 11493,
    "contract": "200509"
  },
  {
    "date": "2005-09-22",
    "close": 5979.0,
    "volume": 40394,
    "contract": "200510"
  },
  {
    "date": "2005-09-23",
    "close": 5931.0,
    "volume": 29486,
    "contract": "200510"
  },
  {
    "date": "2005-09-26",
    "close": 5950.0,
    "volume": 25371,
    "contract": "200510"
  },
  {
    "date": "2005-09-27",
    "close": 5935.0,
    "volume": 29561,
    "contract": "200510"
  },
  {
    "date": "2005-09-28",
    "close": 5933.0,
    "volume": 25048,
    "contract": "200510"
  },
  {
    "date": "2005-09-29",
    "close": 6022.0,
    "volume": 31786,
    "contract": "200510"
  },
  {
    "date": "2005-09-30",
    "close": 6095.0,
    "volume": 38775,
    "contract": "200510"
  },
  {
    "date": "2005-10-03",
    "close": 6118.0,
    "volume": 21930,
    "contract": "200510"
  },
  {
    "date": "2005-10-04",
    "close": 6142.0,
    "volume": 27085,
    "contract": "200510"
  },
  {
    "date": "2005-10-05",
    "close": 6130.0,
    "volume": 24357,
    "contract": "200510"
  },
  {
    "date": "2005-10-06",
    "close": 6100.0,
    "volume": 20362,
    "contract": "200510"
  },
  {
    "date": "2005-10-07",
    "close": 6095.0,
    "volume": 14818,
    "contract": "200510"
  },
  {
    "date": "2005-10-11",
    "close": 6099.0,
    "volume": 17179,
    "contract": "200510"
  },
  {
    "date": "2005-10-12",
    "close": 6004.0,
    "volume": 34386,
    "contract": "200510"
  },
  {
    "date": "2005-10-13",
    "close": 5985.0,
    "volume": 22831,
    "contract": "200510"
  },
  {
    "date": "2005-10-14",
    "close": 5968.0,
    "volume": 14179,
    "contract": "200510"
  },
  {
    "date": "2005-10-17",
    "close": 5815.0,
    "volume": 26245,
    "contract": "200510"
  },
  {
    "date": "2005-10-18",
    "close": 5839.0,
    "volume": 15703,
    "contract": "200510"
  },
  {
    "date": "2005-10-19",
    "close": 5678.0,
    "volume": 16491,
    "contract": "200510"
  },
  {
    "date": "2005-10-20",
    "close": 5772.0,
    "volume": 51040,
    "contract": "200511"
  },
  {
    "date": "2005-10-21",
    "close": 5735.0,
    "volume": 30574,
    "contract": "200511"
  },
  {
    "date": "2005-10-24",
    "close": 5712.0,
    "volume": 20445,
    "contract": "200511"
  },
  {
    "date": "2005-10-25",
    "close": 5718.0,
    "volume": 31195,
    "contract": "200511"
  },
  {
    "date": "2005-10-26",
    "close": 5704.0,
    "volume": 30395,
    "contract": "200511"
  },
  {
    "date": "2005-10-27",
    "close": 5675.0,
    "volume": 28506,
    "contract": "200511"
  },
  {
    "date": "2005-10-28",
    "close": 5660.0,
    "volume": 23730,
    "contract": "200511"
  },
  {
    "date": "2005-10-31",
    "close": 5775.0,
    "volume": 27380,
    "contract": "200511"
  },
  {
    "date": "2005-11-01",
    "close": 5798.0,
    "volume": 25676,
    "contract": "200511"
  },
  {
    "date": "2005-11-02",
    "close": 5853.0,
    "volume": 25541,
    "contract": "200511"
  },
  {
    "date": "2005-11-03",
    "close": 5842.0,
    "volume": 20397,
    "contract": "200511"
  },
  {
    "date": "2005-11-04",
    "close": 5885.0,
    "volume": 27723,
    "contract": "200511"
  },
  {
    "date": "2005-11-07",
    "close": 5832.0,
    "volume": 21955,
    "contract": "200511"
  },
  {
    "date": "2005-11-08",
    "close": 5840.0,
    "volume": 15963,
    "contract": "200511"
  },
  {
    "date": "2005-11-09",
    "close": 5973.0,
    "volume": 38918,
    "contract": "200511"
  },
  {
    "date": "2005-11-10",
    "close": 6000.0,
    "volume": 33364,
    "contract": "200511"
  },
  {
    "date": "2005-11-11",
    "close": 6096.0,
    "volume": 29255,
    "contract": "200511"
  },
  {
    "date": "2005-11-14",
    "close": 6090.0,
    "volume": 16172,
    "contract": "200511"
  },
  {
    "date": "2005-11-15",
    "close": 6030.0,
    "volume": 26802,
    "contract": "200511"
  },
  {
    "date": "2005-11-16",
    "close": 6039.0,
    "volume": 14372,
    "contract": "200511"
  },
  {
    "date": "2005-11-17",
    "close": 6023.0,
    "volume": 30170,
    "contract": "200512"
  },
  {
    "date": "2005-11-18",
    "close": 6110.0,
    "volume": 30861,
    "contract": "200512"
  },
  {
    "date": "2005-11-21",
    "close": 6117.0,
    "volume": 22464,
    "contract": "200512"
  },
  {
    "date": "2005-11-22",
    "close": 6075.0,
    "volume": 19036,
    "contract": "200512"
  },
  {
    "date": "2005-11-23",
    "close": 6123.0,
    "volume": 26318,
    "contract": "200512"
  },
  {
    "date": "2005-11-24",
    "close": 6096.0,
    "volume": 22624,
    "contract": "200512"
  },
  {
    "date": "2005-11-25",
    "close": 6110.0,
    "volume": 17155,
    "contract": "200512"
  },
  {
    "date": "2005-11-28",
    "close": 6213.0,
    "volume": 26737,
    "contract": "200512"
  },
  {
    "date": "2005-11-29",
    "close": 6145.0,
    "volume": 20972,
    "contract": "200512"
  },
  {
    "date": "2005-11-30",
    "close": 6187.0,
    "volume": 22364,
    "contract": "200512"
  },
  {
    "date": "2005-12-01",
    "close": 6174.0,
    "volume": 14516,
    "contract": "200512"
  },
  {
    "date": "2005-12-02",
    "close": 6223.0,
    "volume": 21991,
    "contract": "200512"
  },
  {
    "date": "2005-12-05",
    "close": 6363.0,
    "volume": 35180,
    "contract": "200512"
  },
  {
    "date": "2005-12-06",
    "close": 6369.0,
    "volume": 20727,
    "contract": "200512"
  },
  {
    "date": "2005-12-07",
    "close": 6347.0,
    "volume": 27086,
    "contract": "200512"
  },
  {
    "date": "2005-12-08",
    "close": 6240.0,
    "volume": 34819,
    "contract": "200512"
  },
  {
    "date": "2005-12-09",
    "close": 6240.0,
    "volume": 27932,
    "contract": "200512"
  },
  {
    "date": "2005-12-12",
    "close": 6273.0,
    "volume": 27904,
    "contract": "200512"
  },
  {
    "date": "2005-12-13",
    "close": 6241.0,
    "volume": 21926,
    "contract": "200512"
  },
  {
    "date": "2005-12-14",
    "close": 6215.0,
    "volume": 23297,
    "contract": "200512"
  },
  {
    "date": "2005-12-15",
    "close": 6270.0,
    "volume": 21871,
    "contract": "200512"
  },
  {
    "date": "2005-12-16",
    "close": 6356.0,
    "volume": 32188,
    "contract": "200512"
  },
  {
    "date": "2005-12-19",
    "close": 6450.0,
    "volume": 24030,
    "contract": "200512"
  },
  {
    "date": "2005-12-20",
    "close": 6433.0,
    "volume": 16630,
    "contract": "200512"
  },
  {
    "date": "2005-12-21",
    "close": 6469.0,
    "volume": 10999,
    "contract": "200512"
  },
  {
    "date": "2005-12-22",
    "close": 6430.0,
    "volume": 21977,
    "contract": "200601"
  },
  {
    "date": "2005-12-23",
    "close": 6544.0,
    "volume": 32155,
    "contract": "200601"
  },
  {
    "date": "2005-12-26",
    "close": 6578.0,
    "volume": 15889,
    "contract": "200601"
  },
  {
    "date": "2005-12-27",
    "close": 6567.0,
    "volume": 23749,
    "contract": "200601"
  },
  {
    "date": "2005-12-28",
    "close": 6550.0,
    "volume": 19686,
    "contract": "200601"
  },
  {
    "date": "2005-12-29",
    "close": 6605.0,
    "volume": 29221,
    "contract": "200601"
  },
  {
    "date": "2005-12-30",
    "close": 6595.0,
    "volume": 19675,
    "contract": "200601"
  },
  {
    "date": "2006-01-02",
    "close": 6478.0,
    "volume": 27202,
    "contract": "200601"
  },
  {
    "date": "2006-01-03",
    "close": 6641.0,
    "volume": 41424,
    "contract": "200601"
  },
  {
    "date": "2006-01-04",
    "close": 6655.0,
    "volume": 33521,
    "contract": "200601"
  },
  {
    "date": "2006-01-05",
    "close": 6723.0,
    "volume": 37557,
    "contract": "200601"
  },
  {
    "date": "2006-01-06",
    "close": 6717.0,
    "volume": 26989,
    "contract": "200601"
  },
  {
    "date": "2006-01-09",
    "close": 6760.0,
    "volume": 27074,
    "contract": "200601"
  },
  {
    "date": "2006-01-10",
    "close": 6739.0,
    "volume": 29761,
    "contract": "200601"
  },
  {
    "date": "2006-01-11",
    "close": 6760.0,
    "volume": 38793,
    "contract": "200601"
  },
  {
    "date": "2006-01-12",
    "close": 6705.0,
    "volume": 33809,
    "contract": "200601"
  },
  {
    "date": "2006-01-13",
    "close": 6712.0,
    "volume": 32377,
    "contract": "200601"
  },
  {
    "date": "2006-01-16",
    "close": 6729.0,
    "volume": 34214,
    "contract": "200601"
  },
  {
    "date": "2006-01-17",
    "close": 6689.0,
    "volume": 28043,
    "contract": "200601"
  },
  {
    "date": "2006-01-18",
    "close": 6490.0,
    "volume": 27815,
    "contract": "200601"
  },
  {
    "date": "2006-01-19",
    "close": 6513.0,
    "volume": 41758,
    "contract": "200602"
  },
  {
    "date": "2006-01-20",
    "close": 6472.0,
    "volume": 36292,
    "contract": "200602"
  },
  {
    "date": "2006-01-23",
    "close": 6380.0,
    "volume": 28242,
    "contract": "200602"
  },
  {
    "date": "2006-01-24",
    "close": 6450.0,
    "volume": 24722,
    "contract": "200602"
  },
  {
    "date": "2006-01-25",
    "close": 6532.0,
    "volume": 30132,
    "contract": "200602"
  },
  {
    "date": "2006-02-03",
    "close": 6585.0,
    "volume": 31029,
    "contract": "200602"
  },
  {
    "date": "2006-02-06",
    "close": 6700.0,
    "volume": 39983,
    "contract": "200602"
  },
  {
    "date": "2006-02-07",
    "close": 6705.0,
    "volume": 35636,
    "contract": "200602"
  },
  {
    "date": "2006-02-08",
    "close": 6619.0,
    "volume": 32331,
    "contract": "200602"
  },
  {
    "date": "2006-02-09",
    "close": 6593.0,
    "volume": 38601,
    "contract": "200602"
  },
  {
    "date": "2006-02-10",
    "close": 6563.0,
    "volume": 36182,
    "contract": "200602"
  },
  {
    "date": "2006-02-13",
    "close": 6541.0,
    "volume": 28680,
    "contract": "200602"
  },
  {
    "date": "2006-02-14",
    "close": 6610.0,
    "volume": 31792,
    "contract": "200602"
  },
  {
    "date": "2006-02-15",
    "close": 6590.0,
    "volume": 15038,
    "contract": "200602"
  },
  {
    "date": "2006-02-16",
    "close": 6669.0,
    "volume": 48942,
    "contract": "200603"
  },
  {
    "date": "2006-02-17",
    "close": 6682.0,
    "volume": 39693,
    "contract": "200603"
  },
  {
    "date": "2006-02-20",
    "close": 6677.0,
    "volume": 36121,
    "contract": "200603"
  },
  {
    "date": "2006-02-21",
    "close": 6628.0,
    "volume": 35794,
    "contract": "200603"
  },
  {
    "date": "2006-02-22",
    "close": 6528.0,
    "volume": 55797,
    "contract": "200603"
  },
  {
    "date": "2006-02-23",
    "close": 6493.0,
    "volume": 41063,
    "contract": "200603"
  },
  {
    "date": "2006-02-24",
    "close": 6527.0,
    "volume": 33242,
    "contract": "200603"
  },
  {
    "date": "2006-02-27",
    "close": 6530.0,
    "volume": 31587,
    "contract": "200603"
  },
  {
    "date": "2006-03-01",
    "close": 6582.0,
    "volume": 44348,
    "contract": "200603"
  },
  {
    "date": "2006-03-02",
    "close": 6617.0,
    "volume": 35536,
    "contract": "200603"
  },
  {
    "date": "2006-03-03",
    "close": 6503.0,
    "volume": 43846,
    "contract": "200603"
  },
  {
    "date": "2006-03-06",
    "close": 6548.0,
    "volume": 30517,
    "contract": "200603"
  },
  {
    "date": "2006-03-07",
    "close": 6475.0,
    "volume": 37478,
    "contract": "200603"
  },
  {
    "date": "2006-03-08",
    "close": 6455.0,
    "volume": 48943,
    "contract": "200603"
  },
  {
    "date": "2006-03-09",
    "close": 6477.0,
    "volume": 30782,
    "contract": "200603"
  },
  {
    "date": "2006-03-10",
    "close": 6467.0,
    "volume": 40901,
    "contract": "200603"
  },
  {
    "date": "2006-03-13",
    "close": 6535.0,
    "volume": 26800,
    "contract": "200603"
  },
  {
    "date": "2006-03-14",
    "close": 6454.0,
    "volume": 36681,
    "contract": "200603"
  },
  {
    "date": "2006-03-15",
    "close": 6510.0,
    "volume": 19982,
    "contract": "200603"
  },
  {
    "date": "2006-03-16",
    "close": 6448.0,
    "volume": 55910,
    "contract": "200604"
  },
  {
    "date": "2006-03-17",
    "close": 6478.0,
    "volume": 32944,
    "contract": "200604"
  },
  {
    "date": "2006-03-20",
    "close": 6496.0,
    "volume": 37693,
    "contract": "200604"
  },
  {
    "date": "2006-03-21",
    "close": 6450.0,
    "volume": 40546,
    "contract": "200604"
  },
  {
    "date": "2006-03-22",
    "close": 6361.0,
    "volume": 46240,
    "contract": "200604"
  },
  {
    "date": "2006-03-23",
    "close": 6358.0,
    "volume": 36717,
    "contract": "200604"
  },
  {
    "date": "2006-03-24",
    "close": 6366.0,
    "volume": 24238,
    "contract": "200604"
  },
  {
    "date": "2006-03-27",
    "close": 6390.0,
    "volume": 18537,
    "contract": "200604"
  },
  {
    "date": "2006-03-28",
    "close": 6405.0,
    "volume": 27770,
    "contract": "200604"
  },
  {
    "date": "2006-03-29",
    "close": 6440.0,
    "volume": 35201,
    "contract": "200604"
  },
  {
    "date": "2006-03-30",
    "close": 6487.0,
    "volume": 43072,
    "contract": "200604"
  },
  {
    "date": "2006-03-31",
    "close": 6561.0,
    "volume": 41291,
    "contract": "200604"
  },
  {
    "date": "2006-04-03",
    "close": 6638.0,
    "volume": 30043,
    "contract": "200604"
  },
  {
    "date": "2006-04-04",
    "close": 6630.0,
    "volume": 21774,
    "contract": "200604"
  },
  {
    "date": "2006-04-06",
    "close": 6727.0,
    "volume": 29681,
    "contract": "200604"
  },
  {
    "date": "2006-04-07",
    "close": 6751.0,
    "volume": 34751,
    "contract": "200604"
  },
  {
    "date": "2006-04-10",
    "close": 6779.0,
    "volume": 48184,
    "contract": "200604"
  },
  {
    "date": "2006-04-11",
    "close": 6755.0,
    "volume": 33134,
    "contract": "200604"
  },
  {
    "date": "2006-04-12",
    "close": 6808.0,
    "volume": 53379,
    "contract": "200604"
  },
  {
    "date": "2006-04-13",
    "close": 6866.0,
    "volume": 37579,
    "contract": "200604"
  },
  {
    "date": "2006-04-14",
    "close": 6984.0,
    "volume": 42551,
    "contract": "200604"
  },
  {
    "date": "2006-04-17",
    "close": 6986.0,
    "volume": 40534,
    "contract": "200604"
  },
  {
    "date": "2006-04-18",
    "close": 6983.0,
    "volume": 38280,
    "contract": "200604"
  },
  {
    "date": "2006-04-19",
    "close": 7042.0,
    "volume": 22187,
    "contract": "200604"
  },
  {
    "date": "2006-04-20",
    "close": 7121.0,
    "volume": 52886,
    "contract": "200605"
  },
  {
    "date": "2006-04-21",
    "close": 7105.0,
    "volume": 38249,
    "contract": "200605"
  },
  {
    "date": "2006-04-24",
    "close": 7081.0,
    "volume": 41657,
    "contract": "200605"
  },
  {
    "date": "2006-04-25",
    "close": 7053.0,
    "volume": 49974,
    "contract": "200605"
  },
  {
    "date": "2006-04-26",
    "close": 7208.0,
    "volume": 43395,
    "contract": "200605"
  },
  {
    "date": "2006-04-27",
    "close": 7176.0,
    "volume": 45862,
    "contract": "200605"
  },
  {
    "date": "2006-04-28",
    "close": 7180.0,
    "volume": 46131,
    "contract": "200605"
  },
  {
    "date": "2006-05-02",
    "close": 7219.0,
    "volume": 40395,
    "contract": "200605"
  },
  {
    "date": "2006-05-03",
    "close": 7267.0,
    "volume": 35619,
    "contract": "200605"
  },
  {
    "date": "2006-05-04",
    "close": 7375.0,
    "volume": 42418,
    "contract": "200605"
  },
  {
    "date": "2006-05-05",
    "close": 7421.0,
    "volume": 51836,
    "contract": "200605"
  },
  {
    "date": "2006-05-08",
    "close": 7518.0,
    "volume": 30678,
    "contract": "200605"
  },
  {
    "date": "2006-05-09",
    "close": 7392.0,
    "volume": 56421,
    "contract": "200605"
  },
  {
    "date": "2006-05-10",
    "close": 7318.0,
    "volume": 65982,
    "contract": "200605"
  },
  {
    "date": "2006-05-11",
    "close": 7369.0,
    "volume": 43606,
    "contract": "200605"
  },
  {
    "date": "2006-05-12",
    "close": 7257.0,
    "volume": 42212,
    "contract": "200605"
  },
  {
    "date": "2006-05-15",
    "close": 7153.0,
    "volume": 33060,
    "contract": "200605"
  },
  {
    "date": "2006-05-16",
    "close": 7022.0,
    "volume": 40184,
    "contract": "200605"
  },
  {
    "date": "2006-05-17",
    "close": 7111.0,
    "volume": 24239,
    "contract": "200605"
  },
  {
    "date": "2006-05-18",
    "close": 7000.0,
    "volume": 41162,
    "contract": "200606"
  },
  {
    "date": "2006-05-19",
    "close": 7042.0,
    "volume": 35174,
    "contract": "200606"
  },
  {
    "date": "2006-05-22",
    "close": 6868.0,
    "volume": 46371,
    "contract": "200606"
  },
  {
    "date": "2006-05-23",
    "close": 6844.0,
    "volume": 49188,
    "contract": "200606"
  },
  {
    "date": "2006-05-24",
    "close": 6890.0,
    "volume": 70600,
    "contract": "200606"
  },
  {
    "date": "2006-05-25",
    "close": 6855.0,
    "volume": 39864,
    "contract": "200606"
  },
  {
    "date": "2006-05-26",
    "close": 6872.0,
    "volume": 43097,
    "contract": "200606"
  },
  {
    "date": "2006-05-29",
    "close": 6891.0,
    "volume": 27085,
    "contract": "200606"
  },
  {
    "date": "2006-05-30",
    "close": 6844.0,
    "volume": 49838,
    "contract": "200606"
  },
  {
    "date": "2006-06-01",
    "close": 6854.0,
    "volume": 30427,
    "contract": "200606"
  },
  {
    "date": "2006-06-02",
    "close": 6967.0,
    "volume": 44918,
    "contract": "200606"
  },
  {
    "date": "2006-06-05",
    "close": 6678.0,
    "volume": 56135,
    "contract": "200606"
  },
  {
    "date": "2006-06-06",
    "close": 6689.0,
    "volume": 52334,
    "contract": "200606"
  },
  {
    "date": "2006-06-07",
    "close": 6576.0,
    "volume": 46653,
    "contract": "200606"
  },
  {
    "date": "2006-06-08",
    "close": 6216.0,
    "volume": 74759,
    "contract": "200606"
  },
  {
    "date": "2006-06-09",
    "close": 6375.0,
    "volume": 70824,
    "contract": "200606"
  },
  {
    "date": "2006-06-12",
    "close": 6379.0,
    "volume": 50729,
    "contract": "200606"
  },
  {
    "date": "2006-06-13",
    "close": 6270.0,
    "volume": 52290,
    "contract": "200606"
  },
  {
    "date": "2006-06-14",
    "close": 6465.0,
    "volume": 57589,
    "contract": "200606"
  },
  {
    "date": "2006-06-15",
    "close": 6409.0,
    "volume": 51995,
    "contract": "200606"
  },
  {
    "date": "2006-06-16",
    "close": 6580.0,
    "volume": 44190,
    "contract": "200606"
  },
  {
    "date": "2006-06-19",
    "close": 6575.0,
    "volume": 28420,
    "contract": "200606"
  },
  {
    "date": "2006-06-20",
    "close": 6359.0,
    "volume": 53447,
    "contract": "200606"
  },
  {
    "date": "2006-06-21",
    "close": 6316.0,
    "volume": 20587,
    "contract": "200606"
  },
  {
    "date": "2006-06-22",
    "close": 6430.0,
    "volume": 43047,
    "contract": "200607"
  },
  {
    "date": "2006-06-23",
    "close": 6377.0,
    "volume": 52097,
    "contract": "200607"
  },
  {
    "date": "2006-06-26",
    "close": 6481.0,
    "volume": 36611,
    "contract": "200607"
  },
  {
    "date": "2006-06-27",
    "close": 6515.0,
    "volume": 53268,
    "contract": "200607"
  },
  {
    "date": "2006-06-28",
    "close": 6455.0,
    "volume": 36982,
    "contract": "200607"
  },
  {
    "date": "2006-06-29",
    "close": 6535.0,
    "volume": 42461,
    "contract": "200607"
  },
  {
    "date": "2006-06-30",
    "close": 6655.0,
    "volume": 31052,
    "contract": "200607"
  },
  {
    "date": "2006-07-03",
    "close": 6666.0,
    "volume": 18313,
    "contract": "200607"
  },
  {
    "date": "2006-07-04",
    "close": 6668.0,
    "volume": 38372,
    "contract": "200607"
  },
  {
    "date": "2006-07-05",
    "close": 6570.0,
    "volume": 39808,
    "contract": "200607"
  },
  {
    "date": "2006-07-06",
    "close": 6579.0,
    "volume": 38115,
    "contract": "200607"
  },
  {
    "date": "2006-07-07",
    "close": 6558.0,
    "volume": 24849,
    "contract": "200607"
  },
  {
    "date": "2006-07-10",
    "close": 6659.0,
    "volume": 37308,
    "contract": "200607"
  },
  {
    "date": "2006-07-11",
    "close": 6598.0,
    "volume": 29751,
    "contract": "200607"
  },
  {
    "date": "2006-07-12",
    "close": 6579.0,
    "volume": 53264,
    "contract": "200607"
  },
  {
    "date": "2006-07-13",
    "close": 6516.0,
    "volume": 35590,
    "contract": "200607"
  },
  {
    "date": "2006-07-14",
    "close": 6368.0,
    "volume": 43041,
    "contract": "200607"
  },
  {
    "date": "2006-07-17",
    "close": 6221.0,
    "volume": 42713,
    "contract": "200607"
  },
  {
    "date": "2006-07-18",
    "close": 6266.0,
    "volume": 28311,
    "contract": "200607"
  },
  {
    "date": "2006-07-19",
    "close": 6266.0,
    "volume": 20676,
    "contract": "200607"
  },
  {
    "date": "2006-07-20",
    "close": 6339.0,
    "volume": 39806,
    "contract": "200608"
  },
  {
    "date": "2006-07-21",
    "close": 6292.0,
    "volume": 30885,
    "contract": "200608"
  },
  {
    "date": "2006-07-24",
    "close": 6238.0,
    "volume": 30122,
    "contract": "200608"
  },
  {
    "date": "2006-07-25",
    "close": 6315.0,
    "volume": 29392,
    "contract": "200608"
  },
  {
    "date": "2006-07-26",
    "close": 6292.0,
    "volume": 36527,
    "contract": "200608"
  },
  {
    "date": "2006-07-27",
    "close": 6401.0,
    "volume": 42213,
    "contract": "200608"
  },
  {
    "date": "2006-07-28",
    "close": 6396.0,
    "volume": 34105,
    "contract": "200608"
  },
  {
    "date": "2006-07-31",
    "close": 6361.0,
    "volume": 42815,
    "contract": "200608"
  },
  {
    "date": "2006-08-01",
    "close": 6379.0,
    "volume": 33712,
    "contract": "200608"
  },
  {
    "date": "2006-08-02",
    "close": 6439.0,
    "volume": 35217,
    "contract": "200608"
  },
  {
    "date": "2006-08-03",
    "close": 6408.0,
    "volume": 35058,
    "contract": "200608"
  },
  {
    "date": "2006-08-04",
    "close": 6366.0,
    "volume": 36034,
    "contract": "200608"
  },
  {
    "date": "2006-08-07",
    "close": 6350.0,
    "volume": 31285,
    "contract": "200608"
  },
  {
    "date": "2006-08-08",
    "close": 6501.0,
    "volume": 37968,
    "contract": "200608"
  },
  {
    "date": "2006-08-09",
    "close": 6580.0,
    "volume": 39843,
    "contract": "200608"
  },
  {
    "date": "2006-08-10",
    "close": 6555.0,
    "volume": 42468,
    "contract": "200608"
  },
  {
    "date": "2006-08-11",
    "close": 6538.0,
    "volume": 26788,
    "contract": "200608"
  },
  {
    "date": "2006-08-14",
    "close": 6595.0,
    "volume": 33840,
    "contract": "200608"
  },
  {
    "date": "2006-08-15",
    "close": 6607.0,
    "volume": 22235,
    "contract": "200608"
  },
  {
    "date": "2006-08-16",
    "close": 6692.0,
    "volume": 15698,
    "contract": "200608"
  },
  {
    "date": "2006-08-17",
    "close": 6695.0,
    "volume": 31341,
    "contract": "200609"
  },
  {
    "date": "2006-08-18",
    "close": 6698.0,
    "volume": 16755,
    "contract": "200609"
  },
  {
    "date": "2006-08-21",
    "close": 6460.0,
    "volume": 51454,
    "contract": "200609"
  },
  {
    "date": "2006-08-22",
    "close": 6539.0,
    "volume": 30828,
    "contract": "200609"
  },
  {
    "date": "2006-08-23",
    "close": 6515.0,
    "volume": 54678,
    "contract": "200609"
  },
  {
    "date": "2006-08-24",
    "close": 6515.0,
    "volume": 31298,
    "contract": "200609"
  },
  {
    "date": "2006-08-25",
    "close": 6489.0,
    "volume": 35082,
    "contract": "200609"
  },
  {
    "date": "2006-08-28",
    "close": 6402.0,
    "volume": 38685,
    "contract": "200609"
  },
  {
    "date": "2006-08-29",
    "close": 6439.0,
    "volume": 20856,
    "contract": "200609"
  },
  {
    "date": "2006-08-30",
    "close": 6563.0,
    "volume": 42254,
    "contract": "200609"
  },
  {
    "date": "2006-08-31",
    "close": 6621.0,
    "volume": 37036,
    "contract": "200609"
  },
  {
    "date": "2006-09-01",
    "close": 6646.0,
    "volume": 19448,
    "contract": "200609"
  },
  {
    "date": "2006-09-04",
    "close": 6738.0,
    "volume": 30208,
    "contract": "200609"
  },
  {
    "date": "2006-09-05",
    "close": 6738.0,
    "volume": 18901,
    "contract": "200609"
  },
  {
    "date": "2006-09-06",
    "close": 6653.0,
    "volume": 42708,
    "contract": "200609"
  },
  {
    "date": "2006-09-07",
    "close": 6640.0,
    "volume": 37185,
    "contract": "200609"
  },
  {
    "date": "2006-09-08",
    "close": 6696.0,
    "volume": 36646,
    "contract": "200609"
  },
  {
    "date": "2006-09-11",
    "close": 6648.0,
    "volume": 53917,
    "contract": "200609"
  },
  {
    "date": "2006-09-12",
    "close": 6588.0,
    "volume": 36788,
    "contract": "200609"
  },
  {
    "date": "2006-09-13",
    "close": 6644.0,
    "volume": 31146,
    "contract": "200609"
  },
  {
    "date": "2006-09-14",
    "close": 6579.0,
    "volume": 57041,
    "contract": "200609"
  },
  {
    "date": "2006-09-15",
    "close": 6669.0,
    "volume": 40687,
    "contract": "200609"
  },
  {
    "date": "2006-09-18",
    "close": 6895.0,
    "volume": 44150,
    "contract": "200609"
  },
  {
    "date": "2006-09-19",
    "close": 6876.0,
    "volume": 28810,
    "contract": "200609"
  },
  {
    "date": "2006-09-20",
    "close": 6880.0,
    "volume": 19392,
    "contract": "200609"
  },
  {
    "date": "2006-09-21",
    "close": 6880.0,
    "volume": 46723,
    "contract": "200610"
  },
  {
    "date": "2006-09-22",
    "close": 6858.0,
    "volume": 28471,
    "contract": "200610"
  },
  {
    "date": "2006-09-25",
    "close": 6925.0,
    "volume": 43446,
    "contract": "200610"
  },
  {
    "date": "2006-09-26",
    "close": 6900.0,
    "volume": 32795,
    "contract": "200610"
  },
  {
    "date": "2006-09-27",
    "close": 6955.0,
    "volume": 32825,
    "contract": "200610"
  },
  {
    "date": "2006-09-28",
    "close": 6864.0,
    "volume": 45437,
    "contract": "200610"
  },
  {
    "date": "2006-09-29",
    "close": 6877.0,
    "volume": 25305,
    "contract": "200610"
  },
  {
    "date": "2006-10-02",
    "close": 6959.0,
    "volume": 38959,
    "contract": "200610"
  },
  {
    "date": "2006-10-03",
    "close": 6940.0,
    "volume": 21877,
    "contract": "200610"
  },
  {
    "date": "2006-10-04",
    "close": 6867.0,
    "volume": 38041,
    "contract": "200610"
  },
  {
    "date": "2006-10-05",
    "close": 7012.0,
    "volume": 39715,
    "contract": "200610"
  },
  {
    "date": "2006-10-11",
    "close": 7009.0,
    "volume": 19733,
    "contract": "200610"
  },
  {
    "date": "2006-10-12",
    "close": 6981.0,
    "volume": 28286,
    "contract": "200610"
  },
  {
    "date": "2006-10-13",
    "close": 7080.0,
    "volume": 32782,
    "contract": "200610"
  },
  {
    "date": "2006-10-14",
    "close": 7102.0,
    "volume": 14484,
    "contract": "200610"
  },
  {
    "date": "2006-10-16",
    "close": 7143.0,
    "volume": 29394,
    "contract": "200610"
  },
  {
    "date": "2006-10-17",
    "close": 7076.0,
    "volume": 29787,
    "contract": "200610"
  },
  {
    "date": "2006-10-18",
    "close": 7025.0,
    "volume": 22247,
    "contract": "200610"
  },
  {
    "date": "2006-10-19",
    "close": 6981.0,
    "volume": 32306,
    "contract": "200611"
  },
  {
    "date": "2006-10-20",
    "close": 7017.0,
    "volume": 19252,
    "contract": "200611"
  },
  {
    "date": "2006-10-23",
    "close": 7049.0,
    "volume": 25923,
    "contract": "200611"
  },
  {
    "date": "2006-10-24",
    "close": 7097.0,
    "volume": 31856,
    "contract": "200611"
  },
  {
    "date": "2006-10-25",
    "close": 7060.0,
    "volume": 24986,
    "contract": "200611"
  },
  {
    "date": "2006-10-26",
    "close": 7093.0,
    "volume": 29245,
    "contract": "200611"
  },
  {
    "date": "2006-10-27",
    "close": 7093.0,
    "volume": 25496,
    "contract": "200611"
  },
  {
    "date": "2006-10-30",
    "close": 6981.0,
    "volume": 35126,
    "contract": "200611"
  },
  {
    "date": "2006-10-31",
    "close": 7002.0,
    "volume": 19002,
    "contract": "200611"
  },
  {
    "date": "2006-11-01",
    "close": 7003.0,
    "volume": 17726,
    "contract": "200611"
  },
  {
    "date": "2006-11-02",
    "close": 7063.0,
    "volume": 35289,
    "contract": "200611"
  },
  {
    "date": "2006-11-03",
    "close": 7141.0,
    "volume": 38694,
    "contract": "200611"
  },
  {
    "date": "2006-11-06",
    "close": 7115.0,
    "volume": 34569,
    "contract": "200611"
  },
  {
    "date": "2006-11-07",
    "close": 7183.0,
    "volume": 29299,
    "contract": "200611"
  },
  {
    "date": "2006-11-08",
    "close": 7156.0,
    "volume": 17501,
    "contract": "200611"
  },
  {
    "date": "2006-11-09",
    "close": 7128.0,
    "volume": 41875,
    "contract": "200611"
  },
  {
    "date": "2006-11-10",
    "close": 7162.0,
    "volume": 24567,
    "contract": "200611"
  },
  {
    "date": "2006-11-13",
    "close": 7132.0,
    "volume": 25746,
    "contract": "200611"
  },
  {
    "date": "2006-11-14",
    "close": 7206.0,
    "volume": 26040,
    "contract": "200611"
  },
  {
    "date": "2006-11-15",
    "close": 7247.0,
    "volume": 19349,
    "contract": "200611"
  },
  {
    "date": "2006-11-16",
    "close": 7248.0,
    "volume": 27623,
    "contract": "200612"
  },
  {
    "date": "2006-11-17",
    "close": 7257.0,
    "volume": 20089,
    "contract": "200612"
  },
  {
    "date": "2006-11-20",
    "close": 7220.0,
    "volume": 25021,
    "contract": "200612"
  },
  {
    "date": "2006-11-21",
    "close": 7306.0,
    "volume": 32372,
    "contract": "200612"
  },
  {
    "date": "2006-11-22",
    "close": 7343.0,
    "volume": 22689,
    "contract": "200612"
  },
  {
    "date": "2006-11-23",
    "close": 7394.0,
    "volume": 40116,
    "contract": "200612"
  },
  {
    "date": "2006-11-24",
    "close": 7433.0,
    "volume": 24044,
    "contract": "200612"
  },
  {
    "date": "2006-11-27",
    "close": 7510.0,
    "volume": 32533,
    "contract": "200612"
  },
  {
    "date": "2006-11-28",
    "close": 7454.0,
    "volume": 22049,
    "contract": "200612"
  },
  {
    "date": "2006-11-29",
    "close": 7465.0,
    "volume": 39880,
    "contract": "200612"
  },
  {
    "date": "2006-11-30",
    "close": 7542.0,
    "volume": 34317,
    "contract": "200612"
  },
  {
    "date": "2006-12-01",
    "close": 7612.0,
    "volume": 37466,
    "contract": "200612"
  },
  {
    "date": "2006-12-04",
    "close": 7658.0,
    "volume": 32018,
    "contract": "200612"
  },
  {
    "date": "2006-12-05",
    "close": 7610.0,
    "volume": 42122,
    "contract": "200612"
  },
  {
    "date": "2006-12-06",
    "close": 7714.0,
    "volume": 35769,
    "contract": "200612"
  },
  {
    "date": "2006-12-07",
    "close": 7698.0,
    "volume": 32712,
    "contract": "200612"
  },
  {
    "date": "2006-12-08",
    "close": 7633.0,
    "volume": 35681,
    "contract": "200612"
  },
  {
    "date": "2006-12-11",
    "close": 7614.0,
    "volume": 30621,
    "contract": "200612"
  },
  {
    "date": "2006-12-12",
    "close": 7467.0,
    "volume": 51804,
    "contract": "200612"
  },
  {
    "date": "2006-12-13",
    "close": 7450.0,
    "volume": 49738,
    "contract": "200612"
  },
  {
    "date": "2006-12-14",
    "close": 7478.0,
    "volume": 30195,
    "contract": "200612"
  },
  {
    "date": "2006-12-15",
    "close": 7540.0,
    "volume": 24152,
    "contract": "200612"
  },
  {
    "date": "2006-12-18",
    "close": 7634.0,
    "volume": 36449,
    "contract": "200612"
  },
  {
    "date": "2006-12-19",
    "close": 7593.0,
    "volume": 36552,
    "contract": "200612"
  },
  {
    "date": "2006-12-20",
    "close": 7662.0,
    "volume": 15925,
    "contract": "200612"
  },
  {
    "date": "2006-12-21",
    "close": 7642.0,
    "volume": 44642,
    "contract": "200701"
  },
  {
    "date": "2006-12-22",
    "close": 7692.0,
    "volume": 30690,
    "contract": "200701"
  },
  {
    "date": "2006-12-25",
    "close": 7679.0,
    "volume": 17995,
    "contract": "200701"
  },
  {
    "date": "2006-12-26",
    "close": 7789.0,
    "volume": 34596,
    "contract": "200701"
  },
  {
    "date": "2006-12-27",
    "close": 7795.0,
    "volume": 29812,
    "contract": "200701"
  },
  {
    "date": "2006-12-28",
    "close": 7800.0,
    "volume": 34566,
    "contract": "200701"
  },
  {
    "date": "2006-12-29",
    "close": 7880.0,
    "volume": 34940,
    "contract": "200701"
  },
  {
    "date": "2007-01-02",
    "close": 7988.0,
    "volume": 31340,
    "contract": "200701"
  },
  {
    "date": "2007-01-03",
    "close": 7989.0,
    "volume": 37179,
    "contract": "200701"
  },
  {
    "date": "2007-01-04",
    "close": 7976.0,
    "volume": 32038,
    "contract": "200701"
  },
  {
    "date": "2007-01-05",
    "close": 7830.0,
    "volume": 48656,
    "contract": "200701"
  },
  {
    "date": "2007-01-08",
    "close": 7736.0,
    "volume": 36132,
    "contract": "200701"
  },
  {
    "date": "2007-01-09",
    "close": 7822.0,
    "volume": 36861,
    "contract": "200701"
  },
  {
    "date": "2007-01-10",
    "close": 7693.0,
    "volume": 42190,
    "contract": "200701"
  },
  {
    "date": "2007-01-11",
    "close": 7626.0,
    "volume": 46898,
    "contract": "200701"
  },
  {
    "date": "2007-01-12",
    "close": 7786.0,
    "volume": 43724,
    "contract": "200701"
  },
  {
    "date": "2007-01-15",
    "close": 7804.0,
    "volume": 32962,
    "contract": "200701"
  },
  {
    "date": "2007-01-16",
    "close": 7815.0,
    "volume": 31978,
    "contract": "200701"
  },
  {
    "date": "2007-01-17",
    "close": 7835.0,
    "volume": 23325,
    "contract": "200701"
  },
  {
    "date": "2007-01-18",
    "close": 7922.0,
    "volume": 41441,
    "contract": "200702"
  },
  {
    "date": "2007-01-19",
    "close": 7862.0,
    "volume": 34809,
    "contract": "200702"
  },
  {
    "date": "2007-01-22",
    "close": 7885.0,
    "volume": 44400,
    "contract": "200702"
  },
  {
    "date": "2007-01-23",
    "close": 7885.0,
    "volume": 28102,
    "contract": "200702"
  },
  {
    "date": "2007-01-24",
    "close": 7993.0,
    "volume": 25656,
    "contract": "200702"
  },
  {
    "date": "2007-01-25",
    "close": 7975.0,
    "volume": 26050,
    "contract": "200702"
  },
  {
    "date": "2007-01-26",
    "close": 7837.0,
    "volume": 40760,
    "contract": "200702"
  },
  {
    "date": "2007-01-29",
    "close": 7787.0,
    "volume": 28290,
    "contract": "200702"
  },
  {
    "date": "2007-01-30",
    "close": 7769.0,
    "volume": 29544,
    "contract": "200702"
  },
  {
    "date": "2007-01-31",
    "close": 7734.0,
    "volume": 46446,
    "contract": "200702"
  },
  {
    "date": "2007-02-01",
    "close": 7740.0,
    "volume": 35069,
    "contract": "200702"
  },
  {
    "date": "2007-02-02",
    "close": 7810.0,
    "volume": 34328,
    "contract": "200702"
  },
  {
    "date": "2007-02-05",
    "close": 7779.0,
    "volume": 27962,
    "contract": "200702"
  },
  {
    "date": "2007-02-06",
    "close": 7889.0,
    "volume": 35426,
    "contract": "200702"
  },
  {
    "date": "2007-02-07",
    "close": 7868.0,
    "volume": 20412,
    "contract": "200702"
  },
  {
    "date": "2007-02-08",
    "close": 7870.0,
    "volume": 42625,
    "contract": "200702"
  },
  {
    "date": "2007-02-09",
    "close": 7884.0,
    "volume": 32858,
    "contract": "200702"
  },
  {
    "date": "2007-02-12",
    "close": 7792.0,
    "volume": 31133,
    "contract": "200702"
  },
  {
    "date": "2007-02-13",
    "close": 7743.0,
    "volume": 35858,
    "contract": "200702"
  },
  {
    "date": "2007-02-14",
    "close": 7833.0,
    "volume": 27208,
    "contract": "200702"
  },
  {
    "date": "2007-02-26",
    "close": 7899.0,
    "volume": 14654,
    "contract": "200702"
  },
  {
    "date": "2007-02-27",
    "close": 7925.0,
    "volume": 32570,
    "contract": "200703"
  },
  {
    "date": "2007-03-01",
    "close": 7660.0,
    "volume": 50519,
    "contract": "200703"
  },
  {
    "date": "2007-03-02",
    "close": 7668.0,
    "volume": 30154,
    "contract": "200703"
  },
  {
    "date": "2007-03-03",
    "close": 7589.0,
    "volume": 35595,
    "contract": "200703"
  },
  {
    "date": "2007-03-05",
    "close": 7285.0,
    "volume": 61878,
    "contract": "200703"
  },
  {
    "date": "2007-03-06",
    "close": 7409.0,
    "volume": 37007,
    "contract": "200703"
  },
  {
    "date": "2007-03-07",
    "close": 7427.0,
    "volume": 44177,
    "contract": "200703"
  },
  {
    "date": "2007-03-08",
    "close": 7523.0,
    "volume": 39855,
    "contract": "200703"
  },
  {
    "date": "2007-03-09",
    "close": 7517.0,
    "volume": 32239,
    "contract": "200703"
  },
  {
    "date": "2007-03-12",
    "close": 7595.0,
    "volume": 26540,
    "contract": "200703"
  },
  {
    "date": "2007-03-13",
    "close": 7624.0,
    "volume": 26140,
    "contract": "200703"
  },
  {
    "date": "2007-03-14",
    "close": 7469.0,
    "volume": 42852,
    "contract": "200703"
  },
  {
    "date": "2007-03-15",
    "close": 7652.0,
    "volume": 39038,
    "contract": "200703"
  },
  {
    "date": "2007-03-16",
    "close": 7666.0,
    "volume": 38393,
    "contract": "200703"
  },
  {
    "date": "2007-03-19",
    "close": 7710.0,
    "volume": 29624,
    "contract": "200703"
  },
  {
    "date": "2007-03-20",
    "close": 7721.0,
    "volume": 25915,
    "contract": "200703"
  },
  {
    "date": "2007-03-21",
    "close": 7753.0,
    "volume": 15264,
    "contract": "200703"
  },
  {
    "date": "2007-03-22",
    "close": 7829.0,
    "volume": 32326,
    "contract": "200704"
  },
  {
    "date": "2007-03-23",
    "close": 7855.0,
    "volume": 35621,
    "contract": "200704"
  },
  {
    "date": "2007-03-26",
    "close": 7883.0,
    "volume": 18563,
    "contract": "200704"
  },
  {
    "date": "2007-03-27",
    "close": 7824.0,
    "volume": 44457,
    "contract": "200704"
  },
  {
    "date": "2007-03-28",
    "close": 7750.0,
    "volume": 38366,
    "contract": "200704"
  },
  {
    "date": "2007-03-29",
    "close": 7838.0,
    "volume": 42427,
    "contract": "200704"
  },
  {
    "date": "2007-03-30",
    "close": 7834.0,
    "volume": 33221,
    "contract": "200704"
  },
  {
    "date": "2007-04-02",
    "close": 7849.0,
    "volume": 38270,
    "contract": "200704"
  },
  {
    "date": "2007-04-03",
    "close": 7919.0,
    "volume": 33861,
    "contract": "200704"
  },
  {
    "date": "2007-04-04",
    "close": 7999.0,
    "volume": 38073,
    "contract": "200704"
  },
  {
    "date": "2007-04-09",
    "close": 8072.0,
    "volume": 27923,
    "contract": "200704"
  },
  {
    "date": "2007-04-10",
    "close": 8053.0,
    "volume": 30335,
    "contract": "200704"
  },
  {
    "date": "2007-04-11",
    "close": 8095.0,
    "volume": 32416,
    "contract": "200704"
  },
  {
    "date": "2007-04-12",
    "close": 8077.0,
    "volume": 27047,
    "contract": "200704"
  },
  {
    "date": "2007-04-13",
    "close": 7990.0,
    "volume": 46821,
    "contract": "200704"
  },
  {
    "date": "2007-04-14",
    "close": 8067.0,
    "volume": 17797,
    "contract": "200704"
  },
  {
    "date": "2007-04-16",
    "close": 8057.0,
    "volume": 35553,
    "contract": "200704"
  },
  {
    "date": "2007-04-17",
    "close": 7964.0,
    "volume": 44842,
    "contract": "200704"
  },
  {
    "date": "2007-04-18",
    "close": 8010.0,
    "volume": 18882,
    "contract": "200704"
  },
  {
    "date": "2007-04-19",
    "close": 7839.0,
    "volume": 53798,
    "contract": "200705"
  },
  {
    "date": "2007-04-20",
    "close": 7887.0,
    "volume": 25520,
    "contract": "200705"
  },
  {
    "date": "2007-04-23",
    "close": 8016.0,
    "volume": 41605,
    "contract": "200705"
  },
  {
    "date": "2007-04-24",
    "close": 8038.0,
    "volume": 37592,
    "contract": "200705"
  },
  {
    "date": "2007-04-25",
    "close": 7960.0,
    "volume": 38631,
    "contract": "200705"
  },
  {
    "date": "2007-04-26",
    "close": 8002.0,
    "volume": 30959,
    "contract": "200705"
  },
  {
    "date": "2007-04-27",
    "close": 7946.0,
    "volume": 38300,
    "contract": "200705"
  },
  {
    "date": "2007-04-30",
    "close": 7850.0,
    "volume": 38588,
    "contract": "200705"
  },
  {
    "date": "2007-05-02",
    "close": 7896.0,
    "volume": 31632,
    "contract": "200705"
  },
  {
    "date": "2007-05-03",
    "close": 7936.0,
    "volume": 46485,
    "contract": "200705"
  },
  {
    "date": "2007-05-04",
    "close": 8057.0,
    "volume": 42442,
    "contract": "200705"
  },
  {
    "date": "2007-05-07",
    "close": 8114.0,
    "volume": 30749,
    "contract": "200705"
  },
  {
    "date": "2007-05-08",
    "close": 8072.0,
    "volume": 34102,
    "contract": "200705"
  },
  {
    "date": "2007-05-09",
    "close": 8068.0,
    "volume": 34187,
    "contract": "200705"
  },
  {
    "date": "2007-05-10",
    "close": 8109.0,
    "volume": 26439,
    "contract": "200705"
  },
  {
    "date": "2007-05-11",
    "close": 8021.0,
    "volume": 34106,
    "contract": "200705"
  },
  {
    "date": "2007-05-14",
    "close": 8044.0,
    "volume": 31220,
    "contract": "200705"
  },
  {
    "date": "2007-05-15",
    "close": 7969.0,
    "volume": 40725,
    "contract": "200705"
  },
  {
    "date": "2007-05-16",
    "close": 7991.0,
    "volume": 15997,
    "contract": "200705"
  },
  {
    "date": "2007-05-17",
    "close": 8015.0,
    "volume": 37732,
    "contract": "200706"
  },
  {
    "date": "2007-05-18",
    "close": 8030.0,
    "volume": 30649,
    "contract": "200706"
  },
  {
    "date": "2007-05-21",
    "close": 8122.0,
    "volume": 47037,
    "contract": "200706"
  },
  {
    "date": "2007-05-22",
    "close": 8176.0,
    "volume": 34802,
    "contract": "200706"
  },
  {
    "date": "2007-05-23",
    "close": 8204.0,
    "volume": 29667,
    "contract": "200706"
  },
  {
    "date": "2007-05-24",
    "close": 8170.0,
    "volume": 30996,
    "contract": "200706"
  },
  {
    "date": "2007-05-25",
    "close": 8134.0,
    "volume": 29357,
    "contract": "200706"
  },
  {
    "date": "2007-05-28",
    "close": 8154.0,
    "volume": 20495,
    "contract": "200706"
  },
  {
    "date": "2007-05-29",
    "close": 8168.0,
    "volume": 36991,
    "contract": "200706"
  },
  {
    "date": "2007-05-30",
    "close": 8111.0,
    "volume": 45902,
    "contract": "200706"
  },
  {
    "date": "2007-05-31",
    "close": 8171.0,
    "volume": 33935,
    "contract": "200706"
  },
  {
    "date": "2007-06-01",
    "close": 8232.0,
    "volume": 30878,
    "contract": "200706"
  },
  {
    "date": "2007-06-04",
    "close": 8257.0,
    "volume": 24926,
    "contract": "200706"
  },
  {
    "date": "2007-06-05",
    "close": 8254.0,
    "volume": 33482,
    "contract": "200706"
  },
  {
    "date": "2007-06-06",
    "close": 8285.0,
    "volume": 43403,
    "contract": "200706"
  },
  {
    "date": "2007-06-07",
    "close": 8336.0,
    "volume": 40731,
    "contract": "200706"
  },
  {
    "date": "2007-06-08",
    "close": 8276.0,
    "volume": 37950,
    "contract": "200706"
  },
  {
    "date": "2007-06-11",
    "close": 8313.0,
    "volume": 23889,
    "contract": "200706"
  },
  {
    "date": "2007-06-12",
    "close": 8338.0,
    "volume": 32051,
    "contract": "200706"
  },
  {
    "date": "2007-06-13",
    "close": 8331.0,
    "volume": 27311,
    "contract": "200706"
  },
  {
    "date": "2007-06-14",
    "close": 8443.0,
    "volume": 37951,
    "contract": "200706"
  },
  {
    "date": "2007-06-15",
    "close": 8595.0,
    "volume": 41472,
    "contract": "200706"
  },
  {
    "date": "2007-06-20",
    "close": 8770.0,
    "volume": 39099,
    "contract": "200706"
  },
  {
    "date": "2007-06-21",
    "close": 8862.0,
    "volume": 73073,
    "contract": "200707"
  },
  {
    "date": "2007-06-22",
    "close": 8825.0,
    "volume": 45593,
    "contract": "200707"
  },
  {
    "date": "2007-06-23",
    "close": 8770.0,
    "volume": 19549,
    "contract": "200707"
  },
  {
    "date": "2007-06-25",
    "close": 8913.0,
    "volume": 50431,
    "contract": "200707"
  },
  {
    "date": "2007-06-26",
    "close": 8840.0,
    "volume": 43813,
    "contract": "200707"
  },
  {
    "date": "2007-06-27",
    "close": 8776.0,
    "volume": 45178,
    "contract": "200707"
  },
  {
    "date": "2007-06-28",
    "close": 8838.0,
    "volume": 41259,
    "contract": "200707"
  },
  {
    "date": "2007-06-29",
    "close": 8808.0,
    "volume": 41445,
    "contract": "200707"
  },
  {
    "date": "2007-07-02",
    "close": 8895.0,
    "volume": 42687,
    "contract": "200707"
  },
  {
    "date": "2007-07-03",
    "close": 8972.0,
    "volume": 40061,
    "contract": "200707"
  },
  {
    "date": "2007-07-04",
    "close": 9053.0,
    "volume": 53666,
    "contract": "200707"
  },
  {
    "date": "2007-07-05",
    "close": 9123.0,
    "volume": 40206,
    "contract": "200707"
  },
  {
    "date": "2007-07-06",
    "close": 9142.0,
    "volume": 48518,
    "contract": "200707"
  },
  {
    "date": "2007-07-09",
    "close": 9376.0,
    "volume": 53212,
    "contract": "200707"
  },
  {
    "date": "2007-07-10",
    "close": 9336.0,
    "volume": 53062,
    "contract": "200707"
  },
  {
    "date": "2007-07-11",
    "close": 9226.0,
    "volume": 43586,
    "contract": "200707"
  },
  {
    "date": "2007-07-12",
    "close": 9323.0,
    "volume": 53576,
    "contract": "200707"
  },
  {
    "date": "2007-07-13",
    "close": 9458.0,
    "volume": 55472,
    "contract": "200707"
  },
  {
    "date": "2007-07-16",
    "close": 9372.0,
    "volume": 52746,
    "contract": "200707"
  },
  {
    "date": "2007-07-17",
    "close": 9524.0,
    "volume": 57891,
    "contract": "200707"
  },
  {
    "date": "2007-07-18",
    "close": 9480.0,
    "volume": 35817,
    "contract": "200707"
  },
  {
    "date": "2007-07-19",
    "close": 9419.0,
    "volume": 64275,
    "contract": "200708"
  },
  {
    "date": "2007-07-20",
    "close": 9545.0,
    "volume": 54337,
    "contract": "200708"
  },
  {
    "date": "2007-07-23",
    "close": 9549.0,
    "volume": 44963,
    "contract": "200708"
  },
  {
    "date": "2007-07-24",
    "close": 9674.0,
    "volume": 64366,
    "contract": "200708"
  },
  {
    "date": "2007-07-25",
    "close": 9739.0,
    "volume": 61436,
    "contract": "200708"
  },
  {
    "date": "2007-07-26",
    "close": 9546.0,
    "volume": 98191,
    "contract": "200708"
  },
  {
    "date": "2007-07-27",
    "close": 8981.0,
    "volume": 107872,
    "contract": "200708"
  },
  {
    "date": "2007-07-30",
    "close": 8990.0,
    "volume": 90159,
    "contract": "200708"
  },
  {
    "date": "2007-07-31",
    "close": 9176.0,
    "volume": 71135,
    "contract": "200708"
  },
  {
    "date": "2007-08-01",
    "close": 8695.0,
    "volume": 116430,
    "contract": "200708"
  },
  {
    "date": "2007-08-02",
    "close": 8880.0,
    "volume": 116485,
    "contract": "200708"
  },
  {
    "date": "2007-08-03",
    "close": 8985.0,
    "volume": 67768,
    "contract": "200708"
  },
  {
    "date": "2007-08-06",
    "close": 8860.0,
    "volume": 52686,
    "contract": "200708"
  },
  {
    "date": "2007-08-07",
    "close": 8767.0,
    "volume": 58867,
    "contract": "200708"
  },
  {
    "date": "2007-08-08",
    "close": 9078.0,
    "volume": 52580,
    "contract": "200708"
  },
  {
    "date": "2007-08-09",
    "close": 9136.0,
    "volume": 53202,
    "contract": "200708"
  },
  {
    "date": "2007-08-10",
    "close": 8800.0,
    "volume": 64613,
    "contract": "200708"
  },
  {
    "date": "2007-08-13",
    "close": 8925.0,
    "volume": 47528,
    "contract": "200708"
  },
  {
    "date": "2007-08-14",
    "close": 8885.0,
    "volume": 55688,
    "contract": "200708"
  },
  {
    "date": "2007-08-15",
    "close": 8570.0,
    "volume": 28708,
    "contract": "200708"
  },
  {
    "date": "2007-08-16",
    "close": 8154.0,
    "volume": 86225,
    "contract": "200709"
  },
  {
    "date": "2007-08-17",
    "close": 7885.0,
    "volume": 79117,
    "contract": "200709"
  },
  {
    "date": "2007-08-20",
    "close": 8428.0,
    "volume": 55861,
    "contract": "200709"
  },
  {
    "date": "2007-08-21",
    "close": 8365.0,
    "volume": 67565,
    "contract": "200709"
  },
  {
    "date": "2007-08-22",
    "close": 8437.0,
    "volume": 41609,
    "contract": "200709"
  },
  {
    "date": "2007-08-23",
    "close": 8687.0,
    "volume": 36469,
    "contract": "200709"
  },
  {
    "date": "2007-08-24",
    "close": 8600.0,
    "volume": 30079,
    "contract": "200709"
  },
  {
    "date": "2007-08-27",
    "close": 8637.0,
    "volume": 29878,
    "contract": "200709"
  },
  {
    "date": "2007-08-28",
    "close": 8680.0,
    "volume": 36694,
    "contract": "200709"
  },
  {
    "date": "2007-08-29",
    "close": 8549.0,
    "volume": 37086,
    "contract": "200709"
  },
  {
    "date": "2007-08-30",
    "close": 8700.0,
    "volume": 36585,
    "contract": "200709"
  },
  {
    "date": "2007-08-31",
    "close": 8976.0,
    "volume": 43967,
    "contract": "200709"
  },
  {
    "date": "2007-09-03",
    "close": 8956.0,
    "volume": 26681,
    "contract": "200709"
  },
  {
    "date": "2007-09-04",
    "close": 8890.0,
    "volume": 41278,
    "contract": "200709"
  },
  {
    "date": "2007-09-05",
    "close": 8821.0,
    "volume": 34174,
    "contract": "200709"
  },
  {
    "date": "2007-09-06",
    "close": 9017.0,
    "volume": 48008,
    "contract": "200709"
  },
  {
    "date": "2007-09-07",
    "close": 8982.0,
    "volume": 34938,
    "contract": "200709"
  },
  {
    "date": "2007-09-10",
    "close": 8890.0,
    "volume": 40589,
    "contract": "200709"
  },
  {
    "date": "2007-09-11",
    "close": 9002.0,
    "volume": 32391,
    "contract": "200709"
  },
  {
    "date": "2007-09-12",
    "close": 8936.0,
    "volume": 38628,
    "contract": "200709"
  },
  {
    "date": "2007-09-13",
    "close": 8921.0,
    "volume": 35159,
    "contract": "200709"
  },
  {
    "date": "2007-09-14",
    "close": 9030.0,
    "volume": 37575,
    "contract": "200709"
  },
  {
    "date": "2007-09-17",
    "close": 8888.0,
    "volume": 41479,
    "contract": "200709"
  },
  {
    "date": "2007-09-19",
    "close": 8923.0,
    "volume": 41268,
    "contract": "200709"
  },
  {
    "date": "2007-09-20",
    "close": 9016.0,
    "volume": 50212,
    "contract": "200710"
  },
  {
    "date": "2007-09-21",
    "close": 9132.0,
    "volume": 37301,
    "contract": "200710"
  },
  {
    "date": "2007-09-26",
    "close": 9275.0,
    "volume": 29579,
    "contract": "200710"
  },
  {
    "date": "2007-09-27",
    "close": 9410.0,
    "volume": 33940,
    "contract": "200710"
  },
  {
    "date": "2007-09-28",
    "close": 9380.0,
    "volume": 35106,
    "contract": "200710"
  },
  {
    "date": "2007-09-29",
    "close": 9492.0,
    "volume": 28355,
    "contract": "200710"
  },
  {
    "date": "2007-10-01",
    "close": 9501.0,
    "volume": 30668,
    "contract": "200710"
  },
  {
    "date": "2007-10-02",
    "close": 9669.0,
    "volume": 38781,
    "contract": "200710"
  },
  {
    "date": "2007-10-03",
    "close": 9771.0,
    "volume": 51611,
    "contract": "200710"
  },
  {
    "date": "2007-10-04",
    "close": 9678.0,
    "volume": 42259,
    "contract": "200710"
  },
  {
    "date": "2007-10-05",
    "close": 9617.0,
    "volume": 37296,
    "contract": "200710"
  },
  {
    "date": "2007-10-08",
    "close": 9740.0,
    "volume": 27198,
    "contract": "200710"
  },
  {
    "date": "2007-10-09",
    "close": 9653.0,
    "volume": 38169,
    "contract": "200710"
  },
  {
    "date": "2007-10-11",
    "close": 9747.0,
    "volume": 32380,
    "contract": "200710"
  },
  {
    "date": "2007-10-12",
    "close": 9452.0,
    "volume": 56332,
    "contract": "200710"
  },
  {
    "date": "2007-10-15",
    "close": 9503.0,
    "volume": 38356,
    "contract": "200710"
  },
  {
    "date": "2007-10-16",
    "close": 9562.0,
    "volume": 43561,
    "contract": "200710"
  },
  {
    "date": "2007-10-17",
    "close": 9555.0,
    "volume": 23703,
    "contract": "200710"
  },
  {
    "date": "2007-10-18",
    "close": 9677.0,
    "volume": 44778,
    "contract": "200711"
  },
  {
    "date": "2007-10-19",
    "close": 9608.0,
    "volume": 30317,
    "contract": "200711"
  },
  {
    "date": "2007-10-22",
    "close": 9324.0,
    "volume": 47846,
    "contract": "200711"
  },
  {
    "date": "2007-10-23",
    "close": 9511.0,
    "volume": 37836,
    "contract": "200711"
  },
  {
    "date": "2007-10-24",
    "close": 9457.0,
    "volume": 49167,
    "contract": "200711"
  },
  {
    "date": "2007-10-25",
    "close": 9594.0,
    "volume": 42192,
    "contract": "200711"
  },
  {
    "date": "2007-10-26",
    "close": 9675.0,
    "volume": 36849,
    "contract": "200711"
  },
  {
    "date": "2007-10-29",
    "close": 9862.0,
    "volume": 37243,
    "contract": "200711"
  },
  {
    "date": "2007-10-30",
    "close": 9787.0,
    "volume": 35700,
    "contract": "200711"
  },
  {
    "date": "2007-10-31",
    "close": 9777.0,
    "volume": 41545,
    "contract": "200711"
  },
  {
    "date": "2007-11-01",
    "close": 9657.0,
    "volume": 62539,
    "contract": "200711"
  },
  {
    "date": "2007-11-02",
    "close": 9230.0,
    "volume": 63487,
    "contract": "200711"
  },
  {
    "date": "2007-11-05",
    "close": 9275.0,
    "volume": 53640,
    "contract": "200711"
  },
  {
    "date": "2007-11-06",
    "close": 9304.0,
    "volume": 41027,
    "contract": "200711"
  },
  {
    "date": "2007-11-07",
    "close": 9270.0,
    "volume": 42965,
    "contract": "200711"
  },
  {
    "date": "2007-11-08",
    "close": 8917.0,
    "volume": 62070,
    "contract": "200711"
  },
  {
    "date": "2007-11-09",
    "close": 8966.0,
    "volume": 56249,
    "contract": "200711"
  },
  {
    "date": "2007-11-12",
    "close": 8679.0,
    "volume": 58576,
    "contract": "200711"
  },
  {
    "date": "2007-11-13",
    "close": 8747.0,
    "volume": 57468,
    "contract": "200711"
  },
  {
    "date": "2007-11-14",
    "close": 8942.0,
    "volume": 37713,
    "contract": "200711"
  },
  {
    "date": "2007-11-15",
    "close": 8867.0,
    "volume": 30295,
    "contract": "200711"
  },
  {
    "date": "2007-11-16",
    "close": 8758.0,
    "volume": 44668,
    "contract": "200711"
  },
  {
    "date": "2007-11-19",
    "close": 8621.0,
    "volume": 41913,
    "contract": "200711"
  },
  {
    "date": "2007-11-20",
    "close": 8717.0,
    "volume": 62113,
    "contract": "200711"
  },
  {
    "date": "2007-11-21",
    "close": 8436.0,
    "volume": 33404,
    "contract": "200711"
  },
  {
    "date": "2007-11-22",
    "close": 8468.0,
    "volume": 74399,
    "contract": "200712"
  },
  {
    "date": "2007-11-23",
    "close": 8322.0,
    "volume": 64396,
    "contract": "200712"
  },
  {
    "date": "2007-11-26",
    "close": 8530.0,
    "volume": 50371,
    "contract": "200712"
  },
  {
    "date": "2007-11-27",
    "close": 8395.0,
    "volume": 83553,
    "contract": "200712"
  },
  {
    "date": "2007-11-28",
    "close": 8246.0,
    "volume": 65310,
    "contract": "200712"
  },
  {
    "date": "2007-11-29",
    "close": 8428.0,
    "volume": 49198,
    "contract": "200712"
  },
  {
    "date": "2007-11-30",
    "close": 8609.0,
    "volume": 50961,
    "contract": "200712"
  },
  {
    "date": "2007-12-03",
    "close": 8596.0,
    "volume": 36221,
    "contract": "200712"
  },
  {
    "date": "2007-12-04",
    "close": 8618.0,
    "volume": 42369,
    "contract": "200712"
  },
  {
    "date": "2007-12-05",
    "close": 8704.0,
    "volume": 58853,
    "contract": "200712"
  },
  {
    "date": "2007-12-06",
    "close": 8738.0,
    "volume": 43111,
    "contract": "200712"
  },
  {
    "date": "2007-12-07",
    "close": 8708.0,
    "volume": 48003,
    "contract": "200712"
  },
  {
    "date": "2007-12-10",
    "close": 8558.0,
    "volume": 46878,
    "contract": "200712"
  },
  {
    "date": "2007-12-11",
    "close": 8640.0,
    "volume": 45102,
    "contract": "200712"
  },
  {
    "date": "2007-12-12",
    "close": 8499.0,
    "volume": 52980,
    "contract": "200712"
  },
  {
    "date": "2007-12-13",
    "close": 8106.0,
    "volume": 75792,
    "contract": "200712"
  },
  {
    "date": "2007-12-14",
    "close": 8058.0,
    "volume": 93751,
    "contract": "200712"
  },
  {
    "date": "2007-12-17",
    "close": 7749.0,
    "volume": 71995,
    "contract": "200712"
  },
  {
    "date": "2007-12-18",
    "close": 7812.0,
    "volume": 76912,
    "contract": "200712"
  },
  {
    "date": "2007-12-19",
    "close": 8014.0,
    "volume": 31677,
    "contract": "200712"
  },
  {
    "date": "2007-12-20",
    "close": 7844.0,
    "volume": 63510,
    "contract": "200801"
  },
  {
    "date": "2007-12-21",
    "close": 7970.0,
    "volume": 77603,
    "contract": "200801"
  },
  {
    "date": "2007-12-24",
    "close": 8132.0,
    "volume": 37275,
    "contract": "200801"
  },
  {
    "date": "2007-12-25",
    "close": 8147.0,
    "volume": 30619,
    "contract": "200801"
  },
  {
    "date": "2007-12-26",
    "close": 8185.0,
    "volume": 42692,
    "contract": "200801"
  },
  {
    "date": "2007-12-27",
    "close": 8327.0,
    "volume": 55404,
    "contract": "200801"
  },
  {
    "date": "2007-12-28",
    "close": 8394.0,
    "volume": 65929,
    "contract": "200801"
  },
  {
    "date": "2007-12-31",
    "close": 8483.0,
    "volume": 32943,
    "contract": "200801"
  },
  {
    "date": "2008-01-02",
    "close": 8283.0,
    "volume": 61525,
    "contract": "200801"
  },
  {
    "date": "2008-01-03",
    "close": 8143.0,
    "volume": 80492,
    "contract": "200801"
  },
  {
    "date": "2008-01-04",
    "close": 8210.0,
    "volume": 72552,
    "contract": "200801"
  },
  {
    "date": "2008-01-07",
    "close": 7833.0,
    "volume": 72476,
    "contract": "200801"
  },
  {
    "date": "2008-01-08",
    "close": 7918.0,
    "volume": 55646,
    "contract": "200801"
  },
  {
    "date": "2008-01-09",
    "close": 8090.0,
    "volume": 80583,
    "contract": "200801"
  },
  {
    "date": "2008-01-10",
    "close": 8072.0,
    "volume": 64976,
    "contract": "200801"
  },
  {
    "date": "2008-01-11",
    "close": 7967.0,
    "volume": 71601,
    "contract": "200801"
  },
  {
    "date": "2008-01-14",
    "close": 8243.0,
    "volume": 96124,
    "contract": "200801"
  },
  {
    "date": "2008-01-15",
    "close": 8501.0,
    "volume": 94553,
    "contract": "200801"
  },
  {
    "date": "2008-01-16",
    "close": 8152.0,
    "volume": 45503,
    "contract": "200801"
  },
  {
    "date": "2008-01-17",
    "close": 8081.0,
    "volume": 92836,
    "contract": "200802"
  },
  {
    "date": "2008-01-18",
    "close": 8213.0,
    "volume": 77879,
    "contract": "200802"
  },
  {
    "date": "2008-01-21",
    "close": 8110.0,
    "volume": 59160,
    "contract": "200802"
  },
  {
    "date": "2008-01-22",
    "close": 7543.0,
    "volume": 46130,
    "contract": "200802"
  },
  {
    "date": "2008-01-23",
    "close": 7338.0,
    "volume": 94655,
    "contract": "200802"
  },
  {
    "date": "2008-01-24",
    "close": 7538.0,
    "volume": 86298,
    "contract": "200802"
  },
  {
    "date": "2008-01-25",
    "close": 7766.0,
    "volume": 61697,
    "contract": "200802"
  },
  {
    "date": "2008-01-28",
    "close": 7447.0,
    "volume": 63484,
    "contract": "200802"
  },
  {
    "date": "2008-01-29",
    "close": 7526.0,
    "volume": 70620,
    "contract": "200802"
  },
  {
    "date": "2008-01-30",
    "close": 7517.0,
    "volume": 77131,
    "contract": "200802"
  },
  {
    "date": "2008-01-31",
    "close": 7463.0,
    "volume": 81244,
    "contract": "200802"
  },
  {
    "date": "2008-02-01",
    "close": 7667.0,
    "volume": 57817,
    "contract": "200802"
  },
  {
    "date": "2008-02-12",
    "close": 7505.0,
    "volume": 50394,
    "contract": "200802"
  },
  {
    "date": "2008-02-13",
    "close": 7491.0,
    "volume": 43089,
    "contract": "200802"
  },
  {
    "date": "2008-02-14",
    "close": 7897.0,
    "volume": 53718,
    "contract": "200802"
  },
  {
    "date": "2008-02-15",
    "close": 7890.0,
    "volume": 55764,
    "contract": "200802"
  },
  {
    "date": "2008-02-18",
    "close": 7917.0,
    "volume": 56399,
    "contract": "200802"
  },
  {
    "date": "2008-02-19",
    "close": 8022.0,
    "volume": 50742,
    "contract": "200802"
  },
  {
    "date": "2008-02-20",
    "close": 7877.0,
    "volume": 30928,
    "contract": "200802"
  },
  {
    "date": "2008-02-21",
    "close": 8027.0,
    "volume": 59056,
    "contract": "200803"
  },
  {
    "date": "2008-02-22",
    "close": 8038.0,
    "volume": 52384,
    "contract": "200803"
  },
  {
    "date": "2008-02-25",
    "close": 8226.0,
    "volume": 45763,
    "contract": "200803"
  },
  {
    "date": "2008-02-26",
    "close": 8280.0,
    "volume": 47730,
    "contract": "200803"
  },
  {
    "date": "2008-02-27",
    "close": 8373.0,
    "volume": 49946,
    "contract": "200803"
  },
  {
    "date": "2008-02-29",
    "close": 8341.0,
    "volume": 50020,
    "contract": "200803"
  },
  {
    "date": "2008-03-03",
    "close": 8249.0,
    "volume": 57420,
    "contract": "200803"
  },
  {
    "date": "2008-03-04",
    "close": 8488.0,
    "volume": 73926,
    "contract": "200803"
  },
  {
    "date": "2008-03-05",
    "close": 8510.0,
    "volume": 68568,
    "contract": "200803"
  },
  {
    "date": "2008-03-06",
    "close": 8683.0,
    "volume": 69477,
    "contract": "200803"
  },
  {
    "date": "2008-03-07",
    "close": 8526.0,
    "volume": 70844,
    "contract": "200803"
  },
  {
    "date": "2008-03-10",
    "close": 8305.0,
    "volume": 73338,
    "contract": "200803"
  },
  {
    "date": "2008-03-11",
    "close": 8371.0,
    "volume": 67259,
    "contract": "200803"
  },
  {
    "date": "2008-03-12",
    "close": 8467.0,
    "volume": 68590,
    "contract": "200803"
  },
  {
    "date": "2008-03-13",
    "close": 8190.0,
    "volume": 70064,
    "contract": "200803"
  },
  {
    "date": "2008-03-14",
    "close": 8109.0,
    "volume": 76049,
    "contract": "200803"
  },
  {
    "date": "2008-03-17",
    "close": 7979.0,
    "volume": 84117,
    "contract": "200803"
  },
  {
    "date": "2008-03-18",
    "close": 8053.0,
    "volume": 69653,
    "contract": "200803"
  },
  {
    "date": "2008-03-19",
    "close": 8172.0,
    "volume": 37508,
    "contract": "200803"
  },
  {
    "date": "2008-03-20",
    "close": 8336.0,
    "volume": 83186,
    "contract": "200804"
  },
  {
    "date": "2008-03-21",
    "close": 8612.0,
    "volume": 77309,
    "contract": "200804"
  },
  {
    "date": "2008-03-24",
    "close": 8889.0,
    "volume": 108244,
    "contract": "200804"
  },
  {
    "date": "2008-03-25",
    "close": 8759.0,
    "volume": 87588,
    "contract": "200804"
  },
  {
    "date": "2008-03-26",
    "close": 8723.0,
    "volume": 71776,
    "contract": "200804"
  },
  {
    "date": "2008-03-27",
    "close": 8558.0,
    "volume": 82045,
    "contract": "200804"
  },
  {
    "date": "2008-03-28",
    "close": 8619.0,
    "volume": 67509,
    "contract": "200804"
  },
  {
    "date": "2008-03-31",
    "close": 8520.0,
    "volume": 60141,
    "contract": "200804"
  },
  {
    "date": "2008-04-01",
    "close": 8331.0,
    "volume": 61754,
    "contract": "200804"
  },
  {
    "date": "2008-04-02",
    "close": 8573.0,
    "volume": 65578,
    "contract": "200804"
  },
  {
    "date": "2008-04-03",
    "close": 8572.0,
    "volume": 52347,
    "contract": "200804"
  },
  {
    "date": "2008-04-07",
    "close": 8706.0,
    "volume": 45697,
    "contract": "200804"
  },
  {
    "date": "2008-04-08",
    "close": 8637.0,
    "volume": 43626,
    "contract": "200804"
  },
  {
    "date": "2008-04-09",
    "close": 8676.0,
    "volume": 72873,
    "contract": "200804"
  },
  {
    "date": "2008-04-10",
    "close": 8814.0,
    "volume": 70113,
    "contract": "200804"
  },
  {
    "date": "2008-04-11",
    "close": 8911.0,
    "volume": 65842,
    "contract": "200804"
  },
  {
    "date": "2008-04-14",
    "close": 8871.0,
    "volume": 58867,
    "contract": "200804"
  },
  {
    "date": "2008-04-15",
    "close": 8915.0,
    "volume": 57742,
    "contract": "200804"
  },
  {
    "date": "2008-04-16",
    "close": 9084.0,
    "volume": 35202,
    "contract": "200804"
  },
  {
    "date": "2008-04-17",
    "close": 9064.0,
    "volume": 65275,
    "contract": "200805"
  },
  {
    "date": "2008-04-18",
    "close": 9081.0,
    "volume": 50482,
    "contract": "200805"
  },
  {
    "date": "2008-04-21",
    "close": 9084.0,
    "volume": 49855,
    "contract": "200805"
  },
  {
    "date": "2008-04-22",
    "close": 9029.0,
    "volume": 49137,
    "contract": "200805"
  },
  {
    "date": "2008-04-23",
    "close": 8984.0,
    "volume": 68333,
    "contract": "200805"
  },
  {
    "date": "2008-04-24",
    "close": 8979.0,
    "volume": 50961,
    "contract": "200805"
  },
  {
    "date": "2008-04-25",
    "close": 8986.0,
    "volume": 54703,
    "contract": "200805"
  },
  {
    "date": "2008-04-28",
    "close": 9090.0,
    "volume": 54693,
    "contract": "200805"
  },
  {
    "date": "2008-04-29",
    "close": 8925.0,
    "volume": 62994,
    "contract": "200805"
  },
  {
    "date": "2008-04-30",
    "close": 8933.0,
    "volume": 48508,
    "contract": "200805"
  },
  {
    "date": "2008-05-02",
    "close": 9003.0,
    "volume": 45415,
    "contract": "200805"
  },
  {
    "date": "2008-05-05",
    "close": 8849.0,
    "volume": 56697,
    "contract": "200805"
  },
  {
    "date": "2008-05-06",
    "close": 8869.0,
    "volume": 53812,
    "contract": "200805"
  },
  {
    "date": "2008-05-07",
    "close": 8918.0,
    "volume": 54074,
    "contract": "200805"
  },
  {
    "date": "2008-05-08",
    "close": 8893.0,
    "volume": 52607,
    "contract": "200805"
  },
  {
    "date": "2008-05-09",
    "close": 8773.0,
    "volume": 57824,
    "contract": "200805"
  },
  {
    "date": "2008-05-12",
    "close": 8860.0,
    "volume": 46950,
    "contract": "200805"
  },
  {
    "date": "2008-05-13",
    "close": 9030.0,
    "volume": 62520,
    "contract": "200805"
  },
  {
    "date": "2008-05-14",
    "close": 9059.0,
    "volume": 53252,
    "contract": "200805"
  },
  {
    "date": "2008-05-15",
    "close": 9182.0,
    "volume": 53937,
    "contract": "200805"
  },
  {
    "date": "2008-05-16",
    "close": 9246.0,
    "volume": 55311,
    "contract": "200805"
  },
  {
    "date": "2008-05-19",
    "close": 9373.0,
    "volume": 50694,
    "contract": "200805"
  },
  {
    "date": "2008-05-20",
    "close": 9073.0,
    "volume": 82888,
    "contract": "200805"
  },
  {
    "date": "2008-05-21",
    "close": 8999.0,
    "volume": 31585,
    "contract": "200805"
  },
  {
    "date": "2008-05-22",
    "close": 9015.0,
    "volume": 56927,
    "contract": "200806"
  },
  {
    "date": "2008-05-23",
    "close": 8784.0,
    "volume": 70602,
    "contract": "200806"
  },
  {
    "date": "2008-05-26",
    "close": 8696.0,
    "volume": 55991,
    "contract": "200806"
  },
  {
    "date": "2008-05-27",
    "close": 8772.0,
    "volume": 44115,
    "contract": "200806"
  },
  {
    "date": "2008-05-28",
    "close": 8644.0,
    "volume": 65710,
    "contract": "200806"
  },
  {
    "date": "2008-05-29",
    "close": 8717.0,
    "volume": 56724,
    "contract": "200806"
  },
  {
    "date": "2008-05-30",
    "close": 8649.0,
    "volume": 75944,
    "contract": "200806"
  },
  {
    "date": "2008-06-02",
    "close": 8701.0,
    "volume": 49486,
    "contract": "200806"
  },
  {
    "date": "2008-06-03",
    "close": 8538.0,
    "volume": 55854,
    "contract": "200806"
  },
  {
    "date": "2008-06-04",
    "close": 8592.0,
    "volume": 44304,
    "contract": "200806"
  },
  {
    "date": "2008-06-05",
    "close": 8723.0,
    "volume": 78823,
    "contract": "200806"
  },
  {
    "date": "2008-06-06",
    "close": 8753.0,
    "volume": 49247,
    "contract": "200806"
  },
  {
    "date": "2008-06-09",
    "close": 8528.0,
    "volume": 44700,
    "contract": "200806"
  },
  {
    "date": "2008-06-10",
    "close": 8339.0,
    "volume": 75224,
    "contract": "200806"
  },
  {
    "date": "2008-06-11",
    "close": 8317.0,
    "volume": 58833,
    "contract": "200806"
  },
  {
    "date": "2008-06-12",
    "close": 8038.0,
    "volume": 75487,
    "contract": "200806"
  },
  {
    "date": "2008-06-13",
    "close": 8042.0,
    "volume": 62933,
    "contract": "200806"
  },
  {
    "date": "2008-06-16",
    "close": 8133.0,
    "volume": 53114,
    "contract": "200806"
  },
  {
    "date": "2008-06-17",
    "close": 8146.0,
    "volume": 70641,
    "contract": "200806"
  },
  {
    "date": "2008-06-18",
    "close": 8216.0,
    "volume": 36474,
    "contract": "200806"
  },
  {
    "date": "2008-06-19",
    "close": 7889.0,
    "volume": 53348,
    "contract": "200807"
  },
  {
    "date": "2008-06-20",
    "close": 7777.0,
    "volume": 70635,
    "contract": "200807"
  },
  {
    "date": "2008-06-23",
    "close": 7753.0,
    "volume": 63155,
    "contract": "200807"
  },
  {
    "date": "2008-06-24",
    "close": 7688.0,
    "volume": 64047,
    "contract": "200807"
  },
  {
    "date": "2008-06-25",
    "close": 7749.0,
    "volume": 69319,
    "contract": "200807"
  },
  {
    "date": "2008-06-26",
    "close": 7695.0,
    "volume": 60885,
    "contract": "200807"
  },
  {
    "date": "2008-06-27",
    "close": 7416.0,
    "volume": 67637,
    "contract": "200807"
  },
  {
    "date": "2008-06-30",
    "close": 7417.0,
    "volume": 51421,
    "contract": "200807"
  },
  {
    "date": "2008-07-01",
    "close": 7296.0,
    "volume": 62874,
    "contract": "200807"
  },
  {
    "date": "2008-07-02",
    "close": 7247.0,
    "volume": 74253,
    "contract": "200807"
  },
  {
    "date": "2008-07-03",
    "close": 7296.0,
    "volume": 88271,
    "contract": "200807"
  },
  {
    "date": "2008-07-04",
    "close": 7103.0,
    "volume": 68358,
    "contract": "200807"
  },
  {
    "date": "2008-07-07",
    "close": 7258.0,
    "volume": 62222,
    "contract": "200807"
  },
  {
    "date": "2008-07-08",
    "close": 6985.0,
    "volume": 86146,
    "contract": "200807"
  },
  {
    "date": "2008-07-09",
    "close": 7016.0,
    "volume": 95748,
    "contract": "200807"
  },
  {
    "date": "2008-07-10",
    "close": 7007.0,
    "volume": 94113,
    "contract": "200807"
  },
  {
    "date": "2008-07-11",
    "close": 7177.0,
    "volume": 97960,
    "contract": "200807"
  },
  {
    "date": "2008-07-14",
    "close": 7149.0,
    "volume": 76318,
    "contract": "200807"
  },
  {
    "date": "2008-07-15",
    "close": 6790.0,
    "volume": 94598,
    "contract": "200807"
  },
  {
    "date": "2008-07-16",
    "close": 6679.0,
    "volume": 60578,
    "contract": "200807"
  },
  {
    "date": "2008-07-17",
    "close": 6798.0,
    "volume": 74717,
    "contract": "200808"
  },
  {
    "date": "2008-07-18",
    "close": 6685.0,
    "volume": 87374,
    "contract": "200808"
  },
  {
    "date": "2008-07-21",
    "close": 7001.0,
    "volume": 71813,
    "contract": "200808"
  },
  {
    "date": "2008-07-22",
    "close": 6964.0,
    "volume": 75341,
    "contract": "200808"
  },
  {
    "date": "2008-07-23",
    "close": 7184.0,
    "volume": 80107,
    "contract": "200808"
  },
  {
    "date": "2008-07-24",
    "close": 7301.0,
    "volume": 64281,
    "contract": "200808"
  },
  {
    "date": "2008-07-25",
    "close": 7167.0,
    "volume": 62134,
    "contract": "200808"
  },
  {
    "date": "2008-07-29",
    "close": 6916.0,
    "volume": 57777,
    "contract": "200808"
  },
  {
    "date": "2008-07-30",
    "close": 7026.0,
    "volume": 66831,
    "contract": "200808"
  },
  {
    "date": "2008-07-31",
    "close": 7002.0,
    "volume": 84825,
    "contract": "200808"
  },
  {
    "date": "2008-08-01",
    "close": 6915.0,
    "volume": 66509,
    "contract": "200808"
  },
  {
    "date": "2008-08-04",
    "close": 6934.0,
    "volume": 53143,
    "contract": "200808"
  },
  {
    "date": "2008-08-05",
    "close": 6778.0,
    "volume": 81580,
    "contract": "200808"
  },
  {
    "date": "2008-08-06",
    "close": 7016.0,
    "volume": 63636,
    "contract": "200808"
  },
  {
    "date": "2008-08-07",
    "close": 7005.0,
    "volume": 64802,
    "contract": "200808"
  },
  {
    "date": "2008-08-08",
    "close": 7188.0,
    "volume": 87708,
    "contract": "200808"
  },
  {
    "date": "2008-08-11",
    "close": 7290.0,
    "volume": 59555,
    "contract": "200808"
  },
  {
    "date": "2008-08-12",
    "close": 7269.0,
    "volume": 56265,
    "contract": "200808"
  },
  {
    "date": "2008-08-13",
    "close": 7296.0,
    "volume": 73849,
    "contract": "200808"
  },
  {
    "date": "2008-08-14",
    "close": 7356.0,
    "volume": 64327,
    "contract": "200808"
  },
  {
    "date": "2008-08-15",
    "close": 7218.0,
    "volume": 73474,
    "contract": "200808"
  },
  {
    "date": "2008-08-18",
    "close": 6980.0,
    "volume": 78395,
    "contract": "200808"
  },
  {
    "date": "2008-08-19",
    "close": 6940.0,
    "volume": 75511,
    "contract": "200808"
  },
  {
    "date": "2008-08-20",
    "close": 7037.0,
    "volume": 45006,
    "contract": "200808"
  },
  {
    "date": "2008-08-21",
    "close": 6875.0,
    "volume": 62073,
    "contract": "200809"
  },
  {
    "date": "2008-08-22",
    "close": 6860.0,
    "volume": 85588,
    "contract": "200809"
  },
  {
    "date": "2008-08-25",
    "close": 6989.0,
    "volume": 58898,
    "contract": "200809"
  },
  {
    "date": "2008-08-26",
    "close": 6944.0,
    "volume": 47895,
    "contract": "200809"
  },
  {
    "date": "2008-08-27",
    "close": 7080.0,
    "volume": 65994,
    "contract": "200809"
  },
  {
    "date": "2008-08-28",
    "close": 7042.0,
    "volume": 55653,
    "contract": "200809"
  },
  {
    "date": "2008-08-29",
    "close": 7053.0,
    "volume": 59255,
    "contract": "200809"
  },
  {
    "date": "2008-09-01",
    "close": 6759.0,
    "volume": 70445,
    "contract": "200809"
  },
  {
    "date": "2008-09-02",
    "close": 6695.0,
    "volume": 75022,
    "contract": "200809"
  },
  {
    "date": "2008-09-03",
    "close": 6586.0,
    "volume": 80450,
    "contract": "200809"
  },
  {
    "date": "2008-09-04",
    "close": 6398.0,
    "volume": 85061,
    "contract": "200809"
  },
  {
    "date": "2008-09-05",
    "close": 6241.0,
    "volume": 69240,
    "contract": "200809"
  },
  {
    "date": "2008-09-08",
    "close": 6677.0,
    "volume": 59253,
    "contract": "200809"
  },
  {
    "date": "2008-09-09",
    "close": 6455.0,
    "volume": 74031,
    "contract": "200809"
  },
  {
    "date": "2008-09-10",
    "close": 6452.0,
    "volume": 85603,
    "contract": "200809"
  },
  {
    "date": "2008-09-11",
    "close": 6234.0,
    "volume": 82819,
    "contract": "200809"
  },
  {
    "date": "2008-09-12",
    "close": 6290.0,
    "volume": 86443,
    "contract": "200809"
  },
  {
    "date": "2008-09-15",
    "close": 5969.0,
    "volume": 81846,
    "contract": "200809"
  },
  {
    "date": "2008-09-16",
    "close": 5687.0,
    "volume": 90493,
    "contract": "200809"
  },
  {
    "date": "2008-09-17",
    "close": 5766.0,
    "volume": 68589,
    "contract": "200809"
  },
  {
    "date": "2008-09-18",
    "close": 5522.0,
    "volume": 104745,
    "contract": "200810"
  },
  {
    "date": "2008-09-19",
    "close": 5908.0,
    "volume": 42344,
    "contract": "200810"
  },
  {
    "date": "2008-09-22",
    "close": 6086.0,
    "volume": 79569,
    "contract": "200810"
  },
  {
    "date": "2008-09-23",
    "close": 6135.0,
    "volume": 72431,
    "contract": "200810"
  },
  {
    "date": "2008-09-24",
    "close": 6154.0,
    "volume": 78510,
    "contract": "200810"
  },
  {
    "date": "2008-09-25",
    "close": 6057.0,
    "volume": 77760,
    "contract": "200810"
  },
  {
    "date": "2008-09-26",
    "close": 5869.0,
    "volume": 83525,
    "contract": "200810"
  },
  {
    "date": "2008-09-30",
    "close": 5546.0,
    "volume": 51459,
    "contract": "200810"
  },
  {
    "date": "2008-10-01",
    "close": 5676.0,
    "volume": 70474,
    "contract": "200810"
  },
  {
    "date": "2008-10-02",
    "close": 5620.0,
    "volume": 81005,
    "contract": "200810"
  },
  {
    "date": "2008-10-03",
    "close": 5643.0,
    "volume": 78624,
    "contract": "200810"
  },
  {
    "date": "2008-10-06",
    "close": 5389.0,
    "volume": 72911,
    "contract": "200810"
  },
  {
    "date": "2008-10-07",
    "close": 5442.0,
    "volume": 91706,
    "contract": "200810"
  },
  {
    "date": "2008-10-08",
    "close": 5116.0,
    "volume": 106404,
    "contract": "200810"
  },
  {
    "date": "2008-10-09",
    "close": 5062.0,
    "volume": 113227,
    "contract": "200810"
  },
  {
    "date": "2008-10-13",
    "close": 4942.0,
    "volume": 65331,
    "contract": "200810"
  },
  {
    "date": "2008-10-14",
    "close": 5287.0,
    "volume": 47432,
    "contract": "200810"
  },
  {
    "date": "2008-10-15",
    "close": 5245.0,
    "volume": 60484,
    "contract": "200810"
  },
  {
    "date": "2008-10-16",
    "close": 4978.0,
    "volume": 3373,
    "contract": "200811"
  },
  {
    "date": "2008-10-17",
    "close": 4804.0,
    "volume": 72243,
    "contract": "200811"
  },
  {
    "date": "2008-10-20",
    "close": 4821.0,
    "volume": 86475,
    "contract": "200811"
  },
  {
    "date": "2008-10-21",
    "close": 4818.0,
    "volume": 117280,
    "contract": "200811"
  },
  {
    "date": "2008-10-22",
    "close": 4656.0,
    "volume": 114002,
    "contract": "200811"
  },
  {
    "date": "2008-10-23",
    "close": 4494.0,
    "volume": 28538,
    "contract": "200811"
  },
  {
    "date": "2008-10-24",
    "close": 4337.0,
    "volume": 31793,
    "contract": "200811"
  },
  {
    "date": "2008-10-27",
    "close": 4034.0,
    "volume": 89165,
    "contract": "200811"
  },
  {
    "date": "2008-10-28",
    "close": 4316.0,
    "volume": 162434,
    "contract": "200811"
  },
  {
    "date": "2008-10-29",
    "close": 4294.0,
    "volume": 170198,
    "contract": "200811"
  },
  {
    "date": "2008-10-30",
    "close": 4594.0,
    "volume": 71800,
    "contract": "200811"
  },
  {
    "date": "2008-10-31",
    "close": 4838.0,
    "volume": 172208,
    "contract": "200811"
  },
  {
    "date": "2008-11-03",
    "close": 4990.0,
    "volume": 146465,
    "contract": "200811"
  },
  {
    "date": "2008-11-04",
    "close": 4982.0,
    "volume": 130831,
    "contract": "200811"
  },
  {
    "date": "2008-11-05",
    "close": 4900.0,
    "volume": 134188,
    "contract": "200811"
  },
  {
    "date": "2008-11-06",
    "close": 4557.0,
    "volume": 61117,
    "contract": "200811"
  },
  {
    "date": "2008-11-07",
    "close": 4630.0,
    "volume": 168009,
    "contract": "200811"
  },
  {
    "date": "2008-11-10",
    "close": 4634.0,
    "volume": 118580,
    "contract": "200811"
  },
  {
    "date": "2008-11-11",
    "close": 4477.0,
    "volume": 121380,
    "contract": "200811"
  },
  {
    "date": "2008-11-12",
    "close": 4522.0,
    "volume": 127683,
    "contract": "200811"
  },
  {
    "date": "2008-11-13",
    "close": 4280.0,
    "volume": 95728,
    "contract": "200811"
  },
  {
    "date": "2008-11-14",
    "close": 4380.0,
    "volume": 117202,
    "contract": "200811"
  },
  {
    "date": "2008-11-17",
    "close": 4360.0,
    "volume": 107475,
    "contract": "200811"
  },
  {
    "date": "2008-11-18",
    "close": 4245.0,
    "volume": 105169,
    "contract": "200811"
  },
  {
    "date": "2008-11-19",
    "close": 4263.0,
    "volume": 66464,
    "contract": "200811"
  },
  {
    "date": "2008-11-20",
    "close": 3902.0,
    "volume": 90822,
    "contract": "200812"
  },
  {
    "date": "2008-11-21",
    "close": 4119.0,
    "volume": 125186,
    "contract": "200812"
  },
  {
    "date": "2008-11-24",
    "close": 4048.0,
    "volume": 100411,
    "contract": "200812"
  },
  {
    "date": "2008-11-25",
    "close": 4198.0,
    "volume": 123548,
    "contract": "200812"
  },
  {
    "date": "2008-11-26",
    "close": 4206.0,
    "volume": 107767,
    "contract": "200812"
  },
  {
    "date": "2008-11-27",
    "close": 4428.0,
    "volume": 105400,
    "contract": "200812"
  },
  {
    "date": "2008-11-28",
    "close": 4459.0,
    "volume": 84216,
    "contract": "200812"
  },
  {
    "date": "2008-12-01",
    "close": 4501.0,
    "volume": 106527,
    "contract": "200812"
  },
  {
    "date": "2008-12-02",
    "close": 4230.0,
    "volume": 89986,
    "contract": "200812"
  },
  {
    "date": "2008-12-03",
    "close": 4189.0,
    "volume": 94480,
    "contract": "200812"
  },
  {
    "date": "2008-12-04",
    "close": 4142.0,
    "volume": 101106,
    "contract": "200812"
  },
  {
    "date": "2008-12-05",
    "close": 4179.0,
    "volume": 91707,
    "contract": "200812"
  },
  {
    "date": "2008-12-08",
    "close": 4471.0,
    "volume": 92419,
    "contract": "200812"
  },
  {
    "date": "2008-12-09",
    "close": 4461.0,
    "volume": 108417,
    "contract": "200812"
  },
  {
    "date": "2008-12-10",
    "close": 4689.0,
    "volume": 115226,
    "contract": "200812"
  },
  {
    "date": "2008-12-11",
    "close": 4669.0,
    "volume": 96047,
    "contract": "200812"
  },
  {
    "date": "2008-12-12",
    "close": 4423.0,
    "volume": 120190,
    "contract": "200812"
  },
  {
    "date": "2008-12-15",
    "close": 4607.0,
    "volume": 111291,
    "contract": "200812"
  },
  {
    "date": "2008-12-16",
    "close": 4589.0,
    "volume": 84148,
    "contract": "200812"
  },
  {
    "date": "2008-12-17",
    "close": 4666.0,
    "volume": 56705,
    "contract": "200812"
  },
  {
    "date": "2008-12-18",
    "close": 4697.0,
    "volume": 87280,
    "contract": "200901"
  },
  {
    "date": "2008-12-19",
    "close": 4680.0,
    "volume": 108938,
    "contract": "200901"
  },
  {
    "date": "2008-12-22",
    "close": 4527.0,
    "volume": 100137,
    "contract": "200901"
  },
  {
    "date": "2008-12-23",
    "close": 4350.0,
    "volume": 104885,
    "contract": "200901"
  },
  {
    "date": "2008-12-24",
    "close": 4377.0,
    "volume": 103168,
    "contract": "200901"
  },
  {
    "date": "2008-12-25",
    "close": 4396.0,
    "volume": 43403,
    "contract": "200901"
  },
  {
    "date": "2008-12-26",
    "close": 4377.0,
    "volume": 68149,
    "contract": "200901"
  },
  {
    "date": "2008-12-29",
    "close": 4388.0,
    "volume": 47088,
    "contract": "200901"
  },
  {
    "date": "2008-12-30",
    "close": 4562.0,
    "volume": 71724,
    "contract": "200901"
  },
  {
    "date": "2008-12-31",
    "close": 4548.0,
    "volume": 68222,
    "contract": "200901"
  },
  {
    "date": "2009-01-05",
    "close": 4669.0,
    "volume": 97901,
    "contract": "200901"
  },
  {
    "date": "2009-01-06",
    "close": 4704.0,
    "volume": 90329,
    "contract": "200901"
  },
  {
    "date": "2009-01-07",
    "close": 4755.0,
    "volume": 90885,
    "contract": "200901"
  },
  {
    "date": "2009-01-08",
    "close": 4455.0,
    "volume": 95701,
    "contract": "200901"
  },
  {
    "date": "2009-01-09",
    "close": 4422.0,
    "volume": 90308,
    "contract": "200901"
  },
  {
    "date": "2009-01-10",
    "close": 4376.0,
    "volume": 56215,
    "contract": "200901"
  },
  {
    "date": "2009-01-12",
    "close": 4423.0,
    "volume": 93281,
    "contract": "200901"
  },
  {
    "date": "2009-01-13",
    "close": 4517.0,
    "volume": 93835,
    "contract": "200901"
  },
  {
    "date": "2009-01-14",
    "close": 4509.0,
    "volume": 82268,
    "contract": "200901"
  },
  {
    "date": "2009-01-15",
    "close": 4235.0,
    "volume": 75818,
    "contract": "200901"
  },
  {
    "date": "2009-01-16",
    "close": 4324.0,
    "volume": 78421,
    "contract": "200901"
  },
  {
    "date": "2009-01-17",
    "close": 4345.0,
    "volume": 38490,
    "contract": "200901"
  },
  {
    "date": "2009-01-19",
    "close": 4359.0,
    "volume": 58908,
    "contract": "200901"
  },
  {
    "date": "2009-01-20",
    "close": 4242.0,
    "volume": 52093,
    "contract": "200901"
  },
  {
    "date": "2009-01-21",
    "close": 4254.0,
    "volume": 36615,
    "contract": "200901"
  },
  {
    "date": "2009-02-02",
    "close": 4159.0,
    "volume": 50727,
    "contract": "200902"
  },
  {
    "date": "2009-02-03",
    "close": 4277.0,
    "volume": 77684,
    "contract": "200902"
  },
  {
    "date": "2009-02-04",
    "close": 4352.0,
    "volume": 68432,
    "contract": "200902"
  },
  {
    "date": "2009-02-05",
    "close": 4271.0,
    "volume": 82511,
    "contract": "200902"
  },
  {
    "date": "2009-02-06",
    "close": 4439.0,
    "volume": 94693,
    "contract": "200902"
  },
  {
    "date": "2009-02-09",
    "close": 4454.0,
    "volume": 71256,
    "contract": "200902"
  },
  {
    "date": "2009-02-10",
    "close": 4497.0,
    "volume": 60664,
    "contract": "200902"
  },
  {
    "date": "2009-02-11",
    "close": 4553.0,
    "volume": 91929,
    "contract": "200902"
  },
  {
    "date": "2009-02-12",
    "close": 4443.0,
    "volume": 112991,
    "contract": "200902"
  },
  {
    "date": "2009-02-13",
    "close": 4568.0,
    "volume": 109267,
    "contract": "200902"
  },
  {
    "date": "2009-02-16",
    "close": 4570.0,
    "volume": 69481,
    "contract": "200902"
  },
  {
    "date": "2009-02-17",
    "close": 4492.0,
    "volume": 91320,
    "contract": "200902"
  },
  {
    "date": "2009-02-18",
    "close": 4517.0,
    "volume": 45601,
    "contract": "200902"
  },
  {
    "date": "2009-02-19",
    "close": 4471.0,
    "volume": 118698,
    "contract": "200903"
  },
  {
    "date": "2009-02-20",
    "close": 4365.0,
    "volume": 105149,
    "contract": "200903"
  },
  {
    "date": "2009-02-23",
    "close": 4427.0,
    "volume": 102528,
    "contract": "200903"
  },
  {
    "date": "2009-02-24",
    "close": 4380.0,
    "volume": 83737,
    "contract": "200903"
  },
  {
    "date": "2009-02-25",
    "close": 4468.0,
    "volume": 105000,
    "contract": "200903"
  },
  {
    "date": "2009-02-26",
    "close": 4478.0,
    "volume": 89516,
    "contract": "200903"
  },
  {
    "date": "2009-02-27",
    "close": 4512.0,
    "volume": 73633,
    "contract": "200903"
  },
  {
    "date": "2009-03-02",
    "close": 4330.0,
    "volume": 101313,
    "contract": "200903"
  },
  {
    "date": "2009-03-03",
    "close": 4367.0,
    "volume": 104158,
    "contract": "200903"
  },
  {
    "date": "2009-03-04",
    "close": 4512.0,
    "volume": 109861,
    "contract": "200903"
  },
  {
    "date": "2009-03-05",
    "close": 4597.0,
    "volume": 120308,
    "contract": "200903"
  },
  {
    "date": "2009-03-06",
    "close": 4630.0,
    "volume": 109500,
    "contract": "200903"
  },
  {
    "date": "2009-03-09",
    "close": 4623.0,
    "volume": 93692,
    "contract": "200903"
  },
  {
    "date": "2009-03-10",
    "close": 4655.0,
    "volume": 91653,
    "contract": "200903"
  },
  {
    "date": "2009-03-11",
    "close": 4758.0,
    "volume": 77516,
    "contract": "200903"
  },
  {
    "date": "2009-03-12",
    "close": 4748.0,
    "volume": 66848,
    "contract": "200903"
  },
  {
    "date": "2009-03-13",
    "close": 4900.0,
    "volume": 98336,
    "contract": "200903"
  },
  {
    "date": "2009-03-16",
    "close": 4962.0,
    "volume": 79029,
    "contract": "200903"
  },
  {
    "date": "2009-03-17",
    "close": 5057.0,
    "volume": 94430,
    "contract": "200903"
  },
  {
    "date": "2009-03-18",
    "close": 5067.0,
    "volume": 59723,
    "contract": "200903"
  },
  {
    "date": "2009-03-19",
    "close": 4980.0,
    "volume": 105836,
    "contract": "200904"
  },
  {
    "date": "2009-03-20",
    "close": 4950.0,
    "volume": 106431,
    "contract": "200904"
  },
  {
    "date": "2009-03-23",
    "close": 5128.0,
    "volume": 95403,
    "contract": "200904"
  },
  {
    "date": "2009-03-24",
    "close": 5259.0,
    "volume": 99502,
    "contract": "200904"
  },
  {
    "date": "2009-03-25",
    "close": 5359.0,
    "volume": 114172,
    "contract": "200904"
  },
  {
    "date": "2009-03-26",
    "close": 5385.0,
    "volume": 130922,
    "contract": "200904"
  },
  {
    "date": "2009-03-27",
    "close": 5356.0,
    "volume": 110172,
    "contract": "200904"
  },
  {
    "date": "2009-03-30",
    "close": 5179.0,
    "volume": 111500,
    "contract": "200904"
  },
  {
    "date": "2009-03-31",
    "close": 5199.0,
    "volume": 105649,
    "contract": "200904"
  },
  {
    "date": "2009-04-01",
    "close": 5314.0,
    "volume": 135958,
    "contract": "200904"
  },
  {
    "date": "2009-04-02",
    "close": 5512.0,
    "volume": 115854,
    "contract": "200904"
  },
  {
    "date": "2009-04-03",
    "close": 5511.0,
    "volume": 103180,
    "contract": "200904"
  },
  {
    "date": "2009-04-06",
    "close": 5526.0,
    "volume": 105000,
    "contract": "200904"
  },
  {
    "date": "2009-04-07",
    "close": 5584.0,
    "volume": 97735,
    "contract": "200904"
  },
  {
    "date": "2009-04-08",
    "close": 5459.0,
    "volume": 134387,
    "contract": "200904"
  },
  {
    "date": "2009-04-09",
    "close": 5712.0,
    "volume": 113141,
    "contract": "200904"
  },
  {
    "date": "2009-04-10",
    "close": 5826.0,
    "volume": 127509,
    "contract": "200904"
  },
  {
    "date": "2009-04-13",
    "close": 5846.0,
    "volume": 108378,
    "contract": "200904"
  },
  {
    "date": "2009-04-14",
    "close": 5858.0,
    "volume": 106808,
    "contract": "200904"
  },
  {
    "date": "2009-04-15",
    "close": 5861.0,
    "volume": 57688,
    "contract": "200904"
  },
  {
    "date": "2009-04-16",
    "close": 5997.0,
    "volume": 112966,
    "contract": "200905"
  },
  {
    "date": "2009-04-17",
    "close": 5776.0,
    "volume": 150477,
    "contract": "200905"
  },
  {
    "date": "2009-04-20",
    "close": 5767.0,
    "volume": 128665,
    "contract": "200905"
  },
  {
    "date": "2009-04-21",
    "close": 5891.0,
    "volume": 132016,
    "contract": "200905"
  },
  {
    "date": "2009-04-22",
    "close": 5847.0,
    "volume": 115857,
    "contract": "200905"
  },
  {
    "date": "2009-04-23",
    "close": 5899.0,
    "volume": 138442,
    "contract": "200905"
  },
  {
    "date": "2009-04-24",
    "close": 5903.0,
    "volume": 146131,
    "contract": "200905"
  },
  {
    "date": "2009-04-27",
    "close": 5706.0,
    "volume": 147704,
    "contract": "200905"
  },
  {
    "date": "2009-04-28",
    "close": 5582.0,
    "volume": 159423,
    "contract": "200905"
  },
  {
    "date": "2009-04-29",
    "close": 5622.0,
    "volume": 109869,
    "contract": "200905"
  },
  {
    "date": "2009-04-30",
    "close": 6015.0,
    "volume": 29390,
    "contract": "200905"
  },
  {
    "date": "2009-05-04",
    "close": 6436.0,
    "volume": 39803,
    "contract": "200905"
  },
  {
    "date": "2009-05-05",
    "close": 6540.0,
    "volume": 156581,
    "contract": "200905"
  },
  {
    "date": "2009-05-06",
    "close": 6540.0,
    "volume": 119763,
    "contract": "200905"
  },
  {
    "date": "2009-05-07",
    "close": 6611.0,
    "volume": 109284,
    "contract": "200905"
  },
  {
    "date": "2009-05-08",
    "close": 6572.0,
    "volume": 93346,
    "contract": "200905"
  },
  {
    "date": "2009-05-11",
    "close": 6597.0,
    "volume": 100933,
    "contract": "200905"
  },
  {
    "date": "2009-05-12",
    "close": 6446.0,
    "volume": 125471,
    "contract": "200905"
  },
  {
    "date": "2009-05-13",
    "close": 6469.0,
    "volume": 81965,
    "contract": "200905"
  },
  {
    "date": "2009-05-14",
    "close": 6322.0,
    "volume": 90653,
    "contract": "200905"
  },
  {
    "date": "2009-05-15",
    "close": 6475.0,
    "volume": 99721,
    "contract": "200905"
  },
  {
    "date": "2009-05-18",
    "close": 6562.0,
    "volume": 110397,
    "contract": "200905"
  },
  {
    "date": "2009-05-19",
    "close": 6690.0,
    "volume": 106087,
    "contract": "200905"
  },
  {
    "date": "2009-05-20",
    "close": 6697.0,
    "volume": 77508,
    "contract": "200905"
  },
  {
    "date": "2009-05-21",
    "close": 6670.0,
    "volume": 91060,
    "contract": "200906"
  },
  {
    "date": "2009-05-22",
    "close": 6690.0,
    "volume": 90309,
    "contract": "200906"
  },
  {
    "date": "2009-05-25",
    "close": 6724.0,
    "volume": 109555,
    "contract": "200906"
  },
  {
    "date": "2009-05-26",
    "close": 6646.0,
    "volume": 94266,
    "contract": "200906"
  },
  {
    "date": "2009-05-27",
    "close": 6931.0,
    "volume": 115397,
    "contract": "200906"
  },
  {
    "date": "2009-06-01",
    "close": 6957.0,
    "volume": 76133,
    "contract": "200906"
  },
  {
    "date": "2009-06-02",
    "close": 6918.0,
    "volume": 92552,
    "contract": "200906"
  },
  {
    "date": "2009-06-03",
    "close": 6897.0,
    "volume": 80200,
    "contract": "200906"
  },
  {
    "date": "2009-06-04",
    "close": 6785.0,
    "volume": 112986,
    "contract": "200906"
  },
  {
    "date": "2009-06-05",
    "close": 6792.0,
    "volume": 74537,
    "contract": "200906"
  },
  {
    "date": "2009-06-06",
    "close": 6832.0,
    "volume": 39231,
    "contract": "200906"
  },
  {
    "date": "2009-06-08",
    "close": 6645.0,
    "volume": 98861,
    "contract": "200906"
  },
  {
    "date": "2009-06-09",
    "close": 6414.0,
    "volume": 120988,
    "contract": "200906"
  },
  {
    "date": "2009-06-10",
    "close": 6460.0,
    "volume": 91519,
    "contract": "200906"
  },
  {
    "date": "2009-06-11",
    "close": 6517.0,
    "volume": 122673,
    "contract": "200906"
  },
  {
    "date": "2009-06-12",
    "close": 6442.0,
    "volume": 105325,
    "contract": "200906"
  },
  {
    "date": "2009-06-15",
    "close": 6208.0,
    "volume": 122373,
    "contract": "200906"
  },
  {
    "date": "2009-06-16",
    "close": 6208.0,
    "volume": 103392,
    "contract": "200906"
  },
  {
    "date": "2009-06-17",
    "close": 6204.0,
    "volume": 63998,
    "contract": "200906"
  },
  {
    "date": "2009-06-18",
    "close": 6084.0,
    "volume": 124107,
    "contract": "200907"
  },
  {
    "date": "2009-06-19",
    "close": 6138.0,
    "volume": 91433,
    "contract": "200907"
  },
  {
    "date": "2009-06-22",
    "close": 6209.0,
    "volume": 96819,
    "contract": "200907"
  },
  {
    "date": "2009-06-23",
    "close": 6070.0,
    "volume": 83089,
    "contract": "200907"
  },
  {
    "date": "2009-06-24",
    "close": 6306.0,
    "volume": 143068,
    "contract": "200907"
  },
  {
    "date": "2009-06-25",
    "close": 6388.0,
    "volume": 101790,
    "contract": "200907"
  },
  {
    "date": "2009-06-26",
    "close": 6388.0,
    "volume": 76262,
    "contract": "200907"
  },
  {
    "date": "2009-06-29",
    "close": 6342.0,
    "volume": 92895,
    "contract": "200907"
  },
  {
    "date": "2009-06-30",
    "close": 6384.0,
    "volume": 97666,
    "contract": "200907"
  },
  {
    "date": "2009-07-01",
    "close": 6514.0,
    "volume": 108225,
    "contract": "200907"
  },
  {
    "date": "2009-07-02",
    "close": 6585.0,
    "volume": 96176,
    "contract": "200907"
  },
  {
    "date": "2009-07-03",
    "close": 6599.0,
    "volume": 91953,
    "contract": "200907"
  },
  {
    "date": "2009-07-06",
    "close": 6588.0,
    "volume": 90788,
    "contract": "200907"
  },
  {
    "date": "2009-07-07",
    "close": 6662.0,
    "volume": 97969,
    "contract": "200907"
  },
  {
    "date": "2009-07-08",
    "close": 6625.0,
    "volume": 92894,
    "contract": "200907"
  },
  {
    "date": "2009-07-09",
    "close": 6722.0,
    "volume": 101563,
    "contract": "200907"
  },
  {
    "date": "2009-07-10",
    "close": 6753.0,
    "volume": 74365,
    "contract": "200907"
  },
  {
    "date": "2009-07-13",
    "close": 6476.0,
    "volume": 122838,
    "contract": "200907"
  },
  {
    "date": "2009-07-14",
    "close": 6578.0,
    "volume": 79254,
    "contract": "200907"
  },
  {
    "date": "2009-07-15",
    "close": 6763.0,
    "volume": 66513,
    "contract": "200907"
  },
  {
    "date": "2009-07-16",
    "close": 6705.0,
    "volume": 90133,
    "contract": "200908"
  },
  {
    "date": "2009-07-17",
    "close": 6760.0,
    "volume": 79837,
    "contract": "200908"
  },
  {
    "date": "2009-07-20",
    "close": 6860.0,
    "volume": 86232,
    "contract": "200908"
  },
  {
    "date": "2009-07-21",
    "close": 6877.0,
    "volume": 91337,
    "contract": "200908"
  },
  {
    "date": "2009-07-22",
    "close": 6890.0,
    "volume": 93603,
    "contract": "200908"
  },
  {
    "date": "2009-07-23",
    "close": 6879.0,
    "volume": 94592,
    "contract": "200908"
  },
  {
    "date": "2009-07-24",
    "close": 6897.0,
    "volume": 75387,
    "contract": "200908"
  },
  {
    "date": "2009-07-27",
    "close": 6967.0,
    "volume": 79395,
    "contract": "200908"
  },
  {
    "date": "2009-07-28",
    "close": 7078.0,
    "volume": 82604,
    "contract": "200908"
  },
  {
    "date": "2009-07-29",
    "close": 7037.0,
    "volume": 86739,
    "contract": "200908"
  },
  {
    "date": "2009-07-30",
    "close": 6962.0,
    "volume": 103156,
    "contract": "200908"
  },
  {
    "date": "2009-07-31",
    "close": 7032.0,
    "volume": 94020,
    "contract": "200908"
  },
  {
    "date": "2009-08-03",
    "close": 6982.0,
    "volume": 92249,
    "contract": "200908"
  },
  {
    "date": "2009-08-04",
    "close": 6881.0,
    "volume": 121427,
    "contract": "200908"
  },
  {
    "date": "2009-08-05",
    "close": 6769.0,
    "volume": 115725,
    "contract": "200908"
  },
  {
    "date": "2009-08-06",
    "close": 6799.0,
    "volume": 116213,
    "contract": "200908"
  },
  {
    "date": "2009-08-10",
    "close": 6815.0,
    "volume": 87325,
    "contract": "200908"
  },
  {
    "date": "2009-08-11",
    "close": 6888.0,
    "volume": 88944,
    "contract": "200908"
  },
  {
    "date": "2009-08-12",
    "close": 6840.0,
    "volume": 83658,
    "contract": "200908"
  },
  {
    "date": "2009-08-13",
    "close": 7012.0,
    "volume": 102013,
    "contract": "200908"
  },
  {
    "date": "2009-08-14",
    "close": 7061.0,
    "volume": 79285,
    "contract": "200908"
  },
  {
    "date": "2009-08-17",
    "close": 6915.0,
    "volume": 98803,
    "contract": "200908"
  },
  {
    "date": "2009-08-18",
    "close": 6816.0,
    "volume": 118179,
    "contract": "200908"
  },
  {
    "date": "2009-08-19",
    "close": 6795.0,
    "volume": 47901,
    "contract": "200908"
  },
  {
    "date": "2009-08-20",
    "close": 6691.0,
    "volume": 107256,
    "contract": "200909"
  },
  {
    "date": "2009-08-21",
    "close": 6596.0,
    "volume": 121651,
    "contract": "200909"
  },
  {
    "date": "2009-08-24",
    "close": 6807.0,
    "volume": 96127,
    "contract": "200909"
  },
  {
    "date": "2009-08-25",
    "close": 6760.0,
    "volume": 92967,
    "contract": "200909"
  },
  {
    "date": "2009-08-26",
    "close": 6700.0,
    "volume": 129062,
    "contract": "200909"
  },
  {
    "date": "2009-08-27",
    "close": 6645.0,
    "volume": 108007,
    "contract": "200909"
  },
  {
    "date": "2009-08-28",
    "close": 6755.0,
    "volume": 108868,
    "contract": "200909"
  },
  {
    "date": "2009-08-31",
    "close": 6757.0,
    "volume": 95992,
    "contract": "200909"
  },
  {
    "date": "2009-09-01",
    "close": 7024.0,
    "volume": 126480,
    "contract": "200909"
  },
  {
    "date": "2009-09-02",
    "close": 7025.0,
    "volume": 107506,
    "contract": "200909"
  },
  {
    "date": "2009-09-03",
    "close": 7091.0,
    "volume": 112518,
    "contract": "200909"
  },
  {
    "date": "2009-09-04",
    "close": 7152.0,
    "volume": 97250,
    "contract": "200909"
  },
  {
    "date": "2009-09-07",
    "close": 7219.0,
    "volume": 81702,
    "contract": "200909"
  },
  {
    "date": "2009-09-08",
    "close": 7316.0,
    "volume": 124697,
    "contract": "200909"
  },
  {
    "date": "2009-09-09",
    "close": 7256.0,
    "volume": 86455,
    "contract": "200909"
  },
  {
    "date": "2009-09-10",
    "close": 7361.0,
    "volume": 161712,
    "contract": "200909"
  },
  {
    "date": "2009-09-11",
    "close": 7353.0,
    "volume": 68490,
    "contract": "200909"
  },
  {
    "date": "2009-09-14",
    "close": 7254.0,
    "volume": 101737,
    "contract": "200909"
  },
  {
    "date": "2009-09-15",
    "close": 7356.0,
    "volume": 85200,
    "contract": "200909"
  },
  {
    "date": "2009-09-16",
    "close": 7444.0,
    "volume": 58879,
    "contract": "200909"
  },
  {
    "date": "2009-09-17",
    "close": 7467.0,
    "volume": 98899,
    "contract": "200910"
  },
  {
    "date": "2009-09-18",
    "close": 7467.0,
    "volume": 73594,
    "contract": "200910"
  },
  {
    "date": "2009-09-21",
    "close": 7464.0,
    "volume": 93350,
    "contract": "200910"
  },
  {
    "date": "2009-09-22",
    "close": 7456.0,
    "volume": 67476,
    "contract": "200910"
  },
  {
    "date": "2009-09-23",
    "close": 7351.0,
    "volume": 122587,
    "contract": "200910"
  },
  {
    "date": "2009-09-24",
    "close": 7298.0,
    "volume": 99619,
    "contract": "200910"
  },
  {
    "date": "2009-09-25",
    "close": 7335.0,
    "volume": 79576,
    "contract": "200910"
  },
  {
    "date": "2009-09-28",
    "close": 7281.0,
    "volume": 81690,
    "contract": "200910"
  },
  {
    "date": "2009-09-29",
    "close": 7403.0,
    "volume": 88224,
    "contract": "200910"
  },
  {
    "date": "2009-09-30",
    "close": 7489.0,
    "volume": 86999,
    "contract": "200910"
  },
  {
    "date": "2009-10-01",
    "close": 7538.0,
    "volume": 98150,
    "contract": "200910"
  },
  {
    "date": "2009-10-02",
    "close": 7358.0,
    "volume": 89168,
    "contract": "200910"
  },
  {
    "date": "2009-10-05",
    "close": 7392.0,
    "volume": 68734,
    "contract": "200910"
  },
  {
    "date": "2009-10-06",
    "close": 7507.0,
    "volume": 104990,
    "contract": "200910"
  },
  {
    "date": "2009-10-07",
    "close": 7590.0,
    "volume": 79201,
    "contract": "200910"
  },
  {
    "date": "2009-10-08",
    "close": 7483.0,
    "volume": 100041,
    "contract": "200910"
  },
  {
    "date": "2009-10-09",
    "close": 7555.0,
    "volume": 86628,
    "contract": "200910"
  },
  {
    "date": "2009-10-12",
    "close": 7576.0,
    "volume": 84394,
    "contract": "200910"
  },
  {
    "date": "2009-10-13",
    "close": 7563.0,
    "volume": 114719,
    "contract": "200910"
  },
  {
    "date": "2009-10-14",
    "close": 7698.0,
    "volume": 80060,
    "contract": "200910"
  },
  {
    "date": "2009-10-15",
    "close": 7705.0,
    "volume": 97453,
    "contract": "200910"
  },
  {
    "date": "2009-10-16",
    "close": 7695.0,
    "volume": 75741,
    "contract": "200910"
  },
  {
    "date": "2009-10-19",
    "close": 7751.0,
    "volume": 73626,
    "contract": "200910"
  },
  {
    "date": "2009-10-20",
    "close": 7750.0,
    "volume": 69904,
    "contract": "200910"
  },
  {
    "date": "2009-10-21",
    "close": 7706.0,
    "volume": 60536,
    "contract": "200910"
  },
  {
    "date": "2009-10-22",
    "close": 7570.0,
    "volume": 110014,
    "contract": "200911"
  },
  {
    "date": "2009-10-23",
    "close": 7599.0,
    "volume": 62746,
    "contract": "200911"
  },
  {
    "date": "2009-10-26",
    "close": 7642.0,
    "volume": 83612,
    "contract": "200911"
  },
  {
    "date": "2009-10-27",
    "close": 7644.0,
    "volume": 90053,
    "contract": "200911"
  },
  {
    "date": "2009-10-28",
    "close": 7505.0,
    "volume": 115957,
    "contract": "200911"
  },
  {
    "date": "2009-10-29",
    "close": 7320.0,
    "volume": 127331,
    "contract": "200911"
  },
  {
    "date": "2009-10-30",
    "close": 7283.0,
    "volume": 83450,
    "contract": "200911"
  },
  {
    "date": "2009-11-02",
    "close": 7278.0,
    "volume": 91237,
    "contract": "200911"
  },
  {
    "date": "2009-11-03",
    "close": 7275.0,
    "volume": 72941,
    "contract": "200911"
  },
  {
    "date": "2009-11-04",
    "close": 7438.0,
    "volume": 88160,
    "contract": "200911"
  },
  {
    "date": "2009-11-05",
    "close": 7406.0,
    "volume": 84857,
    "contract": "200911"
  },
  {
    "date": "2009-11-06",
    "close": 7474.0,
    "volume": 75178,
    "contract": "200911"
  },
  {
    "date": "2009-11-09",
    "close": 7547.0,
    "volume": 73533,
    "contract": "200911"
  },
  {
    "date": "2009-11-10",
    "close": 7591.0,
    "volume": 63116,
    "contract": "200911"
  },
  {
    "date": "2009-11-11",
    "close": 7678.0,
    "volume": 101971,
    "contract": "200911"
  },
  {
    "date": "2009-11-12",
    "close": 7685.0,
    "volume": 65745,
    "contract": "200911"
  },
  {
    "date": "2009-11-13",
    "close": 7673.0,
    "volume": 75594,
    "contract": "200911"
  },
  {
    "date": "2009-11-16",
    "close": 7805.0,
    "volume": 83204,
    "contract": "200911"
  },
  {
    "date": "2009-11-17",
    "close": 7737.0,
    "volume": 120252,
    "contract": "200911"
  },
  {
    "date": "2009-11-18",
    "close": 7787.0,
    "volume": 42101,
    "contract": "200911"
  },
  {
    "date": "2009-11-19",
    "close": 7702.0,
    "volume": 78989,
    "contract": "200912"
  },
  {
    "date": "2009-11-20",
    "close": 7670.0,
    "volume": 92058,
    "contract": "200912"
  },
  {
    "date": "2009-11-23",
    "close": 7691.0,
    "volume": 49686,
    "contract": "200912"
  },
  {
    "date": "2009-11-24",
    "close": 7698.0,
    "volume": 50194,
    "contract": "200912"
  },
  {
    "date": "2009-11-25",
    "close": 7773.0,
    "volume": 81022,
    "contract": "200912"
  },
  {
    "date": "2009-11-26",
    "close": 7745.0,
    "volume": 75629,
    "contract": "200912"
  },
  {
    "date": "2009-11-27",
    "close": 7441.0,
    "volume": 109681,
    "contract": "200912"
  },
  {
    "date": "2009-11-30",
    "close": 7557.0,
    "volume": 59762,
    "contract": "200912"
  },
  {
    "date": "2009-12-01",
    "close": 7641.0,
    "volume": 90333,
    "contract": "200912"
  },
  {
    "date": "2009-12-02",
    "close": 7689.0,
    "volume": 73228,
    "contract": "200912"
  },
  {
    "date": "2009-12-03",
    "close": 7697.0,
    "volume": 80219,
    "contract": "200912"
  },
  {
    "date": "2009-12-04",
    "close": 7594.0,
    "volume": 69102,
    "contract": "200912"
  },
  {
    "date": "2009-12-07",
    "close": 7752.0,
    "volume": 88669,
    "contract": "200912"
  },
  {
    "date": "2009-12-08",
    "close": 7754.0,
    "volume": 72028,
    "contract": "200912"
  },
  {
    "date": "2009-12-09",
    "close": 7789.0,
    "volume": 65111,
    "contract": "200912"
  },
  {
    "date": "2009-12-10",
    "close": 7639.0,
    "volume": 128000,
    "contract": "200912"
  },
  {
    "date": "2009-12-11",
    "close": 7790.0,
    "volume": 94856,
    "contract": "200912"
  },
  {
    "date": "2009-12-14",
    "close": 7829.0,
    "volume": 97062,
    "contract": "200912"
  },
  {
    "date": "2009-12-15",
    "close": 7799.0,
    "volume": 70162,
    "contract": "200912"
  },
  {
    "date": "2009-12-16",
    "close": 7753.0,
    "volume": 64166,
    "contract": "200912"
  },
  {
    "date": "2009-12-17",
    "close": 7692.0,
    "volume": 106265,
    "contract": "201001"
  },
  {
    "date": "2009-12-18",
    "close": 7701.0,
    "volume": 77636,
    "contract": "201001"
  },
  {
    "date": "2009-12-21",
    "close": 7752.0,
    "volume": 74447,
    "contract": "201001"
  },
  {
    "date": "2009-12-22",
    "close": 7829.0,
    "volume": 67618,
    "contract": "201001"
  },
  {
    "date": "2009-12-23",
    "close": 7866.0,
    "volume": 62343,
    "contract": "201001"
  },
  {
    "date": "2009-12-24",
    "close": 7951.0,
    "volume": 79018,
    "contract": "201001"
  },
  {
    "date": "2009-12-25",
    "close": 7982.0,
    "volume": 40328,
    "contract": "201001"
  },
  {
    "date": "2009-12-28",
    "close": 8046.0,
    "volume": 73145,
    "contract": "201001"
  },
  {
    "date": "2009-12-29",
    "close": 8058.0,
    "volume": 53930,
    "contract": "201001"
  },
  {
    "date": "2009-12-30",
    "close": 8091.0,
    "volume": 59359,
    "contract": "201001"
  },
  {
    "date": "2009-12-31",
    "close": 8201.0,
    "volume": 67209,
    "contract": "201001"
  },
  {
    "date": "2010-01-04",
    "close": 8167.0,
    "volume": 84131,
    "contract": "201001"
  },
  {
    "date": "2010-01-05",
    "close": 8178.0,
    "volume": 108012,
    "contract": "201001"
  },
  {
    "date": "2010-01-06",
    "close": 8321.0,
    "volume": 120081,
    "contract": "201001"
  },
  {
    "date": "2010-01-07",
    "close": 8260.0,
    "volume": 120555,
    "contract": "201001"
  },
  {
    "date": "2010-01-08",
    "close": 8277.0,
    "volume": 104771,
    "contract": "201001"
  },
  {
    "date": "2010-01-11",
    "close": 8322.0,
    "volume": 88096,
    "contract": "201001"
  },
  {
    "date": "2010-01-12",
    "close": 8309.0,
    "volume": 99739,
    "contract": "201001"
  },
  {
    "date": "2010-01-13",
    "close": 8215.0,
    "volume": 108932,
    "contract": "201001"
  },
  {
    "date": "2010-01-14",
    "close": 8299.0,
    "volume": 81125,
    "contract": "201001"
  },
  {
    "date": "2010-01-15",
    "close": 8367.0,
    "volume": 96104,
    "contract": "201001"
  },
  {
    "date": "2010-01-18",
    "close": 8351.0,
    "volume": 78516,
    "contract": "201001"
  },
  {
    "date": "2010-01-19",
    "close": 8269.0,
    "volume": 121248,
    "contract": "201001"
  },
  {
    "date": "2010-01-20",
    "close": 8215.0,
    "volume": 67857,
    "contract": "201001"
  },
  {
    "date": "2010-01-21",
    "close": 8134.0,
    "volume": 117077,
    "contract": "201002"
  },
  {
    "date": "2010-01-22",
    "close": 7897.0,
    "volume": 126740,
    "contract": "201002"
  },
  {
    "date": "2010-01-25",
    "close": 7852.0,
    "volume": 87477,
    "contract": "201002"
  },
  {
    "date": "2010-01-26",
    "close": 7558.0,
    "volume": 182130,
    "contract": "201002"
  },
  {
    "date": "2010-01-27",
    "close": 7535.0,
    "volume": 116963,
    "contract": "201002"
  },
  {
    "date": "2010-01-28",
    "close": 7697.0,
    "volume": 117356,
    "contract": "201002"
  },
  {
    "date": "2010-01-29",
    "close": 7581.0,
    "volume": 148605,
    "contract": "201002"
  },
  {
    "date": "2010-02-01",
    "close": 7510.0,
    "volume": 133007,
    "contract": "201002"
  },
  {
    "date": "2010-02-02",
    "close": 7374.0,
    "volume": 143485,
    "contract": "201002"
  },
  {
    "date": "2010-02-03",
    "close": 7501.0,
    "volume": 139624,
    "contract": "201002"
  },
  {
    "date": "2010-02-04",
    "close": 7505.0,
    "volume": 90229,
    "contract": "201002"
  },
  {
    "date": "2010-02-05",
    "close": 7202.0,
    "volume": 127511,
    "contract": "201002"
  },
  {
    "date": "2010-02-06",
    "close": 7155.0,
    "volume": 102594,
    "contract": "201002"
  },
  {
    "date": "2010-02-08",
    "close": 7162.0,
    "volume": 99368,
    "contract": "201002"
  },
  {
    "date": "2010-02-09",
    "close": 7316.0,
    "volume": 115841,
    "contract": "201002"
  },
  {
    "date": "2010-02-10",
    "close": 7414.0,
    "volume": 117786,
    "contract": "201002"
  },
  {
    "date": "2010-02-22",
    "close": 7558.0,
    "volume": 49687,
    "contract": "201002"
  },
  {
    "date": "2010-02-23",
    "close": 7537.0,
    "volume": 90651,
    "contract": "201003"
  },
  {
    "date": "2010-02-24",
    "close": 7481.0,
    "volume": 83099,
    "contract": "201003"
  },
  {
    "date": "2010-02-25",
    "close": 7368.0,
    "volume": 124223,
    "contract": "201003"
  },
  {
    "date": "2010-02-26",
    "close": 7383.0,
    "volume": 91371,
    "contract": "201003"
  },
  {
    "date": "2010-03-01",
    "close": 7571.0,
    "volume": 118336,
    "contract": "201003"
  },
  {
    "date": "2010-03-02",
    "close": 7598.0,
    "volume": 85761,
    "contract": "201003"
  },
  {
    "date": "2010-03-03",
    "close": 7612.0,
    "volume": 90229,
    "contract": "201003"
  },
  {
    "date": "2010-03-04",
    "close": 7527.0,
    "volume": 117200,
    "contract": "201003"
  },
  {
    "date": "2010-03-05",
    "close": 7656.0,
    "volume": 117270,
    "contract": "201003"
  },
  {
    "date": "2010-03-08",
    "close": 7756.0,
    "volume": 78128,
    "contract": "201003"
  },
  {
    "date": "2010-03-09",
    "close": 7764.0,
    "volume": 57308,
    "contract": "201003"
  },
  {
    "date": "2010-03-10",
    "close": 7769.0,
    "volume": 80818,
    "contract": "201003"
  },
  {
    "date": "2010-03-11",
    "close": 7758.0,
    "volume": 84883,
    "contract": "201003"
  },
  {
    "date": "2010-03-12",
    "close": 7752.0,
    "volume": 66469,
    "contract": "201003"
  },
  {
    "date": "2010-03-15",
    "close": 7655.0,
    "volume": 111429,
    "contract": "201003"
  },
  {
    "date": "2010-03-16",
    "close": 7704.0,
    "volume": 61394,
    "contract": "201003"
  },
  {
    "date": "2010-03-17",
    "close": 7842.0,
    "volume": 63598,
    "contract": "201003"
  },
  {
    "date": "2010-03-18",
    "close": 7849.0,
    "volume": 93097,
    "contract": "201004"
  },
  {
    "date": "2010-03-19",
    "close": 7867.0,
    "volume": 66434,
    "contract": "201004"
  },
  {
    "date": "2010-03-22",
    "close": 7803.0,
    "volume": 92460,
    "contract": "201004"
  },
  {
    "date": "2010-03-23",
    "close": 7805.0,
    "volume": 90596,
    "contract": "201004"
  },
  {
    "date": "2010-03-24",
    "close": 7814.0,
    "volume": 84035,
    "contract": "201004"
  },
  {
    "date": "2010-03-25",
    "close": 7809.0,
    "volume": 129037,
    "contract": "201004"
  },
  {
    "date": "2010-03-26",
    "close": 7883.0,
    "volume": 138132,
    "contract": "201004"
  },
  {
    "date": "2010-03-29",
    "close": 7956.0,
    "volume": 80247,
    "contract": "201004"
  },
  {
    "date": "2010-03-30",
    "close": 7959.0,
    "volume": 62687,
    "contract": "201004"
  },
  {
    "date": "2010-03-31",
    "close": 7908.0,
    "volume": 74622,
    "contract": "201004"
  },
  {
    "date": "2010-04-01",
    "close": 8024.0,
    "volume": 95385,
    "contract": "201004"
  },
  {
    "date": "2010-04-02",
    "close": 8037.0,
    "volume": 40155,
    "contract": "201004"
  },
  {
    "date": "2010-04-06",
    "close": 8095.0,
    "volume": 87309,
    "contract": "201004"
  },
  {
    "date": "2010-04-07",
    "close": 8124.0,
    "volume": 62123,
    "contract": "201004"
  },
  {
    "date": "2010-04-08",
    "close": 8081.0,
    "volume": 127263,
    "contract": "201004"
  },
  {
    "date": "2010-04-09",
    "close": 8099.0,
    "volume": 71514,
    "contract": "201004"
  },
  {
    "date": "2010-04-12",
    "close": 8126.0,
    "volume": 79826,
    "contract": "201004"
  },
  {
    "date": "2010-04-13",
    "close": 8019.0,
    "volume": 118213,
    "contract": "201004"
  },
  {
    "date": "2010-04-14",
    "close": 8111.0,
    "volume": 79410,
    "contract": "201004"
  },
  {
    "date": "2010-04-15",
    "close": 8162.0,
    "volume": 82591,
    "contract": "201004"
  },
  {
    "date": "2010-04-16",
    "close": 8102.0,
    "volume": 97706,
    "contract": "201004"
  },
  {
    "date": "2010-04-19",
    "close": 7825.0,
    "volume": 132915,
    "contract": "201004"
  },
  {
    "date": "2010-04-20",
    "close": 7877.0,
    "volume": 90356,
    "contract": "201004"
  },
  {
    "date": "2010-04-21",
    "close": 7980.0,
    "volume": 75433,
    "contract": "201004"
  },
  {
    "date": "2010-04-22",
    "close": 7923.0,
    "volume": 116094,
    "contract": "201005"
  },
  {
    "date": "2010-04-23",
    "close": 7959.0,
    "volume": 79346,
    "contract": "201005"
  },
  {
    "date": "2010-04-26",
    "close": 8146.0,
    "volume": 87141,
    "contract": "201005"
  },
  {
    "date": "2010-04-27",
    "close": 8129.0,
    "volume": 60876,
    "contract": "201005"
  },
  {
    "date": "2010-04-28",
    "close": 8036.0,
    "volume": 116469,
    "contract": "201005"
  },
  {
    "date": "2010-04-29",
    "close": 8043.0,
    "volume": 70064,
    "contract": "201005"
  },
  {
    "date": "2010-04-30",
    "close": 7989.0,
    "volume": 131598,
    "contract": "201005"
  },
  {
    "date": "2010-05-03",
    "close": 7932.0,
    "volume": 116275,
    "contract": "201005"
  },
  {
    "date": "2010-05-04",
    "close": 7881.0,
    "volume": 129308,
    "contract": "201005"
  },
  {
    "date": "2010-05-05",
    "close": 7655.0,
    "volume": 139679,
    "contract": "201005"
  },
  {
    "date": "2010-05-06",
    "close": 7578.0,
    "volume": 128579,
    "contract": "201005"
  },
  {
    "date": "2010-05-07",
    "close": 7504.0,
    "volume": 157944,
    "contract": "201005"
  },
  {
    "date": "2010-05-10",
    "close": 7635.0,
    "volume": 104819,
    "contract": "201005"
  },
  {
    "date": "2010-05-11",
    "close": 7570.0,
    "volume": 137129,
    "contract": "201005"
  },
  {
    "date": "2010-05-12",
    "close": 7586.0,
    "volume": 125000,
    "contract": "201005"
  },
  {
    "date": "2010-05-13",
    "close": 7763.0,
    "volume": 118535,
    "contract": "201005"
  },
  {
    "date": "2010-05-14",
    "close": 7756.0,
    "volume": 83064,
    "contract": "201005"
  },
  {
    "date": "2010-05-17",
    "close": 7602.0,
    "volume": 132831,
    "contract": "201005"
  },
  {
    "date": "2010-05-18",
    "close": 7616.0,
    "volume": 92214,
    "contract": "201005"
  },
  {
    "date": "2010-05-19",
    "close": 7576.0,
    "volume": 80404,
    "contract": "201005"
  },
  {
    "date": "2010-05-20",
    "close": 7364.0,
    "volume": 129922,
    "contract": "201006"
  },
  {
    "date": "2010-05-21",
    "close": 7206.0,
    "volume": 121989,
    "contract": "201006"
  },
  {
    "date": "2010-05-24",
    "close": 7274.0,
    "volume": 100810,
    "contract": "201006"
  },
  {
    "date": "2010-05-25",
    "close": 7052.0,
    "volume": 149343,
    "contract": "201006"
  },
  {
    "date": "2010-05-26",
    "close": 7123.0,
    "volume": 128300,
    "contract": "201006"
  },
  {
    "date": "2010-05-27",
    "close": 7200.0,
    "volume": 133780,
    "contract": "201006"
  },
  {
    "date": "2010-05-28",
    "close": 7277.0,
    "volume": 127565,
    "contract": "201006"
  },
  {
    "date": "2010-05-31",
    "close": 7325.0,
    "volume": 81072,
    "contract": "201006"
  },
  {
    "date": "2010-06-01",
    "close": 7243.0,
    "volume": 131341,
    "contract": "201006"
  },
  {
    "date": "2010-06-02",
    "close": 7140.0,
    "volume": 146272,
    "contract": "201006"
  },
  {
    "date": "2010-06-03",
    "close": 7338.0,
    "volume": 110634,
    "contract": "201006"
  },
  {
    "date": "2010-06-04",
    "close": 7318.0,
    "volume": 62707,
    "contract": "201006"
  },
  {
    "date": "2010-06-07",
    "close": 7097.0,
    "volume": 128756,
    "contract": "201006"
  },
  {
    "date": "2010-06-08",
    "close": 7128.0,
    "volume": 86675,
    "contract": "201006"
  },
  {
    "date": "2010-06-09",
    "close": 7037.0,
    "volume": 125232,
    "contract": "201006"
  },
  {
    "date": "2010-06-10",
    "close": 7161.0,
    "volume": 109141,
    "contract": "201006"
  },
  {
    "date": "2010-06-11",
    "close": 7292.0,
    "volume": 84575,
    "contract": "201006"
  },
  {
    "date": "2010-06-14",
    "close": 7386.0,
    "volume": 76580,
    "contract": "201006"
  },
  {
    "date": "2010-06-15",
    "close": 7457.0,
    "volume": 93703,
    "contract": "201006"
  },
  {
    "date": "2010-06-17",
    "close": 7519.0,
    "volume": 57082,
    "contract": "201006"
  },
  {
    "date": "2010-06-18",
    "close": 7349.0,
    "volume": 96166,
    "contract": "201007"
  },
  {
    "date": "2010-06-21",
    "close": 7521.0,
    "volume": 114904,
    "contract": "201007"
  },
  {
    "date": "2010-06-22",
    "close": 7481.0,
    "volume": 61354,
    "contract": "201007"
  },
  {
    "date": "2010-06-23",
    "close": 7433.0,
    "volume": 98541,
    "contract": "201007"
  },
  {
    "date": "2010-06-24",
    "close": 7428.0,
    "volume": 69407,
    "contract": "201007"
  },
  {
    "date": "2010-06-25",
    "close": 7322.0,
    "volume": 101937,
    "contract": "201007"
  },
  {
    "date": "2010-06-28",
    "close": 7363.0,
    "volume": 57111,
    "contract": "201007"
  },
  {
    "date": "2010-06-29",
    "close": 7254.0,
    "volume": 136712,
    "contract": "201007"
  },
  {
    "date": "2010-06-30",
    "close": 7153.0,
    "volume": 88601,
    "contract": "201007"
  },
  {
    "date": "2010-07-01",
    "close": 7100.0,
    "volume": 113002,
    "contract": "201007"
  },
  {
    "date": "2010-07-02",
    "close": 7161.0,
    "volume": 105182,
    "contract": "201007"
  },
  {
    "date": "2010-07-05",
    "close": 7322.0,
    "volume": 108042,
    "contract": "201007"
  },
  {
    "date": "2010-07-06",
    "close": 7455.0,
    "volume": 124317,
    "contract": "201007"
  },
  {
    "date": "2010-07-07",
    "close": 7448.0,
    "volume": 79243,
    "contract": "201007"
  },
  {
    "date": "2010-07-08",
    "close": 7535.0,
    "volume": 96454,
    "contract": "201007"
  },
  {
    "date": "2010-07-09",
    "close": 7566.0,
    "volume": 70477,
    "contract": "201007"
  },
  {
    "date": "2010-07-12",
    "close": 7531.0,
    "volume": 97622,
    "contract": "201007"
  },
  {
    "date": "2010-07-13",
    "close": 7558.0,
    "volume": 92650,
    "contract": "201007"
  },
  {
    "date": "2010-07-14",
    "close": 7700.0,
    "volume": 82523,
    "contract": "201007"
  },
  {
    "date": "2010-07-15",
    "close": 7707.0,
    "volume": 76060,
    "contract": "201007"
  },
  {
    "date": "2010-07-16",
    "close": 7670.0,
    "volume": 106135,
    "contract": "201007"
  },
  {
    "date": "2010-07-19",
    "close": 7657.0,
    "volume": 77670,
    "contract": "201007"
  },
  {
    "date": "2010-07-20",
    "close": 7711.0,
    "volume": 100166,
    "contract": "201007"
  },
  {
    "date": "2010-07-21",
    "close": 7687.0,
    "volume": 51616,
    "contract": "201007"
  },
  {
    "date": "2010-07-22",
    "close": 7561.0,
    "volume": 91546,
    "contract": "201008"
  },
  {
    "date": "2010-07-23",
    "close": 7678.0,
    "volume": 83773,
    "contract": "201008"
  },
  {
    "date": "2010-07-26",
    "close": 7708.0,
    "volume": 61705,
    "contract": "201008"
  },
  {
    "date": "2010-07-27",
    "close": 7659.0,
    "volume": 84227,
    "contract": "201008"
  },
  {
    "date": "2010-07-28",
    "close": 7720.0,
    "volume": 80898,
    "contract": "201008"
  },
  {
    "date": "2010-07-29",
    "close": 7708.0,
    "volume": 80324,
    "contract": "201008"
  },
  {
    "date": "2010-07-30",
    "close": 7680.0,
    "volume": 83628,
    "contract": "201008"
  },
  {
    "date": "2010-08-02",
    "close": 7866.0,
    "volume": 88137,
    "contract": "201008"
  },
  {
    "date": "2010-08-03",
    "close": 7912.0,
    "volume": 58141,
    "contract": "201008"
  },
  {
    "date": "2010-08-04",
    "close": 7913.0,
    "volume": 79056,
    "contract": "201008"
  },
  {
    "date": "2010-08-05",
    "close": 7911.0,
    "volume": 88965,
    "contract": "201008"
  },
  {
    "date": "2010-08-06",
    "close": 7928.0,
    "volume": 65549,
    "contract": "201008"
  },
  {
    "date": "2010-08-09",
    "close": 7986.0,
    "volume": 71723,
    "contract": "201008"
  },
  {
    "date": "2010-08-10",
    "close": 7936.0,
    "volume": 70375,
    "contract": "201008"
  },
  {
    "date": "2010-08-11",
    "close": 7856.0,
    "volume": 114453,
    "contract": "201008"
  },
  {
    "date": "2010-08-12",
    "close": 7801.0,
    "volume": 85123,
    "contract": "201008"
  },
  {
    "date": "2010-08-13",
    "close": 7913.0,
    "volume": 95376,
    "contract": "201008"
  },
  {
    "date": "2010-08-16",
    "close": 7946.0,
    "volume": 85244,
    "contract": "201008"
  },
  {
    "date": "2010-08-17",
    "close": 7939.0,
    "volume": 66398,
    "contract": "201008"
  },
  {
    "date": "2010-08-18",
    "close": 7919.0,
    "volume": 59966,
    "contract": "201008"
  },
  {
    "date": "2010-08-19",
    "close": 7918.0,
    "volume": 88915,
    "contract": "201009"
  },
  {
    "date": "2010-08-20",
    "close": 7888.0,
    "volume": 65098,
    "contract": "201009"
  },
  {
    "date": "2010-08-23",
    "close": 7951.0,
    "volume": 88947,
    "contract": "201009"
  },
  {
    "date": "2010-08-24",
    "close": 7885.0,
    "volume": 90103,
    "contract": "201009"
  },
  {
    "date": "2010-08-25",
    "close": 7680.0,
    "volume": 136835,
    "contract": "201009"
  },
  {
    "date": "2010-08-26",
    "close": 7622.0,
    "volume": 90562,
    "contract": "201009"
  },
  {
    "date": "2010-08-27",
    "close": 7660.0,
    "volume": 89168,
    "contract": "201009"
  },
  {
    "date": "2010-08-30",
    "close": 7716.0,
    "volume": 106064,
    "contract": "201009"
  },
  {
    "date": "2010-08-31",
    "close": 7559.0,
    "volume": 119636,
    "contract": "201009"
  },
  {
    "date": "2010-09-01",
    "close": 7628.0,
    "volume": 77257,
    "contract": "201009"
  },
  {
    "date": "2010-09-02",
    "close": 7693.0,
    "volume": 102840,
    "contract": "201009"
  },
  {
    "date": "2010-09-03",
    "close": 7779.0,
    "volume": 94555,
    "contract": "201009"
  },
  {
    "date": "2010-09-06",
    "close": 7864.0,
    "volume": 77831,
    "contract": "201009"
  },
  {
    "date": "2010-09-07",
    "close": 7853.0,
    "volume": 60520,
    "contract": "201009"
  },
  {
    "date": "2010-09-08",
    "close": 7849.0,
    "volume": 116025,
    "contract": "201009"
  },
  {
    "date": "2010-09-09",
    "close": 7833.0,
    "volume": 100524,
    "contract": "201009"
  },
  {
    "date": "2010-09-10",
    "close": 7897.0,
    "volume": 88648,
    "contract": "201009"
  },
  {
    "date": "2010-09-13",
    "close": 8108.0,
    "volume": 127838,
    "contract": "201009"
  },
  {
    "date": "2010-09-14",
    "close": 8121.0,
    "volume": 67460,
    "contract": "201009"
  },
  {
    "date": "2010-09-15",
    "close": 8154.0,
    "volume": 51515,
    "contract": "201009"
  },
  {
    "date": "2010-09-16",
    "close": 8071.0,
    "volume": 94098,
    "contract": "201010"
  },
  {
    "date": "2010-09-17",
    "close": 8170.0,
    "volume": 111718,
    "contract": "201010"
  },
  {
    "date": "2010-09-20",
    "close": 8179.0,
    "volume": 72390,
    "contract": "201010"
  },
  {
    "date": "2010-09-21",
    "close": 8191.0,
    "volume": 89176,
    "contract": "201010"
  },
  {
    "date": "2010-09-23",
    "close": 8202.0,
    "volume": 84525,
    "contract": "201010"
  },
  {
    "date": "2010-09-24",
    "close": 8147.0,
    "volume": 126534,
    "contract": "201010"
  },
  {
    "date": "2010-09-27",
    "close": 8187.0,
    "volume": 77297,
    "contract": "201010"
  },
  {
    "date": "2010-09-28",
    "close": 8180.0,
    "volume": 68963,
    "contract": "201010"
  },
  {
    "date": "2010-09-29",
    "close": 8211.0,
    "volume": 117733,
    "contract": "201010"
  },
  {
    "date": "2010-09-30",
    "close": 8216.0,
    "volume": 81016,
    "contract": "201010"
  },
  {
    "date": "2010-10-01",
    "close": 8235.0,
    "volume": 75235,
    "contract": "201010"
  },
  {
    "date": "2010-10-04",
    "close": 8216.0,
    "volume": 90840,
    "contract": "201010"
  },
  {
    "date": "2010-10-05",
    "close": 8190.0,
    "volume": 115261,
    "contract": "201010"
  },
  {
    "date": "2010-10-06",
    "close": 8272.0,
    "volume": 79300,
    "contract": "201010"
  },
  {
    "date": "2010-10-07",
    "close": 8272.0,
    "volume": 50519,
    "contract": "201010"
  },
  {
    "date": "2010-10-08",
    "close": 8215.0,
    "volume": 102711,
    "contract": "201010"
  },
  {
    "date": "2010-10-11",
    "close": 8136.0,
    "volume": 98905,
    "contract": "201010"
  },
  {
    "date": "2010-10-12",
    "close": 8058.0,
    "volume": 122291,
    "contract": "201010"
  },
  {
    "date": "2010-10-13",
    "close": 8107.0,
    "volume": 96903,
    "contract": "201010"
  },
  {
    "date": "2010-10-14",
    "close": 8227.0,
    "volume": 119656,
    "contract": "201010"
  },
  {
    "date": "2010-10-15",
    "close": 8194.0,
    "volume": 81159,
    "contract": "201010"
  },
  {
    "date": "2010-10-18",
    "close": 8030.0,
    "volume": 141294,
    "contract": "201010"
  },
  {
    "date": "2010-10-19",
    "close": 8019.0,
    "volume": 85879,
    "contract": "201010"
  },
  {
    "date": "2010-10-20",
    "close": 8120.0,
    "volume": 82275,
    "contract": "201010"
  },
  {
    "date": "2010-10-21",
    "close": 8088.0,
    "volume": 111011,
    "contract": "201011"
  },
  {
    "date": "2010-10-22",
    "close": 8139.0,
    "volume": 67964,
    "contract": "201011"
  },
  {
    "date": "2010-10-25",
    "close": 8303.0,
    "volume": 109281,
    "contract": "201011"
  },
  {
    "date": "2010-10-26",
    "close": 8314.0,
    "volume": 70560,
    "contract": "201011"
  },
  {
    "date": "2010-10-27",
    "close": 8280.0,
    "volume": 117085,
    "contract": "201011"
  },
  {
    "date": "2010-10-28",
    "close": 8340.0,
    "volume": 91823,
    "contract": "201011"
  },
  {
    "date": "2010-10-29",
    "close": 8302.0,
    "volume": 99968,
    "contract": "201011"
  },
  {
    "date": "2010-11-01",
    "close": 8390.0,
    "volume": 107257,
    "contract": "201011"
  },
  {
    "date": "2010-11-02",
    "close": 8367.0,
    "volume": 58662,
    "contract": "201011"
  },
  {
    "date": "2010-11-03",
    "close": 8323.0,
    "volume": 136324,
    "contract": "201011"
  },
  {
    "date": "2010-11-04",
    "close": 8371.0,
    "volume": 77018,
    "contract": "201011"
  },
  {
    "date": "2010-11-05",
    "close": 8464.0,
    "volume": 79141,
    "contract": "201011"
  },
  {
    "date": "2010-11-08",
    "close": 8450.0,
    "volume": 75622,
    "contract": "201011"
  },
  {
    "date": "2010-11-09",
    "close": 8466.0,
    "volume": 58677,
    "contract": "201011"
  },
  {
    "date": "2010-11-10",
    "close": 8482.0,
    "volume": 76611,
    "contract": "201011"
  },
  {
    "date": "2010-11-11",
    "close": 8451.0,
    "volume": 58177,
    "contract": "201011"
  },
  {
    "date": "2010-11-12",
    "close": 8311.0,
    "volume": 130015,
    "contract": "201011"
  },
  {
    "date": "2010-11-15",
    "close": 8270.0,
    "volume": 101630,
    "contract": "201011"
  },
  {
    "date": "2010-11-16",
    "close": 8289.0,
    "volume": 101891,
    "contract": "201011"
  },
  {
    "date": "2010-11-17",
    "close": 8246.0,
    "volume": 61629,
    "contract": "201011"
  },
  {
    "date": "2010-11-18",
    "close": 8291.0,
    "volume": 78768,
    "contract": "201012"
  },
  {
    "date": "2010-11-19",
    "close": 8290.0,
    "volume": 117715,
    "contract": "201012"
  },
  {
    "date": "2010-11-22",
    "close": 8369.0,
    "volume": 90490,
    "contract": "201012"
  },
  {
    "date": "2010-11-23",
    "close": 8329.0,
    "volume": 74225,
    "contract": "201012"
  },
  {
    "date": "2010-11-24",
    "close": 8303.0,
    "volume": 94334,
    "contract": "201012"
  },
  {
    "date": "2010-11-25",
    "close": 8339.0,
    "volume": 70220,
    "contract": "201012"
  },
  {
    "date": "2010-11-26",
    "close": 8298.0,
    "volume": 82714,
    "contract": "201012"
  },
  {
    "date": "2010-11-29",
    "close": 8379.0,
    "volume": 123857,
    "contract": "201012"
  },
  {
    "date": "2010-11-30",
    "close": 8401.0,
    "volume": 119667,
    "contract": "201012"
  },
  {
    "date": "2010-12-01",
    "close": 8547.0,
    "volume": 108687,
    "contract": "201012"
  },
  {
    "date": "2010-12-02",
    "close": 8618.0,
    "volume": 88977,
    "contract": "201012"
  },
  {
    "date": "2010-12-03",
    "close": 8628.0,
    "volume": 70423,
    "contract": "201012"
  },
  {
    "date": "2010-12-06",
    "close": 8695.0,
    "volume": 80691,
    "contract": "201012"
  },
  {
    "date": "2010-12-07",
    "close": 8713.0,
    "volume": 69626,
    "contract": "201012"
  },
  {
    "date": "2010-12-08",
    "close": 8700.0,
    "volume": 61331,
    "contract": "201012"
  },
  {
    "date": "2010-12-09",
    "close": 8788.0,
    "volume": 95653,
    "contract": "201012"
  },
  {
    "date": "2010-12-10",
    "close": 8743.0,
    "volume": 91693,
    "contract": "201012"
  },
  {
    "date": "2010-12-13",
    "close": 8737.0,
    "volume": 60110,
    "contract": "201012"
  },
  {
    "date": "2010-12-14",
    "close": 8737.0,
    "volume": 98988,
    "contract": "201012"
  },
  {
    "date": "2010-12-15",
    "close": 8726.0,
    "volume": 49981,
    "contract": "201012"
  },
  {
    "date": "2010-12-16",
    "close": 8773.0,
    "volume": 68086,
    "contract": "201101"
  },
  {
    "date": "2010-12-17",
    "close": 8808.0,
    "volume": 83266,
    "contract": "201101"
  },
  {
    "date": "2010-12-20",
    "close": 8763.0,
    "volume": 101924,
    "contract": "201101"
  },
  {
    "date": "2010-12-21",
    "close": 8845.0,
    "volume": 76748,
    "contract": "201101"
  },
  {
    "date": "2010-12-22",
    "close": 8852.0,
    "volume": 66539,
    "contract": "201101"
  },
  {
    "date": "2010-12-23",
    "close": 8898.0,
    "volume": 72427,
    "contract": "201101"
  },
  {
    "date": "2010-12-24",
    "close": 8879.0,
    "volume": 49958,
    "contract": "201101"
  },
  {
    "date": "2010-12-27",
    "close": 8884.0,
    "volume": 82851,
    "contract": "201101"
  },
  {
    "date": "2010-12-28",
    "close": 8877.0,
    "volume": 82968,
    "contract": "201101"
  },
  {
    "date": "2010-12-29",
    "close": 8872.0,
    "volume": 81948,
    "contract": "201101"
  },
  {
    "date": "2010-12-30",
    "close": 8905.0,
    "volume": 82893,
    "contract": "201101"
  },
  {
    "date": "2010-12-31",
    "close": 8987.0,
    "volume": 88956,
    "contract": "201101"
  },
  {
    "date": "2011-01-03",
    "close": 9020.0,
    "volume": 61494,
    "contract": "201101"
  },
  {
    "date": "2011-01-04",
    "close": 8976.0,
    "volume": 62547,
    "contract": "201101"
  },
  {
    "date": "2011-01-05",
    "close": 8839.0,
    "volume": 165903,
    "contract": "201101"
  },
  {
    "date": "2011-01-06",
    "close": 8868.0,
    "volume": 82566,
    "contract": "201101"
  },
  {
    "date": "2011-01-07",
    "close": 8753.0,
    "volume": 128865,
    "contract": "201101"
  },
  {
    "date": "2011-01-10",
    "close": 8787.0,
    "volume": 68409,
    "contract": "201101"
  },
  {
    "date": "2011-01-11",
    "close": 8940.0,
    "volume": 131239,
    "contract": "201101"
  },
  {
    "date": "2011-01-12",
    "close": 8965.0,
    "volume": 82550,
    "contract": "201101"
  },
  {
    "date": "2011-01-13",
    "close": 8969.0,
    "volume": 107360,
    "contract": "201101"
  },
  {
    "date": "2011-01-14",
    "close": 8969.0,
    "volume": 67802,
    "contract": "201101"
  },
  {
    "date": "2011-01-17",
    "close": 8920.0,
    "volume": 97047,
    "contract": "201101"
  },
  {
    "date": "2011-01-18",
    "close": 8973.0,
    "volume": 107216,
    "contract": "201101"
  },
  {
    "date": "2011-01-19",
    "close": 9083.0,
    "volume": 62356,
    "contract": "201101"
  },
  {
    "date": "2011-01-20",
    "close": 9007.0,
    "volume": 64889,
    "contract": "201102"
  },
  {
    "date": "2011-01-21",
    "close": 8906.0,
    "volume": 139586,
    "contract": "201102"
  },
  {
    "date": "2011-01-24",
    "close": 8944.0,
    "volume": 72357,
    "contract": "201102"
  },
  {
    "date": "2011-01-25",
    "close": 8967.0,
    "volume": 80982,
    "contract": "201102"
  },
  {
    "date": "2011-01-26",
    "close": 9051.0,
    "volume": 94345,
    "contract": "201102"
  },
  {
    "date": "2011-01-27",
    "close": 9103.0,
    "volume": 83534,
    "contract": "201102"
  },
  {
    "date": "2011-01-28",
    "close": 9136.0,
    "volume": 64992,
    "contract": "201102"
  },
  {
    "date": "2011-02-08",
    "close": 9099.0,
    "volume": 98816,
    "contract": "201102"
  },
  {
    "date": "2011-02-09",
    "close": 9012.0,
    "volume": 129231,
    "contract": "201102"
  },
  {
    "date": "2011-02-10",
    "close": 8823.0,
    "volume": 139801,
    "contract": "201102"
  },
  {
    "date": "2011-02-11",
    "close": 8564.0,
    "volume": 194208,
    "contract": "201102"
  },
  {
    "date": "2011-02-14",
    "close": 8645.0,
    "volume": 98497,
    "contract": "201102"
  },
  {
    "date": "2011-02-15",
    "close": 8697.0,
    "volume": 131734,
    "contract": "201102"
  },
  {
    "date": "2011-02-16",
    "close": 8719.0,
    "volume": 58640,
    "contract": "201102"
  },
  {
    "date": "2011-02-17",
    "close": 8625.0,
    "volume": 119834,
    "contract": "201103"
  },
  {
    "date": "2011-02-18",
    "close": 8809.0,
    "volume": 119179,
    "contract": "201103"
  },
  {
    "date": "2011-02-21",
    "close": 8809.0,
    "volume": 83876,
    "contract": "201103"
  },
  {
    "date": "2011-02-22",
    "close": 8620.0,
    "volume": 145288,
    "contract": "201103"
  },
  {
    "date": "2011-02-23",
    "close": 8521.0,
    "volume": 139848,
    "contract": "201103"
  },
  {
    "date": "2011-02-24",
    "close": 8531.0,
    "volume": 118991,
    "contract": "201103"
  },
  {
    "date": "2011-02-25",
    "close": 8615.0,
    "volume": 185991,
    "contract": "201103"
  },
  {
    "date": "2011-03-01",
    "close": 8690.0,
    "volume": 84843,
    "contract": "201103"
  },
  {
    "date": "2011-03-02",
    "close": 8601.0,
    "volume": 126612,
    "contract": "201103"
  },
  {
    "date": "2011-03-03",
    "close": 8739.0,
    "volume": 122404,
    "contract": "201103"
  },
  {
    "date": "2011-03-04",
    "close": 8761.0,
    "volume": 83715,
    "contract": "201103"
  },
  {
    "date": "2011-03-07",
    "close": 8721.0,
    "volume": 108312,
    "contract": "201103"
  },
  {
    "date": "2011-03-08",
    "close": 8740.0,
    "volume": 77993,
    "contract": "201103"
  },
  {
    "date": "2011-03-09",
    "close": 8758.0,
    "volume": 101352,
    "contract": "201103"
  },
  {
    "date": "2011-03-10",
    "close": 8623.0,
    "volume": 140984,
    "contract": "201103"
  },
  {
    "date": "2011-03-11",
    "close": 8559.0,
    "volume": 129690,
    "contract": "201103"
  },
  {
    "date": "2011-03-14",
    "close": 8504.0,
    "volume": 172522,
    "contract": "201103"
  },
  {
    "date": "2011-03-15",
    "close": 8257.0,
    "volume": 281996,
    "contract": "201103"
  },
  {
    "date": "2011-03-16",
    "close": 8306.0,
    "volume": 98122,
    "contract": "201103"
  },
  {
    "date": "2011-03-17",
    "close": 8257.0,
    "volume": 148030,
    "contract": "201104"
  },
  {
    "date": "2011-03-18",
    "close": 8321.0,
    "volume": 104790,
    "contract": "201104"
  },
  {
    "date": "2011-03-21",
    "close": 8391.0,
    "volume": 110694,
    "contract": "201104"
  },
  {
    "date": "2011-03-22",
    "close": 8417.0,
    "volume": 91071,
    "contract": "201104"
  },
  {
    "date": "2011-03-23",
    "close": 8451.0,
    "volume": 116480,
    "contract": "201104"
  },
  {
    "date": "2011-03-24",
    "close": 8527.0,
    "volume": 97401,
    "contract": "201104"
  },
  {
    "date": "2011-03-25",
    "close": 8577.0,
    "volume": 98085,
    "contract": "201104"
  },
  {
    "date": "2011-03-28",
    "close": 8520.0,
    "volume": 95878,
    "contract": "201104"
  },
  {
    "date": "2011-03-29",
    "close": 8573.0,
    "volume": 99788,
    "contract": "201104"
  },
  {
    "date": "2011-03-30",
    "close": 8592.0,
    "volume": 94925,
    "contract": "201104"
  },
  {
    "date": "2011-03-31",
    "close": 8640.0,
    "volume": 110985,
    "contract": "201104"
  },
  {
    "date": "2011-04-01",
    "close": 8684.0,
    "volume": 77932,
    "contract": "201104"
  },
  {
    "date": "2011-04-06",
    "close": 8839.0,
    "volume": 117188,
    "contract": "201104"
  },
  {
    "date": "2011-04-07",
    "close": 8896.0,
    "volume": 87447,
    "contract": "201104"
  },
  {
    "date": "2011-04-08",
    "close": 8868.0,
    "volume": 112662,
    "contract": "201104"
  },
  {
    "date": "2011-04-11",
    "close": 8859.0,
    "volume": 86849,
    "contract": "201104"
  },
  {
    "date": "2011-04-12",
    "close": 8706.0,
    "volume": 144977,
    "contract": "201104"
  },
  {
    "date": "2011-04-13",
    "close": 8807.0,
    "volume": 102232,
    "contract": "201104"
  },
  {
    "date": "2011-04-14",
    "close": 8796.0,
    "volume": 124710,
    "contract": "201104"
  },
  {
    "date": "2011-04-15",
    "close": 8705.0,
    "volume": 113500,
    "contract": "201104"
  },
  {
    "date": "2011-04-18",
    "close": 8708.0,
    "volume": 101713,
    "contract": "201104"
  },
  {
    "date": "2011-04-19",
    "close": 8627.0,
    "volume": 125140,
    "contract": "201104"
  },
  {
    "date": "2011-04-20",
    "close": 8791.0,
    "volume": 67546,
    "contract": "201104"
  },
  {
    "date": "2011-04-21",
    "close": 8989.0,
    "volume": 119477,
    "contract": "201105"
  },
  {
    "date": "2011-04-22",
    "close": 8991.0,
    "volume": 55335,
    "contract": "201105"
  },
  {
    "date": "2011-04-25",
    "close": 8974.0,
    "volume": 106758,
    "contract": "201105"
  },
  {
    "date": "2011-04-26",
    "close": 8968.0,
    "volume": 139109,
    "contract": "201105"
  },
  {
    "date": "2011-04-27",
    "close": 9059.0,
    "volume": 94874,
    "contract": "201105"
  },
  {
    "date": "2011-04-28",
    "close": 9014.0,
    "volume": 107208,
    "contract": "201105"
  },
  {
    "date": "2011-04-29",
    "close": 9024.0,
    "volume": 142920,
    "contract": "201105"
  },
  {
    "date": "2011-05-03",
    "close": 8933.0,
    "volume": 126976,
    "contract": "201105"
  },
  {
    "date": "2011-05-04",
    "close": 8936.0,
    "volume": 118011,
    "contract": "201105"
  },
  {
    "date": "2011-05-05",
    "close": 9050.0,
    "volume": 132287,
    "contract": "201105"
  },
  {
    "date": "2011-05-06",
    "close": 9014.0,
    "volume": 102895,
    "contract": "201105"
  },
  {
    "date": "2011-05-09",
    "close": 9063.0,
    "volume": 106384,
    "contract": "201105"
  },
  {
    "date": "2011-05-10",
    "close": 9045.0,
    "volume": 72713,
    "contract": "201105"
  },
  {
    "date": "2011-05-11",
    "close": 9020.0,
    "volume": 112317,
    "contract": "201105"
  },
  {
    "date": "2011-05-12",
    "close": 9028.0,
    "volume": 118600,
    "contract": "201105"
  },
  {
    "date": "2011-05-13",
    "close": 9029.0,
    "volume": 93101,
    "contract": "201105"
  },
  {
    "date": "2011-05-16",
    "close": 8926.0,
    "volume": 122700,
    "contract": "201105"
  },
  {
    "date": "2011-05-17",
    "close": 8911.0,
    "volume": 121128,
    "contract": "201105"
  },
  {
    "date": "2011-05-18",
    "close": 8933.0,
    "volume": 52086,
    "contract": "201105"
  },
  {
    "date": "2011-05-19",
    "close": 8841.0,
    "volume": 166077,
    "contract": "201106"
  },
  {
    "date": "2011-05-20",
    "close": 8817.0,
    "volume": 121117,
    "contract": "201106"
  },
  {
    "date": "2011-05-23",
    "close": 8734.0,
    "volume": 114374,
    "contract": "201106"
  },
  {
    "date": "2011-05-24",
    "close": 8763.0,
    "volume": 118444,
    "contract": "201106"
  },
  {
    "date": "2011-05-25",
    "close": 8679.0,
    "volume": 127832,
    "contract": "201106"
  },
  {
    "date": "2011-05-26",
    "close": 8785.0,
    "volume": 93892,
    "contract": "201106"
  },
  {
    "date": "2011-05-27",
    "close": 8780.0,
    "volume": 112213,
    "contract": "201106"
  },
  {
    "date": "2011-05-30",
    "close": 8816.0,
    "volume": 109526,
    "contract": "201106"
  },
  {
    "date": "2011-05-31",
    "close": 9018.0,
    "volume": 125480,
    "contract": "201106"
  },
  {
    "date": "2011-06-01",
    "close": 9086.0,
    "volume": 107908,
    "contract": "201106"
  },
  {
    "date": "2011-06-02",
    "close": 9028.0,
    "volume": 94010,
    "contract": "201106"
  },
  {
    "date": "2011-06-03",
    "close": 9070.0,
    "volume": 101815,
    "contract": "201106"
  },
  {
    "date": "2011-06-07",
    "close": 9089.0,
    "volume": 115032,
    "contract": "201106"
  },
  {
    "date": "2011-06-08",
    "close": 9030.0,
    "volume": 117902,
    "contract": "201106"
  },
  {
    "date": "2011-06-09",
    "close": 9029.0,
    "volume": 93200,
    "contract": "201106"
  },
  {
    "date": "2011-06-10",
    "close": 8829.0,
    "volume": 181810,
    "contract": "201106"
  },
  {
    "date": "2011-06-13",
    "close": 8743.0,
    "volume": 130403,
    "contract": "201106"
  },
  {
    "date": "2011-06-14",
    "close": 8845.0,
    "volume": 115004,
    "contract": "201106"
  },
  {
    "date": "2011-06-15",
    "close": 8839.0,
    "volume": 94369,
    "contract": "201106"
  },
  {
    "date": "2011-06-16",
    "close": 8494.0,
    "volume": 122413,
    "contract": "201107"
  },
  {
    "date": "2011-06-17",
    "close": 8462.0,
    "volume": 130186,
    "contract": "201107"
  },
  {
    "date": "2011-06-20",
    "close": 8399.0,
    "volume": 130515,
    "contract": "201107"
  },
  {
    "date": "2011-06-21",
    "close": 8465.0,
    "volume": 122002,
    "contract": "201107"
  },
  {
    "date": "2011-06-22",
    "close": 8442.0,
    "volume": 126014,
    "contract": "201107"
  },
  {
    "date": "2011-06-23",
    "close": 8397.0,
    "volume": 113345,
    "contract": "201107"
  },
  {
    "date": "2011-06-24",
    "close": 8410.0,
    "volume": 99044,
    "contract": "201107"
  },
  {
    "date": "2011-06-27",
    "close": 8335.0,
    "volume": 111310,
    "contract": "201107"
  },
  {
    "date": "2011-06-28",
    "close": 8310.0,
    "volume": 102017,
    "contract": "201107"
  },
  {
    "date": "2011-06-29",
    "close": 8470.0,
    "volume": 131303,
    "contract": "201107"
  },
  {
    "date": "2011-06-30",
    "close": 8505.0,
    "volume": 101928,
    "contract": "201107"
  },
  {
    "date": "2011-07-01",
    "close": 8572.0,
    "volume": 97691,
    "contract": "201107"
  },
  {
    "date": "2011-07-04",
    "close": 8601.0,
    "volume": 81889,
    "contract": "201107"
  },
  {
    "date": "2011-07-05",
    "close": 8629.0,
    "volume": 71709,
    "contract": "201107"
  },
  {
    "date": "2011-07-06",
    "close": 8690.0,
    "volume": 97278,
    "contract": "201107"
  },
  {
    "date": "2011-07-07",
    "close": 8689.0,
    "volume": 75472,
    "contract": "201107"
  },
  {
    "date": "2011-07-08",
    "close": 8643.0,
    "volume": 126547,
    "contract": "201107"
  },
  {
    "date": "2011-07-11",
    "close": 8600.0,
    "volume": 80847,
    "contract": "201107"
  },
  {
    "date": "2011-07-12",
    "close": 8422.0,
    "volume": 118304,
    "contract": "201107"
  },
  {
    "date": "2011-07-13",
    "close": 8463.0,
    "volume": 102488,
    "contract": "201107"
  },
  {
    "date": "2011-07-14",
    "close": 8481.0,
    "volume": 141329,
    "contract": "201107"
  },
  {
    "date": "2011-07-15",
    "close": 8563.0,
    "volume": 123355,
    "contract": "201107"
  },
  {
    "date": "2011-07-18",
    "close": 8486.0,
    "volume": 123707,
    "contract": "201107"
  },
  {
    "date": "2011-07-19",
    "close": 8532.0,
    "volume": 100795,
    "contract": "201107"
  },
  {
    "date": "2011-07-20",
    "close": 8698.0,
    "volume": 68793,
    "contract": "201107"
  },
  {
    "date": "2011-07-21",
    "close": 8651.0,
    "volume": 63011,
    "contract": "201108"
  },
  {
    "date": "2011-07-22",
    "close": 8694.0,
    "volume": 87424,
    "contract": "201108"
  },
  {
    "date": "2011-07-25",
    "close": 8605.0,
    "volume": 106117,
    "contract": "201108"
  },
  {
    "date": "2011-07-26",
    "close": 8734.0,
    "volume": 111221,
    "contract": "201108"
  },
  {
    "date": "2011-07-27",
    "close": 8761.0,
    "volume": 84296,
    "contract": "201108"
  },
  {
    "date": "2011-07-28",
    "close": 8726.0,
    "volume": 107534,
    "contract": "201108"
  },
  {
    "date": "2011-07-29",
    "close": 8610.0,
    "volume": 143010,
    "contract": "201108"
  },
  {
    "date": "2011-08-01",
    "close": 8682.0,
    "volume": 80934,
    "contract": "201108"
  },
  {
    "date": "2011-08-02",
    "close": 8573.0,
    "volume": 103383,
    "contract": "201108"
  },
  {
    "date": "2011-08-03",
    "close": 8436.0,
    "volume": 114328,
    "contract": "201108"
  },
  {
    "date": "2011-08-04",
    "close": 8289.0,
    "volume": 144711,
    "contract": "201108"
  },
  {
    "date": "2011-08-05",
    "close": 7765.0,
    "volume": 206321,
    "contract": "201108"
  },
  {
    "date": "2011-08-08",
    "close": 7556.0,
    "volume": 267551,
    "contract": "201108"
  },
  {
    "date": "2011-08-09",
    "close": 7535.0,
    "volume": 279725,
    "contract": "201108"
  },
  {
    "date": "2011-08-10",
    "close": 7667.0,
    "volume": 172778,
    "contract": "201108"
  },
  {
    "date": "2011-08-11",
    "close": 7699.0,
    "volume": 221701,
    "contract": "201108"
  },
  {
    "date": "2011-08-12",
    "close": 7592.0,
    "volume": 176888,
    "contract": "201108"
  },
  {
    "date": "2011-08-15",
    "close": 7822.0,
    "volume": 105030,
    "contract": "201108"
  },
  {
    "date": "2011-08-16",
    "close": 7772.0,
    "volume": 140095,
    "contract": "201108"
  },
  {
    "date": "2011-08-17",
    "close": 7753.0,
    "volume": 76314,
    "contract": "201108"
  },
  {
    "date": "2011-08-18",
    "close": 7498.0,
    "volume": 152050,
    "contract": "201109"
  },
  {
    "date": "2011-08-19",
    "close": 7197.0,
    "volume": 161405,
    "contract": "201109"
  },
  {
    "date": "2011-08-22",
    "close": 7251.0,
    "volume": 205725,
    "contract": "201109"
  },
  {
    "date": "2011-08-23",
    "close": 7504.0,
    "volume": 167759,
    "contract": "201109"
  },
  {
    "date": "2011-08-24",
    "close": 7422.0,
    "volume": 194977,
    "contract": "201109"
  },
  {
    "date": "2011-08-25",
    "close": 7360.0,
    "volume": 150577,
    "contract": "201109"
  },
  {
    "date": "2011-08-26",
    "close": 7444.0,
    "volume": 156129,
    "contract": "201109"
  },
  {
    "date": "2011-08-29",
    "close": 7529.0,
    "volume": 135929,
    "contract": "201109"
  },
  {
    "date": "2011-08-30",
    "close": 7601.0,
    "volume": 119955,
    "contract": "201109"
  },
  {
    "date": "2011-08-31",
    "close": 7707.0,
    "volume": 130197,
    "contract": "201109"
  },
  {
    "date": "2011-09-01",
    "close": 7699.0,
    "volume": 155568,
    "contract": "201109"
  },
  {
    "date": "2011-09-02",
    "close": 7713.0,
    "volume": 121605,
    "contract": "201109"
  },
  {
    "date": "2011-09-05",
    "close": 7477.0,
    "volume": 122204,
    "contract": "201109"
  },
  {
    "date": "2011-09-06",
    "close": 7336.0,
    "volume": 171382,
    "contract": "201109"
  },
  {
    "date": "2011-09-07",
    "close": 7535.0,
    "volume": 120616,
    "contract": "201109"
  },
  {
    "date": "2011-09-08",
    "close": 7547.0,
    "volume": 140152,
    "contract": "201109"
  },
  {
    "date": "2011-09-09",
    "close": 7602.0,
    "volume": 153577,
    "contract": "201109"
  },
  {
    "date": "2011-09-13",
    "close": 7369.0,
    "volume": 131651,
    "contract": "201109"
  },
  {
    "date": "2011-09-14",
    "close": 7193.0,
    "volume": 182468,
    "contract": "201109"
  },
  {
    "date": "2011-09-15",
    "close": 7405.0,
    "volume": 156249,
    "contract": "201109"
  },
  {
    "date": "2011-09-16",
    "close": 7608.0,
    "volume": 139098,
    "contract": "201109"
  },
  {
    "date": "2011-09-19",
    "close": 7477.0,
    "volume": 116020,
    "contract": "201109"
  },
  {
    "date": "2011-09-20",
    "close": 7486.0,
    "volume": 180541,
    "contract": "201109"
  },
  {
    "date": "2011-09-21",
    "close": 7537.0,
    "volume": 76416,
    "contract": "201109"
  },
  {
    "date": "2011-09-22",
    "close": 7275.0,
    "volume": 125732,
    "contract": "201110"
  },
  {
    "date": "2011-09-23",
    "close": 7048.0,
    "volume": 153498,
    "contract": "201110"
  },
  {
    "date": "2011-09-26",
    "close": 6882.0,
    "volume": 156941,
    "contract": "201110"
  },
  {
    "date": "2011-09-27",
    "close": 7129.0,
    "volume": 122963,
    "contract": "201110"
  },
  {
    "date": "2011-09-28",
    "close": 7102.0,
    "volume": 126297,
    "contract": "201110"
  },
  {
    "date": "2011-09-29",
    "close": 7181.0,
    "volume": 134437,
    "contract": "201110"
  },
  {
    "date": "2011-09-30",
    "close": 7181.0,
    "volume": 124704,
    "contract": "201110"
  },
  {
    "date": "2011-10-03",
    "close": 7017.0,
    "volume": 115048,
    "contract": "201110"
  },
  {
    "date": "2011-10-04",
    "close": 7090.0,
    "volume": 147003,
    "contract": "201110"
  },
  {
    "date": "2011-10-05",
    "close": 6988.0,
    "volume": 110636,
    "contract": "201110"
  },
  {
    "date": "2011-10-06",
    "close": 7122.0,
    "volume": 120600,
    "contract": "201110"
  },
  {
    "date": "2011-10-07",
    "close": 7192.0,
    "volume": 112034,
    "contract": "201110"
  },
  {
    "date": "2011-10-11",
    "close": 7406.0,
    "volume": 83352,
    "contract": "201110"
  },
  {
    "date": "2011-10-12",
    "close": 7389.0,
    "volume": 96807,
    "contract": "201110"
  },
  {
    "date": "2011-10-13",
    "close": 7393.0,
    "volume": 100698,
    "contract": "201110"
  },
  {
    "date": "2011-10-14",
    "close": 7374.0,
    "volume": 80809,
    "contract": "201110"
  },
  {
    "date": "2011-10-17",
    "close": 7454.0,
    "volume": 105086,
    "contract": "201110"
  },
  {
    "date": "2011-10-18",
    "close": 7340.0,
    "volume": 103316,
    "contract": "201110"
  },
  {
    "date": "2011-10-19",
    "close": 7330.0,
    "volume": 48083,
    "contract": "201110"
  },
  {
    "date": "2011-10-20",
    "close": 7216.0,
    "volume": 98691,
    "contract": "201111"
  },
  {
    "date": "2011-10-21",
    "close": 7260.0,
    "volume": 87535,
    "contract": "201111"
  },
  {
    "date": "2011-10-24",
    "close": 7492.0,
    "volume": 95663,
    "contract": "201111"
  },
  {
    "date": "2011-10-25",
    "close": 7471.0,
    "volume": 75563,
    "contract": "201111"
  },
  {
    "date": "2011-10-26",
    "close": 7545.0,
    "volume": 108104,
    "contract": "201111"
  },
  {
    "date": "2011-10-27",
    "close": 7591.0,
    "volume": 109266,
    "contract": "201111"
  },
  {
    "date": "2011-10-28",
    "close": 7628.0,
    "volume": 132787,
    "contract": "201111"
  },
  {
    "date": "2011-10-31",
    "close": 7562.0,
    "volume": 109659,
    "contract": "201111"
  },
  {
    "date": "2011-11-01",
    "close": 7638.0,
    "volume": 137794,
    "contract": "201111"
  },
  {
    "date": "2011-11-02",
    "close": 7604.0,
    "volume": 134837,
    "contract": "201111"
  },
  {
    "date": "2011-11-03",
    "close": 7446.0,
    "volume": 145531,
    "contract": "201111"
  },
  {
    "date": "2011-11-04",
    "close": 7628.0,
    "volume": 114452,
    "contract": "201111"
  },
  {
    "date": "2011-11-07",
    "close": 7635.0,
    "volume": 76533,
    "contract": "201111"
  },
  {
    "date": "2011-11-08",
    "close": 7589.0,
    "volume": 123361,
    "contract": "201111"
  },
  {
    "date": "2011-11-09",
    "close": 7612.0,
    "volume": 94938,
    "contract": "201111"
  },
  {
    "date": "2011-11-10",
    "close": 7317.0,
    "volume": 147157,
    "contract": "201111"
  },
  {
    "date": "2011-11-11",
    "close": 7356.0,
    "volume": 108018,
    "contract": "201111"
  },
  {
    "date": "2011-11-14",
    "close": 7542.0,
    "volume": 95577,
    "contract": "201111"
  },
  {
    "date": "2011-11-15",
    "close": 7501.0,
    "volume": 84264,
    "contract": "201111"
  },
  {
    "date": "2011-11-16",
    "close": 7397.0,
    "volume": 78514,
    "contract": "201111"
  },
  {
    "date": "2011-11-17",
    "close": 7401.0,
    "volume": 119950,
    "contract": "201112"
  },
  {
    "date": "2011-11-18",
    "close": 7246.0,
    "volume": 127241,
    "contract": "201112"
  },
  {
    "date": "2011-11-21",
    "close": 7051.0,
    "volume": 127792,
    "contract": "201112"
  },
  {
    "date": "2011-11-22",
    "close": 7021.0,
    "volume": 135843,
    "contract": "201112"
  },
  {
    "date": "2011-11-23",
    "close": 6823.0,
    "volume": 147518,
    "contract": "201112"
  },
  {
    "date": "2011-11-24",
    "close": 6831.0,
    "volume": 130321,
    "contract": "201112"
  },
  {
    "date": "2011-11-25",
    "close": 6754.0,
    "volume": 172063,
    "contract": "201112"
  },
  {
    "date": "2011-11-28",
    "close": 6916.0,
    "volume": 115248,
    "contract": "201112"
  },
  {
    "date": "2011-11-29",
    "close": 6973.0,
    "volume": 108654,
    "contract": "201112"
  },
  {
    "date": "2011-11-30",
    "close": 6902.0,
    "volume": 133349,
    "contract": "201112"
  },
  {
    "date": "2011-12-01",
    "close": 7210.0,
    "volume": 117187,
    "contract": "201112"
  },
  {
    "date": "2011-12-02",
    "close": 7156.0,
    "volume": 98794,
    "contract": "201112"
  },
  {
    "date": "2011-12-05",
    "close": 7131.0,
    "volume": 112080,
    "contract": "201112"
  },
  {
    "date": "2011-12-06",
    "close": 6982.0,
    "volume": 106833,
    "contract": "201112"
  },
  {
    "date": "2011-12-07",
    "close": 7050.0,
    "volume": 101832,
    "contract": "201112"
  },
  {
    "date": "2011-12-08",
    "close": 6963.0,
    "volume": 120584,
    "contract": "201112"
  },
  {
    "date": "2011-12-09",
    "close": 6887.0,
    "volume": 144562,
    "contract": "201112"
  },
  {
    "date": "2011-12-12",
    "close": 6941.0,
    "volume": 93960,
    "contract": "201112"
  },
  {
    "date": "2011-12-13",
    "close": 6894.0,
    "volume": 94876,
    "contract": "201112"
  },
  {
    "date": "2011-12-14",
    "close": 6921.0,
    "volume": 77078,
    "contract": "201112"
  },
  {
    "date": "2011-12-15",
    "close": 6753.0,
    "volume": 100907,
    "contract": "201112"
  },
  {
    "date": "2011-12-16",
    "close": 6772.0,
    "volume": 77149,
    "contract": "201112"
  },
  {
    "date": "2011-12-19",
    "close": 6634.0,
    "volume": 122210,
    "contract": "201112"
  },
  {
    "date": "2011-12-20",
    "close": 6669.0,
    "volume": 76742,
    "contract": "201112"
  },
  {
    "date": "2011-12-21",
    "close": 6952.0,
    "volume": 57954,
    "contract": "201112"
  },
  {
    "date": "2011-12-22",
    "close": 6955.0,
    "volume": 58656,
    "contract": "201201"
  },
  {
    "date": "2011-12-23",
    "close": 7107.0,
    "volume": 71134,
    "contract": "201201"
  },
  {
    "date": "2011-12-26",
    "close": 7103.0,
    "volume": 44558,
    "contract": "201201"
  },
  {
    "date": "2011-12-27",
    "close": 7084.0,
    "volume": 74041,
    "contract": "201201"
  },
  {
    "date": "2011-12-28",
    "close": 7053.0,
    "volume": 56327,
    "contract": "201201"
  },
  {
    "date": "2011-12-29",
    "close": 7074.0,
    "volume": 67828,
    "contract": "201201"
  },
  {
    "date": "2011-12-30",
    "close": 7039.0,
    "volume": 88497,
    "contract": "201201"
  },
  {
    "date": "2012-01-02",
    "close": 6945.0,
    "volume": 88560,
    "contract": "201201"
  },
  {
    "date": "2012-01-03",
    "close": 7047.0,
    "volume": 86632,
    "contract": "201201"
  },
  {
    "date": "2012-01-04",
    "close": 7072.0,
    "volume": 87283,
    "contract": "201201"
  },
  {
    "date": "2012-01-05",
    "close": 7119.0,
    "volume": 81932,
    "contract": "201201"
  },
  {
    "date": "2012-01-06",
    "close": 7084.0,
    "volume": 90256,
    "contract": "201201"
  },
  {
    "date": "2012-01-09",
    "close": 7057.0,
    "volume": 76575,
    "contract": "201201"
  },
  {
    "date": "2012-01-10",
    "close": 7167.0,
    "volume": 80808,
    "contract": "201201"
  },
  {
    "date": "2012-01-11",
    "close": 7179.0,
    "volume": 58991,
    "contract": "201201"
  },
  {
    "date": "2012-01-12",
    "close": 7185.0,
    "volume": 53064,
    "contract": "201201"
  },
  {
    "date": "2012-01-13",
    "close": 7161.0,
    "volume": 95431,
    "contract": "201201"
  },
  {
    "date": "2012-01-16",
    "close": 7090.0,
    "volume": 136731,
    "contract": "201201"
  },
  {
    "date": "2012-01-17",
    "close": 7225.0,
    "volume": 108548,
    "contract": "201201"
  },
  {
    "date": "2012-01-18",
    "close": 7207.0,
    "volume": 54107,
    "contract": "201201"
  },
  {
    "date": "2012-01-30",
    "close": 7392.0,
    "volume": 88011,
    "contract": "201202"
  },
  {
    "date": "2012-01-31",
    "close": 7468.0,
    "volume": 107138,
    "contract": "201202"
  },
  {
    "date": "2012-02-01",
    "close": 7522.0,
    "volume": 98775,
    "contract": "201202"
  },
  {
    "date": "2012-02-02",
    "close": 7641.0,
    "volume": 96092,
    "contract": "201202"
  },
  {
    "date": "2012-02-03",
    "close": 7640.0,
    "volume": 79813,
    "contract": "201202"
  },
  {
    "date": "2012-02-04",
    "close": 7733.0,
    "volume": 75806,
    "contract": "201202"
  },
  {
    "date": "2012-02-06",
    "close": 7683.0,
    "volume": 87973,
    "contract": "201202"
  },
  {
    "date": "2012-02-07",
    "close": 7720.0,
    "volume": 107371,
    "contract": "201202"
  },
  {
    "date": "2012-02-08",
    "close": 7888.0,
    "volume": 113980,
    "contract": "201202"
  },
  {
    "date": "2012-02-09",
    "close": 7920.0,
    "volume": 109956,
    "contract": "201202"
  },
  {
    "date": "2012-02-10",
    "close": 7865.0,
    "volume": 102524,
    "contract": "201202"
  },
  {
    "date": "2012-02-13",
    "close": 7905.0,
    "volume": 105798,
    "contract": "201202"
  },
  {
    "date": "2012-02-14",
    "close": 7874.0,
    "volume": 118000,
    "contract": "201202"
  },
  {
    "date": "2012-02-15",
    "close": 8006.0,
    "volume": 66187,
    "contract": "201202"
  },
  {
    "date": "2012-02-16",
    "close": 7905.0,
    "volume": 111267,
    "contract": "201203"
  },
  {
    "date": "2012-02-17",
    "close": 7929.0,
    "volume": 141830,
    "contract": "201203"
  },
  {
    "date": "2012-02-20",
    "close": 7957.0,
    "volume": 91101,
    "contract": "201203"
  },
  {
    "date": "2012-02-21",
    "close": 7947.0,
    "volume": 138398,
    "contract": "201203"
  },
  {
    "date": "2012-02-22",
    "close": 8005.0,
    "volume": 129636,
    "contract": "201203"
  },
  {
    "date": "2012-02-23",
    "close": 7963.0,
    "volume": 83248,
    "contract": "201203"
  },
  {
    "date": "2012-02-24",
    "close": 7943.0,
    "volume": 115253,
    "contract": "201203"
  },
  {
    "date": "2012-02-29",
    "close": 8111.0,
    "volume": 100542,
    "contract": "201203"
  },
  {
    "date": "2012-03-01",
    "close": 8139.0,
    "volume": 91701,
    "contract": "201203"
  },
  {
    "date": "2012-03-02",
    "close": 8152.0,
    "volume": 85994,
    "contract": "201203"
  },
  {
    "date": "2012-03-03",
    "close": 8120.0,
    "volume": 50421,
    "contract": "201203"
  },
  {
    "date": "2012-03-05",
    "close": 8038.0,
    "volume": 106909,
    "contract": "201203"
  },
  {
    "date": "2012-03-06",
    "close": 7945.0,
    "volume": 137557,
    "contract": "201203"
  },
  {
    "date": "2012-03-07",
    "close": 7892.0,
    "volume": 104775,
    "contract": "201203"
  },
  {
    "date": "2012-03-08",
    "close": 7976.0,
    "volume": 109999,
    "contract": "201203"
  },
  {
    "date": "2012-03-09",
    "close": 8003.0,
    "volume": 107445,
    "contract": "201203"
  },
  {
    "date": "2012-03-12",
    "close": 7927.0,
    "volume": 91819,
    "contract": "201203"
  },
  {
    "date": "2012-03-13",
    "close": 8032.0,
    "volume": 114304,
    "contract": "201203"
  },
  {
    "date": "2012-03-14",
    "close": 8140.0,
    "volume": 86162,
    "contract": "201203"
  },
  {
    "date": "2012-03-15",
    "close": 8135.0,
    "volume": 85516,
    "contract": "201203"
  },
  {
    "date": "2012-03-16",
    "close": 8068.0,
    "volume": 85853,
    "contract": "201203"
  },
  {
    "date": "2012-03-19",
    "close": 8050.0,
    "volume": 130033,
    "contract": "201203"
  },
  {
    "date": "2012-03-20",
    "close": 7984.0,
    "volume": 107278,
    "contract": "201203"
  },
  {
    "date": "2012-03-21",
    "close": 7980.0,
    "volume": 64741,
    "contract": "201203"
  },
  {
    "date": "2012-03-22",
    "close": 8081.0,
    "volume": 105507,
    "contract": "201204"
  },
  {
    "date": "2012-03-23",
    "close": 8080.0,
    "volume": 69157,
    "contract": "201204"
  },
  {
    "date": "2012-03-26",
    "close": 7959.0,
    "volume": 120901,
    "contract": "201204"
  },
  {
    "date": "2012-03-27",
    "close": 8012.0,
    "volume": 82263,
    "contract": "201204"
  },
  {
    "date": "2012-03-28",
    "close": 8028.0,
    "volume": 92823,
    "contract": "201204"
  },
  {
    "date": "2012-03-29",
    "close": 7849.0,
    "volume": 137007,
    "contract": "201204"
  },
  {
    "date": "2012-03-30",
    "close": 7886.0,
    "volume": 107110,
    "contract": "201204"
  },
  {
    "date": "2012-04-02",
    "close": 7865.0,
    "volume": 83322,
    "contract": "201204"
  },
  {
    "date": "2012-04-03",
    "close": 7778.0,
    "volume": 138985,
    "contract": "201204"
  },
  {
    "date": "2012-04-05",
    "close": 7619.0,
    "volume": 138350,
    "contract": "201204"
  },
  {
    "date": "2012-04-06",
    "close": 7672.0,
    "volume": 92586,
    "contract": "201204"
  },
  {
    "date": "2012-04-09",
    "close": 7577.0,
    "volume": 107628,
    "contract": "201204"
  },
  {
    "date": "2012-04-10",
    "close": 7610.0,
    "volume": 111434,
    "contract": "201204"
  },
  {
    "date": "2012-04-11",
    "close": 7638.0,
    "volume": 114869,
    "contract": "201204"
  },
  {
    "date": "2012-04-12",
    "close": 7634.0,
    "volume": 111410,
    "contract": "201204"
  },
  {
    "date": "2012-04-13",
    "close": 7755.0,
    "volume": 114567,
    "contract": "201204"
  },
  {
    "date": "2012-04-16",
    "close": 7712.0,
    "volume": 71070,
    "contract": "201204"
  },
  {
    "date": "2012-04-17",
    "close": 7597.0,
    "volume": 128889,
    "contract": "201204"
  },
  {
    "date": "2012-04-18",
    "close": 7620.0,
    "volume": 62080,
    "contract": "201204"
  },
  {
    "date": "2012-04-19",
    "close": 7613.0,
    "volume": 112215,
    "contract": "201205"
  },
  {
    "date": "2012-04-20",
    "close": 7515.0,
    "volume": 109626,
    "contract": "201205"
  },
  {
    "date": "2012-04-23",
    "close": 7478.0,
    "volume": 109398,
    "contract": "201205"
  },
  {
    "date": "2012-04-24",
    "close": 7488.0,
    "volume": 130651,
    "contract": "201205"
  },
  {
    "date": "2012-04-25",
    "close": 7539.0,
    "volume": 90160,
    "contract": "201205"
  },
  {
    "date": "2012-04-26",
    "close": 7496.0,
    "volume": 116655,
    "contract": "201205"
  },
  {
    "date": "2012-04-27",
    "close": 7446.0,
    "volume": 127455,
    "contract": "201205"
  },
  {
    "date": "2012-04-30",
    "close": 7465.0,
    "volume": 84782,
    "contract": "201205"
  },
  {
    "date": "2012-05-02",
    "close": 7675.0,
    "volume": 124081,
    "contract": "201205"
  },
  {
    "date": "2012-05-03",
    "close": 7657.0,
    "volume": 65044,
    "contract": "201205"
  },
  {
    "date": "2012-05-04",
    "close": 7664.0,
    "volume": 104609,
    "contract": "201205"
  },
  {
    "date": "2012-05-07",
    "close": 7502.0,
    "volume": 105959,
    "contract": "201205"
  },
  {
    "date": "2012-05-08",
    "close": 7520.0,
    "volume": 70997,
    "contract": "201205"
  },
  {
    "date": "2012-05-09",
    "close": 7459.0,
    "volume": 111427,
    "contract": "201205"
  },
  {
    "date": "2012-05-10",
    "close": 7479.0,
    "volume": 105113,
    "contract": "201205"
  },
  {
    "date": "2012-05-11",
    "close": 7366.0,
    "volume": 116762,
    "contract": "201205"
  },
  {
    "date": "2012-05-14",
    "close": 7369.0,
    "volume": 91396,
    "contract": "201205"
  },
  {
    "date": "2012-05-15",
    "close": 7384.0,
    "volume": 113623,
    "contract": "201205"
  },
  {
    "date": "2012-05-16",
    "close": 7255.0,
    "volume": 79053,
    "contract": "201205"
  },
  {
    "date": "2012-05-17",
    "close": 7314.0,
    "volume": 107382,
    "contract": "201206"
  },
  {
    "date": "2012-05-18",
    "close": 7135.0,
    "volume": 137508,
    "contract": "201206"
  },
  {
    "date": "2012-05-21",
    "close": 7184.0,
    "volume": 90002,
    "contract": "201206"
  },
  {
    "date": "2012-05-22",
    "close": 7236.0,
    "volume": 84457,
    "contract": "201206"
  },
  {
    "date": "2012-05-23",
    "close": 7135.0,
    "volume": 104162,
    "contract": "201206"
  },
  {
    "date": "2012-05-24",
    "close": 7129.0,
    "volume": 110432,
    "contract": "201206"
  },
  {
    "date": "2012-05-25",
    "close": 7058.0,
    "volume": 112160,
    "contract": "201206"
  },
  {
    "date": "2012-05-28",
    "close": 7114.0,
    "volume": 88137,
    "contract": "201206"
  },
  {
    "date": "2012-05-29",
    "close": 7294.0,
    "volume": 133522,
    "contract": "201206"
  },
  {
    "date": "2012-05-30",
    "close": 7234.0,
    "volume": 106158,
    "contract": "201206"
  },
  {
    "date": "2012-05-31",
    "close": 7217.0,
    "volume": 133197,
    "contract": "201206"
  },
  {
    "date": "2012-06-01",
    "close": 7096.0,
    "volume": 148958,
    "contract": "201206"
  },
  {
    "date": "2012-06-04",
    "close": 6869.0,
    "volume": 136278,
    "contract": "201206"
  },
  {
    "date": "2012-06-05",
    "close": 6970.0,
    "volume": 119982,
    "contract": "201206"
  },
  {
    "date": "2012-06-06",
    "close": 7015.0,
    "volume": 119994,
    "contract": "201206"
  },
  {
    "date": "2012-06-07",
    "close": 7047.0,
    "volume": 109350,
    "contract": "201206"
  },
  {
    "date": "2012-06-08",
    "close": 6955.0,
    "volume": 113544,
    "contract": "201206"
  },
  {
    "date": "2012-06-11",
    "close": 7092.0,
    "volume": 104743,
    "contract": "201206"
  },
  {
    "date": "2012-06-12",
    "close": 7019.0,
    "volume": 91231,
    "contract": "201206"
  },
  {
    "date": "2012-06-13",
    "close": 7048.0,
    "volume": 92489,
    "contract": "201206"
  },
  {
    "date": "2012-06-14",
    "close": 7063.0,
    "volume": 92161,
    "contract": "201206"
  },
  {
    "date": "2012-06-15",
    "close": 7154.0,
    "volume": 105833,
    "contract": "201206"
  },
  {
    "date": "2012-06-18",
    "close": 7265.0,
    "volume": 92004,
    "contract": "201206"
  },
  {
    "date": "2012-06-19",
    "close": 7265.0,
    "volume": 80407,
    "contract": "201206"
  },
  {
    "date": "2012-06-20",
    "close": 7311.0,
    "volume": 50941,
    "contract": "201206"
  },
  {
    "date": "2012-06-21",
    "close": 7117.0,
    "volume": 87665,
    "contract": "201207"
  },
  {
    "date": "2012-06-22",
    "close": 7034.0,
    "volume": 86796,
    "contract": "201207"
  },
  {
    "date": "2012-06-25",
    "close": 6948.0,
    "volume": 79925,
    "contract": "201207"
  },
  {
    "date": "2012-06-26",
    "close": 6939.0,
    "volume": 61535,
    "contract": "201207"
  },
  {
    "date": "2012-06-27",
    "close": 6986.0,
    "volume": 89541,
    "contract": "201207"
  },
  {
    "date": "2012-06-28",
    "close": 7001.0,
    "volume": 93508,
    "contract": "201207"
  },
  {
    "date": "2012-06-29",
    "close": 7114.0,
    "volume": 125080,
    "contract": "201207"
  },
  {
    "date": "2012-07-02",
    "close": 7136.0,
    "volume": 61181,
    "contract": "201207"
  },
  {
    "date": "2012-07-03",
    "close": 7228.0,
    "volume": 100095,
    "contract": "201207"
  },
  {
    "date": "2012-07-04",
    "close": 7290.0,
    "volume": 83106,
    "contract": "201207"
  },
  {
    "date": "2012-07-05",
    "close": 7297.0,
    "volume": 61592,
    "contract": "201207"
  },
  {
    "date": "2012-07-06",
    "close": 7272.0,
    "volume": 88904,
    "contract": "201207"
  },
  {
    "date": "2012-07-09",
    "close": 7236.0,
    "volume": 78681,
    "contract": "201207"
  },
  {
    "date": "2012-07-10",
    "close": 7181.0,
    "volume": 111304,
    "contract": "201207"
  },
  {
    "date": "2012-07-11",
    "close": 7186.0,
    "volume": 84861,
    "contract": "201207"
  },
  {
    "date": "2012-07-12",
    "close": 7079.0,
    "volume": 120546,
    "contract": "201207"
  },
  {
    "date": "2012-07-13",
    "close": 7071.0,
    "volume": 96058,
    "contract": "201207"
  },
  {
    "date": "2012-07-16",
    "close": 7057.0,
    "volume": 98746,
    "contract": "201207"
  },
  {
    "date": "2012-07-17",
    "close": 7107.0,
    "volume": 123931,
    "contract": "201207"
  },
  {
    "date": "2012-07-18",
    "close": 7059.0,
    "volume": 52519,
    "contract": "201207"
  },
  {
    "date": "2012-07-19",
    "close": 7022.0,
    "volume": 105346,
    "contract": "201208"
  },
  {
    "date": "2012-07-20",
    "close": 7013.0,
    "volume": 72895,
    "contract": "201208"
  },
  {
    "date": "2012-07-23",
    "close": 6873.0,
    "volume": 89331,
    "contract": "201208"
  },
  {
    "date": "2012-07-24",
    "close": 6874.0,
    "volume": 70435,
    "contract": "201208"
  },
  {
    "date": "2012-07-25",
    "close": 6846.0,
    "volume": 109485,
    "contract": "201208"
  },
  {
    "date": "2012-07-26",
    "close": 6875.0,
    "volume": 89439,
    "contract": "201208"
  },
  {
    "date": "2012-07-27",
    "close": 7028.0,
    "volume": 101947,
    "contract": "201208"
  },
  {
    "date": "2012-07-30",
    "close": 7078.0,
    "volume": 73940,
    "contract": "201208"
  },
  {
    "date": "2012-07-31",
    "close": 7157.0,
    "volume": 111301,
    "contract": "201208"
  },
  {
    "date": "2012-08-01",
    "close": 7194.0,
    "volume": 91583,
    "contract": "201208"
  },
  {
    "date": "2012-08-03",
    "close": 7140.0,
    "volume": 77401,
    "contract": "201208"
  },
  {
    "date": "2012-08-06",
    "close": 7237.0,
    "volume": 87031,
    "contract": "201208"
  },
  {
    "date": "2012-08-07",
    "close": 7236.0,
    "volume": 62956,
    "contract": "201208"
  },
  {
    "date": "2012-08-08",
    "close": 7300.0,
    "volume": 103055,
    "contract": "201208"
  },
  {
    "date": "2012-08-09",
    "close": 7438.0,
    "volume": 125910,
    "contract": "201208"
  },
  {
    "date": "2012-08-10",
    "close": 7444.0,
    "volume": 68582,
    "contract": "201208"
  },
  {
    "date": "2012-08-13",
    "close": 7453.0,
    "volume": 67806,
    "contract": "201208"
  },
  {
    "date": "2012-08-14",
    "close": 7495.0,
    "volume": 113777,
    "contract": "201208"
  },
  {
    "date": "2012-08-15",
    "close": 7468.0,
    "volume": 43962,
    "contract": "201208"
  },
  {
    "date": "2012-08-16",
    "close": 7493.0,
    "volume": 91628,
    "contract": "201209"
  },
  {
    "date": "2012-08-17",
    "close": 7474.0,
    "volume": 66804,
    "contract": "201209"
  },
  {
    "date": "2012-08-20",
    "close": 7441.0,
    "volume": 85890,
    "contract": "201209"
  },
  {
    "date": "2012-08-21",
    "close": 7515.0,
    "volume": 104595,
    "contract": "201209"
  },
  {
    "date": "2012-08-22",
    "close": 7490.0,
    "volume": 73832,
    "contract": "201209"
  },
  {
    "date": "2012-08-23",
    "close": 7513.0,
    "volume": 92576,
    "contract": "201209"
  },
  {
    "date": "2012-08-24",
    "close": 7487.0,
    "volume": 63615,
    "contract": "201209"
  },
  {
    "date": "2012-08-27",
    "close": 7454.0,
    "volume": 85683,
    "contract": "201209"
  },
  {
    "date": "2012-08-28",
    "close": 7399.0,
    "volume": 90608,
    "contract": "201209"
  },
  {
    "date": "2012-08-29",
    "close": 7403.0,
    "volume": 48276,
    "contract": "201209"
  },
  {
    "date": "2012-08-30",
    "close": 7367.0,
    "volume": 84738,
    "contract": "201209"
  },
  {
    "date": "2012-08-31",
    "close": 7382.0,
    "volume": 75810,
    "contract": "201209"
  },
  {
    "date": "2012-09-03",
    "close": 7442.0,
    "volume": 95691,
    "contract": "201209"
  },
  {
    "date": "2012-09-04",
    "close": 7448.0,
    "volume": 49798,
    "contract": "201209"
  },
  {
    "date": "2012-09-05",
    "close": 7344.0,
    "volume": 89655,
    "contract": "201209"
  },
  {
    "date": "2012-09-06",
    "close": 7332.0,
    "volume": 88818,
    "contract": "201209"
  },
  {
    "date": "2012-09-07",
    "close": 7419.0,
    "volume": 86302,
    "contract": "201209"
  },
  {
    "date": "2012-09-10",
    "close": 7456.0,
    "volume": 67675,
    "contract": "201209"
  },
  {
    "date": "2012-09-11",
    "close": 7465.0,
    "volume": 59702,
    "contract": "201209"
  },
  {
    "date": "2012-09-12",
    "close": 7583.0,
    "volume": 92821,
    "contract": "201209"
  },
  {
    "date": "2012-09-13",
    "close": 7576.0,
    "volume": 65782,
    "contract": "201209"
  },
  {
    "date": "2012-09-14",
    "close": 7738.0,
    "volume": 103221,
    "contract": "201209"
  },
  {
    "date": "2012-09-17",
    "close": 7750.0,
    "volume": 70895,
    "contract": "201209"
  },
  {
    "date": "2012-09-18",
    "close": 7749.0,
    "volume": 76925,
    "contract": "201209"
  },
  {
    "date": "2012-09-19",
    "close": 7767.0,
    "volume": 46387,
    "contract": "201209"
  },
  {
    "date": "2012-09-20",
    "close": 7749.0,
    "volume": 81485,
    "contract": "201210"
  },
  {
    "date": "2012-09-21",
    "close": 7761.0,
    "volume": 61018,
    "contract": "201210"
  },
  {
    "date": "2012-09-24",
    "close": 7775.0,
    "volume": 98891,
    "contract": "201210"
  },
  {
    "date": "2012-09-25",
    "close": 7756.0,
    "volume": 68390,
    "contract": "201210"
  },
  {
    "date": "2012-09-26",
    "close": 7700.0,
    "volume": 74746,
    "contract": "201210"
  },
  {
    "date": "2012-09-27",
    "close": 7728.0,
    "volume": 67769,
    "contract": "201210"
  },
  {
    "date": "2012-09-28",
    "close": 7719.0,
    "volume": 88739,
    "contract": "201210"
  },
  {
    "date": "2012-10-01",
    "close": 7684.0,
    "volume": 50167,
    "contract": "201210"
  },
  {
    "date": "2012-10-02",
    "close": 7729.0,
    "volume": 67005,
    "contract": "201210"
  },
  {
    "date": "2012-10-03",
    "close": 7704.0,
    "volume": 58958,
    "contract": "201210"
  },
  {
    "date": "2012-10-04",
    "close": 7706.0,
    "volume": 103623,
    "contract": "201210"
  },
  {
    "date": "2012-10-05",
    "close": 7701.0,
    "volume": 74558,
    "contract": "201210"
  },
  {
    "date": "2012-10-08",
    "close": 7625.0,
    "volume": 84411,
    "contract": "201210"
  },
  {
    "date": "2012-10-09",
    "close": 7596.0,
    "volume": 86468,
    "contract": "201210"
  },
  {
    "date": "2012-10-11",
    "close": 7444.0,
    "volume": 95582,
    "contract": "201210"
  },
  {
    "date": "2012-10-12",
    "close": 7413.0,
    "volume": 92390,
    "contract": "201210"
  },
  {
    "date": "2012-10-15",
    "close": 7425.0,
    "volume": 74135,
    "contract": "201210"
  },
  {
    "date": "2012-10-16",
    "close": 7458.0,
    "volume": 62568,
    "contract": "201210"
  },
  {
    "date": "2012-10-17",
    "close": 7460.0,
    "volume": 50723,
    "contract": "201210"
  },
  {
    "date": "2012-10-18",
    "close": 7453.0,
    "volume": 57034,
    "contract": "201211"
  },
  {
    "date": "2012-10-19",
    "close": 7387.0,
    "volume": 78020,
    "contract": "201211"
  },
  {
    "date": "2012-10-22",
    "close": 7347.0,
    "volume": 71985,
    "contract": "201211"
  },
  {
    "date": "2012-10-23",
    "close": 7299.0,
    "volume": 65177,
    "contract": "201211"
  },
  {
    "date": "2012-10-24",
    "close": 7303.0,
    "volume": 100109,
    "contract": "201211"
  },
  {
    "date": "2012-10-25",
    "close": 7254.0,
    "volume": 75504,
    "contract": "201211"
  },
  {
    "date": "2012-10-26",
    "close": 7092.0,
    "volume": 124395,
    "contract": "201211"
  },
  {
    "date": "2012-10-29",
    "close": 7121.0,
    "volume": 86593,
    "contract": "201211"
  },
  {
    "date": "2012-10-30",
    "close": 7162.0,
    "volume": 104953,
    "contract": "201211"
  },
  {
    "date": "2012-10-31",
    "close": 7141.0,
    "volume": 89170,
    "contract": "201211"
  },
  {
    "date": "2012-11-01",
    "close": 7172.0,
    "volume": 140249,
    "contract": "201211"
  },
  {
    "date": "2012-11-02",
    "close": 7201.0,
    "volume": 74949,
    "contract": "201211"
  },
  {
    "date": "2012-11-05",
    "close": 7181.0,
    "volume": 85380,
    "contract": "201211"
  },
  {
    "date": "2012-11-06",
    "close": 7256.0,
    "volume": 78730,
    "contract": "201211"
  },
  {
    "date": "2012-11-07",
    "close": 7256.0,
    "volume": 138988,
    "contract": "201211"
  },
  {
    "date": "2012-11-08",
    "close": 7201.0,
    "volume": 87322,
    "contract": "201211"
  },
  {
    "date": "2012-11-09",
    "close": 7286.0,
    "volume": 125251,
    "contract": "201211"
  },
  {
    "date": "2012-11-12",
    "close": 7243.0,
    "volume": 73703,
    "contract": "201211"
  },
  {
    "date": "2012-11-13",
    "close": 7094.0,
    "volume": 116093,
    "contract": "201211"
  },
  {
    "date": "2012-11-14",
    "close": 7128.0,
    "volume": 85707,
    "contract": "201211"
  },
  {
    "date": "2012-11-15",
    "close": 7121.0,
    "volume": 110846,
    "contract": "201211"
  },
  {
    "date": "2012-11-16",
    "close": 7107.0,
    "volume": 106108,
    "contract": "201211"
  },
  {
    "date": "2012-11-19",
    "close": 7121.0,
    "volume": 85220,
    "contract": "201211"
  },
  {
    "date": "2012-11-20",
    "close": 7159.0,
    "volume": 73796,
    "contract": "201211"
  },
  {
    "date": "2012-11-21",
    "close": 7084.0,
    "volume": 63354,
    "contract": "201211"
  },
  {
    "date": "2012-11-22",
    "close": 7089.0,
    "volume": 64895,
    "contract": "201212"
  },
  {
    "date": "2012-11-23",
    "close": 7319.0,
    "volume": 120286,
    "contract": "201212"
  },
  {
    "date": "2012-11-26",
    "close": 7388.0,
    "volume": 66389,
    "contract": "201212"
  },
  {
    "date": "2012-11-27",
    "close": 7421.0,
    "volume": 76309,
    "contract": "201212"
  },
  {
    "date": "2012-11-28",
    "close": 7429.0,
    "volume": 62717,
    "contract": "201212"
  },
  {
    "date": "2012-11-29",
    "close": 7525.0,
    "volume": 98874,
    "contract": "201212"
  },
  {
    "date": "2012-11-30",
    "close": 7594.0,
    "volume": 97251,
    "contract": "201212"
  },
  {
    "date": "2012-12-03",
    "close": 7599.0,
    "volume": 94211,
    "contract": "201212"
  },
  {
    "date": "2012-12-04",
    "close": 7593.0,
    "volume": 76536,
    "contract": "201212"
  },
  {
    "date": "2012-12-05",
    "close": 7651.0,
    "volume": 96482,
    "contract": "201212"
  },
  {
    "date": "2012-12-06",
    "close": 7639.0,
    "volume": 68952,
    "contract": "201212"
  },
  {
    "date": "2012-12-07",
    "close": 7659.0,
    "volume": 73118,
    "contract": "201212"
  },
  {
    "date": "2012-12-10",
    "close": 7623.0,
    "volume": 76659,
    "contract": "201212"
  },
  {
    "date": "2012-12-11",
    "close": 7638.0,
    "volume": 78461,
    "contract": "201212"
  },
  {
    "date": "2012-12-12",
    "close": 7695.0,
    "volume": 89122,
    "contract": "201212"
  },
  {
    "date": "2012-12-13",
    "close": 7773.0,
    "volume": 82175,
    "contract": "201212"
  },
  {
    "date": "2012-12-14",
    "close": 7704.0,
    "volume": 84818,
    "contract": "201212"
  },
  {
    "date": "2012-12-17",
    "close": 7649.0,
    "volume": 100268,
    "contract": "201212"
  },
  {
    "date": "2012-12-18",
    "close": 7653.0,
    "volume": 70612,
    "contract": "201212"
  },
  {
    "date": "2012-12-19",
    "close": 7659.0,
    "volume": 46969,
    "contract": "201212"
  },
  {
    "date": "2012-12-20",
    "close": 7559.0,
    "volume": 79058,
    "contract": "201301"
  },
  {
    "date": "2012-12-21",
    "close": 7492.0,
    "volume": 107770,
    "contract": "201301"
  },
  {
    "date": "2012-12-22",
    "close": 7527.0,
    "volume": 30095,
    "contract": "201301"
  },
  {
    "date": "2012-12-24",
    "close": 7521.0,
    "volume": 51155,
    "contract": "201301"
  },
  {
    "date": "2012-12-25",
    "close": 7671.0,
    "volume": 85986,
    "contract": "201301"
  },
  {
    "date": "2012-12-26",
    "close": 7632.0,
    "volume": 65775,
    "contract": "201301"
  },
  {
    "date": "2012-12-27",
    "close": 7628.0,
    "volume": 80035,
    "contract": "201301"
  },
  {
    "date": "2012-12-28",
    "close": 7677.0,
    "volume": 69670,
    "contract": "201301"
  },
  {
    "date": "2013-01-02",
    "close": 7773.0,
    "volume": 89092,
    "contract": "201301"
  },
  {
    "date": "2013-01-03",
    "close": 7824.0,
    "volume": 63225,
    "contract": "201301"
  },
  {
    "date": "2013-01-04",
    "close": 7775.0,
    "volume": 71943,
    "contract": "201301"
  },
  {
    "date": "2013-01-07",
    "close": 7741.0,
    "volume": 81337,
    "contract": "201301"
  },
  {
    "date": "2013-01-08",
    "close": 7709.0,
    "volume": 90290,
    "contract": "201301"
  },
  {
    "date": "2013-01-09",
    "close": 7738.0,
    "volume": 88574,
    "contract": "201301"
  },
  {
    "date": "2013-01-10",
    "close": 7833.0,
    "volume": 122619,
    "contract": "201301"
  },
  {
    "date": "2013-01-11",
    "close": 7802.0,
    "volume": 90984,
    "contract": "201301"
  },
  {
    "date": "2013-01-14",
    "close": 7823.0,
    "volume": 111839,
    "contract": "201301"
  },
  {
    "date": "2013-01-15",
    "close": 7743.0,
    "volume": 99174,
    "contract": "201301"
  },
  {
    "date": "2013-01-16",
    "close": 7717.0,
    "volume": 58511,
    "contract": "201301"
  },
  {
    "date": "2013-01-17",
    "close": 7614.0,
    "volume": 146042,
    "contract": "201302"
  },
  {
    "date": "2013-01-18",
    "close": 7712.0,
    "volume": 86279,
    "contract": "201302"
  },
  {
    "date": "2013-01-21",
    "close": 7704.0,
    "volume": 94447,
    "contract": "201302"
  },
  {
    "date": "2013-01-22",
    "close": 7748.0,
    "volume": 106112,
    "contract": "201302"
  },
  {
    "date": "2013-01-23",
    "close": 7722.0,
    "volume": 77820,
    "contract": "201302"
  },
  {
    "date": "2013-01-24",
    "close": 7683.0,
    "volume": 121098,
    "contract": "201302"
  },
  {
    "date": "2013-01-25",
    "close": 7650.0,
    "volume": 98883,
    "contract": "201302"
  },
  {
    "date": "2013-01-28",
    "close": 7727.0,
    "volume": 92771,
    "contract": "201302"
  },
  {
    "date": "2013-01-29",
    "close": 7812.0,
    "volume": 99284,
    "contract": "201302"
  },
  {
    "date": "2013-01-30",
    "close": 7796.0,
    "volume": 100596,
    "contract": "201302"
  },
  {
    "date": "2013-01-31",
    "close": 7846.0,
    "volume": 84766,
    "contract": "201302"
  },
  {
    "date": "2013-02-01",
    "close": 7859.0,
    "volume": 87506,
    "contract": "201302"
  },
  {
    "date": "2013-02-04",
    "close": 7939.0,
    "volume": 87092,
    "contract": "201302"
  },
  {
    "date": "2013-02-05",
    "close": 7901.0,
    "volume": 74233,
    "contract": "201302"
  },
  {
    "date": "2013-02-06",
    "close": 7901.0,
    "volume": 72671,
    "contract": "201302"
  },
  {
    "date": "2013-02-18",
    "close": 7936.0,
    "volume": 77582,
    "contract": "201302"
  },
  {
    "date": "2013-02-19",
    "close": 7958.0,
    "volume": 60019,
    "contract": "201302"
  },
  {
    "date": "2013-02-20",
    "close": 8023.0,
    "volume": 52976,
    "contract": "201302"
  },
  {
    "date": "2013-02-21",
    "close": 7949.0,
    "volume": 63895,
    "contract": "201303"
  },
  {
    "date": "2013-02-22",
    "close": 7951.0,
    "volume": 85371,
    "contract": "201303"
  },
  {
    "date": "2013-02-23",
    "close": 7992.0,
    "volume": 27144,
    "contract": "201303"
  },
  {
    "date": "2013-02-25",
    "close": 7941.0,
    "volume": 72527,
    "contract": "201303"
  },
  {
    "date": "2013-02-26",
    "close": 7883.0,
    "volume": 82377,
    "contract": "201303"
  },
  {
    "date": "2013-02-27",
    "close": 7879.0,
    "volume": 53936,
    "contract": "201303"
  },
  {
    "date": "2013-03-01",
    "close": 7936.0,
    "volume": 44461,
    "contract": "201303"
  },
  {
    "date": "2013-03-04",
    "close": 7844.0,
    "volume": 94448,
    "contract": "201303"
  },
  {
    "date": "2013-03-05",
    "close": 7911.0,
    "volume": 74896,
    "contract": "201303"
  },
  {
    "date": "2013-03-06",
    "close": 7945.0,
    "volume": 83576,
    "contract": "201303"
  },
  {
    "date": "2013-03-07",
    "close": 7939.0,
    "volume": 72539,
    "contract": "201303"
  },
  {
    "date": "2013-03-08",
    "close": 8008.0,
    "volume": 81964,
    "contract": "201303"
  },
  {
    "date": "2013-03-11",
    "close": 8042.0,
    "volume": 79351,
    "contract": "201303"
  },
  {
    "date": "2013-03-12",
    "close": 7998.0,
    "volume": 75116,
    "contract": "201303"
  },
  {
    "date": "2013-03-13",
    "close": 7989.0,
    "volume": 106264,
    "contract": "201303"
  },
  {
    "date": "2013-03-14",
    "close": 7950.0,
    "volume": 80451,
    "contract": "201303"
  },
  {
    "date": "2013-03-15",
    "close": 7909.0,
    "volume": 108975,
    "contract": "201303"
  },
  {
    "date": "2013-03-18",
    "close": 7792.0,
    "volume": 102089,
    "contract": "201303"
  },
  {
    "date": "2013-03-19",
    "close": 7831.0,
    "volume": 76505,
    "contract": "201303"
  },
  {
    "date": "2013-03-20",
    "close": 7796.0,
    "volume": 52532,
    "contract": "201303"
  },
  {
    "date": "2013-03-21",
    "close": 7796.0,
    "volume": 68584,
    "contract": "201304"
  },
  {
    "date": "2013-03-22",
    "close": 7774.0,
    "volume": 63792,
    "contract": "201304"
  },
  {
    "date": "2013-03-25",
    "close": 7850.0,
    "volume": 60627,
    "contract": "201304"
  },
  {
    "date": "2013-03-26",
    "close": 7835.0,
    "volume": 52993,
    "contract": "201304"
  },
  {
    "date": "2013-03-27",
    "close": 7862.0,
    "volume": 74979,
    "contract": "201304"
  },
  {
    "date": "2013-03-28",
    "close": 7843.0,
    "volume": 64977,
    "contract": "201304"
  },
  {
    "date": "2013-03-29",
    "close": 7923.0,
    "volume": 73177,
    "contract": "201304"
  },
  {
    "date": "2013-04-01",
    "close": 7918.0,
    "volume": 45554,
    "contract": "201304"
  },
  {
    "date": "2013-04-02",
    "close": 7903.0,
    "volume": 80431,
    "contract": "201304"
  },
  {
    "date": "2013-04-03",
    "close": 7936.0,
    "volume": 67602,
    "contract": "201304"
  },
  {
    "date": "2013-04-08",
    "close": 7737.0,
    "volume": 128621,
    "contract": "201304"
  },
  {
    "date": "2013-04-09",
    "close": 7708.0,
    "volume": 84475,
    "contract": "201304"
  },
  {
    "date": "2013-04-10",
    "close": 7726.0,
    "volume": 59229,
    "contract": "201304"
  },
  {
    "date": "2013-04-11",
    "close": 7816.0,
    "volume": 84730,
    "contract": "201304"
  },
  {
    "date": "2013-04-12",
    "close": 7784.0,
    "volume": 64379,
    "contract": "201304"
  },
  {
    "date": "2013-04-15",
    "close": 7761.0,
    "volume": 109119,
    "contract": "201304"
  },
  {
    "date": "2013-04-16",
    "close": 7775.0,
    "volume": 118952,
    "contract": "201304"
  },
  {
    "date": "2013-04-17",
    "close": 7809.0,
    "volume": 57751,
    "contract": "201304"
  },
  {
    "date": "2013-04-18",
    "close": 7750.0,
    "volume": 104794,
    "contract": "201305"
  },
  {
    "date": "2013-04-19",
    "close": 7942.0,
    "volume": 139916,
    "contract": "201305"
  },
  {
    "date": "2013-04-22",
    "close": 7955.0,
    "volume": 64238,
    "contract": "201305"
  },
  {
    "date": "2013-04-23",
    "close": 7926.0,
    "volume": 79418,
    "contract": "201305"
  },
  {
    "date": "2013-04-24",
    "close": 7992.0,
    "volume": 110367,
    "contract": "201305"
  },
  {
    "date": "2013-04-25",
    "close": 8005.0,
    "volume": 71490,
    "contract": "201305"
  },
  {
    "date": "2013-04-26",
    "close": 7997.0,
    "volume": 94160,
    "contract": "201305"
  },
  {
    "date": "2013-04-29",
    "close": 8021.0,
    "volume": 62673,
    "contract": "201305"
  },
  {
    "date": "2013-04-30",
    "close": 8098.0,
    "volume": 79288,
    "contract": "201305"
  },
  {
    "date": "2013-05-02",
    "close": 8119.0,
    "volume": 63345,
    "contract": "201305"
  },
  {
    "date": "2013-05-03",
    "close": 8140.0,
    "volume": 82194,
    "contract": "201305"
  },
  {
    "date": "2013-05-06",
    "close": 8168.0,
    "volume": 67723,
    "contract": "201305"
  },
  {
    "date": "2013-05-07",
    "close": 8174.0,
    "volume": 61199,
    "contract": "201305"
  },
  {
    "date": "2013-05-08",
    "close": 8269.0,
    "volume": 130480,
    "contract": "201305"
  },
  {
    "date": "2013-05-09",
    "close": 8313.0,
    "volume": 83971,
    "contract": "201305"
  },
  {
    "date": "2013-05-10",
    "close": 8309.0,
    "volume": 65770,
    "contract": "201305"
  },
  {
    "date": "2013-05-13",
    "close": 8260.0,
    "volume": 100298,
    "contract": "201305"
  },
  {
    "date": "2013-05-14",
    "close": 8272.0,
    "volume": 98400,
    "contract": "201305"
  },
  {
    "date": "2013-05-15",
    "close": 8304.0,
    "volume": 61581,
    "contract": "201305"
  },
  {
    "date": "2013-05-16",
    "close": 8423.0,
    "volume": 122633,
    "contract": "201306"
  },
  {
    "date": "2013-05-17",
    "close": 8401.0,
    "volume": 60464,
    "contract": "201306"
  },
  {
    "date": "2013-05-20",
    "close": 8386.0,
    "volume": 74722,
    "contract": "201306"
  },
  {
    "date": "2013-05-21",
    "close": 8390.0,
    "volume": 102289,
    "contract": "201306"
  },
  {
    "date": "2013-05-22",
    "close": 8396.0,
    "volume": 82669,
    "contract": "201306"
  },
  {
    "date": "2013-05-23",
    "close": 8213.0,
    "volume": 140140,
    "contract": "201306"
  },
  {
    "date": "2013-05-24",
    "close": 8220.0,
    "volume": 102660,
    "contract": "201306"
  },
  {
    "date": "2013-05-27",
    "close": 8257.0,
    "volume": 86472,
    "contract": "201306"
  },
  {
    "date": "2013-05-28",
    "close": 8257.0,
    "volume": 69512,
    "contract": "201306"
  },
  {
    "date": "2013-05-29",
    "close": 8315.0,
    "volume": 106194,
    "contract": "201306"
  },
  {
    "date": "2013-05-30",
    "close": 8230.0,
    "volume": 121294,
    "contract": "201306"
  },
  {
    "date": "2013-05-31",
    "close": 8242.0,
    "volume": 125054,
    "contract": "201306"
  },
  {
    "date": "2013-06-03",
    "close": 8191.0,
    "volume": 107007,
    "contract": "201306"
  },
  {
    "date": "2013-06-04",
    "close": 8162.0,
    "volume": 92115,
    "contract": "201306"
  },
  {
    "date": "2013-06-05",
    "close": 8146.0,
    "volume": 90608,
    "contract": "201306"
  },
  {
    "date": "2013-06-06",
    "close": 8102.0,
    "volume": 116805,
    "contract": "201306"
  },
  {
    "date": "2013-06-07",
    "close": 8087.0,
    "volume": 99118,
    "contract": "201306"
  },
  {
    "date": "2013-06-10",
    "close": 8147.0,
    "volume": 88305,
    "contract": "201306"
  },
  {
    "date": "2013-06-11",
    "close": 8126.0,
    "volume": 78773,
    "contract": "201306"
  },
  {
    "date": "2013-06-13",
    "close": 7932.0,
    "volume": 127540,
    "contract": "201306"
  },
  {
    "date": "2013-06-14",
    "close": 7921.0,
    "volume": 91743,
    "contract": "201306"
  },
  {
    "date": "2013-06-17",
    "close": 7972.0,
    "volume": 80161,
    "contract": "201306"
  },
  {
    "date": "2013-06-18",
    "close": 7996.0,
    "volume": 108806,
    "contract": "201306"
  },
  {
    "date": "2013-06-19",
    "close": 8019.0,
    "volume": 60936,
    "contract": "201306"
  },
  {
    "date": "2013-06-20",
    "close": 7750.0,
    "volume": 107714,
    "contract": "201307"
  },
  {
    "date": "2013-06-21",
    "close": 7658.0,
    "volume": 124153,
    "contract": "201307"
  },
  {
    "date": "2013-06-24",
    "close": 7629.0,
    "volume": 91483,
    "contract": "201307"
  },
  {
    "date": "2013-06-25",
    "close": 7604.0,
    "volume": 158891,
    "contract": "201307"
  },
  {
    "date": "2013-06-26",
    "close": 7638.0,
    "volume": 121002,
    "contract": "201307"
  },
  {
    "date": "2013-06-27",
    "close": 7715.0,
    "volume": 92515,
    "contract": "201307"
  },
  {
    "date": "2013-06-28",
    "close": 7828.0,
    "volume": 121780,
    "contract": "201307"
  },
  {
    "date": "2013-07-01",
    "close": 7903.0,
    "volume": 101184,
    "contract": "201307"
  },
  {
    "date": "2013-07-02",
    "close": 7906.0,
    "volume": 69586,
    "contract": "201307"
  },
  {
    "date": "2013-07-03",
    "close": 7811.0,
    "volume": 99164,
    "contract": "201307"
  },
  {
    "date": "2013-07-04",
    "close": 7842.0,
    "volume": 90570,
    "contract": "201307"
  },
  {
    "date": "2013-07-05",
    "close": 7964.0,
    "volume": 109225,
    "contract": "201307"
  },
  {
    "date": "2013-07-08",
    "close": 7830.0,
    "volume": 117123,
    "contract": "201307"
  },
  {
    "date": "2013-07-09",
    "close": 7922.0,
    "volume": 116183,
    "contract": "201307"
  },
  {
    "date": "2013-07-10",
    "close": 7959.0,
    "volume": 133445,
    "contract": "201307"
  },
  {
    "date": "2013-07-11",
    "close": 8164.0,
    "volume": 117871,
    "contract": "201307"
  },
  {
    "date": "2013-07-12",
    "close": 8183.0,
    "volume": 64591,
    "contract": "201307"
  },
  {
    "date": "2013-07-15",
    "close": 8216.0,
    "volume": 110657,
    "contract": "201307"
  },
  {
    "date": "2013-07-16",
    "close": 8230.0,
    "volume": 77162,
    "contract": "201307"
  },
  {
    "date": "2013-07-17",
    "close": 8242.0,
    "volume": 49919,
    "contract": "201307"
  },
  {
    "date": "2013-07-18",
    "close": 8100.0,
    "volume": 99742,
    "contract": "201308"
  },
  {
    "date": "2013-07-19",
    "close": 7957.0,
    "volume": 130696,
    "contract": "201308"
  },
  {
    "date": "2013-07-22",
    "close": 8019.0,
    "volume": 85680,
    "contract": "201308"
  },
  {
    "date": "2013-07-23",
    "close": 8134.0,
    "volume": 115683,
    "contract": "201308"
  },
  {
    "date": "2013-07-24",
    "close": 8124.0,
    "volume": 77552,
    "contract": "201308"
  },
  {
    "date": "2013-07-25",
    "close": 8108.0,
    "volume": 101640,
    "contract": "201308"
  },
  {
    "date": "2013-07-26",
    "close": 8099.0,
    "volume": 107217,
    "contract": "201308"
  },
  {
    "date": "2013-07-29",
    "close": 8033.0,
    "volume": 99697,
    "contract": "201308"
  },
  {
    "date": "2013-07-30",
    "close": 8128.0,
    "volume": 97473,
    "contract": "201308"
  },
  {
    "date": "2013-07-31",
    "close": 8049.0,
    "volume": 89142,
    "contract": "201308"
  },
  {
    "date": "2013-08-01",
    "close": 8044.0,
    "volume": 96228,
    "contract": "201308"
  },
  {
    "date": "2013-08-02",
    "close": 8061.0,
    "volume": 115177,
    "contract": "201308"
  },
  {
    "date": "2013-08-05",
    "close": 8099.0,
    "volume": 88505,
    "contract": "201308"
  },
  {
    "date": "2013-08-06",
    "close": 7991.0,
    "volume": 106562,
    "contract": "201308"
  },
  {
    "date": "2013-08-07",
    "close": 7847.0,
    "volume": 98256,
    "contract": "201308"
  },
  {
    "date": "2013-08-08",
    "close": 7845.0,
    "volume": 77382,
    "contract": "201308"
  },
  {
    "date": "2013-08-09",
    "close": 7824.0,
    "volume": 118651,
    "contract": "201308"
  },
  {
    "date": "2013-08-12",
    "close": 7858.0,
    "volume": 75573,
    "contract": "201308"
  },
  {
    "date": "2013-08-13",
    "close": 7951.0,
    "volume": 88013,
    "contract": "201308"
  },
  {
    "date": "2013-08-14",
    "close": 7927.0,
    "volume": 86574,
    "contract": "201308"
  },
  {
    "date": "2013-08-15",
    "close": 7859.0,
    "volume": 90020,
    "contract": "201308"
  },
  {
    "date": "2013-08-16",
    "close": 7914.0,
    "volume": 135604,
    "contract": "201308"
  },
  {
    "date": "2013-08-19",
    "close": 7886.0,
    "volume": 76711,
    "contract": "201308"
  },
  {
    "date": "2013-08-20",
    "close": 7806.0,
    "volume": 122385,
    "contract": "201308"
  },
  {
    "date": "2013-08-22",
    "close": 7813.0,
    "volume": 60397,
    "contract": "201308"
  },
  {
    "date": "2013-08-23",
    "close": 7784.0,
    "volume": 87872,
    "contract": "201309"
  },
  {
    "date": "2013-08-26",
    "close": 7823.0,
    "volume": 77414,
    "contract": "201309"
  },
  {
    "date": "2013-08-27",
    "close": 7756.0,
    "volume": 84175,
    "contract": "201309"
  },
  {
    "date": "2013-08-28",
    "close": 7777.0,
    "volume": 108500,
    "contract": "201309"
  },
  {
    "date": "2013-08-29",
    "close": 7894.0,
    "volume": 106632,
    "contract": "201309"
  },
  {
    "date": "2013-08-30",
    "close": 7972.0,
    "volume": 101116,
    "contract": "201309"
  },
  {
    "date": "2013-09-02",
    "close": 8018.0,
    "volume": 87835,
    "contract": "201309"
  },
  {
    "date": "2013-09-03",
    "close": 8052.0,
    "volume": 83489,
    "contract": "201309"
  },
  {
    "date": "2013-09-04",
    "close": 8071.0,
    "volume": 88373,
    "contract": "201309"
  },
  {
    "date": "2013-09-05",
    "close": 8129.0,
    "volume": 98558,
    "contract": "201309"
  },
  {
    "date": "2013-09-06",
    "close": 8140.0,
    "volume": 61960,
    "contract": "201309"
  },
  {
    "date": "2013-09-09",
    "close": 8159.0,
    "volume": 100993,
    "contract": "201309"
  },
  {
    "date": "2013-09-10",
    "close": 8170.0,
    "volume": 101742,
    "contract": "201309"
  },
  {
    "date": "2013-09-11",
    "close": 8187.0,
    "volume": 110597,
    "contract": "201309"
  },
  {
    "date": "2013-09-12",
    "close": 8193.0,
    "volume": 90528,
    "contract": "201309"
  },
  {
    "date": "2013-09-13",
    "close": 8147.0,
    "volume": 71727,
    "contract": "201309"
  },
  {
    "date": "2013-09-14",
    "close": 8162.0,
    "volume": 32151,
    "contract": "201309"
  },
  {
    "date": "2013-09-16",
    "close": 8247.0,
    "volume": 81309,
    "contract": "201309"
  },
  {
    "date": "2013-09-17",
    "close": 8240.0,
    "volume": 61438,
    "contract": "201309"
  },
  {
    "date": "2013-09-18",
    "close": 8238.0,
    "volume": 44188,
    "contract": "201309"
  },
  {
    "date": "2013-09-23",
    "close": 8257.0,
    "volume": 72601,
    "contract": "201310"
  },
  {
    "date": "2013-09-24",
    "close": 8267.0,
    "volume": 72399,
    "contract": "201310"
  },
  {
    "date": "2013-09-25",
    "close": 8233.0,
    "volume": 69047,
    "contract": "201310"
  },
  {
    "date": "2013-09-26",
    "close": 8181.0,
    "volume": 89062,
    "contract": "201310"
  },
  {
    "date": "2013-09-27",
    "close": 8182.0,
    "volume": 53228,
    "contract": "201310"
  },
  {
    "date": "2013-09-30",
    "close": 8121.0,
    "volume": 96072,
    "contract": "201310"
  },
  {
    "date": "2013-10-01",
    "close": 8149.0,
    "volume": 72550,
    "contract": "201310"
  },
  {
    "date": "2013-10-02",
    "close": 8159.0,
    "volume": 66374,
    "contract": "201310"
  },
  {
    "date": "2013-10-03",
    "close": 8377.0,
    "volume": 121376,
    "contract": "201310"
  },
  {
    "date": "2013-10-04",
    "close": 8366.0,
    "volume": 76363,
    "contract": "201310"
  },
  {
    "date": "2013-10-07",
    "close": 8325.0,
    "volume": 68526,
    "contract": "201310"
  },
  {
    "date": "2013-10-08",
    "close": 8373.0,
    "volume": 86038,
    "contract": "201310"
  },
  {
    "date": "2013-10-09",
    "close": 8338.0,
    "volume": 72882,
    "contract": "201310"
  },
  {
    "date": "2013-10-11",
    "close": 8361.0,
    "volume": 95865,
    "contract": "201310"
  },
  {
    "date": "2013-10-14",
    "close": 8294.0,
    "volume": 94880,
    "contract": "201310"
  },
  {
    "date": "2013-10-15",
    "close": 8355.0,
    "volume": 86777,
    "contract": "201310"
  },
  {
    "date": "2013-10-16",
    "close": 8345.0,
    "volume": 36523,
    "contract": "201310"
  },
  {
    "date": "2013-10-17",
    "close": 8364.0,
    "volume": 76826,
    "contract": "201311"
  },
  {
    "date": "2013-10-18",
    "close": 8417.0,
    "volume": 71072,
    "contract": "201311"
  },
  {
    "date": "2013-10-21",
    "close": 8400.0,
    "volume": 59834,
    "contract": "201311"
  },
  {
    "date": "2013-10-22",
    "close": 8416.0,
    "volume": 75663,
    "contract": "201311"
  },
  {
    "date": "2013-10-23",
    "close": 8359.0,
    "volume": 95797,
    "contract": "201311"
  },
  {
    "date": "2013-10-24",
    "close": 8393.0,
    "volume": 78189,
    "contract": "201311"
  },
  {
    "date": "2013-10-25",
    "close": 8320.0,
    "volume": 98615,
    "contract": "201311"
  },
  {
    "date": "2013-10-28",
    "close": 8389.0,
    "volume": 73935,
    "contract": "201311"
  },
  {
    "date": "2013-10-29",
    "close": 8408.0,
    "volume": 98283,
    "contract": "201311"
  },
  {
    "date": "2013-10-30",
    "close": 8440.0,
    "volume": 75193,
    "contract": "201311"
  },
  {
    "date": "2013-10-31",
    "close": 8429.0,
    "volume": 77387,
    "contract": "201311"
  },
  {
    "date": "2013-11-01",
    "close": 8391.0,
    "volume": 101517,
    "contract": "201311"
  },
  {
    "date": "2013-11-04",
    "close": 8338.0,
    "volume": 81711,
    "contract": "201311"
  },
  {
    "date": "2013-11-05",
    "close": 8267.0,
    "volume": 99344,
    "contract": "201311"
  },
  {
    "date": "2013-11-06",
    "close": 8269.0,
    "volume": 86347,
    "contract": "201311"
  },
  {
    "date": "2013-11-07",
    "close": 8258.0,
    "volume": 74161,
    "contract": "201311"
  },
  {
    "date": "2013-11-08",
    "close": 8224.0,
    "volume": 77595,
    "contract": "201311"
  },
  {
    "date": "2013-11-11",
    "close": 8195.0,
    "volume": 74493,
    "contract": "201311"
  },
  {
    "date": "2013-11-12",
    "close": 8215.0,
    "volume": 83476,
    "contract": "201311"
  },
  {
    "date": "2013-11-13",
    "close": 8107.0,
    "volume": 90870,
    "contract": "201311"
  },
  {
    "date": "2013-11-14",
    "close": 8124.0,
    "volume": 85513,
    "contract": "201311"
  },
  {
    "date": "2013-11-15",
    "close": 8161.0,
    "volume": 93361,
    "contract": "201311"
  },
  {
    "date": "2013-11-18",
    "close": 8189.0,
    "volume": 76515,
    "contract": "201311"
  },
  {
    "date": "2013-11-19",
    "close": 8246.0,
    "volume": 81106,
    "contract": "201311"
  },
  {
    "date": "2013-11-20",
    "close": 8219.0,
    "volume": 36809,
    "contract": "201311"
  },
  {
    "date": "2013-11-21",
    "close": 8078.0,
    "volume": 96488,
    "contract": "201312"
  },
  {
    "date": "2013-11-22",
    "close": 8087.0,
    "volume": 55847,
    "contract": "201312"
  },
  {
    "date": "2013-11-25",
    "close": 8192.0,
    "volume": 77378,
    "contract": "201312"
  },
  {
    "date": "2013-11-26",
    "close": 8245.0,
    "volume": 100277,
    "contract": "201312"
  },
  {
    "date": "2013-11-27",
    "close": 8297.0,
    "volume": 73671,
    "contract": "201312"
  },
  {
    "date": "2013-11-28",
    "close": 8377.0,
    "volume": 73050,
    "contract": "201312"
  },
  {
    "date": "2013-11-29",
    "close": 8425.0,
    "volume": 65787,
    "contract": "201312"
  },
  {
    "date": "2013-12-02",
    "close": 8411.0,
    "volume": 73323,
    "contract": "201312"
  },
  {
    "date": "2013-12-03",
    "close": 8408.0,
    "volume": 65908,
    "contract": "201312"
  },
  {
    "date": "2013-12-04",
    "close": 8434.0,
    "volume": 93441,
    "contract": "201312"
  },
  {
    "date": "2013-12-05",
    "close": 8378.0,
    "volume": 100533,
    "contract": "201312"
  },
  {
    "date": "2013-12-06",
    "close": 8384.0,
    "volume": 77433,
    "contract": "201312"
  },
  {
    "date": "2013-12-09",
    "close": 8456.0,
    "volume": 76944,
    "contract": "201312"
  },
  {
    "date": "2013-12-10",
    "close": 8454.0,
    "volume": 55279,
    "contract": "201312"
  },
  {
    "date": "2013-12-11",
    "close": 8432.0,
    "volume": 110731,
    "contract": "201312"
  },
  {
    "date": "2013-12-12",
    "close": 8392.0,
    "volume": 85000,
    "contract": "201312"
  },
  {
    "date": "2013-12-13",
    "close": 8396.0,
    "volume": 78852,
    "contract": "201312"
  },
  {
    "date": "2013-12-16",
    "close": 8334.0,
    "volume": 95020,
    "contract": "201312"
  },
  {
    "date": "2013-12-17",
    "close": 8361.0,
    "volume": 57370,
    "contract": "201312"
  },
  {
    "date": "2013-12-18",
    "close": 8338.0,
    "volume": 31195,
    "contract": "201312"
  },
  {
    "date": "2013-12-19",
    "close": 8392.0,
    "volume": 83798,
    "contract": "201401"
  },
  {
    "date": "2013-12-20",
    "close": 8414.0,
    "volume": 63180,
    "contract": "201401"
  },
  {
    "date": "2013-12-23",
    "close": 8475.0,
    "volume": 53452,
    "contract": "201401"
  },
  {
    "date": "2013-12-24",
    "close": 8481.0,
    "volume": 34318,
    "contract": "201401"
  },
  {
    "date": "2013-12-25",
    "close": 8500.0,
    "volume": 28150,
    "contract": "201401"
  },
  {
    "date": "2013-12-26",
    "close": 8501.0,
    "volume": 30200,
    "contract": "201401"
  },
  {
    "date": "2013-12-27",
    "close": 8543.0,
    "volume": 56418,
    "contract": "201401"
  },
  {
    "date": "2013-12-30",
    "close": 8624.0,
    "volume": 70122,
    "contract": "201401"
  },
  {
    "date": "2013-12-31",
    "close": 8633.0,
    "volume": 51329,
    "contract": "201401"
  },
  {
    "date": "2014-01-02",
    "close": 8616.0,
    "volume": 70152,
    "contract": "201401"
  },
  {
    "date": "2014-01-03",
    "close": 8542.0,
    "volume": 82686,
    "contract": "201401"
  },
  {
    "date": "2014-01-06",
    "close": 8526.0,
    "volume": 81494,
    "contract": "201401"
  },
  {
    "date": "2014-01-07",
    "close": 8550.0,
    "volume": 76176,
    "contract": "201401"
  },
  {
    "date": "2014-01-08",
    "close": 8584.0,
    "volume": 69802,
    "contract": "201401"
  },
  {
    "date": "2014-01-09",
    "close": 8528.0,
    "volume": 99558,
    "contract": "201401"
  },
  {
    "date": "2014-01-10",
    "close": 8541.0,
    "volume": 63745,
    "contract": "201401"
  },
  {
    "date": "2014-01-13",
    "close": 8571.0,
    "volume": 95870,
    "contract": "201401"
  },
  {
    "date": "2014-01-14",
    "close": 8547.0,
    "volume": 73027,
    "contract": "201401"
  },
  {
    "date": "2014-01-15",
    "close": 8610.0,
    "volume": 52535,
    "contract": "201401"
  },
  {
    "date": "2014-01-16",
    "close": 8618.0,
    "volume": 65354,
    "contract": "201402"
  },
  {
    "date": "2014-01-17",
    "close": 8604.0,
    "volume": 76169,
    "contract": "201402"
  },
  {
    "date": "2014-01-20",
    "close": 8623.0,
    "volume": 69809,
    "contract": "201402"
  },
  {
    "date": "2014-01-21",
    "close": 8621.0,
    "volume": 65389,
    "contract": "201402"
  },
  {
    "date": "2014-01-22",
    "close": 8634.0,
    "volume": 61473,
    "contract": "201402"
  },
  {
    "date": "2014-01-23",
    "close": 8597.0,
    "volume": 77610,
    "contract": "201402"
  },
  {
    "date": "2014-01-24",
    "close": 8617.0,
    "volume": 76250,
    "contract": "201402"
  },
  {
    "date": "2014-01-27",
    "close": 8449.0,
    "volume": 124091,
    "contract": "201402"
  },
  {
    "date": "2014-02-05",
    "close": 8242.0,
    "volume": 123024,
    "contract": "201402"
  },
  {
    "date": "2014-02-06",
    "close": 8276.0,
    "volume": 81137,
    "contract": "201402"
  },
  {
    "date": "2014-02-07",
    "close": 8339.0,
    "volume": 84636,
    "contract": "201402"
  },
  {
    "date": "2014-02-10",
    "close": 8354.0,
    "volume": 75690,
    "contract": "201402"
  },
  {
    "date": "2014-02-11",
    "close": 8413.0,
    "volume": 69071,
    "contract": "201402"
  },
  {
    "date": "2014-02-12",
    "close": 8483.0,
    "volume": 84727,
    "contract": "201402"
  },
  {
    "date": "2014-02-13",
    "close": 8445.0,
    "volume": 60328,
    "contract": "201402"
  },
  {
    "date": "2014-02-14",
    "close": 8506.0,
    "volume": 108056,
    "contract": "201402"
  },
  {
    "date": "2014-02-17",
    "close": 8526.0,
    "volume": 68133,
    "contract": "201402"
  },
  {
    "date": "2014-02-18",
    "close": 8562.0,
    "volume": 74608,
    "contract": "201402"
  },
  {
    "date": "2014-02-19",
    "close": 8557.0,
    "volume": 33192,
    "contract": "201402"
  },
  {
    "date": "2014-02-20",
    "close": 8485.0,
    "volume": 104153,
    "contract": "201403"
  },
  {
    "date": "2014-02-21",
    "close": 8588.0,
    "volume": 70932,
    "contract": "201403"
  },
  {
    "date": "2014-02-24",
    "close": 8549.0,
    "volume": 73629,
    "contract": "201403"
  },
  {
    "date": "2014-02-25",
    "close": 8573.0,
    "volume": 59959,
    "contract": "201403"
  },
  {
    "date": "2014-02-26",
    "close": 8607.0,
    "volume": 78863,
    "contract": "201403"
  },
  {
    "date": "2014-02-27",
    "close": 8625.0,
    "volume": 62426,
    "contract": "201403"
  },
  {
    "date": "2014-03-03",
    "close": 8566.0,
    "volume": 102233,
    "contract": "201403"
  },
  {
    "date": "2014-03-04",
    "close": 8552.0,
    "volume": 68908,
    "contract": "201403"
  },
  {
    "date": "2014-03-05",
    "close": 8619.0,
    "volume": 59854,
    "contract": "201403"
  },
  {
    "date": "2014-03-06",
    "close": 8694.0,
    "volume": 87968,
    "contract": "201403"
  },
  {
    "date": "2014-03-07",
    "close": 8704.0,
    "volume": 104339,
    "contract": "201403"
  },
  {
    "date": "2014-03-10",
    "close": 8676.0,
    "volume": 69919,
    "contract": "201403"
  },
  {
    "date": "2014-03-11",
    "close": 8713.0,
    "volume": 67391,
    "contract": "201403"
  },
  {
    "date": "2014-03-12",
    "close": 8659.0,
    "volume": 73277,
    "contract": "201403"
  },
  {
    "date": "2014-03-13",
    "close": 8742.0,
    "volume": 84582,
    "contract": "201403"
  },
  {
    "date": "2014-03-14",
    "close": 8692.0,
    "volume": 58515,
    "contract": "201403"
  },
  {
    "date": "2014-03-17",
    "close": 8699.0,
    "volume": 77365,
    "contract": "201403"
  },
  {
    "date": "2014-03-18",
    "close": 8728.0,
    "volume": 65644,
    "contract": "201403"
  },
  {
    "date": "2014-03-19",
    "close": 8696.0,
    "volume": 47587,
    "contract": "201403"
  },
  {
    "date": "2014-03-20",
    "close": 8568.0,
    "volume": 95027,
    "contract": "201404"
  },
  {
    "date": "2014-03-21",
    "close": 8573.0,
    "volume": 66251,
    "contract": "201404"
  },
  {
    "date": "2014-03-24",
    "close": 8601.0,
    "volume": 99699,
    "contract": "201404"
  },
  {
    "date": "2014-03-25",
    "close": 8658.0,
    "volume": 91751,
    "contract": "201404"
  },
  {
    "date": "2014-03-26",
    "close": 8712.0,
    "volume": 77869,
    "contract": "201404"
  },
  {
    "date": "2014-03-27",
    "close": 8754.0,
    "volume": 86325,
    "contract": "201404"
  },
  {
    "date": "2014-03-28",
    "close": 8736.0,
    "volume": 78831,
    "contract": "201404"
  },
  {
    "date": "2014-03-31",
    "close": 8790.0,
    "volume": 76765,
    "contract": "201404"
  },
  {
    "date": "2014-04-01",
    "close": 8828.0,
    "volume": 77021,
    "contract": "201404"
  },
  {
    "date": "2014-04-02",
    "close": 8855.0,
    "volume": 73667,
    "contract": "201404"
  },
  {
    "date": "2014-04-03",
    "close": 8867.0,
    "volume": 58189,
    "contract": "201404"
  },
  {
    "date": "2014-04-07",
    "close": 8858.0,
    "volume": 63927,
    "contract": "201404"
  },
  {
    "date": "2014-04-08",
    "close": 8877.0,
    "volume": 79196,
    "contract": "201404"
  },
  {
    "date": "2014-04-09",
    "close": 8896.0,
    "volume": 52603,
    "contract": "201404"
  },
  {
    "date": "2014-04-10",
    "close": 8907.0,
    "volume": 86825,
    "contract": "201404"
  },
  {
    "date": "2014-04-11",
    "close": 8869.0,
    "volume": 95782,
    "contract": "201404"
  },
  {
    "date": "2014-04-14",
    "close": 8856.0,
    "volume": 65746,
    "contract": "201404"
  },
  {
    "date": "2014-04-15",
    "close": 8896.0,
    "volume": 72126,
    "contract": "201404"
  },
  {
    "date": "2014-04-16",
    "close": 8955.0,
    "volume": 49182,
    "contract": "201404"
  },
  {
    "date": "2014-04-17",
    "close": 8895.0,
    "volume": 77255,
    "contract": "201405"
  },
  {
    "date": "2014-04-18",
    "close": 8917.0,
    "volume": 63285,
    "contract": "201405"
  },
  {
    "date": "2014-04-21",
    "close": 8922.0,
    "volume": 36842,
    "contract": "201405"
  },
  {
    "date": "2014-04-22",
    "close": 8950.0,
    "volume": 60169,
    "contract": "201405"
  },
  {
    "date": "2014-04-23",
    "close": 8922.0,
    "volume": 80288,
    "contract": "201405"
  },
  {
    "date": "2014-04-24",
    "close": 8935.0,
    "volume": 54152,
    "contract": "201405"
  },
  {
    "date": "2014-04-25",
    "close": 8750.0,
    "volume": 174633,
    "contract": "201405"
  },
  {
    "date": "2014-04-28",
    "close": 8818.0,
    "volume": 129874,
    "contract": "201405"
  },
  {
    "date": "2014-04-29",
    "close": 8838.0,
    "volume": 91179,
    "contract": "201405"
  },
  {
    "date": "2014-04-30",
    "close": 8755.0,
    "volume": 122688,
    "contract": "201405"
  },
  {
    "date": "2014-05-02",
    "close": 8840.0,
    "volume": 90635,
    "contract": "201405"
  },
  {
    "date": "2014-05-05",
    "close": 8828.0,
    "volume": 94208,
    "contract": "201405"
  },
  {
    "date": "2014-05-06",
    "close": 8881.0,
    "volume": 97864,
    "contract": "201405"
  },
  {
    "date": "2014-05-07",
    "close": 8839.0,
    "volume": 104464,
    "contract": "201405"
  },
  {
    "date": "2014-05-08",
    "close": 8880.0,
    "volume": 88751,
    "contract": "201405"
  },
  {
    "date": "2014-05-09",
    "close": 8842.0,
    "volume": 77008,
    "contract": "201405"
  },
  {
    "date": "2014-05-12",
    "close": 8821.0,
    "volume": 88270,
    "contract": "201405"
  },
  {
    "date": "2014-05-13",
    "close": 8829.0,
    "volume": 83445,
    "contract": "201405"
  },
  {
    "date": "2014-05-14",
    "close": 8883.0,
    "volume": 85759,
    "contract": "201405"
  },
  {
    "date": "2014-05-15",
    "close": 8877.0,
    "volume": 59657,
    "contract": "201405"
  },
  {
    "date": "2014-05-16",
    "close": 8876.0,
    "volume": 88877,
    "contract": "201405"
  },
  {
    "date": "2014-05-19",
    "close": 8887.0,
    "volume": 70962,
    "contract": "201405"
  },
  {
    "date": "2014-05-20",
    "close": 8896.0,
    "volume": 74046,
    "contract": "201405"
  },
  {
    "date": "2014-05-21",
    "close": 8860.0,
    "volume": 54036,
    "contract": "201405"
  },
  {
    "date": "2014-05-22",
    "close": 8957.0,
    "volume": 100620,
    "contract": "201406"
  },
  {
    "date": "2014-05-23",
    "close": 9011.0,
    "volume": 75182,
    "contract": "201406"
  },
  {
    "date": "2014-05-26",
    "close": 9040.0,
    "volume": 51900,
    "contract": "201406"
  },
  {
    "date": "2014-05-27",
    "close": 9056.0,
    "volume": 52031,
    "contract": "201406"
  },
  {
    "date": "2014-05-28",
    "close": 9135.0,
    "volume": 94218,
    "contract": "201406"
  },
  {
    "date": "2014-05-29",
    "close": 9114.0,
    "volume": 69424,
    "contract": "201406"
  },
  {
    "date": "2014-05-30",
    "close": 9089.0,
    "volume": 76393,
    "contract": "201406"
  },
  {
    "date": "2014-06-03",
    "close": 9106.0,
    "volume": 83254,
    "contract": "201406"
  },
  {
    "date": "2014-06-04",
    "close": 9102.0,
    "volume": 53898,
    "contract": "201406"
  },
  {
    "date": "2014-06-05",
    "close": 9116.0,
    "volume": 67500,
    "contract": "201406"
  },
  {
    "date": "2014-06-06",
    "close": 9125.0,
    "volume": 59766,
    "contract": "201406"
  },
  {
    "date": "2014-06-09",
    "close": 9144.0,
    "volume": 45298,
    "contract": "201406"
  },
  {
    "date": "2014-06-10",
    "close": 9185.0,
    "volume": 72200,
    "contract": "201406"
  },
  {
    "date": "2014-06-11",
    "close": 9210.0,
    "volume": 43499,
    "contract": "201406"
  },
  {
    "date": "2014-06-12",
    "close": 9202.0,
    "volume": 46433,
    "contract": "201406"
  },
  {
    "date": "2014-06-13",
    "close": 9195.0,
    "volume": 69155,
    "contract": "201406"
  },
  {
    "date": "2014-06-16",
    "close": 9200.0,
    "volume": 54947,
    "contract": "201406"
  },
  {
    "date": "2014-06-17",
    "close": 9242.0,
    "volume": 66123,
    "contract": "201406"
  },
  {
    "date": "2014-06-18",
    "close": 9302.0,
    "volume": 64896,
    "contract": "201406"
  },
  {
    "date": "2014-06-19",
    "close": 9226.0,
    "volume": 74612,
    "contract": "201407"
  },
  {
    "date": "2014-06-20",
    "close": 9179.0,
    "volume": 74727,
    "contract": "201407"
  },
  {
    "date": "2014-06-23",
    "close": 9167.0,
    "volume": 82798,
    "contract": "201407"
  },
  {
    "date": "2014-06-24",
    "close": 9173.0,
    "volume": 65966,
    "contract": "201407"
  },
  {
    "date": "2014-06-25",
    "close": 9156.0,
    "volume": 63400,
    "contract": "201407"
  },
  {
    "date": "2014-06-26",
    "close": 9230.0,
    "volume": 75765,
    "contract": "201407"
  },
  {
    "date": "2014-06-27",
    "close": 9206.0,
    "volume": 58349,
    "contract": "201407"
  },
  {
    "date": "2014-06-30",
    "close": 9290.0,
    "volume": 77543,
    "contract": "201407"
  },
  {
    "date": "2014-07-01",
    "close": 9380.0,
    "volume": 101041,
    "contract": "201407"
  },
  {
    "date": "2014-07-02",
    "close": 9400.0,
    "volume": 178185,
    "contract": "201407"
  },
  {
    "date": "2014-07-03",
    "close": 9455.0,
    "volume": 111701,
    "contract": "201407"
  },
  {
    "date": "2014-07-04",
    "close": 9453.0,
    "volume": 105559,
    "contract": "201407"
  },
  {
    "date": "2014-07-07",
    "close": 9451.0,
    "volume": 86345,
    "contract": "201407"
  },
  {
    "date": "2014-07-08",
    "close": 9477.0,
    "volume": 82334,
    "contract": "201407"
  },
  {
    "date": "2014-07-09",
    "close": 9463.0,
    "volume": 77026,
    "contract": "201407"
  },
  {
    "date": "2014-07-10",
    "close": 9553.0,
    "volume": 100623,
    "contract": "201407"
  },
  {
    "date": "2014-07-11",
    "close": 9486.0,
    "volume": 157882,
    "contract": "201407"
  },
  {
    "date": "2014-07-14",
    "close": 9523.0,
    "volume": 85979,
    "contract": "201407"
  },
  {
    "date": "2014-07-15",
    "close": 9560.0,
    "volume": 92920,
    "contract": "201407"
  },
  {
    "date": "2014-07-16",
    "close": 9483.0,
    "volume": 67424,
    "contract": "201407"
  },
  {
    "date": "2014-07-17",
    "close": 9357.0,
    "volume": 123718,
    "contract": "201408"
  },
  {
    "date": "2014-07-18",
    "close": 9339.0,
    "volume": 107971,
    "contract": "201408"
  },
  {
    "date": "2014-07-21",
    "close": 9365.0,
    "volume": 78887,
    "contract": "201408"
  },
  {
    "date": "2014-07-22",
    "close": 9431.0,
    "volume": 100000,
    "contract": "201408"
  },
  {
    "date": "2014-07-24",
    "close": 9468.0,
    "volume": 86204,
    "contract": "201408"
  },
  {
    "date": "2014-07-25",
    "close": 9390.0,
    "volume": 118354,
    "contract": "201408"
  },
  {
    "date": "2014-07-28",
    "close": 9386.0,
    "volume": 113816,
    "contract": "201408"
  },
  {
    "date": "2014-07-29",
    "close": 9360.0,
    "volume": 128049,
    "contract": "201408"
  },
  {
    "date": "2014-07-30",
    "close": 9414.0,
    "volume": 99330,
    "contract": "201408"
  },
  {
    "date": "2014-07-31",
    "close": 9290.0,
    "volume": 134333,
    "contract": "201408"
  },
  {
    "date": "2014-08-01",
    "close": 9251.0,
    "volume": 104509,
    "contract": "201408"
  },
  {
    "date": "2014-08-04",
    "close": 9285.0,
    "volume": 81817,
    "contract": "201408"
  },
  {
    "date": "2014-08-05",
    "close": 9097.0,
    "volume": 149588,
    "contract": "201408"
  },
  {
    "date": "2014-08-06",
    "close": 9097.0,
    "volume": 121642,
    "contract": "201408"
  },
  {
    "date": "2014-08-07",
    "close": 9093.0,
    "volume": 84268,
    "contract": "201408"
  },
  {
    "date": "2014-08-08",
    "close": 9090.0,
    "volume": 123219,
    "contract": "201408"
  },
  {
    "date": "2014-08-11",
    "close": 9139.0,
    "volume": 80134,
    "contract": "201408"
  },
  {
    "date": "2014-08-12",
    "close": 9122.0,
    "volume": 87612,
    "contract": "201408"
  },
  {
    "date": "2014-08-13",
    "close": 9199.0,
    "volume": 94649,
    "contract": "201408"
  },
  {
    "date": "2014-08-14",
    "close": 9219.0,
    "volume": 85033,
    "contract": "201408"
  },
  {
    "date": "2014-08-15",
    "close": 9202.0,
    "volume": 90406,
    "contract": "201408"
  },
  {
    "date": "2014-08-18",
    "close": 9140.0,
    "volume": 111283,
    "contract": "201408"
  },
  {
    "date": "2014-08-19",
    "close": 9237.0,
    "volume": 91282,
    "contract": "201408"
  },
  {
    "date": "2014-08-20",
    "close": 9275.0,
    "volume": 61787,
    "contract": "201408"
  },
  {
    "date": "2014-08-21",
    "close": 9230.0,
    "volume": 103529,
    "contract": "201409"
  },
  {
    "date": "2014-08-22",
    "close": 9378.0,
    "volume": 116443,
    "contract": "201409"
  },
  {
    "date": "2014-08-25",
    "close": 9391.0,
    "volume": 61977,
    "contract": "201409"
  },
  {
    "date": "2014-08-26",
    "close": 9390.0,
    "volume": 57561,
    "contract": "201409"
  },
  {
    "date": "2014-08-27",
    "close": 9477.0,
    "volume": 96315,
    "contract": "201409"
  },
  {
    "date": "2014-08-28",
    "close": 9478.0,
    "volume": 60649,
    "contract": "201409"
  },
  {
    "date": "2014-08-29",
    "close": 9471.0,
    "volume": 77443,
    "contract": "201409"
  },
  {
    "date": "2014-09-01",
    "close": 9528.0,
    "volume": 68798,
    "contract": "201409"
  },
  {
    "date": "2014-09-02",
    "close": 9409.0,
    "volume": 125697,
    "contract": "201409"
  },
  {
    "date": "2014-09-03",
    "close": 9449.0,
    "volume": 101507,
    "contract": "201409"
  },
  {
    "date": "2014-09-04",
    "close": 9424.0,
    "volume": 96821,
    "contract": "201409"
  },
  {
    "date": "2014-09-05",
    "close": 9406.0,
    "volume": 104786,
    "contract": "201409"
  },
  {
    "date": "2014-09-09",
    "close": 9429.0,
    "volume": 78139,
    "contract": "201409"
  },
  {
    "date": "2014-09-10",
    "close": 9347.0,
    "volume": 106510,
    "contract": "201409"
  },
  {
    "date": "2014-09-11",
    "close": 9301.0,
    "volume": 75048,
    "contract": "201409"
  },
  {
    "date": "2014-09-12",
    "close": 9246.0,
    "volume": 121575,
    "contract": "201409"
  },
  {
    "date": "2014-09-15",
    "close": 9219.0,
    "volume": 119266,
    "contract": "201409"
  },
  {
    "date": "2014-09-16",
    "close": 9153.0,
    "volume": 98071,
    "contract": "201409"
  },
  {
    "date": "2014-09-17",
    "close": 9172.0,
    "volume": 72499,
    "contract": "201409"
  },
  {
    "date": "2014-09-18",
    "close": 9241.0,
    "volume": 90173,
    "contract": "201410"
  },
  {
    "date": "2014-09-19",
    "close": 9263.0,
    "volume": 101134,
    "contract": "201410"
  },
  {
    "date": "2014-09-22",
    "close": 9128.0,
    "volume": 120832,
    "contract": "201410"
  },
  {
    "date": "2014-09-23",
    "close": 9114.0,
    "volume": 87165,
    "contract": "201410"
  },
  {
    "date": "2014-09-24",
    "close": 9126.0,
    "volume": 87035,
    "contract": "201410"
  },
  {
    "date": "2014-09-25",
    "close": 9026.0,
    "volume": 138558,
    "contract": "201410"
  },
  {
    "date": "2014-09-26",
    "close": 8982.0,
    "volume": 115750,
    "contract": "201410"
  },
  {
    "date": "2014-09-29",
    "close": 8981.0,
    "volume": 101474,
    "contract": "201410"
  },
  {
    "date": "2014-09-30",
    "close": 8991.0,
    "volume": 150107,
    "contract": "201410"
  },
  {
    "date": "2014-10-01",
    "close": 8980.0,
    "volume": 114235,
    "contract": "201410"
  },
  {
    "date": "2014-10-02",
    "close": 8992.0,
    "volume": 126762,
    "contract": "201410"
  },
  {
    "date": "2014-10-03",
    "close": 9098.0,
    "volume": 124812,
    "contract": "201410"
  },
  {
    "date": "2014-10-06",
    "close": 9085.0,
    "volume": 95157,
    "contract": "201410"
  },
  {
    "date": "2014-10-07",
    "close": 9018.0,
    "volume": 127569,
    "contract": "201410"
  },
  {
    "date": "2014-10-08",
    "close": 8932.0,
    "volume": 103779,
    "contract": "201410"
  },
  {
    "date": "2014-10-09",
    "close": 8980.0,
    "volume": 139674,
    "contract": "201410"
  },
  {
    "date": "2014-10-13",
    "close": 8712.0,
    "volume": 157956,
    "contract": "201410"
  },
  {
    "date": "2014-10-14",
    "close": 8743.0,
    "volume": 104866,
    "contract": "201410"
  },
  {
    "date": "2014-10-15",
    "close": 8646.0,
    "volume": 82391,
    "contract": "201410"
  },
  {
    "date": "2014-10-16",
    "close": 8628.0,
    "volume": 177584,
    "contract": "201411"
  },
  {
    "date": "2014-10-17",
    "close": 8499.0,
    "volume": 174947,
    "contract": "201411"
  },
  {
    "date": "2014-10-20",
    "close": 8660.0,
    "volume": 121860,
    "contract": "201411"
  },
  {
    "date": "2014-10-21",
    "close": 8639.0,
    "volume": 90638,
    "contract": "201411"
  },
  {
    "date": "2014-10-22",
    "close": 8744.0,
    "volume": 96753,
    "contract": "201411"
  },
  {
    "date": "2014-10-23",
    "close": 8722.0,
    "volume": 79233,
    "contract": "201411"
  },
  {
    "date": "2014-10-24",
    "close": 8641.0,
    "volume": 133051,
    "contract": "201411"
  },
  {
    "date": "2014-10-27",
    "close": 8643.0,
    "volume": 108102,
    "contract": "201411"
  },
  {
    "date": "2014-10-28",
    "close": 8792.0,
    "volume": 127091,
    "contract": "201411"
  },
  {
    "date": "2014-10-29",
    "close": 8879.0,
    "volume": 106490,
    "contract": "201411"
  },
  {
    "date": "2014-10-30",
    "close": 8879.0,
    "volume": 95556,
    "contract": "201411"
  },
  {
    "date": "2014-10-31",
    "close": 8975.0,
    "volume": 137623,
    "contract": "201411"
  },
  {
    "date": "2014-11-03",
    "close": 8981.0,
    "volume": 117415,
    "contract": "201411"
  },
  {
    "date": "2014-11-04",
    "close": 8991.0,
    "volume": 140218,
    "contract": "201411"
  },
  {
    "date": "2014-11-05",
    "close": 8985.0,
    "volume": 111110,
    "contract": "201411"
  },
  {
    "date": "2014-11-06",
    "close": 8903.0,
    "volume": 129127,
    "contract": "201411"
  },
  {
    "date": "2014-11-07",
    "close": 8937.0,
    "volume": 117608,
    "contract": "201411"
  },
  {
    "date": "2014-11-10",
    "close": 9073.0,
    "volume": 120952,
    "contract": "201411"
  },
  {
    "date": "2014-11-11",
    "close": 9061.0,
    "volume": 91460,
    "contract": "201411"
  },
  {
    "date": "2014-11-12",
    "close": 8905.0,
    "volume": 141490,
    "contract": "201411"
  },
  {
    "date": "2014-11-13",
    "close": 8960.0,
    "volume": 112842,
    "contract": "201411"
  },
  {
    "date": "2014-11-14",
    "close": 8962.0,
    "volume": 109824,
    "contract": "201411"
  },
  {
    "date": "2014-11-17",
    "close": 8899.0,
    "volume": 156670,
    "contract": "201411"
  },
  {
    "date": "2014-11-18",
    "close": 8873.0,
    "volume": 124772,
    "contract": "201411"
  },
  {
    "date": "2014-11-19",
    "close": 8953.0,
    "volume": 73761,
    "contract": "201411"
  },
  {
    "date": "2014-11-20",
    "close": 9091.0,
    "volume": 113333,
    "contract": "201412"
  },
  {
    "date": "2014-11-21",
    "close": 9103.0,
    "volume": 83395,
    "contract": "201412"
  },
  {
    "date": "2014-11-24",
    "close": 9130.0,
    "volume": 77972,
    "contract": "201412"
  },
  {
    "date": "2014-11-25",
    "close": 9108.0,
    "volume": 101177,
    "contract": "201412"
  },
  {
    "date": "2014-11-26",
    "close": 9120.0,
    "volume": 73155,
    "contract": "201412"
  },
  {
    "date": "2014-11-27",
    "close": 9175.0,
    "volume": 109702,
    "contract": "201412"
  },
  {
    "date": "2014-11-28",
    "close": 9179.0,
    "volume": 57835,
    "contract": "201412"
  },
  {
    "date": "2014-12-01",
    "close": 9119.0,
    "volume": 158276,
    "contract": "201412"
  },
  {
    "date": "2014-12-02",
    "close": 9030.0,
    "volume": 145718,
    "contract": "201412"
  },
  {
    "date": "2014-12-03",
    "close": 9209.0,
    "volume": 149036,
    "contract": "201412"
  },
  {
    "date": "2014-12-04",
    "close": 9220.0,
    "volume": 97499,
    "contract": "201412"
  },
  {
    "date": "2014-12-05",
    "close": 9214.0,
    "volume": 87093,
    "contract": "201412"
  },
  {
    "date": "2014-12-08",
    "close": 9186.0,
    "volume": 105218,
    "contract": "201412"
  },
  {
    "date": "2014-12-09",
    "close": 9131.0,
    "volume": 92634,
    "contract": "201412"
  },
  {
    "date": "2014-12-10",
    "close": 9046.0,
    "volume": 165103,
    "contract": "201412"
  },
  {
    "date": "2014-12-11",
    "close": 9009.0,
    "volume": 116039,
    "contract": "201412"
  },
  {
    "date": "2014-12-12",
    "close": 9005.0,
    "volume": 98839,
    "contract": "201412"
  },
  {
    "date": "2014-12-15",
    "close": 9033.0,
    "volume": 125072,
    "contract": "201412"
  },
  {
    "date": "2014-12-16",
    "close": 8979.0,
    "volume": 122633,
    "contract": "201412"
  },
  {
    "date": "2014-12-17",
    "close": 8844.0,
    "volume": 81915,
    "contract": "201412"
  },
  {
    "date": "2014-12-18",
    "close": 8858.0,
    "volume": 101962,
    "contract": "201501"
  },
  {
    "date": "2014-12-19",
    "close": 9017.0,
    "volume": 148633,
    "contract": "201501"
  },
  {
    "date": "2014-12-22",
    "close": 9094.0,
    "volume": 102111,
    "contract": "201501"
  },
  {
    "date": "2014-12-23",
    "close": 9114.0,
    "volume": 69691,
    "contract": "201501"
  },
  {
    "date": "2014-12-24",
    "close": 9176.0,
    "volume": 93125,
    "contract": "201501"
  },
  {
    "date": "2014-12-25",
    "close": 9181.0,
    "volume": 44950,
    "contract": "201501"
  },
  {
    "date": "2014-12-26",
    "close": 9227.0,
    "volume": 73031,
    "contract": "201501"
  },
  {
    "date": "2014-12-27",
    "close": 9255.0,
    "volume": 27720,
    "contract": "201501"
  },
  {
    "date": "2014-12-29",
    "close": 9309.0,
    "volume": 98576,
    "contract": "201501"
  },
  {
    "date": "2014-12-30",
    "close": 9286.0,
    "volume": 92786,
    "contract": "201501"
  },
  {
    "date": "2014-12-31",
    "close": 9281.0,
    "volume": 75117,
    "contract": "201501"
  },
  {
    "date": "2015-01-05",
    "close": 9250.0,
    "volume": 120487,
    "contract": "201501"
  },
  {
    "date": "2015-01-06",
    "close": 9058.0,
    "volume": 148125,
    "contract": "201501"
  },
  {
    "date": "2015-01-07",
    "close": 9044.0,
    "volume": 93314,
    "contract": "201501"
  },
  {
    "date": "2015-01-08",
    "close": 9256.0,
    "volume": 131883,
    "contract": "201501"
  },
  {
    "date": "2015-01-09",
    "close": 9230.0,
    "volume": 117874,
    "contract": "201501"
  },
  {
    "date": "2015-01-12",
    "close": 9185.0,
    "volume": 97827,
    "contract": "201501"
  },
  {
    "date": "2015-01-13",
    "close": 9250.0,
    "volume": 127705,
    "contract": "201501"
  },
  {
    "date": "2015-01-14",
    "close": 9170.0,
    "volume": 122662,
    "contract": "201501"
  },
  {
    "date": "2015-01-15",
    "close": 9194.0,
    "volume": 116348,
    "contract": "201501"
  },
  {
    "date": "2015-01-16",
    "close": 9115.0,
    "volume": 160290,
    "contract": "201501"
  },
  {
    "date": "2015-01-19",
    "close": 9181.0,
    "volume": 134142,
    "contract": "201501"
  },
  {
    "date": "2015-01-20",
    "close": 9267.0,
    "volume": 121592,
    "contract": "201501"
  },
  {
    "date": "2015-01-21",
    "close": 9308.0,
    "volume": 64253,
    "contract": "201501"
  },
  {
    "date": "2015-01-22",
    "close": 9388.0,
    "volume": 108180,
    "contract": "201502"
  },
  {
    "date": "2015-01-23",
    "close": 9461.0,
    "volume": 92808,
    "contract": "201502"
  },
  {
    "date": "2015-01-26",
    "close": 9465.0,
    "volume": 68310,
    "contract": "201502"
  },
  {
    "date": "2015-01-27",
    "close": 9523.0,
    "volume": 90397,
    "contract": "201502"
  },
  {
    "date": "2015-01-28",
    "close": 9527.0,
    "volume": 75013,
    "contract": "201502"
  },
  {
    "date": "2015-01-29",
    "close": 9428.0,
    "volume": 116368,
    "contract": "201502"
  },
  {
    "date": "2015-01-30",
    "close": 9398.0,
    "volume": 97244,
    "contract": "201502"
  },
  {
    "date": "2015-02-02",
    "close": 9420.0,
    "volume": 85483,
    "contract": "201502"
  },
  {
    "date": "2015-02-03",
    "close": 9464.0,
    "volume": 95115,
    "contract": "201502"
  },
  {
    "date": "2015-02-04",
    "close": 9522.0,
    "volume": 86781,
    "contract": "201502"
  },
  {
    "date": "2015-02-05",
    "close": 9513.0,
    "volume": 79030,
    "contract": "201502"
  },
  {
    "date": "2015-02-06",
    "close": 9470.0,
    "volume": 96048,
    "contract": "201502"
  },
  {
    "date": "2015-02-09",
    "close": 9451.0,
    "volume": 78599,
    "contract": "201502"
  },
  {
    "date": "2015-02-10",
    "close": 9432.0,
    "volume": 86724,
    "contract": "201502"
  },
  {
    "date": "2015-02-11",
    "close": 9476.0,
    "volume": 88756,
    "contract": "201502"
  },
  {
    "date": "2015-02-12",
    "close": 9482.0,
    "volume": 80128,
    "contract": "201502"
  },
  {
    "date": "2015-02-13",
    "close": 9514.0,
    "volume": 85659,
    "contract": "201502"
  },
  {
    "date": "2015-02-24",
    "close": 9622.0,
    "volume": 46780,
    "contract": "201502"
  },
  {
    "date": "2015-02-25",
    "close": 9683.0,
    "volume": 66977,
    "contract": "201503"
  },
  {
    "date": "2015-02-26",
    "close": 9648.0,
    "volume": 72451,
    "contract": "201503"
  },
  {
    "date": "2015-03-02",
    "close": 9631.0,
    "volume": 77036,
    "contract": "201503"
  },
  {
    "date": "2015-03-03",
    "close": 9614.0,
    "volume": 88385,
    "contract": "201503"
  },
  {
    "date": "2015-03-04",
    "close": 9620.0,
    "volume": 73997,
    "contract": "201503"
  },
  {
    "date": "2015-03-05",
    "close": 9586.0,
    "volume": 94585,
    "contract": "201503"
  },
  {
    "date": "2015-03-06",
    "close": 9637.0,
    "volume": 87662,
    "contract": "201503"
  },
  {
    "date": "2015-03-09",
    "close": 9574.0,
    "volume": 89409,
    "contract": "201503"
  },
  {
    "date": "2015-03-10",
    "close": 9529.0,
    "volume": 103983,
    "contract": "201503"
  },
  {
    "date": "2015-03-11",
    "close": 9519.0,
    "volume": 103946,
    "contract": "201503"
  },
  {
    "date": "2015-03-12",
    "close": 9607.0,
    "volume": 101568,
    "contract": "201503"
  },
  {
    "date": "2015-03-13",
    "close": 9598.0,
    "volume": 82971,
    "contract": "201503"
  },
  {
    "date": "2015-03-16",
    "close": 9543.0,
    "volume": 100282,
    "contract": "201503"
  },
  {
    "date": "2015-03-17",
    "close": 9556.0,
    "volume": 123433,
    "contract": "201503"
  },
  {
    "date": "2015-03-18",
    "close": 9633.0,
    "volume": 67737,
    "contract": "201503"
  },
  {
    "date": "2015-03-19",
    "close": 9765.0,
    "volume": 100024,
    "contract": "201504"
  },
  {
    "date": "2015-03-20",
    "close": 9757.0,
    "volume": 66890,
    "contract": "201504"
  },
  {
    "date": "2015-03-23",
    "close": 9749.0,
    "volume": 75804,
    "contract": "201504"
  },
  {
    "date": "2015-03-24",
    "close": 9720.0,
    "volume": 89879,
    "contract": "201504"
  },
  {
    "date": "2015-03-25",
    "close": 9688.0,
    "volume": 95109,
    "contract": "201504"
  },
  {
    "date": "2015-03-26",
    "close": 9611.0,
    "volume": 110206,
    "contract": "201504"
  },
  {
    "date": "2015-03-27",
    "close": 9542.0,
    "volume": 126327,
    "contract": "201504"
  },
  {
    "date": "2015-03-30",
    "close": 9553.0,
    "volume": 83437,
    "contract": "201504"
  },
  {
    "date": "2015-03-31",
    "close": 9582.0,
    "volume": 98624,
    "contract": "201504"
  },
  {
    "date": "2015-04-01",
    "close": 9508.0,
    "volume": 111444,
    "contract": "201504"
  },
  {
    "date": "2015-04-02",
    "close": 9614.0,
    "volume": 114119,
    "contract": "201504"
  },
  {
    "date": "2015-04-07",
    "close": 9629.0,
    "volume": 72558,
    "contract": "201504"
  },
  {
    "date": "2015-04-08",
    "close": 9570.0,
    "volume": 93175,
    "contract": "201504"
  },
  {
    "date": "2015-04-09",
    "close": 9570.0,
    "volume": 149624,
    "contract": "201504"
  },
  {
    "date": "2015-04-10",
    "close": 9632.0,
    "volume": 120457,
    "contract": "201504"
  },
  {
    "date": "2015-04-13",
    "close": 9657.0,
    "volume": 93462,
    "contract": "201504"
  },
  {
    "date": "2015-04-14",
    "close": 9644.0,
    "volume": 84520,
    "contract": "201504"
  },
  {
    "date": "2015-04-15",
    "close": 9519.0,
    "volume": 83539,
    "contract": "201504"
  },
  {
    "date": "2015-04-16",
    "close": 9644.0,
    "volume": 125788,
    "contract": "201505"
  },
  {
    "date": "2015-04-17",
    "close": 9582.0,
    "volume": 105924,
    "contract": "201505"
  },
  {
    "date": "2015-04-20",
    "close": 9563.0,
    "volume": 124844,
    "contract": "201505"
  },
  {
    "date": "2015-04-21",
    "close": 9555.0,
    "volume": 109112,
    "contract": "201505"
  },
  {
    "date": "2015-04-22",
    "close": 9614.0,
    "volume": 140112,
    "contract": "201505"
  },
  {
    "date": "2015-04-23",
    "close": 9838.0,
    "volume": 186347,
    "contract": "201505"
  },
  {
    "date": "2015-04-24",
    "close": 9920.0,
    "volume": 206172,
    "contract": "201505"
  },
  {
    "date": "2015-04-27",
    "close": 10018.0,
    "volume": 147811,
    "contract": "201505"
  },
  {
    "date": "2015-04-28",
    "close": 9990.0,
    "volume": 105272,
    "contract": "201505"
  },
  {
    "date": "2015-04-29",
    "close": 9907.0,
    "volume": 173931,
    "contract": "201505"
  },
  {
    "date": "2015-04-30",
    "close": 9877.0,
    "volume": 130960,
    "contract": "201505"
  },
  {
    "date": "2015-05-04",
    "close": 9885.0,
    "volume": 112699,
    "contract": "201505"
  },
  {
    "date": "2015-05-05",
    "close": 9848.0,
    "volume": 102568,
    "contract": "201505"
  },
  {
    "date": "2015-05-06",
    "close": 9846.0,
    "volume": 117999,
    "contract": "201505"
  },
  {
    "date": "2015-05-07",
    "close": 9752.0,
    "volume": 130534,
    "contract": "201505"
  },
  {
    "date": "2015-05-08",
    "close": 9718.0,
    "volume": 92550,
    "contract": "201505"
  },
  {
    "date": "2015-05-11",
    "close": 9722.0,
    "volume": 155184,
    "contract": "201505"
  },
  {
    "date": "2015-05-12",
    "close": 9706.0,
    "volume": 115207,
    "contract": "201505"
  },
  {
    "date": "2015-05-13",
    "close": 9739.0,
    "volume": 114681,
    "contract": "201505"
  },
  {
    "date": "2015-05-14",
    "close": 9605.0,
    "volume": 138661,
    "contract": "201505"
  },
  {
    "date": "2015-05-15",
    "close": 9576.0,
    "volume": 129471,
    "contract": "201505"
  },
  {
    "date": "2015-05-18",
    "close": 9598.0,
    "volume": 102650,
    "contract": "201505"
  },
  {
    "date": "2015-05-19",
    "close": 9703.0,
    "volume": 131463,
    "contract": "201505"
  },
  {
    "date": "2015-05-20",
    "close": 9668.0,
    "volume": 73133,
    "contract": "201505"
  },
  {
    "date": "2015-05-21",
    "close": 9541.0,
    "volume": 128659,
    "contract": "201506"
  },
  {
    "date": "2015-05-22",
    "close": 9627.0,
    "volume": 110540,
    "contract": "201506"
  },
  {
    "date": "2015-05-25",
    "close": 9631.0,
    "volume": 94010,
    "contract": "201506"
  },
  {
    "date": "2015-05-26",
    "close": 9659.0,
    "volume": 113898,
    "contract": "201506"
  },
  {
    "date": "2015-05-27",
    "close": 9662.0,
    "volume": 109490,
    "contract": "201506"
  },
  {
    "date": "2015-05-28",
    "close": 9729.0,
    "volume": 113114,
    "contract": "201506"
  },
  {
    "date": "2015-05-29",
    "close": 9703.0,
    "volume": 105530,
    "contract": "201506"
  },
  {
    "date": "2015-06-01",
    "close": 9630.0,
    "volume": 117845,
    "contract": "201506"
  },
  {
    "date": "2015-06-02",
    "close": 9606.0,
    "volume": 103681,
    "contract": "201506"
  },
  {
    "date": "2015-06-03",
    "close": 9548.0,
    "volume": 124180,
    "contract": "201506"
  },
  {
    "date": "2015-06-04",
    "close": 9312.0,
    "volume": 202135,
    "contract": "201506"
  },
  {
    "date": "2015-06-05",
    "close": 9309.0,
    "volume": 125037,
    "contract": "201506"
  },
  {
    "date": "2015-06-08",
    "close": 9348.0,
    "volume": 134575,
    "contract": "201506"
  },
  {
    "date": "2015-06-09",
    "close": 9235.0,
    "volume": 142752,
    "contract": "201506"
  },
  {
    "date": "2015-06-10",
    "close": 9284.0,
    "volume": 122486,
    "contract": "201506"
  },
  {
    "date": "2015-06-11",
    "close": 9285.0,
    "volume": 119493,
    "contract": "201506"
  },
  {
    "date": "2015-06-12",
    "close": 9268.0,
    "volume": 106398,
    "contract": "201506"
  },
  {
    "date": "2015-06-15",
    "close": 9245.0,
    "volume": 119565,
    "contract": "201506"
  },
  {
    "date": "2015-06-16",
    "close": 9214.0,
    "volume": 119914,
    "contract": "201506"
  },
  {
    "date": "2015-06-17",
    "close": 9182.0,
    "volume": 61706,
    "contract": "201506"
  },
  {
    "date": "2015-06-18",
    "close": 9048.0,
    "volume": 101634,
    "contract": "201507"
  },
  {
    "date": "2015-06-22",
    "close": 9178.0,
    "volume": 103562,
    "contract": "201507"
  },
  {
    "date": "2015-06-23",
    "close": 9230.0,
    "volume": 106239,
    "contract": "201507"
  },
  {
    "date": "2015-06-24",
    "close": 9246.0,
    "volume": 80540,
    "contract": "201507"
  },
  {
    "date": "2015-06-25",
    "close": 9342.0,
    "volume": 134204,
    "contract": "201507"
  },
  {
    "date": "2015-06-26",
    "close": 9322.0,
    "volume": 72218,
    "contract": "201507"
  },
  {
    "date": "2015-06-29",
    "close": 9139.0,
    "volume": 128844,
    "contract": "201507"
  },
  {
    "date": "2015-06-30",
    "close": 9211.0,
    "volume": 103641,
    "contract": "201507"
  },
  {
    "date": "2015-07-01",
    "close": 9292.0,
    "volume": 124416,
    "contract": "201507"
  },
  {
    "date": "2015-07-02",
    "close": 9277.0,
    "volume": 91473,
    "contract": "201507"
  },
  {
    "date": "2015-07-03",
    "close": 9301.0,
    "volume": 133033,
    "contract": "201507"
  },
  {
    "date": "2015-07-06",
    "close": 9203.0,
    "volume": 124973,
    "contract": "201507"
  },
  {
    "date": "2015-07-07",
    "close": 9242.0,
    "volume": 131787,
    "contract": "201507"
  },
  {
    "date": "2015-07-08",
    "close": 8945.0,
    "volume": 208496,
    "contract": "201507"
  },
  {
    "date": "2015-07-09",
    "close": 8875.0,
    "volume": 193187,
    "contract": "201507"
  },
  {
    "date": "2015-07-13",
    "close": 8993.0,
    "volume": 156806,
    "contract": "201507"
  },
  {
    "date": "2015-07-14",
    "close": 8983.0,
    "volume": 136144,
    "contract": "201507"
  },
  {
    "date": "2015-07-15",
    "close": 9030.0,
    "volume": 88463,
    "contract": "201507"
  },
  {
    "date": "2015-07-16",
    "close": 8916.0,
    "volume": 132945,
    "contract": "201508"
  },
  {
    "date": "2015-07-17",
    "close": 8913.0,
    "volume": 112382,
    "contract": "201508"
  },
  {
    "date": "2015-07-20",
    "close": 8851.0,
    "volume": 155272,
    "contract": "201508"
  },
  {
    "date": "2015-07-21",
    "close": 8937.0,
    "volume": 130287,
    "contract": "201508"
  },
  {
    "date": "2015-07-22",
    "close": 8811.0,
    "volume": 141837,
    "contract": "201508"
  },
  {
    "date": "2015-07-23",
    "close": 8753.0,
    "volume": 172952,
    "contract": "201508"
  },
  {
    "date": "2015-07-24",
    "close": 8686.0,
    "volume": 119108,
    "contract": "201508"
  },
  {
    "date": "2015-07-27",
    "close": 8525.0,
    "volume": 166804,
    "contract": "201508"
  },
  {
    "date": "2015-07-28",
    "close": 8539.0,
    "volume": 144721,
    "contract": "201508"
  },
  {
    "date": "2015-07-29",
    "close": 8485.0,
    "volume": 163354,
    "contract": "201508"
  },
  {
    "date": "2015-07-30",
    "close": 8607.0,
    "volume": 145799,
    "contract": "201508"
  },
  {
    "date": "2015-07-31",
    "close": 8575.0,
    "volume": 134719,
    "contract": "201508"
  },
  {
    "date": "2015-08-03",
    "close": 8454.0,
    "volume": 136785,
    "contract": "201508"
  },
  {
    "date": "2015-08-04",
    "close": 8464.0,
    "volume": 167590,
    "contract": "201508"
  },
  {
    "date": "2015-08-05",
    "close": 8521.0,
    "volume": 145106,
    "contract": "201508"
  },
  {
    "date": "2015-08-06",
    "close": 8390.0,
    "volume": 179725,
    "contract": "201508"
  },
  {
    "date": "2015-08-07",
    "close": 8389.0,
    "volume": 148962,
    "contract": "201508"
  },
  {
    "date": "2015-08-10",
    "close": 8442.0,
    "volume": 143249,
    "contract": "201508"
  },
  {
    "date": "2015-08-11",
    "close": 8362.0,
    "volume": 185332,
    "contract": "201508"
  },
  {
    "date": "2015-08-12",
    "close": 8301.0,
    "volume": 184836,
    "contract": "201508"
  },
  {
    "date": "2015-08-13",
    "close": 8305.0,
    "volume": 151639,
    "contract": "201508"
  },
  {
    "date": "2015-08-14",
    "close": 8326.0,
    "volume": 112509,
    "contract": "201508"
  },
  {
    "date": "2015-08-17",
    "close": 8239.0,
    "volume": 125957,
    "contract": "201508"
  },
  {
    "date": "2015-08-18",
    "close": 8172.0,
    "volume": 130582,
    "contract": "201508"
  },
  {
    "date": "2015-08-19",
    "close": 8002.0,
    "volume": 101864,
    "contract": "201508"
  },
  {
    "date": "2015-08-20",
    "close": 7973.0,
    "volume": 187942,
    "contract": "201509"
  },
  {
    "date": "2015-08-21",
    "close": 7744.0,
    "volume": 174438,
    "contract": "201509"
  },
  {
    "date": "2015-08-24",
    "close": 7345.0,
    "volume": 364785,
    "contract": "201509"
  },
  {
    "date": "2015-08-25",
    "close": 7572.0,
    "volume": 233175,
    "contract": "201509"
  },
  {
    "date": "2015-08-26",
    "close": 7607.0,
    "volume": 238178,
    "contract": "201509"
  },
  {
    "date": "2015-08-27",
    "close": 7679.0,
    "volume": 169791,
    "contract": "201509"
  },
  {
    "date": "2015-08-28",
    "close": 7871.0,
    "volume": 167248,
    "contract": "201509"
  },
  {
    "date": "2015-08-31",
    "close": 7973.0,
    "volume": 144165,
    "contract": "201509"
  },
  {
    "date": "2015-09-01",
    "close": 7829.0,
    "volume": 174196,
    "contract": "201509"
  },
  {
    "date": "2015-09-02",
    "close": 7938.0,
    "volume": 197665,
    "contract": "201509"
  },
  {
    "date": "2015-09-03",
    "close": 7975.0,
    "volume": 151197,
    "contract": "201509"
  },
  {
    "date": "2015-09-04",
    "close": 7894.0,
    "volume": 176043,
    "contract": "201509"
  },
  {
    "date": "2015-09-07",
    "close": 7930.0,
    "volume": 169579,
    "contract": "201509"
  },
  {
    "date": "2015-09-08",
    "close": 7972.0,
    "volume": 137093,
    "contract": "201509"
  },
  {
    "date": "2015-09-09",
    "close": 8334.0,
    "volume": 194442,
    "contract": "201509"
  },
  {
    "date": "2015-09-10",
    "close": 8265.0,
    "volume": 146244,
    "contract": "201509"
  },
  {
    "date": "2015-09-11",
    "close": 8266.0,
    "volume": 120481,
    "contract": "201509"
  },
  {
    "date": "2015-09-14",
    "close": 8275.0,
    "volume": 149956,
    "contract": "201509"
  },
  {
    "date": "2015-09-15",
    "close": 8237.0,
    "volume": 137170,
    "contract": "201509"
  },
  {
    "date": "2015-09-16",
    "close": 8318.0,
    "volume": 80906,
    "contract": "201509"
  },
  {
    "date": "2015-09-17",
    "close": 8441.0,
    "volume": 141074,
    "contract": "201510"
  },
  {
    "date": "2015-09-18",
    "close": 8438.0,
    "volume": 122478,
    "contract": "201510"
  },
  {
    "date": "2015-09-21",
    "close": 8270.0,
    "volume": 126365,
    "contract": "201510"
  },
  {
    "date": "2015-09-22",
    "close": 8331.0,
    "volume": 99115,
    "contract": "201510"
  },
  {
    "date": "2015-09-23",
    "close": 8142.0,
    "volume": 138538,
    "contract": "201510"
  },
  {
    "date": "2015-09-24",
    "close": 8090.0,
    "volume": 163890,
    "contract": "201510"
  },
  {
    "date": "2015-09-25",
    "close": 8119.0,
    "volume": 161413,
    "contract": "201510"
  },
  {
    "date": "2015-09-30",
    "close": 8135.0,
    "volume": 165188,
    "contract": "201510"
  },
  {
    "date": "2015-10-01",
    "close": 8307.0,
    "volume": 178858,
    "contract": "201510"
  },
  {
    "date": "2015-10-02",
    "close": 8278.0,
    "volume": 104901,
    "contract": "201510"
  },
  {
    "date": "2015-10-05",
    "close": 8331.0,
    "volume": 131099,
    "contract": "201510"
  },
  {
    "date": "2015-10-06",
    "close": 8369.0,
    "volume": 147140,
    "contract": "201510"
  },
  {
    "date": "2015-10-07",
    "close": 8491.0,
    "volume": 140147,
    "contract": "201510"
  },
  {
    "date": "2015-10-08",
    "close": 8443.0,
    "volume": 142571,
    "contract": "201510"
  },
  {
    "date": "2015-10-12",
    "close": 8552.0,
    "volume": 125543,
    "contract": "201510"
  },
  {
    "date": "2015-10-13",
    "close": 8557.0,
    "volume": 99975,
    "contract": "201510"
  },
  {
    "date": "2015-10-14",
    "close": 8520.0,
    "volume": 108262,
    "contract": "201510"
  },
  {
    "date": "2015-10-15",
    "close": 8609.0,
    "volume": 138824,
    "contract": "201510"
  },
  {
    "date": "2015-10-16",
    "close": 8607.0,
    "volume": 98558,
    "contract": "201510"
  },
  {
    "date": "2015-10-19",
    "close": 8623.0,
    "volume": 117062,
    "contract": "201510"
  },
  {
    "date": "2015-10-20",
    "close": 8659.0,
    "volume": 83770,
    "contract": "201510"
  },
  {
    "date": "2015-10-21",
    "close": 8617.0,
    "volume": 71803,
    "contract": "201510"
  },
  {
    "date": "2015-10-22",
    "close": 8595.0,
    "volume": 97736,
    "contract": "201511"
  },
  {
    "date": "2015-10-23",
    "close": 8694.0,
    "volume": 108905,
    "contract": "201511"
  },
  {
    "date": "2015-10-26",
    "close": 8733.0,
    "volume": 79592,
    "contract": "201511"
  },
  {
    "date": "2015-10-27",
    "close": 8694.0,
    "volume": 99136,
    "contract": "201511"
  },
  {
    "date": "2015-10-28",
    "close": 8638.0,
    "volume": 115433,
    "contract": "201511"
  },
  {
    "date": "2015-10-29",
    "close": 8547.0,
    "volume": 142670,
    "contract": "201511"
  },
  {
    "date": "2015-10-30",
    "close": 8570.0,
    "volume": 155466,
    "contract": "201511"
  },
  {
    "date": "2015-11-02",
    "close": 8587.0,
    "volume": 114793,
    "contract": "201511"
  },
  {
    "date": "2015-11-03",
    "close": 8719.0,
    "volume": 123033,
    "contract": "201511"
  },
  {
    "date": "2015-11-04",
    "close": 8882.0,
    "volume": 160402,
    "contract": "201511"
  },
  {
    "date": "2015-11-05",
    "close": 8872.0,
    "volume": 96100,
    "contract": "201511"
  },
  {
    "date": "2015-11-06",
    "close": 8689.0,
    "volume": 185282,
    "contract": "201511"
  },
  {
    "date": "2015-11-09",
    "close": 8628.0,
    "volume": 165493,
    "contract": "201511"
  },
  {
    "date": "2015-11-10",
    "close": 8533.0,
    "volume": 131070,
    "contract": "201511"
  },
  {
    "date": "2015-11-11",
    "close": 8378.0,
    "volume": 179202,
    "contract": "201511"
  },
  {
    "date": "2015-11-12",
    "close": 8459.0,
    "volume": 148495,
    "contract": "201511"
  },
  {
    "date": "2015-11-13",
    "close": 8356.0,
    "volume": 178126,
    "contract": "201511"
  },
  {
    "date": "2015-11-16",
    "close": 8288.0,
    "volume": 139331,
    "contract": "201511"
  },
  {
    "date": "2015-11-17",
    "close": 8437.0,
    "volume": 152201,
    "contract": "201511"
  },
  {
    "date": "2015-11-18",
    "close": 8336.0,
    "volume": 81613,
    "contract": "201511"
  },
  {
    "date": "2015-11-19",
    "close": 8447.0,
    "volume": 155548,
    "contract": "201512"
  },
  {
    "date": "2015-11-20",
    "close": 8443.0,
    "volume": 114281,
    "contract": "201512"
  },
  {
    "date": "2015-11-23",
    "close": 8481.0,
    "volume": 124827,
    "contract": "201512"
  },
  {
    "date": "2015-11-24",
    "close": 8401.0,
    "volume": 159334,
    "contract": "201512"
  },
  {
    "date": "2015-11-25",
    "close": 8384.0,
    "volume": 137748,
    "contract": "201512"
  },
  {
    "date": "2015-11-26",
    "close": 8499.0,
    "volume": 134327,
    "contract": "201512"
  },
  {
    "date": "2015-11-27",
    "close": 8390.0,
    "volume": 137736,
    "contract": "201512"
  },
  {
    "date": "2015-11-30",
    "close": 8297.0,
    "volume": 167237,
    "contract": "201512"
  },
  {
    "date": "2015-12-01",
    "close": 8456.0,
    "volume": 158141,
    "contract": "201512"
  },
  {
    "date": "2015-12-02",
    "close": 8452.0,
    "volume": 146804,
    "contract": "201512"
  },
  {
    "date": "2015-12-03",
    "close": 8470.0,
    "volume": 147876,
    "contract": "201512"
  },
  {
    "date": "2015-12-04",
    "close": 8393.0,
    "volume": 142112,
    "contract": "201512"
  },
  {
    "date": "2015-12-07",
    "close": 8470.0,
    "volume": 140025,
    "contract": "201512"
  },
  {
    "date": "2015-12-08",
    "close": 8331.0,
    "volume": 148126,
    "contract": "201512"
  },
  {
    "date": "2015-12-09",
    "close": 8220.0,
    "volume": 155405,
    "contract": "201512"
  },
  {
    "date": "2015-12-10",
    "close": 8188.0,
    "volume": 173415,
    "contract": "201512"
  },
  {
    "date": "2015-12-11",
    "close": 8070.0,
    "volume": 164753,
    "contract": "201512"
  },
  {
    "date": "2015-12-14",
    "close": 8060.0,
    "volume": 144310,
    "contract": "201512"
  },
  {
    "date": "2015-12-15",
    "close": 8065.0,
    "volume": 139344,
    "contract": "201512"
  },
  {
    "date": "2015-12-16",
    "close": 8198.0,
    "volume": 87705,
    "contract": "201512"
  },
  {
    "date": "2015-12-17",
    "close": 8282.0,
    "volume": 144410,
    "contract": "201601"
  },
  {
    "date": "2015-12-18",
    "close": 8229.0,
    "volume": 145205,
    "contract": "201601"
  },
  {
    "date": "2015-12-21",
    "close": 8280.0,
    "volume": 137963,
    "contract": "201601"
  },
  {
    "date": "2015-12-22",
    "close": 8275.0,
    "volume": 126517,
    "contract": "201601"
  },
  {
    "date": "2015-12-23",
    "close": 8288.0,
    "volume": 134900,
    "contract": "201601"
  },
  {
    "date": "2015-12-24",
    "close": 8317.0,
    "volume": 114489,
    "contract": "201601"
  },
  {
    "date": "2015-12-25",
    "close": 8374.0,
    "volume": 69641,
    "contract": "201601"
  },
  {
    "date": "2015-12-28",
    "close": 8354.0,
    "volume": 74401,
    "contract": "201601"
  },
  {
    "date": "2015-12-29",
    "close": 8288.0,
    "volume": 110566,
    "contract": "201601"
  },
  {
    "date": "2015-12-30",
    "close": 8258.0,
    "volume": 115891,
    "contract": "201601"
  },
  {
    "date": "2015-12-31",
    "close": 8275.0,
    "volume": 103781,
    "contract": "201601"
  },
  {
    "date": "2016-01-04",
    "close": 8073.0,
    "volume": 191331,
    "contract": "201601"
  },
  {
    "date": "2016-01-05",
    "close": 8025.0,
    "volume": 164756,
    "contract": "201601"
  },
  {
    "date": "2016-01-06",
    "close": 7971.0,
    "volume": 200598,
    "contract": "201601"
  },
  {
    "date": "2016-01-07",
    "close": 7805.0,
    "volume": 246399,
    "contract": "201601"
  },
  {
    "date": "2016-01-08",
    "close": 7865.0,
    "volume": 182333,
    "contract": "201601"
  },
  {
    "date": "2016-01-11",
    "close": 7739.0,
    "volume": 184748,
    "contract": "201601"
  },
  {
    "date": "2016-01-12",
    "close": 7707.0,
    "volume": 176648,
    "contract": "201601"
  },
  {
    "date": "2016-01-13",
    "close": 7806.0,
    "volume": 188268,
    "contract": "201601"
  },
  {
    "date": "2016-01-14",
    "close": 7715.0,
    "volume": 171850,
    "contract": "201601"
  },
  {
    "date": "2016-01-15",
    "close": 7668.0,
    "volume": 183418,
    "contract": "201601"
  },
  {
    "date": "2016-01-18",
    "close": 7810.0,
    "volume": 241486,
    "contract": "201601"
  },
  {
    "date": "2016-01-19",
    "close": 7866.0,
    "volume": 165954,
    "contract": "201601"
  },
  {
    "date": "2016-01-20",
    "close": 7705.0,
    "volume": 116624,
    "contract": "201601"
  },
  {
    "date": "2016-01-21",
    "close": 7613.0,
    "volume": 202230,
    "contract": "201602"
  },
  {
    "date": "2016-01-22",
    "close": 7748.0,
    "volume": 183045,
    "contract": "201602"
  },
  {
    "date": "2016-01-25",
    "close": 7835.0,
    "volume": 145944,
    "contract": "201602"
  },
  {
    "date": "2016-01-26",
    "close": 7778.0,
    "volume": 145032,
    "contract": "201602"
  },
  {
    "date": "2016-01-27",
    "close": 7838.0,
    "volume": 145619,
    "contract": "201602"
  },
  {
    "date": "2016-01-28",
    "close": 7858.0,
    "volume": 153244,
    "contract": "201602"
  },
  {
    "date": "2016-01-29",
    "close": 8053.0,
    "volume": 236477,
    "contract": "201602"
  },
  {
    "date": "2016-01-30",
    "close": 8164.0,
    "volume": 68665,
    "contract": "201602"
  },
  {
    "date": "2016-02-01",
    "close": 8126.0,
    "volume": 152839,
    "contract": "201602"
  },
  {
    "date": "2016-02-02",
    "close": 8104.0,
    "volume": 133729,
    "contract": "201602"
  },
  {
    "date": "2016-02-03",
    "close": 8036.0,
    "volume": 158007,
    "contract": "201602"
  },
  {
    "date": "2016-02-15",
    "close": 8043.0,
    "volume": 132682,
    "contract": "201602"
  },
  {
    "date": "2016-02-16",
    "close": 8206.0,
    "volume": 153558,
    "contract": "201602"
  },
  {
    "date": "2016-02-17",
    "close": 8212.0,
    "volume": 73251,
    "contract": "201602"
  },
  {
    "date": "2016-02-18",
    "close": 8285.0,
    "volume": 123075,
    "contract": "201603"
  },
  {
    "date": "2016-02-19",
    "close": 8307.0,
    "volume": 93479,
    "contract": "201603"
  },
  {
    "date": "2016-02-22",
    "close": 8300.0,
    "volume": 140771,
    "contract": "201603"
  },
  {
    "date": "2016-02-23",
    "close": 8319.0,
    "volume": 109053,
    "contract": "201603"
  },
  {
    "date": "2016-02-24",
    "close": 8247.0,
    "volume": 163799,
    "contract": "201603"
  },
  {
    "date": "2016-02-25",
    "close": 8338.0,
    "volume": 146795,
    "contract": "201603"
  },
  {
    "date": "2016-02-26",
    "close": 8389.0,
    "volume": 139525,
    "contract": "201603"
  },
  {
    "date": "2016-03-01",
    "close": 8448.0,
    "volume": 136259,
    "contract": "201603"
  },
  {
    "date": "2016-03-02",
    "close": 8518.0,
    "volume": 130846,
    "contract": "201603"
  },
  {
    "date": "2016-03-03",
    "close": 8564.0,
    "volume": 133529,
    "contract": "201603"
  },
  {
    "date": "2016-03-04",
    "close": 8601.0,
    "volume": 124749,
    "contract": "201603"
  },
  {
    "date": "2016-03-07",
    "close": 8604.0,
    "volume": 128900,
    "contract": "201603"
  },
  {
    "date": "2016-03-08",
    "close": 8614.0,
    "volume": 136044,
    "contract": "201603"
  },
  {
    "date": "2016-03-09",
    "close": 8618.0,
    "volume": 117377,
    "contract": "201603"
  },
  {
    "date": "2016-03-10",
    "close": 8641.0,
    "volume": 120396,
    "contract": "201603"
  },
  {
    "date": "2016-03-11",
    "close": 8705.0,
    "volume": 132707,
    "contract": "201603"
  },
  {
    "date": "2016-03-14",
    "close": 8741.0,
    "volume": 112139,
    "contract": "201603"
  },
  {
    "date": "2016-03-15",
    "close": 8603.0,
    "volume": 167109,
    "contract": "201603"
  },
  {
    "date": "2016-03-16",
    "close": 8691.0,
    "volume": 64232,
    "contract": "201603"
  },
  {
    "date": "2016-03-17",
    "close": 8698.0,
    "volume": 165522,
    "contract": "201604"
  },
  {
    "date": "2016-03-18",
    "close": 8765.0,
    "volume": 124958,
    "contract": "201604"
  },
  {
    "date": "2016-03-21",
    "close": 8746.0,
    "volume": 118631,
    "contract": "201604"
  },
  {
    "date": "2016-03-22",
    "close": 8750.0,
    "volume": 145545,
    "contract": "201604"
  },
  {
    "date": "2016-03-23",
    "close": 8713.0,
    "volume": 137212,
    "contract": "201604"
  },
  {
    "date": "2016-03-24",
    "close": 8713.0,
    "volume": 151791,
    "contract": "201604"
  },
  {
    "date": "2016-03-25",
    "close": 8700.0,
    "volume": 106496,
    "contract": "201604"
  },
  {
    "date": "2016-03-28",
    "close": 8685.0,
    "volume": 108424,
    "contract": "201604"
  },
  {
    "date": "2016-03-29",
    "close": 8601.0,
    "volume": 158070,
    "contract": "201604"
  },
  {
    "date": "2016-03-30",
    "close": 8740.0,
    "volume": 148145,
    "contract": "201604"
  },
  {
    "date": "2016-03-31",
    "close": 8716.0,
    "volume": 166161,
    "contract": "201604"
  },
  {
    "date": "2016-04-01",
    "close": 8628.0,
    "volume": 156482,
    "contract": "201604"
  },
  {
    "date": "2016-04-06",
    "close": 8458.0,
    "volume": 156407,
    "contract": "201604"
  },
  {
    "date": "2016-04-07",
    "close": 8438.0,
    "volume": 152741,
    "contract": "201604"
  },
  {
    "date": "2016-04-08",
    "close": 8485.0,
    "volume": 141629,
    "contract": "201604"
  },
  {
    "date": "2016-04-11",
    "close": 8515.0,
    "volume": 130911,
    "contract": "201604"
  },
  {
    "date": "2016-04-12",
    "close": 8496.0,
    "volume": 148275,
    "contract": "201604"
  },
  {
    "date": "2016-04-13",
    "close": 8636.0,
    "volume": 147192,
    "contract": "201604"
  },
  {
    "date": "2016-04-14",
    "close": 8660.0,
    "volume": 119974,
    "contract": "201604"
  },
  {
    "date": "2016-04-15",
    "close": 8717.0,
    "volume": 136854,
    "contract": "201604"
  },
  {
    "date": "2016-04-18",
    "close": 8644.0,
    "volume": 111226,
    "contract": "201604"
  },
  {
    "date": "2016-04-19",
    "close": 8636.0,
    "volume": 158491,
    "contract": "201604"
  },
  {
    "date": "2016-04-20",
    "close": 8519.0,
    "volume": 105896,
    "contract": "201604"
  },
  {
    "date": "2016-04-21",
    "close": 8530.0,
    "volume": 121720,
    "contract": "201605"
  },
  {
    "date": "2016-04-22",
    "close": 8500.0,
    "volume": 150062,
    "contract": "201605"
  },
  {
    "date": "2016-04-25",
    "close": 8527.0,
    "volume": 98787,
    "contract": "201605"
  },
  {
    "date": "2016-04-26",
    "close": 8570.0,
    "volume": 135704,
    "contract": "201605"
  },
  {
    "date": "2016-04-27",
    "close": 8560.0,
    "volume": 116757,
    "contract": "201605"
  },
  {
    "date": "2016-04-28",
    "close": 8415.0,
    "volume": 190019,
    "contract": "201605"
  },
  {
    "date": "2016-04-29",
    "close": 8311.0,
    "volume": 132260,
    "contract": "201605"
  },
  {
    "date": "2016-05-03",
    "close": 8261.0,
    "volume": 123157,
    "contract": "201605"
  },
  {
    "date": "2016-05-04",
    "close": 8181.0,
    "volume": 176592,
    "contract": "201605"
  },
  {
    "date": "2016-05-05",
    "close": 8146.0,
    "volume": 137990,
    "contract": "201605"
  },
  {
    "date": "2016-05-06",
    "close": 8105.0,
    "volume": 132563,
    "contract": "201605"
  },
  {
    "date": "2016-05-09",
    "close": 8116.0,
    "volume": 122435,
    "contract": "201605"
  },
  {
    "date": "2016-05-10",
    "close": 8152.0,
    "volume": 151146,
    "contract": "201605"
  },
  {
    "date": "2016-05-11",
    "close": 8124.0,
    "volume": 152178,
    "contract": "201605"
  },
  {
    "date": "2016-05-12",
    "close": 8082.0,
    "volume": 138711,
    "contract": "201605"
  },
  {
    "date": "2016-05-13",
    "close": 8022.0,
    "volume": 170540,
    "contract": "201605"
  },
  {
    "date": "2016-05-16",
    "close": 8063.0,
    "volume": 132897,
    "contract": "201605"
  },
  {
    "date": "2016-05-17",
    "close": 8146.0,
    "volume": 164654,
    "contract": "201605"
  },
  {
    "date": "2016-05-18",
    "close": 8148.0,
    "volume": 77042,
    "contract": "201605"
  },
  {
    "date": "2016-05-19",
    "close": 8033.0,
    "volume": 142629,
    "contract": "201606"
  },
  {
    "date": "2016-05-20",
    "close": 8103.0,
    "volume": 161767,
    "contract": "201606"
  },
  {
    "date": "2016-05-23",
    "close": 8343.0,
    "volume": 210720,
    "contract": "201606"
  },
  {
    "date": "2016-05-24",
    "close": 8284.0,
    "volume": 101231,
    "contract": "201606"
  },
  {
    "date": "2016-05-25",
    "close": 8384.0,
    "volume": 130270,
    "contract": "201606"
  },
  {
    "date": "2016-05-26",
    "close": 8383.0,
    "volume": 89102,
    "contract": "201606"
  },
  {
    "date": "2016-05-27",
    "close": 8462.0,
    "volume": 107120,
    "contract": "201606"
  },
  {
    "date": "2016-05-30",
    "close": 8509.0,
    "volume": 118598,
    "contract": "201606"
  },
  {
    "date": "2016-05-31",
    "close": 8510.0,
    "volume": 126395,
    "contract": "201606"
  },
  {
    "date": "2016-06-01",
    "close": 8564.0,
    "volume": 127418,
    "contract": "201606"
  },
  {
    "date": "2016-06-02",
    "close": 8550.0,
    "volume": 131250,
    "contract": "201606"
  },
  {
    "date": "2016-06-03",
    "close": 8565.0,
    "volume": 89927,
    "contract": "201606"
  },
  {
    "date": "2016-06-04",
    "close": 8577.0,
    "volume": 29951,
    "contract": "201606"
  },
  {
    "date": "2016-06-06",
    "close": 8573.0,
    "volume": 135249,
    "contract": "201606"
  },
  {
    "date": "2016-06-07",
    "close": 8667.0,
    "volume": 127819,
    "contract": "201606"
  },
  {
    "date": "2016-06-08",
    "close": 8713.0,
    "volume": 135065,
    "contract": "201606"
  },
  {
    "date": "2016-06-13",
    "close": 8525.0,
    "volume": 156484,
    "contract": "201606"
  },
  {
    "date": "2016-06-14",
    "close": 8574.0,
    "volume": 113683,
    "contract": "201606"
  },
  {
    "date": "2016-06-15",
    "close": 8601.0,
    "volume": 86838,
    "contract": "201606"
  },
  {
    "date": "2016-06-16",
    "close": 8281.0,
    "volume": 161494,
    "contract": "201607"
  },
  {
    "date": "2016-06-17",
    "close": 8395.0,
    "volume": 135050,
    "contract": "201607"
  },
  {
    "date": "2016-06-20",
    "close": 8469.0,
    "volume": 116528,
    "contract": "201607"
  },
  {
    "date": "2016-06-21",
    "close": 8510.0,
    "volume": 106832,
    "contract": "201607"
  },
  {
    "date": "2016-06-22",
    "close": 8510.0,
    "volume": 113230,
    "contract": "201607"
  },
  {
    "date": "2016-06-23",
    "close": 8510.0,
    "volume": 80671,
    "contract": "201607"
  },
  {
    "date": "2016-06-24",
    "close": 8238.0,
    "volume": 350484,
    "contract": "201607"
  },
  {
    "date": "2016-06-27",
    "close": 8326.0,
    "volume": 123131,
    "contract": "201607"
  },
  {
    "date": "2016-06-28",
    "close": 8376.0,
    "volume": 128666,
    "contract": "201607"
  },
  {
    "date": "2016-06-29",
    "close": 8436.0,
    "volume": 136847,
    "contract": "201607"
  },
  {
    "date": "2016-06-30",
    "close": 8519.0,
    "volume": 149910,
    "contract": "201607"
  },
  {
    "date": "2016-07-01",
    "close": 8623.0,
    "volume": 125937,
    "contract": "201607"
  },
  {
    "date": "2016-07-04",
    "close": 8632.0,
    "volume": 117023,
    "contract": "201607"
  },
  {
    "date": "2016-07-05",
    "close": 8610.0,
    "volume": 99016,
    "contract": "201607"
  },
  {
    "date": "2016-07-06",
    "close": 8469.0,
    "volume": 166638,
    "contract": "201607"
  },
  {
    "date": "2016-07-07",
    "close": 8561.0,
    "volume": 99013,
    "contract": "201607"
  },
  {
    "date": "2016-07-11",
    "close": 8734.0,
    "volume": 120241,
    "contract": "201607"
  },
  {
    "date": "2016-07-12",
    "close": 8776.0,
    "volume": 108508,
    "contract": "201607"
  },
  {
    "date": "2016-07-13",
    "close": 8793.0,
    "volume": 149460,
    "contract": "201607"
  },
  {
    "date": "2016-07-14",
    "close": 8813.0,
    "volume": 115361,
    "contract": "201607"
  },
  {
    "date": "2016-07-15",
    "close": 8912.0,
    "volume": 135980,
    "contract": "201607"
  },
  {
    "date": "2016-07-18",
    "close": 8999.0,
    "volume": 121872,
    "contract": "201607"
  },
  {
    "date": "2016-07-19",
    "close": 9032.0,
    "volume": 135725,
    "contract": "201607"
  },
  {
    "date": "2016-07-20",
    "close": 9003.0,
    "volume": 94642,
    "contract": "201607"
  },
  {
    "date": "2016-07-21",
    "close": 8984.0,
    "volume": 120520,
    "contract": "201608"
  },
  {
    "date": "2016-07-22",
    "close": 8927.0,
    "volume": 108745,
    "contract": "201608"
  },
  {
    "date": "2016-07-25",
    "close": 8891.0,
    "volume": 175723,
    "contract": "201608"
  },
  {
    "date": "2016-07-26",
    "close": 8965.0,
    "volume": 121917,
    "contract": "201608"
  },
  {
    "date": "2016-07-27",
    "close": 8979.0,
    "volume": 150067,
    "contract": "201608"
  },
  {
    "date": "2016-07-28",
    "close": 8979.0,
    "volume": 124950,
    "contract": "201608"
  },
  {
    "date": "2016-07-29",
    "close": 8894.0,
    "volume": 153817,
    "contract": "201608"
  },
  {
    "date": "2016-08-01",
    "close": 9040.0,
    "volume": 121841,
    "contract": "201608"
  },
  {
    "date": "2016-08-02",
    "close": 9012.0,
    "volume": 84612,
    "contract": "201608"
  },
  {
    "date": "2016-08-03",
    "close": 8935.0,
    "volume": 141402,
    "contract": "201608"
  },
  {
    "date": "2016-08-04",
    "close": 8970.0,
    "volume": 125262,
    "contract": "201608"
  },
  {
    "date": "2016-08-05",
    "close": 9062.0,
    "volume": 127647,
    "contract": "201608"
  },
  {
    "date": "2016-08-08",
    "close": 9116.0,
    "volume": 111631,
    "contract": "201608"
  },
  {
    "date": "2016-08-09",
    "close": 9117.0,
    "volume": 94114,
    "contract": "201608"
  },
  {
    "date": "2016-08-10",
    "close": 9149.0,
    "volume": 123597,
    "contract": "201608"
  },
  {
    "date": "2016-08-11",
    "close": 9087.0,
    "volume": 165714,
    "contract": "201608"
  },
  {
    "date": "2016-08-12",
    "close": 9130.0,
    "volume": 109885,
    "contract": "201608"
  },
  {
    "date": "2016-08-15",
    "close": 9124.0,
    "volume": 130933,
    "contract": "201608"
  },
  {
    "date": "2016-08-16",
    "close": 9085.0,
    "volume": 162847,
    "contract": "201608"
  },
  {
    "date": "2016-08-17",
    "close": 9121.0,
    "volume": 68207,
    "contract": "201608"
  },
  {
    "date": "2016-08-18",
    "close": 9041.0,
    "volume": 102776,
    "contract": "201609"
  },
  {
    "date": "2016-08-19",
    "close": 8948.0,
    "volume": 180514,
    "contract": "201609"
  },
  {
    "date": "2016-08-22",
    "close": 8895.0,
    "volume": 140625,
    "contract": "201609"
  },
  {
    "date": "2016-08-23",
    "close": 8983.0,
    "volume": 110642,
    "contract": "201609"
  },
  {
    "date": "2016-08-24",
    "close": 8954.0,
    "volume": 100206,
    "contract": "201609"
  },
  {
    "date": "2016-08-25",
    "close": 9070.0,
    "volume": 131838,
    "contract": "201609"
  },
  {
    "date": "2016-08-26",
    "close": 9080.0,
    "volume": 86770,
    "contract": "201609"
  },
  {
    "date": "2016-08-29",
    "close": 9042.0,
    "volume": 148143,
    "contract": "201609"
  },
  {
    "date": "2016-08-30",
    "close": 9035.0,
    "volume": 106337,
    "contract": "201609"
  },
  {
    "date": "2016-08-31",
    "close": 8976.0,
    "volume": 144241,
    "contract": "201609"
  },
  {
    "date": "2016-09-01",
    "close": 8942.0,
    "volume": 151424,
    "contract": "201609"
  },
  {
    "date": "2016-09-02",
    "close": 8932.0,
    "volume": 110392,
    "contract": "201609"
  },
  {
    "date": "2016-09-05",
    "close": 9063.0,
    "volume": 105105,
    "contract": "201609"
  },
  {
    "date": "2016-09-06",
    "close": 9151.0,
    "volume": 103692,
    "contract": "201609"
  },
  {
    "date": "2016-09-07",
    "close": 9253.0,
    "volume": 121479,
    "contract": "201609"
  },
  {
    "date": "2016-09-08",
    "close": 9239.0,
    "volume": 74430,
    "contract": "201609"
  },
  {
    "date": "2016-09-09",
    "close": 9126.0,
    "volume": 128752,
    "contract": "201609"
  },
  {
    "date": "2016-09-10",
    "close": 8953.0,
    "volume": 75595,
    "contract": "201609"
  },
  {
    "date": "2016-09-12",
    "close": 8900.0,
    "volume": 137444,
    "contract": "201609"
  },
  {
    "date": "2016-09-13",
    "close": 8905.0,
    "volume": 173830,
    "contract": "201609"
  },
  {
    "date": "2016-09-14",
    "close": 8875.0,
    "volume": 129885,
    "contract": "201609"
  },
  {
    "date": "2016-09-19",
    "close": 9149.0,
    "volume": 162262,
    "contract": "201609"
  },
  {
    "date": "2016-09-20",
    "close": 9142.0,
    "volume": 107397,
    "contract": "201609"
  },
  {
    "date": "2016-09-21",
    "close": 9221.0,
    "volume": 76502,
    "contract": "201609"
  },
  {
    "date": "2016-09-22",
    "close": 9187.0,
    "volume": 123322,
    "contract": "201610"
  },
  {
    "date": "2016-09-23",
    "close": 9236.0,
    "volume": 95279,
    "contract": "201610"
  },
  {
    "date": "2016-09-26",
    "close": 9152.0,
    "volume": 95532,
    "contract": "201610"
  },
  {
    "date": "2016-09-29",
    "close": 9251.0,
    "volume": 134752,
    "contract": "201610"
  },
  {
    "date": "2016-09-30",
    "close": 9130.0,
    "volume": 131337,
    "contract": "201610"
  },
  {
    "date": "2016-10-03",
    "close": 9193.0,
    "volume": 100555,
    "contract": "201610"
  },
  {
    "date": "2016-10-04",
    "close": 9251.0,
    "volume": 95262,
    "contract": "201610"
  },
  {
    "date": "2016-10-05",
    "close": 9238.0,
    "volume": 81576,
    "contract": "201610"
  },
  {
    "date": "2016-10-06",
    "close": 9257.0,
    "volume": 100967,
    "contract": "201610"
  },
  {
    "date": "2016-10-07",
    "close": 9251.0,
    "volume": 66389,
    "contract": "201610"
  },
  {
    "date": "2016-10-11",
    "close": 9189.0,
    "volume": 178389,
    "contract": "201610"
  },
  {
    "date": "2016-10-12",
    "close": 9259.0,
    "volume": 113440,
    "contract": "201610"
  },
  {
    "date": "2016-10-13",
    "close": 9201.0,
    "volume": 138511,
    "contract": "201610"
  },
  {
    "date": "2016-10-14",
    "close": 9167.0,
    "volume": 130516,
    "contract": "201610"
  },
  {
    "date": "2016-10-17",
    "close": 9167.0,
    "volume": 202913,
    "contract": "201610"
  },
  {
    "date": "2016-10-18",
    "close": 9210.0,
    "volume": 133283,
    "contract": "201610"
  },
  {
    "date": "2016-10-19",
    "close": 9280.0,
    "volume": 87933,
    "contract": "201610"
  },
  {
    "date": "2016-10-20",
    "close": 9277.0,
    "volume": 101510,
    "contract": "201611"
  },
  {
    "date": "2016-10-21",
    "close": 9264.0,
    "volume": 118712,
    "contract": "201611"
  },
  {
    "date": "2016-10-24",
    "close": 9309.0,
    "volume": 97060,
    "contract": "201611"
  },
  {
    "date": "2016-10-25",
    "close": 9375.0,
    "volume": 112280,
    "contract": "201611"
  },
  {
    "date": "2016-10-26",
    "close": 9334.0,
    "volume": 89110,
    "contract": "201611"
  },
  {
    "date": "2016-10-27",
    "close": 9288.0,
    "volume": 127682,
    "contract": "201611"
  },
  {
    "date": "2016-10-28",
    "close": 9279.0,
    "volume": 95640,
    "contract": "201611"
  },
  {
    "date": "2016-10-31",
    "close": 9284.0,
    "volume": 146504,
    "contract": "201611"
  },
  {
    "date": "2016-11-01",
    "close": 9278.0,
    "volume": 101255,
    "contract": "201611"
  },
  {
    "date": "2016-11-02",
    "close": 9158.0,
    "volume": 150857,
    "contract": "201611"
  },
  {
    "date": "2016-11-03",
    "close": 9088.0,
    "volume": 134541,
    "contract": "201611"
  },
  {
    "date": "2016-11-04",
    "close": 9063.0,
    "volume": 97483,
    "contract": "201611"
  },
  {
    "date": "2016-11-07",
    "close": 9196.0,
    "volume": 105071,
    "contract": "201611"
  },
  {
    "date": "2016-11-08",
    "close": 9223.0,
    "volume": 115585,
    "contract": "201611"
  },
  {
    "date": "2016-11-09",
    "close": 8926.0,
    "volume": 385514,
    "contract": "201611"
  },
  {
    "date": "2016-11-10",
    "close": 9176.0,
    "volume": 134067,
    "contract": "201611"
  },
  {
    "date": "2016-11-11",
    "close": 8967.0,
    "volume": 179369,
    "contract": "201611"
  },
  {
    "date": "2016-11-14",
    "close": 8945.0,
    "volume": 184246,
    "contract": "201611"
  },
  {
    "date": "2016-11-15",
    "close": 8938.0,
    "volume": 142410,
    "contract": "201611"
  },
  {
    "date": "2016-11-16",
    "close": 8983.0,
    "volume": 83943,
    "contract": "201611"
  },
  {
    "date": "2016-11-17",
    "close": 8960.0,
    "volume": 126400,
    "contract": "201612"
  },
  {
    "date": "2016-11-18",
    "close": 8987.0,
    "volume": 131675,
    "contract": "201612"
  },
  {
    "date": "2016-11-21",
    "close": 9017.0,
    "volume": 85149,
    "contract": "201612"
  },
  {
    "date": "2016-11-22",
    "close": 9139.0,
    "volume": 132590,
    "contract": "201612"
  },
  {
    "date": "2016-11-23",
    "close": 9177.0,
    "volume": 97048,
    "contract": "201612"
  },
  {
    "date": "2016-11-24",
    "close": 9142.0,
    "volume": 100734,
    "contract": "201612"
  },
  {
    "date": "2016-11-25",
    "close": 9161.0,
    "volume": 98602,
    "contract": "201612"
  },
  {
    "date": "2016-11-28",
    "close": 9223.0,
    "volume": 116679,
    "contract": "201612"
  },
  {
    "date": "2016-11-29",
    "close": 9202.0,
    "volume": 102746,
    "contract": "201612"
  },
  {
    "date": "2016-11-30",
    "close": 9227.0,
    "volume": 121118,
    "contract": "201612"
  },
  {
    "date": "2016-12-01",
    "close": 9260.0,
    "volume": 107733,
    "contract": "201612"
  },
  {
    "date": "2016-12-02",
    "close": 9163.0,
    "volume": 118876,
    "contract": "201612"
  },
  {
    "date": "2016-12-05",
    "close": 9157.0,
    "volume": 107414,
    "contract": "201612"
  },
  {
    "date": "2016-12-06",
    "close": 9262.0,
    "volume": 100307,
    "contract": "201612"
  },
  {
    "date": "2016-12-07",
    "close": 9262.0,
    "volume": 92062,
    "contract": "201612"
  },
  {
    "date": "2016-12-08",
    "close": 9368.0,
    "volume": 107870,
    "contract": "201612"
  },
  {
    "date": "2016-12-09",
    "close": 9389.0,
    "volume": 73814,
    "contract": "201612"
  },
  {
    "date": "2016-12-12",
    "close": 9356.0,
    "volume": 123782,
    "contract": "201612"
  },
  {
    "date": "2016-12-13",
    "close": 9379.0,
    "volume": 69542,
    "contract": "201612"
  },
  {
    "date": "2016-12-14",
    "close": 9369.0,
    "volume": 85638,
    "contract": "201612"
  },
  {
    "date": "2016-12-15",
    "close": 9368.0,
    "volume": 126853,
    "contract": "201612"
  },
  {
    "date": "2016-12-16",
    "close": 9311.0,
    "volume": 104771,
    "contract": "201612"
  },
  {
    "date": "2016-12-19",
    "close": 9244.0,
    "volume": 127172,
    "contract": "201612"
  },
  {
    "date": "2016-12-20",
    "close": 9260.0,
    "volume": 116914,
    "contract": "201612"
  },
  {
    "date": "2016-12-21",
    "close": 9232.0,
    "volume": 61153,
    "contract": "201612"
  },
  {
    "date": "2016-12-22",
    "close": 9128.0,
    "volume": 116265,
    "contract": "201701"
  },
  {
    "date": "2016-12-23",
    "close": 9092.0,
    "volume": 108536,
    "contract": "201701"
  },
  {
    "date": "2016-12-26",
    "close": 9124.0,
    "volume": 69849,
    "contract": "201701"
  },
  {
    "date": "2016-12-27",
    "close": 9113.0,
    "volume": 47698,
    "contract": "201701"
  },
  {
    "date": "2016-12-28",
    "close": 9211.0,
    "volume": 97287,
    "contract": "201701"
  },
  {
    "date": "2016-12-29",
    "close": 9181.0,
    "volume": 92408,
    "contract": "201701"
  },
  {
    "date": "2016-12-30",
    "close": 9262.0,
    "volume": 116957,
    "contract": "201701"
  },
  {
    "date": "2017-01-03",
    "close": 9280.0,
    "volume": 89282,
    "contract": "201701"
  },
  {
    "date": "2017-01-04",
    "close": 9271.0,
    "volume": 87462,
    "contract": "201701"
  },
  {
    "date": "2017-01-05",
    "close": 9342.0,
    "volume": 119149,
    "contract": "201701"
  },
  {
    "date": "2017-01-06",
    "close": 9365.0,
    "volume": 67027,
    "contract": "201701"
  },
  {
    "date": "2017-01-09",
    "close": 9342.0,
    "volume": 113565,
    "contract": "201701"
  },
  {
    "date": "2017-01-10",
    "close": 9341.0,
    "volume": 76021,
    "contract": "201701"
  },
  {
    "date": "2017-01-11",
    "close": 9337.0,
    "volume": 91651,
    "contract": "201701"
  },
  {
    "date": "2017-01-12",
    "close": 9411.0,
    "volume": 117651,
    "contract": "201701"
  },
  {
    "date": "2017-01-13",
    "close": 9375.0,
    "volume": 88034,
    "contract": "201701"
  },
  {
    "date": "2017-01-16",
    "close": 9285.0,
    "volume": 135414,
    "contract": "201701"
  },
  {
    "date": "2017-01-17",
    "close": 9340.0,
    "volume": 94530,
    "contract": "201701"
  },
  {
    "date": "2017-01-18",
    "close": 9340.0,
    "volume": 55499,
    "contract": "201701"
  },
  {
    "date": "2017-01-19",
    "close": 9304.0,
    "volume": 123137,
    "contract": "201702"
  },
  {
    "date": "2017-01-20",
    "close": 9330.0,
    "volume": 77047,
    "contract": "201702"
  },
  {
    "date": "2017-01-23",
    "close": 9407.0,
    "volume": 99777,
    "contract": "201702"
  },
  {
    "date": "2017-01-24",
    "close": 9442.0,
    "volume": 78935,
    "contract": "201702"
  },
  {
    "date": "2017-02-02",
    "close": 9375.0,
    "volume": 138242,
    "contract": "201702"
  },
  {
    "date": "2017-02-03",
    "close": 9437.0,
    "volume": 95766,
    "contract": "201702"
  },
  {
    "date": "2017-02-06",
    "close": 9505.0,
    "volume": 116954,
    "contract": "201702"
  },
  {
    "date": "2017-02-07",
    "close": 9520.0,
    "volume": 71159,
    "contract": "201702"
  },
  {
    "date": "2017-02-08",
    "close": 9515.0,
    "volume": 114482,
    "contract": "201702"
  },
  {
    "date": "2017-02-09",
    "close": 9574.0,
    "volume": 110690,
    "contract": "201702"
  },
  {
    "date": "2017-02-10",
    "close": 9657.0,
    "volume": 136883,
    "contract": "201702"
  },
  {
    "date": "2017-02-13",
    "close": 9704.0,
    "volume": 118488,
    "contract": "201702"
  },
  {
    "date": "2017-02-14",
    "close": 9708.0,
    "volume": 148146,
    "contract": "201702"
  },
  {
    "date": "2017-02-15",
    "close": 9800.0,
    "volume": 68161,
    "contract": "201702"
  },
  {
    "date": "2017-02-16",
    "close": 9770.0,
    "volume": 136500,
    "contract": "201703"
  },
  {
    "date": "2017-02-17",
    "close": 9763.0,
    "volume": 77496,
    "contract": "201703"
  },
  {
    "date": "2017-02-18",
    "close": 9786.0,
    "volume": 23312,
    "contract": "201703"
  },
  {
    "date": "2017-02-20",
    "close": 9766.0,
    "volume": 101368,
    "contract": "201703"
  },
  {
    "date": "2017-02-21",
    "close": 9767.0,
    "volume": 99916,
    "contract": "201703"
  },
  {
    "date": "2017-02-22",
    "close": 9783.0,
    "volume": 121485,
    "contract": "201703"
  },
  {
    "date": "2017-02-23",
    "close": 9773.0,
    "volume": 115454,
    "contract": "201703"
  },
  {
    "date": "2017-02-24",
    "close": 9760.0,
    "volume": 100020,
    "contract": "201703"
  },
  {
    "date": "2017-03-01",
    "close": 9683.0,
    "volume": 137961,
    "contract": "201703"
  },
  {
    "date": "2017-03-02",
    "close": 9691.0,
    "volume": 158914,
    "contract": "201703"
  },
  {
    "date": "2017-03-03",
    "close": 9630.0,
    "volume": 122036,
    "contract": "201703"
  },
  {
    "date": "2017-03-06",
    "close": 9682.0,
    "volume": 98832,
    "contract": "201703"
  },
  {
    "date": "2017-03-07",
    "close": 9728.0,
    "volume": 95033,
    "contract": "201703"
  },
  {
    "date": "2017-03-08",
    "close": 9746.0,
    "volume": 115988,
    "contract": "201703"
  },
  {
    "date": "2017-03-09",
    "close": 9649.0,
    "volume": 142245,
    "contract": "201703"
  },
  {
    "date": "2017-03-10",
    "close": 9624.0,
    "volume": 170995,
    "contract": "201703"
  },
  {
    "date": "2017-03-13",
    "close": 9693.0,
    "volume": 132818,
    "contract": "201703"
  },
  {
    "date": "2017-03-14",
    "close": 9748.0,
    "volume": 116325,
    "contract": "201703"
  },
  {
    "date": "2017-03-15",
    "close": 9732.0,
    "volume": 67761,
    "contract": "201703"
  },
  {
    "date": "2017-03-16",
    "close": 9840.0,
    "volume": 124172,
    "contract": "201704"
  },
  {
    "date": "2017-03-17",
    "close": 9889.0,
    "volume": 95443,
    "contract": "201704"
  },
  {
    "date": "2017-03-20",
    "close": 9896.0,
    "volume": 87814,
    "contract": "201704"
  },
  {
    "date": "2017-03-21",
    "close": 9963.0,
    "volume": 117665,
    "contract": "201704"
  },
  {
    "date": "2017-03-22",
    "close": 9896.0,
    "volume": 131137,
    "contract": "201704"
  },
  {
    "date": "2017-03-23",
    "close": 9909.0,
    "volume": 124574,
    "contract": "201704"
  },
  {
    "date": "2017-03-24",
    "close": 9900.0,
    "volume": 100432,
    "contract": "201704"
  },
  {
    "date": "2017-03-27",
    "close": 9866.0,
    "volume": 121135,
    "contract": "201704"
  },
  {
    "date": "2017-03-28",
    "close": 9884.0,
    "volume": 180278,
    "contract": "201704"
  },
  {
    "date": "2017-03-29",
    "close": 9860.0,
    "volume": 112257,
    "contract": "201704"
  },
  {
    "date": "2017-03-30",
    "close": 9848.0,
    "volume": 101697,
    "contract": "201704"
  },
  {
    "date": "2017-03-31",
    "close": 9821.0,
    "volume": 97954,
    "contract": "201704"
  },
  {
    "date": "2017-04-05",
    "close": 9962.0,
    "volume": 138318,
    "contract": "201704"
  },
  {
    "date": "2017-04-06",
    "close": 9895.0,
    "volume": 111709,
    "contract": "201704"
  },
  {
    "date": "2017-04-07",
    "close": 9861.0,
    "volume": 202548,
    "contract": "201704"
  },
  {
    "date": "2017-04-10",
    "close": 9875.0,
    "volume": 94012,
    "contract": "201704"
  },
  {
    "date": "2017-04-11",
    "close": 9817.0,
    "volume": 156736,
    "contract": "201704"
  },
  {
    "date": "2017-04-12",
    "close": 9814.0,
    "volume": 119614,
    "contract": "201704"
  },
  {
    "date": "2017-04-13",
    "close": 9845.0,
    "volume": 147700,
    "contract": "201704"
  },
  {
    "date": "2017-04-14",
    "close": 9716.0,
    "volume": 168301,
    "contract": "201704"
  },
  {
    "date": "2017-04-17",
    "close": 9721.0,
    "volume": 166226,
    "contract": "201704"
  },
  {
    "date": "2017-04-18",
    "close": 9736.0,
    "volume": 123870,
    "contract": "201704"
  },
  {
    "date": "2017-04-19",
    "close": 9638.0,
    "volume": 104812,
    "contract": "201704"
  },
  {
    "date": "2017-04-20",
    "close": 9615.0,
    "volume": 114520,
    "contract": "201705"
  },
  {
    "date": "2017-04-21",
    "close": 9698.0,
    "volume": 110196,
    "contract": "201705"
  },
  {
    "date": "2017-04-24",
    "close": 9706.0,
    "volume": 124863,
    "contract": "201705"
  },
  {
    "date": "2017-04-25",
    "close": 9814.0,
    "volume": 140137,
    "contract": "201705"
  },
  {
    "date": "2017-04-26",
    "close": 9842.0,
    "volume": 120562,
    "contract": "201705"
  },
  {
    "date": "2017-04-27",
    "close": 9838.0,
    "volume": 94948,
    "contract": "201705"
  },
  {
    "date": "2017-04-28",
    "close": 9856.0,
    "volume": 107661,
    "contract": "201705"
  },
  {
    "date": "2017-05-02",
    "close": 9930.0,
    "volume": 104635,
    "contract": "201705"
  },
  {
    "date": "2017-05-03",
    "close": 9937.0,
    "volume": 77543,
    "contract": "201705"
  },
  {
    "date": "2017-05-04",
    "close": 9959.0,
    "volume": 87102,
    "contract": "201705"
  },
  {
    "date": "2017-05-05",
    "close": 9886.0,
    "volume": 110276,
    "contract": "201705"
  },
  {
    "date": "2017-05-08",
    "close": 9921.0,
    "volume": 103607,
    "contract": "201705"
  },
  {
    "date": "2017-05-09",
    "close": 9902.0,
    "volume": 165930,
    "contract": "201705"
  },
  {
    "date": "2017-05-10",
    "close": 9948.0,
    "volume": 92446,
    "contract": "201705"
  },
  {
    "date": "2017-05-11",
    "close": 9988.0,
    "volume": 123805,
    "contract": "201705"
  },
  {
    "date": "2017-05-12",
    "close": 9981.0,
    "volume": 86535,
    "contract": "201705"
  },
  {
    "date": "2017-05-15",
    "close": 10025.0,
    "volume": 118391,
    "contract": "201705"
  },
  {
    "date": "2017-05-16",
    "close": 10045.0,
    "volume": 2587,
    "contract": "201705"
  },
  {
    "date": "2017-05-17",
    "close": 10021.0,
    "volume": 1636,
    "contract": "201705"
  },
  {
    "date": "2017-05-18",
    "close": 9895.0,
    "volume": 9404,
    "contract": "201706"
  },
  {
    "date": "2017-05-19",
    "close": 9962.0,
    "volume": 10652,
    "contract": "201706"
  },
  {
    "date": "2017-05-22",
    "close": 9960.0,
    "volume": 6232,
    "contract": "201706"
  },
  {
    "date": "2017-05-23",
    "close": 9990.0,
    "volume": 4286,
    "contract": "201706"
  },
  {
    "date": "2017-05-24",
    "close": 10007.0,
    "volume": 4118,
    "contract": "201706"
  },
  {
    "date": "2017-05-25",
    "close": 10041.0,
    "volume": 3423,
    "contract": "201706"
  },
  {
    "date": "2017-05-26",
    "close": 10132.0,
    "volume": 7124,
    "contract": "201706"
  },
  {
    "date": "2017-05-31",
    "close": 10094.0,
    "volume": 3986,
    "contract": "201706"
  },
  {
    "date": "2017-06-01",
    "close": 10025.0,
    "volume": 6630,
    "contract": "201706"
  },
  {
    "date": "2017-06-02",
    "close": 10098.0,
    "volume": 4300,
    "contract": "201706"
  },
  {
    "date": "2017-06-03",
    "close": 10152.0,
    "volume": 6815,
    "contract": "201706"
  },
  {
    "date": "2017-06-05",
    "close": 10202.0,
    "volume": 109207,
    "contract": "201706"
  },
  {
    "date": "2017-06-06",
    "close": 10200.0,
    "volume": 4086,
    "contract": "201706"
  },
  {
    "date": "2017-06-07",
    "close": 10181.0,
    "volume": 5720,
    "contract": "201706"
  },
  {
    "date": "2017-06-08",
    "close": 10198.0,
    "volume": 3777,
    "contract": "201706"
  },
  {
    "date": "2017-06-09",
    "close": 10230.0,
    "volume": 6565,
    "contract": "201706"
  },
  {
    "date": "2017-06-12",
    "close": 10137.0,
    "volume": 12110,
    "contract": "201706"
  },
  {
    "date": "2017-06-13",
    "close": 10102.0,
    "volume": 11149,
    "contract": "201706"
  },
  {
    "date": "2017-06-14",
    "close": 10158.0,
    "volume": 6480,
    "contract": "201706"
  },
  {
    "date": "2017-06-15",
    "close": 10061.0,
    "volume": 8744,
    "contract": "201706"
  },
  {
    "date": "2017-06-16",
    "close": 10066.0,
    "volume": 13171,
    "contract": "201706"
  },
  {
    "date": "2017-06-19",
    "close": 10149.0,
    "volume": 6244,
    "contract": "201706"
  },
  {
    "date": "2017-06-20",
    "close": 10283.0,
    "volume": 5211,
    "contract": "201706"
  },
  {
    "date": "2017-06-21",
    "close": 10300.0,
    "volume": 5839,
    "contract": "201706"
  },
  {
    "date": "2017-06-22",
    "close": 10194.0,
    "volume": 11637,
    "contract": "201707"
  },
  {
    "date": "2017-06-23",
    "close": 10220.0,
    "volume": 6194,
    "contract": "201707"
  },
  {
    "date": "2017-06-26",
    "close": 10195.0,
    "volume": 11480,
    "contract": "201707"
  },
  {
    "date": "2017-06-27",
    "close": 10394.0,
    "volume": 12213,
    "contract": "201707"
  },
  {
    "date": "2017-06-28",
    "close": 10297.0,
    "volume": 12266,
    "contract": "201707"
  },
  {
    "date": "2017-06-29",
    "close": 10317.0,
    "volume": 14299,
    "contract": "201707"
  },
  {
    "date": "2017-06-30",
    "close": 10223.0,
    "volume": 24285,
    "contract": "201707"
  },
  {
    "date": "2017-07-03",
    "close": 10257.0,
    "volume": 15359,
    "contract": "201707"
  },
  {
    "date": "2017-07-04",
    "close": 10302.0,
    "volume": 11795,
    "contract": "201707"
  },
  {
    "date": "2017-07-05",
    "close": 10220.0,
    "volume": 5766,
    "contract": "201707"
  },
  {
    "date": "2017-07-06",
    "close": 10321.0,
    "volume": 13181,
    "contract": "201707"
  },
  {
    "date": "2017-07-07",
    "close": 10217.0,
    "volume": 16288,
    "contract": "201707"
  },
  {
    "date": "2017-07-10",
    "close": 10224.0,
    "volume": 13469,
    "contract": "201707"
  },
  {
    "date": "2017-07-11",
    "close": 10222.0,
    "volume": 9338,
    "contract": "201707"
  },
  {
    "date": "2017-07-12",
    "close": 10352.0,
    "volume": 11304,
    "contract": "201707"
  },
  {
    "date": "2017-07-13",
    "close": 10387.0,
    "volume": 13832,
    "contract": "201707"
  },
  {
    "date": "2017-07-14",
    "close": 10418.0,
    "volume": 13545,
    "contract": "201707"
  },
  {
    "date": "2017-07-17",
    "close": 10445.0,
    "volume": 10385,
    "contract": "201707"
  },
  {
    "date": "2017-07-18",
    "close": 10431.0,
    "volume": 5962,
    "contract": "201707"
  },
  {
    "date": "2017-07-19",
    "close": 10474.0,
    "volume": 10753,
    "contract": "201707"
  },
  {
    "date": "2017-07-20",
    "close": 10424.0,
    "volume": 8071,
    "contract": "201708"
  },
  {
    "date": "2017-07-21",
    "close": 10380.0,
    "volume": 9694,
    "contract": "201708"
  },
  {
    "date": "2017-07-24",
    "close": 10308.0,
    "volume": 13486,
    "contract": "201708"
  },
  {
    "date": "2017-07-25",
    "close": 10363.0,
    "volume": 7280,
    "contract": "201708"
  },
  {
    "date": "2017-07-26",
    "close": 10385.0,
    "volume": 9246,
    "contract": "201708"
  },
  {
    "date": "2017-07-27",
    "close": 10354.0,
    "volume": 7932,
    "contract": "201708"
  },
  {
    "date": "2017-07-28",
    "close": 10422.0,
    "volume": 14708,
    "contract": "201708"
  },
  {
    "date": "2017-07-31",
    "close": 10348.0,
    "volume": 9109,
    "contract": "201708"
  },
  {
    "date": "2017-08-01",
    "close": 10348.0,
    "volume": 8491,
    "contract": "201708"
  },
  {
    "date": "2017-08-02",
    "close": 10393.0,
    "volume": 9566,
    "contract": "201708"
  },
  {
    "date": "2017-08-03",
    "close": 10451.0,
    "volume": 14649,
    "contract": "201708"
  },
  {
    "date": "2017-08-04",
    "close": 10398.0,
    "volume": 8653,
    "contract": "201708"
  },
  {
    "date": "2017-08-07",
    "close": 10455.0,
    "volume": 8062,
    "contract": "201708"
  },
  {
    "date": "2017-08-08",
    "close": 10564.0,
    "volume": 6629,
    "contract": "201708"
  },
  {
    "date": "2017-08-09",
    "close": 10508.0,
    "volume": 9280,
    "contract": "201708"
  },
  {
    "date": "2017-08-10",
    "close": 10462.0,
    "volume": 13566,
    "contract": "201708"
  },
  {
    "date": "2017-08-11",
    "close": 10225.0,
    "volume": 25345,
    "contract": "201708"
  },
  {
    "date": "2017-08-14",
    "close": 10317.0,
    "volume": 17743,
    "contract": "201708"
  },
  {
    "date": "2017-08-15",
    "close": 10290.0,
    "volume": 13234,
    "contract": "201708"
  },
  {
    "date": "2017-08-16",
    "close": 10278.0,
    "volume": 16563,
    "contract": "201708"
  },
  {
    "date": "2017-08-17",
    "close": 10250.0,
    "volume": 13289,
    "contract": "201709"
  },
  {
    "date": "2017-08-18",
    "close": 10216.0,
    "volume": 21878,
    "contract": "201709"
  },
  {
    "date": "2017-08-21",
    "close": 10253.0,
    "volume": 23196,
    "contract": "201709"
  },
  {
    "date": "2017-08-22",
    "close": 10284.0,
    "volume": 13655,
    "contract": "201709"
  },
  {
    "date": "2017-08-23",
    "close": 10416.0,
    "volume": 14726,
    "contract": "201709"
  },
  {
    "date": "2017-08-24",
    "close": 10351.0,
    "volume": 12548,
    "contract": "201709"
  },
  {
    "date": "2017-08-25",
    "close": 10476.0,
    "volume": 22473,
    "contract": "201709"
  },
  {
    "date": "2017-08-28",
    "close": 10498.0,
    "volume": 13580,
    "contract": "201709"
  },
  {
    "date": "2017-08-29",
    "close": 10504.0,
    "volume": 11325,
    "contract": "201709"
  },
  {
    "date": "2017-08-30",
    "close": 10494.0,
    "volume": 20959,
    "contract": "201709"
  },
  {
    "date": "2017-08-31",
    "close": 10559.0,
    "volume": 12845,
    "contract": "201709"
  },
  {
    "date": "2017-09-01",
    "close": 10574.0,
    "volume": 10754,
    "contract": "201709"
  },
  {
    "date": "2017-09-04",
    "close": 10588.0,
    "volume": 8632,
    "contract": "201709"
  },
  {
    "date": "2017-09-05",
    "close": 10565.0,
    "volume": 5954,
    "contract": "201709"
  },
  {
    "date": "2017-09-06",
    "close": 10524.0,
    "volume": 21175,
    "contract": "201709"
  },
  {
    "date": "2017-09-07",
    "close": 10541.0,
    "volume": 13651,
    "contract": "201709"
  },
  {
    "date": "2017-09-08",
    "close": 10509.0,
    "volume": 14589,
    "contract": "201709"
  },
  {
    "date": "2017-09-11",
    "close": 10556.0,
    "volume": 10780,
    "contract": "201709"
  },
  {
    "date": "2017-09-12",
    "close": 10611.0,
    "volume": 10817,
    "contract": "201709"
  },
  {
    "date": "2017-09-13",
    "close": 10597.0,
    "volume": 8819,
    "contract": "201709"
  },
  {
    "date": "2017-09-14",
    "close": 10510.0,
    "volume": 10852,
    "contract": "201709"
  },
  {
    "date": "2017-09-15",
    "close": 10537.0,
    "volume": 8864,
    "contract": "201709"
  },
  {
    "date": "2017-09-18",
    "close": 10589.0,
    "volume": 7350,
    "contract": "201709"
  },
  {
    "date": "2017-09-19",
    "close": 10652.0,
    "volume": 7166,
    "contract": "201709"
  },
  {
    "date": "2017-09-20",
    "close": 10579.0,
    "volume": 6790,
    "contract": "201709"
  },
  {
    "date": "2017-09-21",
    "close": 10502.0,
    "volume": 13013,
    "contract": "201710"
  },
  {
    "date": "2017-09-22",
    "close": 10564.0,
    "volume": 9070,
    "contract": "201710"
  },
  {
    "date": "2017-09-25",
    "close": 10423.0,
    "volume": 11598,
    "contract": "201710"
  },
  {
    "date": "2017-09-26",
    "close": 10303.0,
    "volume": 18348,
    "contract": "201710"
  },
  {
    "date": "2017-09-27",
    "close": 10296.0,
    "volume": 15294,
    "contract": "201710"
  },
  {
    "date": "2017-09-28",
    "close": 10349.0,
    "volume": 15086,
    "contract": "201710"
  },
  {
    "date": "2017-09-29",
    "close": 10299.0,
    "volume": 12257,
    "contract": "201710"
  },
  {
    "date": "2017-09-30",
    "close": 10349.0,
    "volume": 8935,
    "contract": "201710"
  },
  {
    "date": "2017-10-02",
    "close": 10450.0,
    "volume": 110414,
    "contract": "201710"
  },
  {
    "date": "2017-10-03",
    "close": 10475.0,
    "volume": 10849,
    "contract": "201710"
  },
  {
    "date": "2017-10-05",
    "close": 10464.0,
    "volume": 4471,
    "contract": "201710"
  },
  {
    "date": "2017-10-06",
    "close": 10539.0,
    "volume": 7934,
    "contract": "201710"
  },
  {
    "date": "2017-10-11",
    "close": 10516.0,
    "volume": 6692,
    "contract": "201710"
  },
  {
    "date": "2017-10-12",
    "close": 10652.0,
    "volume": 5864,
    "contract": "201710"
  },
  {
    "date": "2017-10-13",
    "close": 10685.0,
    "volume": 5784,
    "contract": "201710"
  },
  {
    "date": "2017-10-16",
    "close": 10725.0,
    "volume": 8346,
    "contract": "201710"
  },
  {
    "date": "2017-10-17",
    "close": 10777.0,
    "volume": 5634,
    "contract": "201710"
  },
  {
    "date": "2017-10-18",
    "close": 10733.0,
    "volume": 5378,
    "contract": "201710"
  },
  {
    "date": "2017-10-19",
    "close": 10753.0,
    "volume": 13050,
    "contract": "201711"
  },
  {
    "date": "2017-10-20",
    "close": 10726.0,
    "volume": 32871,
    "contract": "201711"
  },
  {
    "date": "2017-10-23",
    "close": 10756.0,
    "volume": 10324,
    "contract": "201711"
  },
  {
    "date": "2017-10-24",
    "close": 10712.0,
    "volume": 8835,
    "contract": "201711"
  },
  {
    "date": "2017-10-25",
    "close": 10772.0,
    "volume": 11069,
    "contract": "201711"
  },
  {
    "date": "2017-10-26",
    "close": 10712.0,
    "volume": 17788,
    "contract": "201711"
  },
  {
    "date": "2017-10-27",
    "close": 10746.0,
    "volume": 10873,
    "contract": "201711"
  },
  {
    "date": "2017-10-30",
    "close": 10752.0,
    "volume": 18497,
    "contract": "201711"
  },
  {
    "date": "2017-10-31",
    "close": 10744.0,
    "volume": 13024,
    "contract": "201711"
  },
  {
    "date": "2017-11-01",
    "close": 10793.0,
    "volume": 6883,
    "contract": "201711"
  },
  {
    "date": "2017-11-02",
    "close": 10792.0,
    "volume": 16712,
    "contract": "201711"
  },
  {
    "date": "2017-11-03",
    "close": 10805.0,
    "volume": 13210,
    "contract": "201711"
  },
  {
    "date": "2017-11-06",
    "close": 10790.0,
    "volume": 10188,
    "contract": "201711"
  },
  {
    "date": "2017-11-07",
    "close": 10783.0,
    "volume": 7060,
    "contract": "201711"
  },
  {
    "date": "2017-11-08",
    "close": 10813.0,
    "volume": 10989,
    "contract": "201711"
  },
  {
    "date": "2017-11-09",
    "close": 10809.0,
    "volume": 6017,
    "contract": "201711"
  },
  {
    "date": "2017-11-10",
    "close": 10689.0,
    "volume": 25524,
    "contract": "201711"
  },
  {
    "date": "2017-11-13",
    "close": 10716.0,
    "volume": 12349,
    "contract": "201711"
  },
  {
    "date": "2017-11-14",
    "close": 10694.0,
    "volume": 12156,
    "contract": "201711"
  },
  {
    "date": "2017-11-15",
    "close": 10659.0,
    "volume": 10684,
    "contract": "201711"
  },
  {
    "date": "2017-11-16",
    "close": 10566.0,
    "volume": 22669,
    "contract": "201712"
  },
  {
    "date": "2017-11-17",
    "close": 10668.0,
    "volume": 14238,
    "contract": "201712"
  },
  {
    "date": "2017-11-20",
    "close": 10712.0,
    "volume": 13746,
    "contract": "201712"
  },
  {
    "date": "2017-11-21",
    "close": 10692.0,
    "volume": 10013,
    "contract": "201712"
  },
  {
    "date": "2017-11-22",
    "close": 10828.0,
    "volume": 13735,
    "contract": "201712"
  },
  {
    "date": "2017-11-23",
    "close": 10829.0,
    "volume": 13692,
    "contract": "201712"
  },
  {
    "date": "2017-11-24",
    "close": 10846.0,
    "volume": 12233,
    "contract": "201712"
  },
  {
    "date": "2017-11-27",
    "close": 10865.0,
    "volume": 7913,
    "contract": "201712"
  },
  {
    "date": "2017-11-28",
    "close": 10731.0,
    "volume": 13155,
    "contract": "201712"
  },
  {
    "date": "2017-11-29",
    "close": 10752.0,
    "volume": 13031,
    "contract": "201712"
  },
  {
    "date": "2017-11-30",
    "close": 10651.0,
    "volume": 31871,
    "contract": "201712"
  },
  {
    "date": "2017-12-01",
    "close": 10612.0,
    "volume": 22866,
    "contract": "201712"
  },
  {
    "date": "2017-12-04",
    "close": 10571.0,
    "volume": 44224,
    "contract": "201712"
  },
  {
    "date": "2017-12-05",
    "close": 10608.0,
    "volume": 20280,
    "contract": "201712"
  },
  {
    "date": "2017-12-06",
    "close": 10551.0,
    "volume": 19459,
    "contract": "201712"
  },
  {
    "date": "2017-12-07",
    "close": 10360.0,
    "volume": 35312,
    "contract": "201712"
  },
  {
    "date": "2017-12-08",
    "close": 10388.0,
    "volume": 21353,
    "contract": "201712"
  },
  {
    "date": "2017-12-11",
    "close": 10409.0,
    "volume": 14331,
    "contract": "201712"
  },
  {
    "date": "2017-12-12",
    "close": 10496.0,
    "volume": 9606,
    "contract": "201712"
  },
  {
    "date": "2017-12-13",
    "close": 10434.0,
    "volume": 9428,
    "contract": "201712"
  },
  {
    "date": "2017-12-14",
    "close": 10490.0,
    "volume": 13707,
    "contract": "201712"
  },
  {
    "date": "2017-12-15",
    "close": 10514.0,
    "volume": 12335,
    "contract": "201712"
  },
  {
    "date": "2017-12-18",
    "close": 10509.0,
    "volume": 16856,
    "contract": "201712"
  },
  {
    "date": "2017-12-19",
    "close": 10531.0,
    "volume": 9747,
    "contract": "201712"
  },
  {
    "date": "2017-12-20",
    "close": 10445.0,
    "volume": 10865,
    "contract": "201712"
  },
  {
    "date": "2017-12-21",
    "close": 10508.0,
    "volume": 15150,
    "contract": "201801"
  },
  {
    "date": "2017-12-22",
    "close": 10500.0,
    "volume": 8853,
    "contract": "201801"
  },
  {
    "date": "2017-12-25",
    "close": 10537.0,
    "volume": 7129,
    "contract": "201801"
  },
  {
    "date": "2017-12-26",
    "close": 10532.0,
    "volume": 1515,
    "contract": "201801"
  },
  {
    "date": "2017-12-27",
    "close": 10402.0,
    "volume": 13272,
    "contract": "201801"
  },
  {
    "date": "2017-12-28",
    "close": 10488.0,
    "volume": 8666,
    "contract": "201801"
  },
  {
    "date": "2017-12-29",
    "close": 10581.0,
    "volume": 7435,
    "contract": "201801"
  },
  {
    "date": "2018-01-02",
    "close": 10708.0,
    "volume": 108602,
    "contract": "201801"
  },
  {
    "date": "2018-01-03",
    "close": 10788.0,
    "volume": 120998,
    "contract": "201801"
  },
  {
    "date": "2018-01-04",
    "close": 10837.0,
    "volume": 119190,
    "contract": "201801"
  },
  {
    "date": "2018-01-05",
    "close": 10858.0,
    "volume": 110637,
    "contract": "201801"
  },
  {
    "date": "2018-01-08",
    "close": 10884.0,
    "volume": 106537,
    "contract": "201801"
  },
  {
    "date": "2018-01-09",
    "close": 10879.0,
    "volume": 97025,
    "contract": "201801"
  },
  {
    "date": "2018-01-10",
    "close": 10810.0,
    "volume": 132570,
    "contract": "201801"
  },
  {
    "date": "2018-01-11",
    "close": 10799.0,
    "volume": 135869,
    "contract": "201801"
  },
  {
    "date": "2018-01-12",
    "close": 10876.0,
    "volume": 124266,
    "contract": "201801"
  },
  {
    "date": "2018-01-15",
    "close": 10956.0,
    "volume": 134712,
    "contract": "201801"
  },
  {
    "date": "2018-01-16",
    "close": 10983.0,
    "volume": 118376,
    "contract": "201801"
  },
  {
    "date": "2018-01-17",
    "close": 11020.0,
    "volume": 85210,
    "contract": "201801"
  },
  {
    "date": "2018-01-18",
    "close": 11058.0,
    "volume": 179169,
    "contract": "201802"
  },
  {
    "date": "2018-01-19",
    "close": 11138.0,
    "volume": 106496,
    "contract": "201802"
  },
  {
    "date": "2018-01-22",
    "close": 11222.0,
    "volume": 139799,
    "contract": "201802"
  },
  {
    "date": "2018-01-23",
    "close": 11225.0,
    "volume": 152547,
    "contract": "201802"
  },
  {
    "date": "2018-01-24",
    "close": 11125.0,
    "volume": 171874,
    "contract": "201802"
  },
  {
    "date": "2018-01-25",
    "close": 11149.0,
    "volume": 207680,
    "contract": "201802"
  },
  {
    "date": "2018-01-26",
    "close": 11144.0,
    "volume": 172894,
    "contract": "201802"
  },
  {
    "date": "2018-01-29",
    "close": 11197.0,
    "volume": 139210,
    "contract": "201802"
  },
  {
    "date": "2018-01-30",
    "close": 11065.0,
    "volume": 176699,
    "contract": "201802"
  },
  {
    "date": "2018-01-31",
    "close": 11098.0,
    "volume": 190849,
    "contract": "201802"
  },
  {
    "date": "2018-02-01",
    "close": 11160.0,
    "volume": 141148,
    "contract": "201802"
  },
  {
    "date": "2018-02-02",
    "close": 11114.0,
    "volume": 176534,
    "contract": "201802"
  },
  {
    "date": "2018-02-05",
    "close": 10927.0,
    "volume": 185574,
    "contract": "201802"
  },
  {
    "date": "2018-02-06",
    "close": 10396.0,
    "volume": 409245,
    "contract": "201802"
  },
  {
    "date": "2018-02-07",
    "close": 10518.0,
    "volume": 236946,
    "contract": "201802"
  },
  {
    "date": "2018-02-08",
    "close": 10518.0,
    "volume": 182147,
    "contract": "201802"
  },
  {
    "date": "2018-02-09",
    "close": 10353.0,
    "volume": 257335,
    "contract": "201802"
  },
  {
    "date": "2018-02-12",
    "close": 10413.0,
    "volume": 151528,
    "contract": "201802"
  },
  {
    "date": "2018-02-21",
    "close": 10705.0,
    "volume": 94033,
    "contract": "201802"
  },
  {
    "date": "2018-02-22",
    "close": 10624.0,
    "volume": 124336,
    "contract": "201803"
  },
  {
    "date": "2018-02-23",
    "close": 10782.0,
    "volume": 131504,
    "contract": "201803"
  },
  {
    "date": "2018-02-26",
    "close": 10820.0,
    "volume": 101181,
    "contract": "201803"
  },
  {
    "date": "2018-02-27",
    "close": 10789.0,
    "volume": 119787,
    "contract": "201803"
  },
  {
    "date": "2018-03-01",
    "close": 10734.0,
    "volume": 150471,
    "contract": "201803"
  },
  {
    "date": "2018-03-02",
    "close": 10678.0,
    "volume": 167243,
    "contract": "201803"
  },
  {
    "date": "2018-03-05",
    "close": 10632.0,
    "volume": 172804,
    "contract": "201803"
  },
  {
    "date": "2018-03-06",
    "close": 10786.0,
    "volume": 142401,
    "contract": "201803"
  },
  {
    "date": "2018-03-07",
    "close": 10708.0,
    "volume": 158990,
    "contract": "201803"
  },
  {
    "date": "2018-03-08",
    "close": 10827.0,
    "volume": 119702,
    "contract": "201803"
  },
  {
    "date": "2018-03-09",
    "close": 10862.0,
    "volume": 128355,
    "contract": "201803"
  },
  {
    "date": "2018-03-12",
    "close": 11022.0,
    "volume": 122637,
    "contract": "201803"
  },
  {
    "date": "2018-03-13",
    "close": 11099.0,
    "volume": 108806,
    "contract": "201803"
  },
  {
    "date": "2018-03-14",
    "close": 11030.0,
    "volume": 127357,
    "contract": "201803"
  },
  {
    "date": "2018-03-15",
    "close": 11041.0,
    "volume": 111968,
    "contract": "201803"
  },
  {
    "date": "2018-03-16",
    "close": 11016.0,
    "volume": 189713,
    "contract": "201803"
  },
  {
    "date": "2018-03-19",
    "close": 11026.0,
    "volume": 151802,
    "contract": "201803"
  },
  {
    "date": "2018-03-20",
    "close": 11011.0,
    "volume": 123903,
    "contract": "201803"
  },
  {
    "date": "2018-03-21",
    "close": 11044.0,
    "volume": 80714,
    "contract": "201803"
  },
  {
    "date": "2018-03-22",
    "close": 10990.0,
    "volume": 192263,
    "contract": "201804"
  },
  {
    "date": "2018-03-23",
    "close": 10733.0,
    "volume": 178593,
    "contract": "201804"
  },
  {
    "date": "2018-03-26",
    "close": 10840.0,
    "volume": 147862,
    "contract": "201804"
  },
  {
    "date": "2018-03-27",
    "close": 10989.0,
    "volume": 131507,
    "contract": "201804"
  },
  {
    "date": "2018-03-28",
    "close": 10819.0,
    "volume": 155315,
    "contract": "201804"
  },
  {
    "date": "2018-03-29",
    "close": 10840.0,
    "volume": 149221,
    "contract": "201804"
  },
  {
    "date": "2018-03-30",
    "close": 10918.0,
    "volume": 111968,
    "contract": "201804"
  },
  {
    "date": "2018-03-31",
    "close": 10924.0,
    "volume": 24169,
    "contract": "201804"
  },
  {
    "date": "2018-04-02",
    "close": 10863.0,
    "volume": 137934,
    "contract": "201804"
  },
  {
    "date": "2018-04-03",
    "close": 10783.0,
    "volume": 133955,
    "contract": "201804"
  },
  {
    "date": "2018-04-09",
    "close": 10903.0,
    "volume": 155952,
    "contract": "201804"
  },
  {
    "date": "2018-04-10",
    "close": 10948.0,
    "volume": 172575,
    "contract": "201804"
  },
  {
    "date": "2018-04-11",
    "close": 10977.0,
    "volume": 119383,
    "contract": "201804"
  },
  {
    "date": "2018-04-12",
    "close": 10942.0,
    "volume": 145737,
    "contract": "201804"
  },
  {
    "date": "2018-04-13",
    "close": 10957.0,
    "volume": 118585,
    "contract": "201804"
  },
  {
    "date": "2018-04-16",
    "close": 10942.0,
    "volume": 145646,
    "contract": "201804"
  },
  {
    "date": "2018-04-17",
    "close": 10807.0,
    "volume": 156247,
    "contract": "201804"
  },
  {
    "date": "2018-04-18",
    "close": 10845.0,
    "volume": 106426,
    "contract": "201804"
  },
  {
    "date": "2018-04-19",
    "close": 10967.0,
    "volume": 147058,
    "contract": "201805"
  },
  {
    "date": "2018-04-20",
    "close": 10786.0,
    "volume": 168412,
    "contract": "201805"
  },
  {
    "date": "2018-04-23",
    "close": 10691.0,
    "volume": 143144,
    "contract": "201805"
  },
  {
    "date": "2018-04-24",
    "close": 10585.0,
    "volume": 185925,
    "contract": "201805"
  },
  {
    "date": "2018-04-25",
    "close": 10535.0,
    "volume": 167276,
    "contract": "201805"
  },
  {
    "date": "2018-04-26",
    "close": 10475.0,
    "volume": 173837,
    "contract": "201805"
  },
  {
    "date": "2018-04-27",
    "close": 10560.0,
    "volume": 138888,
    "contract": "201805"
  },
  {
    "date": "2018-04-30",
    "close": 10653.0,
    "volume": 132890,
    "contract": "201805"
  },
  {
    "date": "2018-05-02",
    "close": 10609.0,
    "volume": 119121,
    "contract": "201805"
  },
  {
    "date": "2018-05-03",
    "close": 10506.0,
    "volume": 145487,
    "contract": "201805"
  },
  {
    "date": "2018-05-04",
    "close": 10522.0,
    "volume": 146168,
    "contract": "201805"
  },
  {
    "date": "2018-05-07",
    "close": 10594.0,
    "volume": 139344,
    "contract": "201805"
  },
  {
    "date": "2018-05-08",
    "close": 10667.0,
    "volume": 120547,
    "contract": "201805"
  },
  {
    "date": "2018-05-09",
    "close": 10703.0,
    "volume": 138372,
    "contract": "201805"
  },
  {
    "date": "2018-05-10",
    "close": 10763.0,
    "volume": 117424,
    "contract": "201805"
  },
  {
    "date": "2018-05-11",
    "close": 10860.0,
    "volume": 127629,
    "contract": "201805"
  },
  {
    "date": "2018-05-14",
    "close": 10956.0,
    "volume": 132634,
    "contract": "201805"
  },
  {
    "date": "2018-05-15",
    "close": 10866.0,
    "volume": 137727,
    "contract": "201805"
  },
  {
    "date": "2018-05-16",
    "close": 10872.0,
    "volume": 89647,
    "contract": "201805"
  },
  {
    "date": "2018-05-17",
    "close": 10824.0,
    "volume": 126166,
    "contract": "201806"
  },
  {
    "date": "2018-05-18",
    "close": 10819.0,
    "volume": 109398,
    "contract": "201806"
  },
  {
    "date": "2018-05-21",
    "close": 10963.0,
    "volume": 101176,
    "contract": "201806"
  },
  {
    "date": "2018-05-22",
    "close": 10920.0,
    "volume": 114865,
    "contract": "201806"
  },
  {
    "date": "2018-05-23",
    "close": 10857.0,
    "volume": 138032,
    "contract": "201806"
  },
  {
    "date": "2018-05-24",
    "close": 10917.0,
    "volume": 113285,
    "contract": "201806"
  },
  {
    "date": "2018-05-25",
    "close": 10932.0,
    "volume": 107432,
    "contract": "201806"
  },
  {
    "date": "2018-05-28",
    "close": 10983.0,
    "volume": 93268,
    "contract": "201806"
  },
  {
    "date": "2018-05-29",
    "close": 10929.0,
    "volume": 119010,
    "contract": "201806"
  },
  {
    "date": "2018-05-30",
    "close": 10776.0,
    "volume": 151570,
    "contract": "201806"
  },
  {
    "date": "2018-05-31",
    "close": 10865.0,
    "volume": 124660,
    "contract": "201806"
  },
  {
    "date": "2018-06-01",
    "close": 10914.0,
    "volume": 111930,
    "contract": "201806"
  },
  {
    "date": "2018-06-04",
    "close": 11084.0,
    "volume": 109687,
    "contract": "201806"
  },
  {
    "date": "2018-06-05",
    "close": 11069.0,
    "volume": 119504,
    "contract": "201806"
  },
  {
    "date": "2018-06-06",
    "close": 11198.0,
    "volume": 134205,
    "contract": "201806"
  },
  {
    "date": "2018-06-07",
    "close": 11227.0,
    "volume": 127407,
    "contract": "201806"
  },
  {
    "date": "2018-06-08",
    "close": 11125.0,
    "volume": 122509,
    "contract": "201806"
  },
  {
    "date": "2018-06-11",
    "close": 11128.0,
    "volume": 104423,
    "contract": "201806"
  },
  {
    "date": "2018-06-12",
    "close": 11141.0,
    "volume": 159832,
    "contract": "201806"
  },
  {
    "date": "2018-06-13",
    "close": 11146.0,
    "volume": 114215,
    "contract": "201806"
  },
  {
    "date": "2018-06-14",
    "close": 10985.0,
    "volume": 143124,
    "contract": "201806"
  },
  {
    "date": "2018-06-15",
    "close": 11054.0,
    "volume": 145449,
    "contract": "201806"
  },
  {
    "date": "2018-06-19",
    "close": 10875.0,
    "volume": 170249,
    "contract": "201806"
  },
  {
    "date": "2018-06-20",
    "close": 10936.0,
    "volume": 109099,
    "contract": "201806"
  },
  {
    "date": "2018-06-21",
    "close": 10707.0,
    "volume": 130352,
    "contract": "201807"
  },
  {
    "date": "2018-06-22",
    "close": 10655.0,
    "volume": 141860,
    "contract": "201807"
  },
  {
    "date": "2018-06-25",
    "close": 10584.0,
    "volume": 122274,
    "contract": "201807"
  },
  {
    "date": "2018-06-26",
    "close": 10592.0,
    "volume": 167431,
    "contract": "201807"
  },
  {
    "date": "2018-06-27",
    "close": 10556.0,
    "volume": 134481,
    "contract": "201807"
  },
  {
    "date": "2018-06-28",
    "close": 10523.0,
    "volume": 150442,
    "contract": "201807"
  },
  {
    "date": "2018-06-29",
    "close": 10677.0,
    "volume": 155640,
    "contract": "201807"
  },
  {
    "date": "2018-07-02",
    "close": 10610.0,
    "volume": 141723,
    "contract": "201807"
  },
  {
    "date": "2018-07-03",
    "close": 10621.0,
    "volume": 221125,
    "contract": "201807"
  },
  {
    "date": "2018-07-04",
    "close": 10617.0,
    "volume": 130994,
    "contract": "201807"
  },
  {
    "date": "2018-07-05",
    "close": 10501.0,
    "volume": 191745,
    "contract": "201807"
  },
  {
    "date": "2018-07-06",
    "close": 10538.0,
    "volume": 218771,
    "contract": "201807"
  },
  {
    "date": "2018-07-09",
    "close": 10662.0,
    "volume": 147171,
    "contract": "201807"
  },
  {
    "date": "2018-07-10",
    "close": 10708.0,
    "volume": 122142,
    "contract": "201807"
  },
  {
    "date": "2018-07-11",
    "close": 10614.0,
    "volume": 177783,
    "contract": "201807"
  },
  {
    "date": "2018-07-12",
    "close": 10738.0,
    "volume": 147260,
    "contract": "201807"
  },
  {
    "date": "2018-07-13",
    "close": 10848.0,
    "volume": 133034,
    "contract": "201807"
  },
  {
    "date": "2018-07-16",
    "close": 10813.0,
    "volume": 137166,
    "contract": "201807"
  },
  {
    "date": "2018-07-17",
    "close": 10769.0,
    "volume": 150847,
    "contract": "201807"
  },
  {
    "date": "2018-07-18",
    "close": 10844.0,
    "volume": 89274,
    "contract": "201807"
  },
  {
    "date": "2018-07-19",
    "close": 10720.0,
    "volume": 142334,
    "contract": "201808"
  },
  {
    "date": "2018-07-20",
    "close": 10824.0,
    "volume": 191859,
    "contract": "201808"
  },
  {
    "date": "2018-07-23",
    "close": 10829.0,
    "volume": 142476,
    "contract": "201808"
  },
  {
    "date": "2018-07-24",
    "close": 10871.0,
    "volume": 115304,
    "contract": "201808"
  },
  {
    "date": "2018-07-25",
    "close": 10864.0,
    "volume": 96247,
    "contract": "201808"
  },
  {
    "date": "2018-07-26",
    "close": 10914.0,
    "volume": 117119,
    "contract": "201808"
  },
  {
    "date": "2018-07-27",
    "close": 10991.0,
    "volume": 111649,
    "contract": "201808"
  },
  {
    "date": "2018-07-30",
    "close": 10939.0,
    "volume": 117666,
    "contract": "201808"
  },
  {
    "date": "2018-07-31",
    "close": 10990.0,
    "volume": 116649,
    "contract": "201808"
  },
  {
    "date": "2018-08-01",
    "close": 11044.0,
    "volume": 96117,
    "contract": "201808"
  },
  {
    "date": "2018-08-02",
    "close": 10872.0,
    "volume": 168828,
    "contract": "201808"
  },
  {
    "date": "2018-08-03",
    "close": 10967.0,
    "volume": 107878,
    "contract": "201808"
  },
  {
    "date": "2018-08-06",
    "close": 10980.0,
    "volume": 133767,
    "contract": "201808"
  },
  {
    "date": "2018-08-07",
    "close": 10968.0,
    "volume": 104241,
    "contract": "201808"
  },
  {
    "date": "2018-08-08",
    "close": 11047.0,
    "volume": 115922,
    "contract": "201808"
  },
  {
    "date": "2018-08-09",
    "close": 11017.0,
    "volume": 118059,
    "contract": "201808"
  },
  {
    "date": "2018-08-10",
    "close": 10961.0,
    "volume": 121790,
    "contract": "201808"
  },
  {
    "date": "2018-08-13",
    "close": 10756.0,
    "volume": 228396,
    "contract": "201808"
  },
  {
    "date": "2018-08-14",
    "close": 10818.0,
    "volume": 145603,
    "contract": "201808"
  },
  {
    "date": "2018-08-15",
    "close": 10737.0,
    "volume": 112549,
    "contract": "201808"
  },
  {
    "date": "2018-08-16",
    "close": 10687.0,
    "volume": 160436,
    "contract": "201809"
  },
  {
    "date": "2018-08-17",
    "close": 10661.0,
    "volume": 118840,
    "contract": "201809"
  },
  {
    "date": "2018-08-20",
    "close": 10670.0,
    "volume": 120121,
    "contract": "201809"
  },
  {
    "date": "2018-08-21",
    "close": 10766.0,
    "volume": 126191,
    "contract": "201809"
  },
  {
    "date": "2018-08-22",
    "close": 10763.0,
    "volume": 124070,
    "contract": "201809"
  },
  {
    "date": "2018-08-23",
    "close": 10840.0,
    "volume": 150200,
    "contract": "201809"
  },
  {
    "date": "2018-08-24",
    "close": 10787.0,
    "volume": 143666,
    "contract": "201809"
  },
  {
    "date": "2018-08-27",
    "close": 10885.0,
    "volume": 127704,
    "contract": "201809"
  },
  {
    "date": "2018-08-28",
    "close": 10954.0,
    "volume": 115627,
    "contract": "201809"
  },
  {
    "date": "2018-08-29",
    "close": 11041.0,
    "volume": 130889,
    "contract": "201809"
  },
  {
    "date": "2018-08-30",
    "close": 11022.0,
    "volume": 160151,
    "contract": "201809"
  },
  {
    "date": "2018-08-31",
    "close": 11022.0,
    "volume": 136261,
    "contract": "201809"
  },
  {
    "date": "2018-09-03",
    "close": 10934.0,
    "volume": 141943,
    "contract": "201809"
  },
  {
    "date": "2018-09-04",
    "close": 11002.0,
    "volume": 131455,
    "contract": "201809"
  },
  {
    "date": "2018-09-05",
    "close": 10949.0,
    "volume": 151692,
    "contract": "201809"
  },
  {
    "date": "2018-09-06",
    "close": 10900.0,
    "volume": 165409,
    "contract": "201809"
  },
  {
    "date": "2018-09-07",
    "close": 10845.0,
    "volume": 178235,
    "contract": "201809"
  },
  {
    "date": "2018-09-10",
    "close": 10734.0,
    "volume": 198790,
    "contract": "201809"
  },
  {
    "date": "2018-09-11",
    "close": 10741.0,
    "volume": 171082,
    "contract": "201809"
  },
  {
    "date": "2018-09-12",
    "close": 10724.0,
    "volume": 161851,
    "contract": "201809"
  },
  {
    "date": "2018-09-13",
    "close": 10718.0,
    "volume": 140045,
    "contract": "201809"
  },
  {
    "date": "2018-09-14",
    "close": 10879.0,
    "volume": 167546,
    "contract": "201809"
  },
  {
    "date": "2018-09-17",
    "close": 10824.0,
    "volume": 130683,
    "contract": "201809"
  },
  {
    "date": "2018-09-18",
    "close": 10781.0,
    "volume": 155686,
    "contract": "201809"
  },
  {
    "date": "2018-09-19",
    "close": 10873.0,
    "volume": 70379,
    "contract": "201809"
  },
  {
    "date": "2018-09-20",
    "close": 10847.0,
    "volume": 147069,
    "contract": "201810"
  },
  {
    "date": "2018-09-21",
    "close": 10972.0,
    "volume": 160951,
    "contract": "201810"
  },
  {
    "date": "2018-09-25",
    "close": 10978.0,
    "volume": 98858,
    "contract": "201810"
  },
  {
    "date": "2018-09-26",
    "close": 10972.0,
    "volume": 107637,
    "contract": "201810"
  },
  {
    "date": "2018-09-27",
    "close": 10980.0,
    "volume": 136789,
    "contract": "201810"
  },
  {
    "date": "2018-09-28",
    "close": 10955.0,
    "volume": 162520,
    "contract": "201810"
  },
  {
    "date": "2018-10-01",
    "close": 11006.0,
    "volume": 89433,
    "contract": "201810"
  },
  {
    "date": "2018-10-02",
    "close": 10879.0,
    "volume": 156457,
    "contract": "201810"
  },
  {
    "date": "2018-10-03",
    "close": 10854.0,
    "volume": 136321,
    "contract": "201810"
  },
  {
    "date": "2018-10-04",
    "close": 10697.0,
    "volume": 160072,
    "contract": "201810"
  },
  {
    "date": "2018-10-05",
    "close": 10510.0,
    "volume": 256183,
    "contract": "201810"
  },
  {
    "date": "2018-10-08",
    "close": 10464.0,
    "volume": 174770,
    "contract": "201810"
  },
  {
    "date": "2018-10-09",
    "close": 10461.0,
    "volume": 153437,
    "contract": "201810"
  },
  {
    "date": "2018-10-11",
    "close": 9654.0,
    "volume": 348653,
    "contract": "201810"
  },
  {
    "date": "2018-10-12",
    "close": 9958.0,
    "volume": 251156,
    "contract": "201810"
  },
  {
    "date": "2018-10-15",
    "close": 9862.0,
    "volume": 164909,
    "contract": "201810"
  },
  {
    "date": "2018-10-16",
    "close": 9949.0,
    "volume": 197823,
    "contract": "201810"
  },
  {
    "date": "2018-10-17",
    "close": 9993.0,
    "volume": 106223,
    "contract": "201810"
  },
  {
    "date": "2018-10-18",
    "close": 9883.0,
    "volume": 151011,
    "contract": "201811"
  },
  {
    "date": "2018-10-19",
    "close": 9901.0,
    "volume": 179393,
    "contract": "201811"
  },
  {
    "date": "2018-10-22",
    "close": 9935.0,
    "volume": 178167,
    "contract": "201811"
  },
  {
    "date": "2018-10-23",
    "close": 9729.0,
    "volume": 186988,
    "contract": "201811"
  },
  {
    "date": "2018-10-24",
    "close": 9715.0,
    "volume": 221429,
    "contract": "201811"
  },
  {
    "date": "2018-10-25",
    "close": 9486.0,
    "volume": 205902,
    "contract": "201811"
  },
  {
    "date": "2018-10-26",
    "close": 9424.0,
    "volume": 241595,
    "contract": "201811"
  },
  {
    "date": "2018-10-29",
    "close": 9472.0,
    "volume": 162497,
    "contract": "201811"
  },
  {
    "date": "2018-10-30",
    "close": 9523.0,
    "volume": 169621,
    "contract": "201811"
  },
  {
    "date": "2018-10-31",
    "close": 9725.0,
    "volume": 166496,
    "contract": "201811"
  },
  {
    "date": "2018-11-01",
    "close": 9788.0,
    "volume": 140555,
    "contract": "201811"
  },
  {
    "date": "2018-11-02",
    "close": 9872.0,
    "volume": 153413,
    "contract": "201811"
  },
  {
    "date": "2018-11-05",
    "close": 9817.0,
    "volume": 145973,
    "contract": "201811"
  },
  {
    "date": "2018-11-06",
    "close": 9774.0,
    "volume": 122426,
    "contract": "201811"
  },
  {
    "date": "2018-11-07",
    "close": 9847.0,
    "volume": 154891,
    "contract": "201811"
  },
  {
    "date": "2018-11-08",
    "close": 9922.0,
    "volume": 115590,
    "contract": "201811"
  },
  {
    "date": "2018-11-09",
    "close": 9791.0,
    "volume": 138795,
    "contract": "201811"
  },
  {
    "date": "2018-11-12",
    "close": 9812.0,
    "volume": 115102,
    "contract": "201811"
  },
  {
    "date": "2018-11-13",
    "close": 9726.0,
    "volume": 170110,
    "contract": "201811"
  },
  {
    "date": "2018-11-14",
    "close": 9768.0,
    "volume": 111585,
    "contract": "201811"
  },
  {
    "date": "2018-11-15",
    "close": 9827.0,
    "volume": 155283,
    "contract": "201811"
  },
  {
    "date": "2018-11-16",
    "close": 9785.0,
    "volume": 147344,
    "contract": "201811"
  },
  {
    "date": "2018-11-19",
    "close": 9818.0,
    "volume": 111237,
    "contract": "201811"
  },
  {
    "date": "2018-11-20",
    "close": 9732.0,
    "volume": 150456,
    "contract": "201811"
  },
  {
    "date": "2018-11-21",
    "close": 9743.0,
    "volume": 75719,
    "contract": "201811"
  },
  {
    "date": "2018-11-22",
    "close": 9714.0,
    "volume": 91042,
    "contract": "201812"
  },
  {
    "date": "2018-11-23",
    "close": 9625.0,
    "volume": 113555,
    "contract": "201812"
  },
  {
    "date": "2018-11-26",
    "close": 9769.0,
    "volume": 147457,
    "contract": "201812"
  },
  {
    "date": "2018-11-27",
    "close": 9739.0,
    "volume": 133623,
    "contract": "201812"
  },
  {
    "date": "2018-11-28",
    "close": 9868.0,
    "volume": 147701,
    "contract": "201812"
  },
  {
    "date": "2018-11-29",
    "close": 9877.0,
    "volume": 130827,
    "contract": "201812"
  },
  {
    "date": "2018-11-30",
    "close": 9854.0,
    "volume": 121317,
    "contract": "201812"
  },
  {
    "date": "2018-12-03",
    "close": 10119.0,
    "volume": 135162,
    "contract": "201812"
  },
  {
    "date": "2018-12-04",
    "close": 10040.0,
    "volume": 105118,
    "contract": "201812"
  },
  {
    "date": "2018-12-05",
    "close": 9878.0,
    "volume": 129691,
    "contract": "201812"
  },
  {
    "date": "2018-12-06",
    "close": 9672.0,
    "volume": 164887,
    "contract": "201812"
  },
  {
    "date": "2018-12-07",
    "close": 9746.0,
    "volume": 105451,
    "contract": "201812"
  },
  {
    "date": "2018-12-10",
    "close": 9626.0,
    "volume": 116350,
    "contract": "201812"
  },
  {
    "date": "2018-12-11",
    "close": 9687.0,
    "volume": 114010,
    "contract": "201812"
  },
  {
    "date": "2018-12-12",
    "close": 9814.0,
    "volume": 132304,
    "contract": "201812"
  },
  {
    "date": "2018-12-13",
    "close": 9852.0,
    "volume": 109467,
    "contract": "201812"
  },
  {
    "date": "2018-12-14",
    "close": 9729.0,
    "volume": 145379,
    "contract": "201812"
  },
  {
    "date": "2018-12-17",
    "close": 9790.0,
    "volume": 127930,
    "contract": "201812"
  },
  {
    "date": "2018-12-18",
    "close": 9717.0,
    "volume": 144686,
    "contract": "201812"
  },
  {
    "date": "2018-12-19",
    "close": 9768.0,
    "volume": 54588,
    "contract": "201812"
  },
  {
    "date": "2018-12-20",
    "close": 9639.0,
    "volume": 141731,
    "contract": "201901"
  },
  {
    "date": "2018-12-21",
    "close": 9657.0,
    "volume": 122129,
    "contract": "201901"
  },
  {
    "date": "2018-12-22",
    "close": 9586.0,
    "volume": 23776,
    "contract": "201901"
  },
  {
    "date": "2018-12-24",
    "close": 9618.0,
    "volume": 89050,
    "contract": "201901"
  },
  {
    "date": "2018-12-25",
    "close": 9477.0,
    "volume": 99787,
    "contract": "201901"
  },
  {
    "date": "2018-12-26",
    "close": 9453.0,
    "volume": 116623,
    "contract": "201901"
  },
  {
    "date": "2018-12-27",
    "close": 9633.0,
    "volume": 124097,
    "contract": "201901"
  },
  {
    "date": "2018-12-28",
    "close": 9669.0,
    "volume": 92809,
    "contract": "201901"
  },
  {
    "date": "2019-01-02",
    "close": 9529.0,
    "volume": 165922,
    "contract": "201901"
  },
  {
    "date": "2019-01-03",
    "close": 9443.0,
    "volume": 130686,
    "contract": "201901"
  },
  {
    "date": "2019-01-04",
    "close": 9370.0,
    "volume": 168796,
    "contract": "201901"
  },
  {
    "date": "2019-01-07",
    "close": 9563.0,
    "volume": 145208,
    "contract": "201901"
  },
  {
    "date": "2019-01-08",
    "close": 9558.0,
    "volume": 121996,
    "contract": "201901"
  },
  {
    "date": "2019-01-09",
    "close": 9709.0,
    "volume": 161013,
    "contract": "201901"
  },
  {
    "date": "2019-01-10",
    "close": 9694.0,
    "volume": 96870,
    "contract": "201901"
  },
  {
    "date": "2019-01-11",
    "close": 9750.0,
    "volume": 137362,
    "contract": "201901"
  },
  {
    "date": "2019-01-14",
    "close": 9689.0,
    "volume": 133304,
    "contract": "201901"
  },
  {
    "date": "2019-01-15",
    "close": 9794.0,
    "volume": 158065,
    "contract": "201901"
  },
  {
    "date": "2019-01-16",
    "close": 9784.0,
    "volume": 62359,
    "contract": "201901"
  },
  {
    "date": "2019-01-17",
    "close": 9779.0,
    "volume": 142688,
    "contract": "201902"
  },
  {
    "date": "2019-01-18",
    "close": 9821.0,
    "volume": 115290,
    "contract": "201902"
  },
  {
    "date": "2019-01-21",
    "close": 9864.0,
    "volume": 119821,
    "contract": "201902"
  },
  {
    "date": "2019-01-22",
    "close": 9845.0,
    "volume": 93410,
    "contract": "201902"
  },
  {
    "date": "2019-01-23",
    "close": 9819.0,
    "volume": 106263,
    "contract": "201902"
  },
  {
    "date": "2019-01-24",
    "close": 9860.0,
    "volume": 104491,
    "contract": "201902"
  },
  {
    "date": "2019-01-25",
    "close": 9968.0,
    "volume": 116395,
    "contract": "201902"
  },
  {
    "date": "2019-01-28",
    "close": 9986.0,
    "volume": 81405,
    "contract": "201902"
  },
  {
    "date": "2019-01-29",
    "close": 9922.0,
    "volume": 113746,
    "contract": "201902"
  },
  {
    "date": "2019-01-30",
    "close": 9924.0,
    "volume": 83963,
    "contract": "201902"
  },
  {
    "date": "2019-02-11",
    "close": 9998.0,
    "volume": 101469,
    "contract": "201902"
  },
  {
    "date": "2019-02-12",
    "close": 10084.0,
    "volume": 79049,
    "contract": "201902"
  },
  {
    "date": "2019-02-13",
    "close": 10085.0,
    "volume": 96794,
    "contract": "201902"
  },
  {
    "date": "2019-02-14",
    "close": 10079.0,
    "volume": 97857,
    "contract": "201902"
  },
  {
    "date": "2019-02-15",
    "close": 10042.0,
    "volume": 121921,
    "contract": "201902"
  },
  {
    "date": "2019-02-18",
    "close": 10138.0,
    "volume": 113809,
    "contract": "201902"
  },
  {
    "date": "2019-02-19",
    "close": 10143.0,
    "volume": 93983,
    "contract": "201902"
  },
  {
    "date": "2019-02-20",
    "close": 10256.0,
    "volume": 73350,
    "contract": "201902"
  },
  {
    "date": "2019-02-21",
    "close": 10323.0,
    "volume": 97337,
    "contract": "201903"
  },
  {
    "date": "2019-02-22",
    "close": 10308.0,
    "volume": 87939,
    "contract": "201903"
  },
  {
    "date": "2019-02-25",
    "close": 10366.0,
    "volume": 104882,
    "contract": "201903"
  },
  {
    "date": "2019-02-26",
    "close": 10352.0,
    "volume": 100522,
    "contract": "201903"
  },
  {
    "date": "2019-02-27",
    "close": 10361.0,
    "volume": 83461,
    "contract": "201903"
  },
  {
    "date": "2019-03-04",
    "close": 10312.0,
    "volume": 122715,
    "contract": "201903"
  },
  {
    "date": "2019-03-05",
    "close": 10275.0,
    "volume": 97390,
    "contract": "201903"
  },
  {
    "date": "2019-03-06",
    "close": 10322.0,
    "volume": 91094,
    "contract": "201903"
  },
  {
    "date": "2019-03-07",
    "close": 10261.0,
    "volume": 95914,
    "contract": "201903"
  },
  {
    "date": "2019-03-08",
    "close": 10201.0,
    "volume": 127917,
    "contract": "201903"
  },
  {
    "date": "2019-03-11",
    "close": 10227.0,
    "volume": 78910,
    "contract": "201903"
  },
  {
    "date": "2019-03-12",
    "close": 10348.0,
    "volume": 109945,
    "contract": "201903"
  },
  {
    "date": "2019-03-13",
    "close": 10363.0,
    "volume": 100182,
    "contract": "201903"
  },
  {
    "date": "2019-03-14",
    "close": 10337.0,
    "volume": 92686,
    "contract": "201903"
  },
  {
    "date": "2019-03-15",
    "close": 10413.0,
    "volume": 116100,
    "contract": "201903"
  },
  {
    "date": "2019-03-18",
    "close": 10478.0,
    "volume": 104180,
    "contract": "201903"
  },
  {
    "date": "2019-03-19",
    "close": 10501.0,
    "volume": 101703,
    "contract": "201903"
  },
  {
    "date": "2019-03-20",
    "close": 10545.0,
    "volume": 56166,
    "contract": "201903"
  },
  {
    "date": "2019-03-21",
    "close": 10588.0,
    "volume": 90838,
    "contract": "201904"
  },
  {
    "date": "2019-03-22",
    "close": 10613.0,
    "volume": 107634,
    "contract": "201904"
  },
  {
    "date": "2019-03-25",
    "close": 10437.0,
    "volume": 100215,
    "contract": "201904"
  },
  {
    "date": "2019-03-26",
    "close": 10523.0,
    "volume": 87187,
    "contract": "201904"
  },
  {
    "date": "2019-03-27",
    "close": 10520.0,
    "volume": 88500,
    "contract": "201904"
  },
  {
    "date": "2019-03-28",
    "close": 10493.0,
    "volume": 83464,
    "contract": "201904"
  },
  {
    "date": "2019-03-29",
    "close": 10598.0,
    "volume": 128163,
    "contract": "201904"
  },
  {
    "date": "2019-04-01",
    "close": 10640.0,
    "volume": 114429,
    "contract": "201904"
  },
  {
    "date": "2019-04-02",
    "close": 10678.0,
    "volume": 78347,
    "contract": "201904"
  },
  {
    "date": "2019-04-03",
    "close": 10695.0,
    "volume": 93675,
    "contract": "201904"
  },
  {
    "date": "2019-04-08",
    "close": 10770.0,
    "volume": 92630,
    "contract": "201904"
  },
  {
    "date": "2019-04-09",
    "close": 10843.0,
    "volume": 70930,
    "contract": "201904"
  },
  {
    "date": "2019-04-10",
    "close": 10861.0,
    "volume": 69994,
    "contract": "201904"
  },
  {
    "date": "2019-04-11",
    "close": 10806.0,
    "volume": 110887,
    "contract": "201904"
  },
  {
    "date": "2019-04-12",
    "close": 10802.0,
    "volume": 85901,
    "contract": "201904"
  },
  {
    "date": "2019-04-15",
    "close": 10876.0,
    "volume": 100286,
    "contract": "201904"
  },
  {
    "date": "2019-04-16",
    "close": 10930.0,
    "volume": 104554,
    "contract": "201904"
  },
  {
    "date": "2019-04-17",
    "close": 11004.0,
    "volume": 63683,
    "contract": "201904"
  },
  {
    "date": "2019-04-18",
    "close": 10938.0,
    "volume": 117490,
    "contract": "201905"
  },
  {
    "date": "2019-04-19",
    "close": 10973.0,
    "volume": 88747,
    "contract": "201905"
  },
  {
    "date": "2019-04-22",
    "close": 10978.0,
    "volume": 77384,
    "contract": "201905"
  },
  {
    "date": "2019-04-23",
    "close": 11023.0,
    "volume": 103861,
    "contract": "201905"
  },
  {
    "date": "2019-04-24",
    "close": 11009.0,
    "volume": 108063,
    "contract": "201905"
  },
  {
    "date": "2019-04-25",
    "close": 11030.0,
    "volume": 86847,
    "contract": "201905"
  },
  {
    "date": "2019-04-26",
    "close": 10934.0,
    "volume": 118536,
    "contract": "201905"
  },
  {
    "date": "2019-04-29",
    "close": 10933.0,
    "volume": 90107,
    "contract": "201905"
  },
  {
    "date": "2019-04-30",
    "close": 10952.0,
    "volume": 99311,
    "contract": "201905"
  },
  {
    "date": "2019-05-02",
    "close": 10978.0,
    "volume": 110504,
    "contract": "201905"
  },
  {
    "date": "2019-05-03",
    "close": 11092.0,
    "volume": 105128,
    "contract": "201905"
  },
  {
    "date": "2019-05-06",
    "close": 10860.0,
    "volume": 157627,
    "contract": "201905"
  },
  {
    "date": "2019-05-07",
    "close": 10971.0,
    "volume": 112695,
    "contract": "201905"
  },
  {
    "date": "2019-05-08",
    "close": 10893.0,
    "volume": 122471,
    "contract": "201905"
  },
  {
    "date": "2019-05-09",
    "close": 10747.0,
    "volume": 163378,
    "contract": "201905"
  },
  {
    "date": "2019-05-10",
    "close": 10744.0,
    "volume": 244648,
    "contract": "201905"
  },
  {
    "date": "2019-05-13",
    "close": 10574.0,
    "volume": 166126,
    "contract": "201905"
  },
  {
    "date": "2019-05-14",
    "close": 10531.0,
    "volume": 182739,
    "contract": "201905"
  },
  {
    "date": "2019-05-15",
    "close": 10579.0,
    "volume": 84213,
    "contract": "201905"
  },
  {
    "date": "2019-05-16",
    "close": 10489.0,
    "volume": 136852,
    "contract": "201906"
  },
  {
    "date": "2019-05-17",
    "close": 10413.0,
    "volume": 148067,
    "contract": "201906"
  },
  {
    "date": "2019-05-20",
    "close": 10432.0,
    "volume": 138410,
    "contract": "201906"
  },
  {
    "date": "2019-05-21",
    "close": 10487.0,
    "volume": 139337,
    "contract": "201906"
  },
  {
    "date": "2019-05-22",
    "close": 10479.0,
    "volume": 116942,
    "contract": "201906"
  },
  {
    "date": "2019-05-23",
    "close": 10311.0,
    "volume": 140826,
    "contract": "201906"
  },
  {
    "date": "2019-05-24",
    "close": 10341.0,
    "volume": 110221,
    "contract": "201906"
  },
  {
    "date": "2019-05-27",
    "close": 10332.0,
    "volume": 103116,
    "contract": "201906"
  },
  {
    "date": "2019-05-28",
    "close": 10340.0,
    "volume": 87667,
    "contract": "201906"
  },
  {
    "date": "2019-05-29",
    "close": 10291.0,
    "volume": 94603,
    "contract": "201906"
  },
  {
    "date": "2019-05-30",
    "close": 10365.0,
    "volume": 118886,
    "contract": "201906"
  },
  {
    "date": "2019-05-31",
    "close": 10455.0,
    "volume": 132616,
    "contract": "201906"
  },
  {
    "date": "2019-06-03",
    "close": 10471.0,
    "volume": 129111,
    "contract": "201906"
  },
  {
    "date": "2019-06-04",
    "close": 10416.0,
    "volume": 91946,
    "contract": "201906"
  },
  {
    "date": "2019-06-05",
    "close": 10456.0,
    "volume": 101638,
    "contract": "201906"
  },
  {
    "date": "2019-06-06",
    "close": 10365.0,
    "volume": 112358,
    "contract": "201906"
  },
  {
    "date": "2019-06-10",
    "close": 10540.0,
    "volume": 122498,
    "contract": "201906"
  },
  {
    "date": "2019-06-11",
    "close": 10590.0,
    "volume": 102065,
    "contract": "201906"
  },
  {
    "date": "2019-06-12",
    "close": 10591.0,
    "volume": 88158,
    "contract": "201906"
  },
  {
    "date": "2019-06-13",
    "close": 10528.0,
    "volume": 115701,
    "contract": "201906"
  },
  {
    "date": "2019-06-14",
    "close": 10528.0,
    "volume": 87499,
    "contract": "201906"
  },
  {
    "date": "2019-06-17",
    "close": 10545.0,
    "volume": 126622,
    "contract": "201906"
  },
  {
    "date": "2019-06-18",
    "close": 10554.0,
    "volume": 89907,
    "contract": "201906"
  },
  {
    "date": "2019-06-19",
    "close": 10770.0,
    "volume": 82967,
    "contract": "201906"
  },
  {
    "date": "2019-06-20",
    "close": 10592.0,
    "volume": 82664,
    "contract": "201907"
  },
  {
    "date": "2019-06-21",
    "close": 10586.0,
    "volume": 96638,
    "contract": "201907"
  },
  {
    "date": "2019-06-24",
    "close": 10622.0,
    "volume": 91686,
    "contract": "201907"
  },
  {
    "date": "2019-06-25",
    "close": 10539.0,
    "volume": 99176,
    "contract": "201907"
  },
  {
    "date": "2019-06-26",
    "close": 10505.0,
    "volume": 84635,
    "contract": "201907"
  },
  {
    "date": "2019-06-27",
    "close": 10621.0,
    "volume": 107467,
    "contract": "201907"
  },
  {
    "date": "2019-06-28",
    "close": 10577.0,
    "volume": 82329,
    "contract": "201907"
  },
  {
    "date": "2019-07-01",
    "close": 10766.0,
    "volume": 97751,
    "contract": "201907"
  },
  {
    "date": "2019-07-02",
    "close": 10749.0,
    "volume": 61053,
    "contract": "201907"
  },
  {
    "date": "2019-07-03",
    "close": 10641.0,
    "volume": 110757,
    "contract": "201907"
  },
  {
    "date": "2019-07-04",
    "close": 10707.0,
    "volume": 77799,
    "contract": "201907"
  },
  {
    "date": "2019-07-05",
    "close": 10718.0,
    "volume": 77791,
    "contract": "201907"
  },
  {
    "date": "2019-07-08",
    "close": 10665.0,
    "volume": 105869,
    "contract": "201907"
  },
  {
    "date": "2019-07-09",
    "close": 10650.0,
    "volume": 79635,
    "contract": "201907"
  },
  {
    "date": "2019-07-10",
    "close": 10732.0,
    "volume": 99635,
    "contract": "201907"
  },
  {
    "date": "2019-07-11",
    "close": 10813.0,
    "volume": 86527,
    "contract": "201907"
  },
  {
    "date": "2019-07-12",
    "close": 10811.0,
    "volume": 77492,
    "contract": "201907"
  },
  {
    "date": "2019-07-15",
    "close": 10849.0,
    "volume": 142849,
    "contract": "201907"
  },
  {
    "date": "2019-07-16",
    "close": 10878.0,
    "volume": 94778,
    "contract": "201907"
  },
  {
    "date": "2019-07-17",
    "close": 10831.0,
    "volume": 73472,
    "contract": "201907"
  },
  {
    "date": "2019-07-18",
    "close": 10651.0,
    "volume": 78967,
    "contract": "201908"
  },
  {
    "date": "2019-07-19",
    "close": 10740.0,
    "volume": 96597,
    "contract": "201908"
  },
  {
    "date": "2019-07-22",
    "close": 10795.0,
    "volume": 78276,
    "contract": "201908"
  },
  {
    "date": "2019-07-23",
    "close": 10803.0,
    "volume": 76794,
    "contract": "201908"
  },
  {
    "date": "2019-07-24",
    "close": 10804.0,
    "volume": 66376,
    "contract": "201908"
  },
  {
    "date": "2019-07-25",
    "close": 10822.0,
    "volume": 73933,
    "contract": "201908"
  },
  {
    "date": "2019-07-26",
    "close": 10788.0,
    "volume": 53262,
    "contract": "201908"
  },
  {
    "date": "2019-07-29",
    "close": 10782.0,
    "volume": 83205,
    "contract": "201908"
  },
  {
    "date": "2019-07-30",
    "close": 10752.0,
    "volume": 91827,
    "contract": "201908"
  },
  {
    "date": "2019-07-31",
    "close": 10736.0,
    "volume": 103963,
    "contract": "201908"
  },
  {
    "date": "2019-08-01",
    "close": 10644.0,
    "volume": 109370,
    "contract": "201908"
  },
  {
    "date": "2019-08-02",
    "close": 10469.0,
    "volume": 142909,
    "contract": "201908"
  },
  {
    "date": "2019-08-05",
    "close": 10376.0,
    "volume": 135670,
    "contract": "201908"
  },
  {
    "date": "2019-08-06",
    "close": 10329.0,
    "volume": 199053,
    "contract": "201908"
  },
  {
    "date": "2019-08-07",
    "close": 10346.0,
    "volume": 113948,
    "contract": "201908"
  },
  {
    "date": "2019-08-08",
    "close": 10436.0,
    "volume": 122318,
    "contract": "201908"
  },
  {
    "date": "2019-08-12",
    "close": 10439.0,
    "volume": 87087,
    "contract": "201908"
  },
  {
    "date": "2019-08-13",
    "close": 10343.0,
    "volume": 102839,
    "contract": "201908"
  },
  {
    "date": "2019-08-14",
    "close": 10429.0,
    "volume": 107891,
    "contract": "201908"
  },
  {
    "date": "2019-08-15",
    "close": 10300.0,
    "volume": 117015,
    "contract": "201908"
  },
  {
    "date": "2019-08-16",
    "close": 10412.0,
    "volume": 135144,
    "contract": "201908"
  },
  {
    "date": "2019-08-19",
    "close": 10481.0,
    "volume": 113319,
    "contract": "201908"
  },
  {
    "date": "2019-08-20",
    "close": 10526.0,
    "volume": 94358,
    "contract": "201908"
  },
  {
    "date": "2019-08-21",
    "close": 10528.0,
    "volume": 61159,
    "contract": "201908"
  },
  {
    "date": "2019-08-22",
    "close": 10476.0,
    "volume": 105769,
    "contract": "201909"
  },
  {
    "date": "2019-08-23",
    "close": 10497.0,
    "volume": 76901,
    "contract": "201909"
  },
  {
    "date": "2019-08-26",
    "close": 10307.0,
    "volume": 120532,
    "contract": "201909"
  },
  {
    "date": "2019-08-27",
    "close": 10363.0,
    "volume": 73290,
    "contract": "201909"
  },
  {
    "date": "2019-08-28",
    "close": 10412.0,
    "volume": 86584,
    "contract": "201909"
  },
  {
    "date": "2019-08-29",
    "close": 10430.0,
    "volume": 84003,
    "contract": "201909"
  },
  {
    "date": "2019-08-30",
    "close": 10577.0,
    "volume": 79713,
    "contract": "201909"
  },
  {
    "date": "2019-09-02",
    "close": 10603.0,
    "volume": 60427,
    "contract": "201909"
  },
  {
    "date": "2019-09-03",
    "close": 10543.0,
    "volume": 91892,
    "contract": "201909"
  },
  {
    "date": "2019-09-04",
    "close": 10644.0,
    "volume": 86712,
    "contract": "201909"
  },
  {
    "date": "2019-09-05",
    "close": 10734.0,
    "volume": 91108,
    "contract": "201909"
  },
  {
    "date": "2019-09-06",
    "close": 10767.0,
    "volume": 68005,
    "contract": "201909"
  },
  {
    "date": "2019-09-09",
    "close": 10793.0,
    "volume": 68953,
    "contract": "201909"
  },
  {
    "date": "2019-09-10",
    "close": 10742.0,
    "volume": 76441,
    "contract": "201909"
  },
  {
    "date": "2019-09-11",
    "close": 10774.0,
    "volume": 89245,
    "contract": "201909"
  },
  {
    "date": "2019-09-12",
    "close": 10824.0,
    "volume": 101288,
    "contract": "201909"
  },
  {
    "date": "2019-09-16",
    "close": 10878.0,
    "volume": 107760,
    "contract": "201909"
  },
  {
    "date": "2019-09-17",
    "close": 10865.0,
    "volume": 86095,
    "contract": "201909"
  },
  {
    "date": "2019-09-18",
    "close": 10959.0,
    "volume": 59301,
    "contract": "201909"
  },
  {
    "date": "2019-09-19",
    "close": 10867.0,
    "volume": 91304,
    "contract": "201910"
  },
  {
    "date": "2019-09-20",
    "close": 10899.0,
    "volume": 60402,
    "contract": "201910"
  },
  {
    "date": "2019-09-23",
    "close": 10892.0,
    "volume": 75227,
    "contract": "201910"
  },
  {
    "date": "2019-09-24",
    "close": 10905.0,
    "volume": 89403,
    "contract": "201910"
  },
  {
    "date": "2019-09-25",
    "close": 10841.0,
    "volume": 100205,
    "contract": "201910"
  },
  {
    "date": "2019-09-26",
    "close": 10843.0,
    "volume": 83512,
    "contract": "201910"
  },
  {
    "date": "2019-09-27",
    "close": 10823.0,
    "volume": 94839,
    "contract": "201910"
  },
  {
    "date": "2019-10-01",
    "close": 10953.0,
    "volume": 91075,
    "contract": "201910"
  },
  {
    "date": "2019-10-02",
    "close": 10923.0,
    "volume": 67011,
    "contract": "201910"
  },
  {
    "date": "2019-10-03",
    "close": 10849.0,
    "volume": 97211,
    "contract": "201910"
  },
  {
    "date": "2019-10-04",
    "close": 10877.0,
    "volume": 106799,
    "contract": "201910"
  },
  {
    "date": "2019-10-07",
    "close": 10914.0,
    "volume": 68946,
    "contract": "201910"
  },
  {
    "date": "2019-10-08",
    "close": 11000.0,
    "volume": 85671,
    "contract": "201910"
  },
  {
    "date": "2019-10-09",
    "close": 10883.0,
    "volume": 90482,
    "contract": "201910"
  },
  {
    "date": "2019-10-14",
    "close": 11073.0,
    "volume": 114852,
    "contract": "201910"
  },
  {
    "date": "2019-10-15",
    "close": 11107.0,
    "volume": 99518,
    "contract": "201910"
  },
  {
    "date": "2019-10-16",
    "close": 11145.0,
    "volume": 66943,
    "contract": "201910"
  },
  {
    "date": "2019-10-17",
    "close": 11158.0,
    "volume": 56152,
    "contract": "201911"
  },
  {
    "date": "2019-10-18",
    "close": 11149.0,
    "volume": 91145,
    "contract": "201911"
  },
  {
    "date": "2019-10-21",
    "close": 11157.0,
    "volume": 54208,
    "contract": "201911"
  },
  {
    "date": "2019-10-22",
    "close": 11240.0,
    "volume": 78469,
    "contract": "201911"
  },
  {
    "date": "2019-10-23",
    "close": 11200.0,
    "volume": 79441,
    "contract": "201911"
  },
  {
    "date": "2019-10-24",
    "close": 11288.0,
    "volume": 71647,
    "contract": "201911"
  },
  {
    "date": "2019-10-25",
    "close": 11283.0,
    "volume": 61411,
    "contract": "201911"
  },
  {
    "date": "2019-10-28",
    "close": 11311.0,
    "volume": 52213,
    "contract": "201911"
  },
  {
    "date": "2019-10-29",
    "close": 11325.0,
    "volume": 80689,
    "contract": "201911"
  },
  {
    "date": "2019-10-30",
    "close": 11338.0,
    "volume": 66641,
    "contract": "201911"
  },
  {
    "date": "2019-10-31",
    "close": 11344.0,
    "volume": 74398,
    "contract": "201911"
  },
  {
    "date": "2019-11-01",
    "close": 11371.0,
    "volume": 60298,
    "contract": "201911"
  },
  {
    "date": "2019-11-04",
    "close": 11542.0,
    "volume": 102908,
    "contract": "201911"
  },
  {
    "date": "2019-11-05",
    "close": 11645.0,
    "volume": 85555,
    "contract": "201911"
  },
  {
    "date": "2019-11-06",
    "close": 11650.0,
    "volume": 89714,
    "contract": "201911"
  },
  {
    "date": "2019-11-07",
    "close": 11596.0,
    "volume": 98305,
    "contract": "201911"
  },
  {
    "date": "2019-11-08",
    "close": 11572.0,
    "volume": 93120,
    "contract": "201911"
  },
  {
    "date": "2019-11-11",
    "close": 11437.0,
    "volume": 115934,
    "contract": "201911"
  },
  {
    "date": "2019-11-12",
    "close": 11524.0,
    "volume": 77144,
    "contract": "201911"
  },
  {
    "date": "2019-11-13",
    "close": 11466.0,
    "volume": 104040,
    "contract": "201911"
  },
  {
    "date": "2019-11-14",
    "close": 11456.0,
    "volume": 106892,
    "contract": "201911"
  },
  {
    "date": "2019-11-15",
    "close": 11532.0,
    "volume": 107490,
    "contract": "201911"
  },
  {
    "date": "2019-11-18",
    "close": 11592.0,
    "volume": 107411,
    "contract": "201911"
  },
  {
    "date": "2019-11-19",
    "close": 11645.0,
    "volume": 96240,
    "contract": "201911"
  },
  {
    "date": "2019-11-20",
    "close": 11607.0,
    "volume": 62136,
    "contract": "201911"
  },
  {
    "date": "2019-11-21",
    "close": 11545.0,
    "volume": 135473,
    "contract": "201912"
  },
  {
    "date": "2019-11-22",
    "close": 11554.0,
    "volume": 80409,
    "contract": "201912"
  },
  {
    "date": "2019-11-25",
    "close": 11566.0,
    "volume": 87376,
    "contract": "201912"
  },
  {
    "date": "2019-11-26",
    "close": 11618.0,
    "volume": 107977,
    "contract": "201912"
  },
  {
    "date": "2019-11-27",
    "close": 11647.0,
    "volume": 70898,
    "contract": "201912"
  },
  {
    "date": "2019-11-28",
    "close": 11613.0,
    "volume": 88687,
    "contract": "201912"
  },
  {
    "date": "2019-11-29",
    "close": 11464.0,
    "volume": 131564,
    "contract": "201912"
  },
  {
    "date": "2019-12-02",
    "close": 11502.0,
    "volume": 90579,
    "contract": "201912"
  },
  {
    "date": "2019-12-03",
    "close": 11523.0,
    "volume": 88994,
    "contract": "201912"
  },
  {
    "date": "2019-12-04",
    "close": 11502.0,
    "volume": 106806,
    "contract": "201912"
  },
  {
    "date": "2019-12-05",
    "close": 11598.0,
    "volume": 91837,
    "contract": "201912"
  },
  {
    "date": "2019-12-06",
    "close": 11611.0,
    "volume": 88309,
    "contract": "201912"
  },
  {
    "date": "2019-12-09",
    "close": 11671.0,
    "volume": 78956,
    "contract": "201912"
  },
  {
    "date": "2019-12-10",
    "close": 11624.0,
    "volume": 73085,
    "contract": "201912"
  },
  {
    "date": "2019-12-11",
    "close": 11704.0,
    "volume": 92546,
    "contract": "201912"
  },
  {
    "date": "2019-12-12",
    "close": 11851.0,
    "volume": 119427,
    "contract": "201912"
  },
  {
    "date": "2019-12-13",
    "close": 11963.0,
    "volume": 117530,
    "contract": "201912"
  },
  {
    "date": "2019-12-16",
    "close": 11959.0,
    "volume": 95670,
    "contract": "201912"
  },
  {
    "date": "2019-12-17",
    "close": 12099.0,
    "volume": 111124,
    "contract": "201912"
  },
  {
    "date": "2019-12-18",
    "close": 12118.0,
    "volume": 54946,
    "contract": "201912"
  },
  {
    "date": "2019-12-19",
    "close": 12031.0,
    "volume": 92209,
    "contract": "202001"
  },
  {
    "date": "2019-12-20",
    "close": 11979.0,
    "volume": 126757,
    "contract": "202001"
  },
  {
    "date": "2019-12-23",
    "close": 12020.0,
    "volume": 75298,
    "contract": "202001"
  },
  {
    "date": "2019-12-24",
    "close": 11983.0,
    "volume": 55384,
    "contract": "202001"
  },
  {
    "date": "2019-12-25",
    "close": 12019.0,
    "volume": 41599,
    "contract": "202001"
  },
  {
    "date": "2019-12-26",
    "close": 12007.0,
    "volume": 52249,
    "contract": "202001"
  },
  {
    "date": "2019-12-27",
    "close": 12097.0,
    "volume": 74454,
    "contract": "202001"
  },
  {
    "date": "2019-12-30",
    "close": 12069.0,
    "volume": 66062,
    "contract": "202001"
  },
  {
    "date": "2019-12-31",
    "close": 11994.0,
    "volume": 74341,
    "contract": "202001"
  },
  {
    "date": "2020-01-02",
    "close": 12101.0,
    "volume": 100401,
    "contract": "202001"
  },
  {
    "date": "2020-01-03",
    "close": 12087.0,
    "volume": 172660,
    "contract": "202001"
  },
  {
    "date": "2020-01-06",
    "close": 11949.0,
    "volume": 118380,
    "contract": "202001"
  },
  {
    "date": "2020-01-07",
    "close": 11871.0,
    "volume": 157264,
    "contract": "202001"
  },
  {
    "date": "2020-01-08",
    "close": 11788.0,
    "volume": 158971,
    "contract": "202001"
  },
  {
    "date": "2020-01-09",
    "close": 11969.0,
    "volume": 115014,
    "contract": "202001"
  },
  {
    "date": "2020-01-10",
    "close": 12011.0,
    "volume": 114171,
    "contract": "202001"
  },
  {
    "date": "2020-01-13",
    "close": 12116.0,
    "volume": 142642,
    "contract": "202001"
  },
  {
    "date": "2020-01-14",
    "close": 12181.0,
    "volume": 104397,
    "contract": "202001"
  },
  {
    "date": "2020-01-15",
    "close": 12063.0,
    "volume": 89882,
    "contract": "202001"
  },
  {
    "date": "2020-01-16",
    "close": 12052.0,
    "volume": 106272,
    "contract": "202002"
  },
  {
    "date": "2020-01-17",
    "close": 12071.0,
    "volume": 101199,
    "contract": "202002"
  },
  {
    "date": "2020-01-20",
    "close": 12111.0,
    "volume": 77557,
    "contract": "202002"
  },
  {
    "date": "2020-01-30",
    "close": 11372.0,
    "volume": 248664,
    "contract": "202002"
  },
  {
    "date": "2020-01-31",
    "close": 11469.0,
    "volume": 154361,
    "contract": "202002"
  },
  {
    "date": "2020-02-03",
    "close": 11324.0,
    "volume": 206381,
    "contract": "202002"
  },
  {
    "date": "2020-02-04",
    "close": 11534.0,
    "volume": 145462,
    "contract": "202002"
  },
  {
    "date": "2020-02-05",
    "close": 11542.0,
    "volume": 155144,
    "contract": "202002"
  },
  {
    "date": "2020-02-06",
    "close": 11739.0,
    "volume": 122911,
    "contract": "202002"
  },
  {
    "date": "2020-02-07",
    "close": 11589.0,
    "volume": 125747,
    "contract": "202002"
  },
  {
    "date": "2020-02-10",
    "close": 11565.0,
    "volume": 147183,
    "contract": "202002"
  },
  {
    "date": "2020-02-11",
    "close": 11664.0,
    "volume": 92406,
    "contract": "202002"
  },
  {
    "date": "2020-02-12",
    "close": 11770.0,
    "volume": 105501,
    "contract": "202002"
  },
  {
    "date": "2020-02-13",
    "close": 11775.0,
    "volume": 110031,
    "contract": "202002"
  },
  {
    "date": "2020-02-14",
    "close": 11810.0,
    "volume": 102988,
    "contract": "202002"
  },
  {
    "date": "2020-02-17",
    "close": 11769.0,
    "volume": 109882,
    "contract": "202002"
  },
  {
    "date": "2020-02-18",
    "close": 11640.0,
    "volume": 154544,
    "contract": "202002"
  },
  {
    "date": "2020-02-19",
    "close": 11760.0,
    "volume": 83637,
    "contract": "202002"
  },
  {
    "date": "2020-02-20",
    "close": 11713.0,
    "volume": 137132,
    "contract": "202003"
  },
  {
    "date": "2020-02-21",
    "close": 11663.0,
    "volume": 139432,
    "contract": "202003"
  },
  {
    "date": "2020-02-24",
    "close": 11511.0,
    "volume": 136123,
    "contract": "202003"
  },
  {
    "date": "2020-02-25",
    "close": 11541.0,
    "volume": 148777,
    "contract": "202003"
  },
  {
    "date": "2020-02-26",
    "close": 11421.0,
    "volume": 162698,
    "contract": "202003"
  },
  {
    "date": "2020-02-27",
    "close": 11276.0,
    "volume": 168661,
    "contract": "202003"
  },
  {
    "date": "2020-03-02",
    "close": 11176.0,
    "volume": 203861,
    "contract": "202003"
  },
  {
    "date": "2020-03-03",
    "close": 11321.0,
    "volume": 165499,
    "contract": "202003"
  },
  {
    "date": "2020-03-04",
    "close": 11358.0,
    "volume": 142617,
    "contract": "202003"
  },
  {
    "date": "2020-03-05",
    "close": 11491.0,
    "volume": 112997,
    "contract": "202003"
  },
  {
    "date": "2020-03-06",
    "close": 11269.0,
    "volume": 154698,
    "contract": "202003"
  },
  {
    "date": "2020-03-09",
    "close": 10951.0,
    "volume": 213069,
    "contract": "202003"
  },
  {
    "date": "2020-03-10",
    "close": 10981.0,
    "volume": 209076,
    "contract": "202003"
  },
  {
    "date": "2020-03-11",
    "close": 10824.0,
    "volume": 183871,
    "contract": "202003"
  },
  {
    "date": "2020-03-12",
    "close": 10362.0,
    "volume": 331510,
    "contract": "202003"
  },
  {
    "date": "2020-03-13",
    "close": 10027.0,
    "volume": 348943,
    "contract": "202003"
  },
  {
    "date": "2020-03-16",
    "close": 9679.0,
    "volume": 260020,
    "contract": "202003"
  },
  {
    "date": "2020-03-17",
    "close": 9371.0,
    "volume": 257921,
    "contract": "202003"
  },
  {
    "date": "2020-03-18",
    "close": 9263.0,
    "volume": 111426,
    "contract": "202003"
  },
  {
    "date": "2020-03-19",
    "close": 8356.0,
    "volume": 307231,
    "contract": "202004"
  },
  {
    "date": "2020-03-20",
    "close": 9041.0,
    "volume": 266159,
    "contract": "202004"
  },
  {
    "date": "2020-03-23",
    "close": 8665.0,
    "volume": 180341,
    "contract": "202004"
  },
  {
    "date": "2020-03-24",
    "close": 9193.0,
    "volume": 179105,
    "contract": "202004"
  },
  {
    "date": "2020-03-25",
    "close": 9585.0,
    "volume": 209717,
    "contract": "202004"
  },
  {
    "date": "2020-03-26",
    "close": 9631.0,
    "volume": 190488,
    "contract": "202004"
  },
  {
    "date": "2020-03-27",
    "close": 9579.0,
    "volume": 187676,
    "contract": "202004"
  },
  {
    "date": "2020-03-30",
    "close": 9566.0,
    "volume": 164970,
    "contract": "202004"
  },
  {
    "date": "2020-03-31",
    "close": 9595.0,
    "volume": 142747,
    "contract": "202004"
  },
  {
    "date": "2020-04-01",
    "close": 9555.0,
    "volume": 116273,
    "contract": "202004"
  },
  {
    "date": "2020-04-06",
    "close": 9823.0,
    "volume": 146380,
    "contract": "202004"
  },
  {
    "date": "2020-04-07",
    "close": 9998.0,
    "volume": 137022,
    "contract": "202004"
  },
  {
    "date": "2020-04-08",
    "close": 10122.0,
    "volume": 130314,
    "contract": "202004"
  },
  {
    "date": "2020-04-09",
    "close": 10100.0,
    "volume": 135819,
    "contract": "202004"
  },
  {
    "date": "2020-04-10",
    "close": 10133.0,
    "volume": 74244,
    "contract": "202004"
  },
  {
    "date": "2020-04-13",
    "close": 10079.0,
    "volume": 124231,
    "contract": "202004"
  },
  {
    "date": "2020-04-14",
    "close": 10343.0,
    "volume": 133841,
    "contract": "202004"
  },
  {
    "date": "2020-04-15",
    "close": 10450.0,
    "volume": 67002,
    "contract": "202004"
  },
  {
    "date": "2020-04-16",
    "close": 10301.0,
    "volume": 117908,
    "contract": "202005"
  },
  {
    "date": "2020-04-17",
    "close": 10563.0,
    "volume": 159024,
    "contract": "202005"
  },
  {
    "date": "2020-04-20",
    "close": 10475.0,
    "volume": 95719,
    "contract": "202005"
  },
  {
    "date": "2020-04-21",
    "close": 10196.0,
    "volume": 185566,
    "contract": "202005"
  },
  {
    "date": "2020-04-22",
    "close": 10222.0,
    "volume": 140413,
    "contract": "202005"
  },
  {
    "date": "2020-04-23",
    "close": 10292.0,
    "volume": 167258,
    "contract": "202005"
  },
  {
    "date": "2020-04-24",
    "close": 10268.0,
    "volume": 104624,
    "contract": "202005"
  },
  {
    "date": "2020-04-27",
    "close": 10545.0,
    "volume": 123332,
    "contract": "202005"
  },
  {
    "date": "2020-04-28",
    "close": 10583.0,
    "volume": 110417,
    "contract": "202005"
  },
  {
    "date": "2020-04-29",
    "close": 10709.0,
    "volume": 114379,
    "contract": "202005"
  },
  {
    "date": "2020-04-30",
    "close": 10947.0,
    "volume": 115419,
    "contract": "202005"
  },
  {
    "date": "2020-05-04",
    "close": 10610.0,
    "volume": 133437,
    "contract": "202005"
  },
  {
    "date": "2020-05-05",
    "close": 10719.0,
    "volume": 110697,
    "contract": "202005"
  },
  {
    "date": "2020-05-06",
    "close": 10749.0,
    "volume": 123280,
    "contract": "202005"
  },
  {
    "date": "2020-05-07",
    "close": 10833.0,
    "volume": 116774,
    "contract": "202005"
  },
  {
    "date": "2020-05-08",
    "close": 10894.0,
    "volume": 106019,
    "contract": "202005"
  },
  {
    "date": "2020-05-11",
    "close": 10982.0,
    "volume": 93372,
    "contract": "202005"
  },
  {
    "date": "2020-05-12",
    "close": 10865.0,
    "volume": 117000,
    "contract": "202005"
  },
  {
    "date": "2020-05-13",
    "close": 10914.0,
    "volume": 103023,
    "contract": "202005"
  },
  {
    "date": "2020-05-14",
    "close": 10749.0,
    "volume": 128433,
    "contract": "202005"
  },
  {
    "date": "2020-05-15",
    "close": 10817.0,
    "volume": 135179,
    "contract": "202005"
  },
  {
    "date": "2020-05-18",
    "close": 10761.0,
    "volume": 134342,
    "contract": "202005"
  },
  {
    "date": "2020-05-19",
    "close": 10868.0,
    "volume": 128453,
    "contract": "202005"
  },
  {
    "date": "2020-05-20",
    "close": 10887.0,
    "volume": 61752,
    "contract": "202005"
  },
  {
    "date": "2020-05-21",
    "close": 10953.0,
    "volume": 116771,
    "contract": "202006"
  },
  {
    "date": "2020-05-22",
    "close": 10744.0,
    "volume": 137601,
    "contract": "202006"
  },
  {
    "date": "2020-05-25",
    "close": 10821.0,
    "volume": 120809,
    "contract": "202006"
  },
  {
    "date": "2020-05-26",
    "close": 10984.0,
    "volume": 106978,
    "contract": "202006"
  },
  {
    "date": "2020-05-27",
    "close": 10973.0,
    "volume": 103162,
    "contract": "202006"
  },
  {
    "date": "2020-05-28",
    "close": 10911.0,
    "volume": 142469,
    "contract": "202006"
  },
  {
    "date": "2020-05-29",
    "close": 10919.0,
    "volume": 115914,
    "contract": "202006"
  },
  {
    "date": "2020-06-01",
    "close": 11057.0,
    "volume": 105285,
    "contract": "202006"
  },
  {
    "date": "2020-06-02",
    "close": 11107.0,
    "volume": 83041,
    "contract": "202006"
  },
  {
    "date": "2020-06-03",
    "close": 11283.0,
    "volume": 109433,
    "contract": "202006"
  },
  {
    "date": "2020-06-04",
    "close": 11358.0,
    "volume": 109338,
    "contract": "202006"
  },
  {
    "date": "2020-06-05",
    "close": 11457.0,
    "volume": 85304,
    "contract": "202006"
  },
  {
    "date": "2020-06-08",
    "close": 11570.0,
    "volume": 107836,
    "contract": "202006"
  },
  {
    "date": "2020-06-09",
    "close": 11606.0,
    "volume": 90763,
    "contract": "202006"
  },
  {
    "date": "2020-06-10",
    "close": 11704.0,
    "volume": 95474,
    "contract": "202006"
  },
  {
    "date": "2020-06-11",
    "close": 11491.0,
    "volume": 144385,
    "contract": "202006"
  },
  {
    "date": "2020-06-12",
    "close": 11391.0,
    "volume": 138977,
    "contract": "202006"
  },
  {
    "date": "2020-06-15",
    "close": 11225.0,
    "volume": 162092,
    "contract": "202006"
  },
  {
    "date": "2020-06-16",
    "close": 11522.0,
    "volume": 132203,
    "contract": "202006"
  },
  {
    "date": "2020-06-17",
    "close": 11521.0,
    "volume": 68402,
    "contract": "202006"
  },
  {
    "date": "2020-06-18",
    "close": 11395.0,
    "volume": 115951,
    "contract": "202007"
  },
  {
    "date": "2020-06-19",
    "close": 11409.0,
    "volume": 94025,
    "contract": "202007"
  },
  {
    "date": "2020-06-22",
    "close": 11421.0,
    "volume": 114951,
    "contract": "202007"
  },
  {
    "date": "2020-06-23",
    "close": 11456.0,
    "volume": 140506,
    "contract": "202007"
  },
  {
    "date": "2020-06-24",
    "close": 11523.0,
    "volume": 90292,
    "contract": "202007"
  },
  {
    "date": "2020-06-29",
    "close": 11363.0,
    "volume": 126715,
    "contract": "202007"
  },
  {
    "date": "2020-06-30",
    "close": 11470.0,
    "volume": 84812,
    "contract": "202007"
  },
  {
    "date": "2020-07-01",
    "close": 11544.0,
    "volume": 102446,
    "contract": "202007"
  },
  {
    "date": "2020-07-02",
    "close": 11695.0,
    "volume": 92103,
    "contract": "202007"
  },
  {
    "date": "2020-07-03",
    "close": 11834.0,
    "volume": 92327,
    "contract": "202007"
  },
  {
    "date": "2020-07-06",
    "close": 12067.0,
    "volume": 107214,
    "contract": "202007"
  },
  {
    "date": "2020-07-07",
    "close": 12028.0,
    "volume": 134410,
    "contract": "202007"
  },
  {
    "date": "2020-07-08",
    "close": 12126.0,
    "volume": 103418,
    "contract": "202007"
  },
  {
    "date": "2020-07-09",
    "close": 12149.0,
    "volume": 112588,
    "contract": "202007"
  },
  {
    "date": "2020-07-10",
    "close": 11995.0,
    "volume": 140575,
    "contract": "202007"
  },
  {
    "date": "2020-07-13",
    "close": 12204.0,
    "volume": 116687,
    "contract": "202007"
  },
  {
    "date": "2020-07-14",
    "close": 12188.0,
    "volume": 136035,
    "contract": "202007"
  },
  {
    "date": "2020-07-15",
    "close": 12220.0,
    "volume": 74574,
    "contract": "202007"
  },
  {
    "date": "2020-07-16",
    "close": 12029.0,
    "volume": 133119,
    "contract": "202008"
  },
  {
    "date": "2020-07-17",
    "close": 12039.0,
    "volume": 112518,
    "contract": "202008"
  },
  {
    "date": "2020-07-20",
    "close": 12033.0,
    "volume": 121048,
    "contract": "202008"
  },
  {
    "date": "2020-07-21",
    "close": 12288.0,
    "volume": 123081,
    "contract": "202008"
  },
  {
    "date": "2020-07-22",
    "close": 12332.0,
    "volume": 95059,
    "contract": "202008"
  },
  {
    "date": "2020-07-23",
    "close": 12287.0,
    "volume": 122819,
    "contract": "202008"
  },
  {
    "date": "2020-07-24",
    "close": 12150.0,
    "volume": 172087,
    "contract": "202008"
  },
  {
    "date": "2020-07-27",
    "close": 12498.0,
    "volume": 140577,
    "contract": "202008"
  },
  {
    "date": "2020-07-28",
    "close": 12454.0,
    "volume": 245816,
    "contract": "202008"
  },
  {
    "date": "2020-07-29",
    "close": 12421.0,
    "volume": 138924,
    "contract": "202008"
  },
  {
    "date": "2020-07-30",
    "close": 12595.0,
    "volume": 126225,
    "contract": "202008"
  },
  {
    "date": "2020-07-31",
    "close": 12576.0,
    "volume": 130348,
    "contract": "202008"
  },
  {
    "date": "2020-08-03",
    "close": 12440.0,
    "volume": 134894,
    "contract": "202008"
  },
  {
    "date": "2020-08-04",
    "close": 12629.0,
    "volume": 111175,
    "contract": "202008"
  },
  {
    "date": "2020-08-05",
    "close": 12741.0,
    "volume": 106101,
    "contract": "202008"
  },
  {
    "date": "2020-08-06",
    "close": 12836.0,
    "volume": 141397,
    "contract": "202008"
  },
  {
    "date": "2020-08-07",
    "close": 12759.0,
    "volume": 114920,
    "contract": "202008"
  },
  {
    "date": "2020-08-10",
    "close": 12854.0,
    "volume": 109604,
    "contract": "202008"
  },
  {
    "date": "2020-08-11",
    "close": 12735.0,
    "volume": 106920,
    "contract": "202008"
  },
  {
    "date": "2020-08-12",
    "close": 12655.0,
    "volume": 131890,
    "contract": "202008"
  },
  {
    "date": "2020-08-13",
    "close": 12725.0,
    "volume": 113664,
    "contract": "202008"
  },
  {
    "date": "2020-08-14",
    "close": 12789.0,
    "volume": 105105,
    "contract": "202008"
  },
  {
    "date": "2020-08-17",
    "close": 12953.0,
    "volume": 126563,
    "contract": "202008"
  },
  {
    "date": "2020-08-18",
    "close": 12877.0,
    "volume": 134346,
    "contract": "202008"
  },
  {
    "date": "2020-08-19",
    "close": 12806.0,
    "volume": 70664,
    "contract": "202008"
  },
  {
    "date": "2020-08-20",
    "close": 12298.0,
    "volume": 237845,
    "contract": "202009"
  },
  {
    "date": "2020-08-21",
    "close": 12551.0,
    "volume": 134925,
    "contract": "202009"
  },
  {
    "date": "2020-08-24",
    "close": 12603.0,
    "volume": 103793,
    "contract": "202009"
  },
  {
    "date": "2020-08-25",
    "close": 12735.0,
    "volume": 111954,
    "contract": "202009"
  },
  {
    "date": "2020-08-26",
    "close": 12795.0,
    "volume": 86909,
    "contract": "202009"
  },
  {
    "date": "2020-08-27",
    "close": 12758.0,
    "volume": 126988,
    "contract": "202009"
  },
  {
    "date": "2020-08-28",
    "close": 12688.0,
    "volume": 138555,
    "contract": "202009"
  },
  {
    "date": "2020-08-31",
    "close": 12589.0,
    "volume": 142474,
    "contract": "202009"
  },
  {
    "date": "2020-09-01",
    "close": 12688.0,
    "volume": 114612,
    "contract": "202009"
  },
  {
    "date": "2020-09-02",
    "close": 12690.0,
    "volume": 127417,
    "contract": "202009"
  },
  {
    "date": "2020-09-03",
    "close": 12734.0,
    "volume": 130555,
    "contract": "202009"
  },
  {
    "date": "2020-09-04",
    "close": 12607.0,
    "volume": 130795,
    "contract": "202009"
  },
  {
    "date": "2020-09-07",
    "close": 12580.0,
    "volume": 137459,
    "contract": "202009"
  },
  {
    "date": "2020-09-08",
    "close": 12667.0,
    "volume": 110554,
    "contract": "202009"
  },
  {
    "date": "2020-09-09",
    "close": 12598.0,
    "volume": 153591,
    "contract": "202009"
  },
  {
    "date": "2020-09-10",
    "close": 12698.0,
    "volume": 111296,
    "contract": "202009"
  },
  {
    "date": "2020-09-11",
    "close": 12663.0,
    "volume": 114638,
    "contract": "202009"
  },
  {
    "date": "2020-09-14",
    "close": 12784.0,
    "volume": 127791,
    "contract": "202009"
  },
  {
    "date": "2020-09-15",
    "close": 12843.0,
    "volume": 108510,
    "contract": "202009"
  },
  {
    "date": "2020-09-16",
    "close": 12968.0,
    "volume": 67977,
    "contract": "202009"
  },
  {
    "date": "2020-09-17",
    "close": 12815.0,
    "volume": 119751,
    "contract": "202010"
  },
  {
    "date": "2020-09-18",
    "close": 12833.0,
    "volume": 95760,
    "contract": "202010"
  },
  {
    "date": "2020-09-21",
    "close": 12659.0,
    "volume": 140049,
    "contract": "202010"
  },
  {
    "date": "2020-09-22",
    "close": 12509.0,
    "volume": 130601,
    "contract": "202010"
  },
  {
    "date": "2020-09-23",
    "close": 12528.0,
    "volume": 117910,
    "contract": "202010"
  },
  {
    "date": "2020-09-24",
    "close": 12180.0,
    "volume": 171038,
    "contract": "202010"
  },
  {
    "date": "2020-09-25",
    "close": 12195.0,
    "volume": 128504,
    "contract": "202010"
  },
  {
    "date": "2020-09-28",
    "close": 12415.0,
    "volume": 94633,
    "contract": "202010"
  },
  {
    "date": "2020-09-29",
    "close": 12421.0,
    "volume": 103096,
    "contract": "202010"
  },
  {
    "date": "2020-09-30",
    "close": 12473.0,
    "volume": 107766,
    "contract": "202010"
  },
  {
    "date": "2020-10-05",
    "close": 12529.0,
    "volume": 93958,
    "contract": "202010"
  },
  {
    "date": "2020-10-06",
    "close": 12677.0,
    "volume": 99739,
    "contract": "202010"
  },
  {
    "date": "2020-10-07",
    "close": 12754.0,
    "volume": 89405,
    "contract": "202010"
  },
  {
    "date": "2020-10-08",
    "close": 12873.0,
    "volume": 99102,
    "contract": "202010"
  },
  {
    "date": "2020-10-12",
    "close": 12921.0,
    "volume": 106219,
    "contract": "202010"
  },
  {
    "date": "2020-10-13",
    "close": 12915.0,
    "volume": 99008,
    "contract": "202010"
  },
  {
    "date": "2020-10-14",
    "close": 12890.0,
    "volume": 82548,
    "contract": "202010"
  },
  {
    "date": "2020-10-15",
    "close": 12840.0,
    "volume": 130422,
    "contract": "202010"
  },
  {
    "date": "2020-10-16",
    "close": 12748.0,
    "volume": 116952,
    "contract": "202010"
  },
  {
    "date": "2020-10-19",
    "close": 12893.0,
    "volume": 127215,
    "contract": "202010"
  },
  {
    "date": "2020-10-20",
    "close": 12855.0,
    "volume": 100271,
    "contract": "202010"
  },
  {
    "date": "2020-10-21",
    "close": 12860.0,
    "volume": 58692,
    "contract": "202010"
  },
  {
    "date": "2020-10-22",
    "close": 12836.0,
    "volume": 100864,
    "contract": "202011"
  },
  {
    "date": "2020-10-23",
    "close": 12838.0,
    "volume": 78710,
    "contract": "202011"
  },
  {
    "date": "2020-10-26",
    "close": 12860.0,
    "volume": 90884,
    "contract": "202011"
  },
  {
    "date": "2020-10-27",
    "close": 12808.0,
    "volume": 82240,
    "contract": "202011"
  },
  {
    "date": "2020-10-28",
    "close": 12743.0,
    "volume": 88057,
    "contract": "202011"
  },
  {
    "date": "2020-10-29",
    "close": 12603.0,
    "volume": 119037,
    "contract": "202011"
  },
  {
    "date": "2020-10-30",
    "close": 12413.0,
    "volume": 121830,
    "contract": "202011"
  },
  {
    "date": "2020-11-02",
    "close": 12516.0,
    "volume": 97211,
    "contract": "202011"
  },
  {
    "date": "2020-11-03",
    "close": 12684.0,
    "volume": 90467,
    "contract": "202011"
  },
  {
    "date": "2020-11-04",
    "close": 12864.0,
    "volume": 149906,
    "contract": "202011"
  },
  {
    "date": "2020-11-05",
    "close": 12891.0,
    "volume": 90854,
    "contract": "202011"
  },
  {
    "date": "2020-11-06",
    "close": 12937.0,
    "volume": 100789,
    "contract": "202011"
  },
  {
    "date": "2020-11-09",
    "close": 13126.0,
    "volume": 117098,
    "contract": "202011"
  },
  {
    "date": "2020-11-10",
    "close": 13071.0,
    "volume": 110282,
    "contract": "202011"
  },
  {
    "date": "2020-11-11",
    "close": 13261.0,
    "volume": 109089,
    "contract": "202011"
  },
  {
    "date": "2020-11-12",
    "close": 13226.0,
    "volume": 93512,
    "contract": "202011"
  },
  {
    "date": "2020-11-13",
    "close": 13282.0,
    "volume": 90650,
    "contract": "202011"
  },
  {
    "date": "2020-11-16",
    "close": 13579.0,
    "volume": 132561,
    "contract": "202011"
  },
  {
    "date": "2020-11-17",
    "close": 13624.0,
    "volume": 130507,
    "contract": "202011"
  },
  {
    "date": "2020-11-18",
    "close": 13756.0,
    "volume": 68642,
    "contract": "202011"
  },
  {
    "date": "2020-11-19",
    "close": 13742.0,
    "volume": 95715,
    "contract": "202012"
  },
  {
    "date": "2020-11-20",
    "close": 13733.0,
    "volume": 85986,
    "contract": "202012"
  },
  {
    "date": "2020-11-23",
    "close": 13873.0,
    "volume": 115103,
    "contract": "202012"
  },
  {
    "date": "2020-11-24",
    "close": 13799.0,
    "volume": 89096,
    "contract": "202012"
  },
  {
    "date": "2020-11-25",
    "close": 13712.0,
    "volume": 123391,
    "contract": "202012"
  },
  {
    "date": "2020-11-26",
    "close": 13839.0,
    "volume": 97189,
    "contract": "202012"
  },
  {
    "date": "2020-11-27",
    "close": 13878.0,
    "volume": 94853,
    "contract": "202012"
  },
  {
    "date": "2020-11-30",
    "close": 13720.0,
    "volume": 134279,
    "contract": "202012"
  },
  {
    "date": "2020-12-01",
    "close": 13875.0,
    "volume": 91672,
    "contract": "202012"
  },
  {
    "date": "2020-12-02",
    "close": 13955.0,
    "volume": 110308,
    "contract": "202012"
  },
  {
    "date": "2020-12-03",
    "close": 13982.0,
    "volume": 125877,
    "contract": "202012"
  },
  {
    "date": "2020-12-04",
    "close": 14133.0,
    "volume": 110715,
    "contract": "202012"
  },
  {
    "date": "2020-12-07",
    "close": 14220.0,
    "volume": 125628,
    "contract": "202012"
  },
  {
    "date": "2020-12-08",
    "close": 14340.0,
    "volume": 111313,
    "contract": "202012"
  },
  {
    "date": "2020-12-09",
    "close": 14397.0,
    "volume": 96545,
    "contract": "202012"
  },
  {
    "date": "2020-12-10",
    "close": 14237.0,
    "volume": 126413,
    "contract": "202012"
  },
  {
    "date": "2020-12-11",
    "close": 14237.0,
    "volume": 159011,
    "contract": "202012"
  },
  {
    "date": "2020-12-14",
    "close": 14201.0,
    "volume": 120593,
    "contract": "202012"
  },
  {
    "date": "2020-12-15",
    "close": 14084.0,
    "volume": 158662,
    "contract": "202012"
  },
  {
    "date": "2020-12-16",
    "close": 14323.0,
    "volume": 71732,
    "contract": "202012"
  },
  {
    "date": "2020-12-17",
    "close": 14186.0,
    "volume": 116139,
    "contract": "202101"
  },
  {
    "date": "2020-12-18",
    "close": 14136.0,
    "volume": 89422,
    "contract": "202101"
  },
  {
    "date": "2020-12-21",
    "close": 14309.0,
    "volume": 135177,
    "contract": "202101"
  },
  {
    "date": "2020-12-22",
    "close": 14046.0,
    "volume": 136896,
    "contract": "202101"
  },
  {
    "date": "2020-12-23",
    "close": 14114.0,
    "volume": 115346,
    "contract": "202101"
  },
  {
    "date": "2020-12-24",
    "close": 14242.0,
    "volume": 106221,
    "contract": "202101"
  },
  {
    "date": "2020-12-25",
    "close": 14304.0,
    "volume": 88875,
    "contract": "202101"
  },
  {
    "date": "2020-12-28",
    "close": 14436.0,
    "volume": 82692,
    "contract": "202101"
  },
  {
    "date": "2020-12-29",
    "close": 14458.0,
    "volume": 80587,
    "contract": "202101"
  },
  {
    "date": "2020-12-30",
    "close": 14636.0,
    "volume": 97857,
    "contract": "202101"
  },
  {
    "date": "2020-12-31",
    "close": 14678.0,
    "volume": 96684,
    "contract": "202101"
  },
  {
    "date": "2021-01-04",
    "close": 14873.0,
    "volume": 137069,
    "contract": "202101"
  },
  {
    "date": "2021-01-05",
    "close": 14976.0,
    "volume": 110886,
    "contract": "202101"
  },
  {
    "date": "2021-01-06",
    "close": 14911.0,
    "volume": 233806,
    "contract": "202101"
  },
  {
    "date": "2021-01-07",
    "close": 15226.0,
    "volume": 151918,
    "contract": "202101"
  },
  {
    "date": "2021-01-08",
    "close": 15451.0,
    "volume": 158703,
    "contract": "202101"
  },
  {
    "date": "2021-01-11",
    "close": 15531.0,
    "volume": 139479,
    "contract": "202101"
  },
  {
    "date": "2021-01-12",
    "close": 15489.0,
    "volume": 175838,
    "contract": "202101"
  },
  {
    "date": "2021-01-13",
    "close": 15759.0,
    "volume": 154811,
    "contract": "202101"
  },
  {
    "date": "2021-01-14",
    "close": 15727.0,
    "volume": 121305,
    "contract": "202101"
  },
  {
    "date": "2021-01-15",
    "close": 15632.0,
    "volume": 231505,
    "contract": "202101"
  },
  {
    "date": "2021-01-18",
    "close": 15608.0,
    "volume": 200935,
    "contract": "202101"
  },
  {
    "date": "2021-01-19",
    "close": 15888.0,
    "volume": 173474,
    "contract": "202101"
  },
  {
    "date": "2021-01-20",
    "close": 15766.0,
    "volume": 119559,
    "contract": "202101"
  },
  {
    "date": "2021-01-21",
    "close": 16125.0,
    "volume": 231416,
    "contract": "202102"
  },
  {
    "date": "2021-01-22",
    "close": 15977.0,
    "volume": 161218,
    "contract": "202102"
  },
  {
    "date": "2021-01-25",
    "close": 15911.0,
    "volume": 168191,
    "contract": "202102"
  },
  {
    "date": "2021-01-26",
    "close": 15628.0,
    "volume": 230474,
    "contract": "202102"
  },
  {
    "date": "2021-01-27",
    "close": 15657.0,
    "volume": 184037,
    "contract": "202102"
  },
  {
    "date": "2021-01-28",
    "close": 15382.0,
    "volume": 202151,
    "contract": "202102"
  },
  {
    "date": "2021-01-29",
    "close": 15070.0,
    "volume": 206011,
    "contract": "202102"
  },
  {
    "date": "2021-02-01",
    "close": 15362.0,
    "volume": 164870,
    "contract": "202102"
  },
  {
    "date": "2021-02-02",
    "close": 15752.0,
    "volume": 177487,
    "contract": "202102"
  },
  {
    "date": "2021-02-03",
    "close": 15773.0,
    "volume": 145093,
    "contract": "202102"
  },
  {
    "date": "2021-02-04",
    "close": 15696.0,
    "volume": 179004,
    "contract": "202102"
  },
  {
    "date": "2021-02-05",
    "close": 15802.0,
    "volume": 178540,
    "contract": "202102"
  },
  {
    "date": "2021-02-17",
    "close": 16326.0,
    "volume": 100608,
    "contract": "202102"
  },
  {
    "date": "2021-02-18",
    "close": 16380.0,
    "volume": 152979,
    "contract": "202103"
  },
  {
    "date": "2021-02-19",
    "close": 16309.0,
    "volume": 152680,
    "contract": "202103"
  },
  {
    "date": "2021-02-22",
    "close": 16382.0,
    "volume": 151539,
    "contract": "202103"
  },
  {
    "date": "2021-02-23",
    "close": 16434.0,
    "volume": 136807,
    "contract": "202103"
  },
  {
    "date": "2021-02-24",
    "close": 16181.0,
    "volume": 180413,
    "contract": "202103"
  },
  {
    "date": "2021-02-25",
    "close": 16387.0,
    "volume": 135256,
    "contract": "202103"
  },
  {
    "date": "2021-02-26",
    "close": 15931.0,
    "volume": 197795,
    "contract": "202103"
  },
  {
    "date": "2021-03-02",
    "close": 15904.0,
    "volume": 146577,
    "contract": "202103"
  },
  {
    "date": "2021-03-03",
    "close": 16179.0,
    "volume": 153225,
    "contract": "202103"
  },
  {
    "date": "2021-03-04",
    "close": 15922.0,
    "volume": 198855,
    "contract": "202103"
  },
  {
    "date": "2021-03-05",
    "close": 15847.0,
    "volume": 168446,
    "contract": "202103"
  },
  {
    "date": "2021-03-08",
    "close": 15819.0,
    "volume": 175531,
    "contract": "202103"
  },
  {
    "date": "2021-03-09",
    "close": 15822.0,
    "volume": 171528,
    "contract": "202103"
  },
  {
    "date": "2021-03-10",
    "close": 15885.0,
    "volume": 136272,
    "contract": "202103"
  },
  {
    "date": "2021-03-11",
    "close": 16169.0,
    "volume": 135436,
    "contract": "202103"
  },
  {
    "date": "2021-03-12",
    "close": 16223.0,
    "volume": 116406,
    "contract": "202103"
  },
  {
    "date": "2021-03-15",
    "close": 16199.0,
    "volume": 125844,
    "contract": "202103"
  },
  {
    "date": "2021-03-16",
    "close": 16305.0,
    "volume": 128695,
    "contract": "202103"
  },
  {
    "date": "2021-03-17",
    "close": 16176.0,
    "volume": 72615,
    "contract": "202103"
  },
  {
    "date": "2021-03-18",
    "close": 16235.0,
    "volume": 138744,
    "contract": "202104"
  },
  {
    "date": "2021-03-19",
    "close": 16010.0,
    "volume": 149724,
    "contract": "202104"
  },
  {
    "date": "2021-03-22",
    "close": 16137.0,
    "volume": 134577,
    "contract": "202104"
  },
  {
    "date": "2021-03-23",
    "close": 16119.0,
    "volume": 117179,
    "contract": "202104"
  },
  {
    "date": "2021-03-24",
    "close": 15981.0,
    "volume": 131876,
    "contract": "202104"
  },
  {
    "date": "2021-03-25",
    "close": 16030.0,
    "volume": 136413,
    "contract": "202104"
  },
  {
    "date": "2021-03-26",
    "close": 16285.0,
    "volume": 123696,
    "contract": "202104"
  },
  {
    "date": "2021-03-29",
    "close": 16408.0,
    "volume": 112333,
    "contract": "202104"
  },
  {
    "date": "2021-03-30",
    "close": 16520.0,
    "volume": 100799,
    "contract": "202104"
  },
  {
    "date": "2021-03-31",
    "close": 16423.0,
    "volume": 104772,
    "contract": "202104"
  },
  {
    "date": "2021-04-01",
    "close": 16549.0,
    "volume": 115342,
    "contract": "202104"
  },
  {
    "date": "2021-04-06",
    "close": 16728.0,
    "volume": 103549,
    "contract": "202104"
  },
  {
    "date": "2021-04-07",
    "close": 16767.0,
    "volume": 93030,
    "contract": "202104"
  },
  {
    "date": "2021-04-08",
    "close": 16927.0,
    "volume": 111596,
    "contract": "202104"
  },
  {
    "date": "2021-04-09",
    "close": 16839.0,
    "volume": 103181,
    "contract": "202104"
  },
  {
    "date": "2021-04-12",
    "close": 16835.0,
    "volume": 113383,
    "contract": "202104"
  },
  {
    "date": "2021-04-13",
    "close": 16793.0,
    "volume": 150603,
    "contract": "202104"
  },
  {
    "date": "2021-04-14",
    "close": 16857.0,
    "volume": 185298,
    "contract": "202104"
  },
  {
    "date": "2021-04-15",
    "close": 17069.0,
    "volume": 132033,
    "contract": "202104"
  },
  {
    "date": "2021-04-16",
    "close": 17156.0,
    "volume": 127426,
    "contract": "202104"
  },
  {
    "date": "2021-04-19",
    "close": 17269.0,
    "volume": 124734,
    "contract": "202104"
  },
  {
    "date": "2021-04-20",
    "close": 17320.0,
    "volume": 114295,
    "contract": "202104"
  },
  {
    "date": "2021-04-21",
    "close": 17231.0,
    "volume": 83992,
    "contract": "202104"
  },
  {
    "date": "2021-04-22",
    "close": 17106.0,
    "volume": 189953,
    "contract": "202105"
  },
  {
    "date": "2021-04-23",
    "close": 17255.0,
    "volume": 122696,
    "contract": "202105"
  },
  {
    "date": "2021-04-26",
    "close": 17526.0,
    "volume": 128096,
    "contract": "202105"
  },
  {
    "date": "2021-04-27",
    "close": 17570.0,
    "volume": 120862,
    "contract": "202105"
  },
  {
    "date": "2021-04-28",
    "close": 17533.0,
    "volume": 101986,
    "contract": "202105"
  },
  {
    "date": "2021-04-29",
    "close": 17569.0,
    "volume": 150499,
    "contract": "202105"
  },
  {
    "date": "2021-05-03",
    "close": 17254.0,
    "volume": 184441,
    "contract": "202105"
  },
  {
    "date": "2021-05-04",
    "close": 16931.0,
    "volume": 243802,
    "contract": "202105"
  },
  {
    "date": "2021-05-05",
    "close": 16765.0,
    "volume": 157298,
    "contract": "202105"
  },
  {
    "date": "2021-05-06",
    "close": 16945.0,
    "volume": 197754,
    "contract": "202105"
  },
  {
    "date": "2021-05-07",
    "close": 17283.0,
    "volume": 142796,
    "contract": "202105"
  },
  {
    "date": "2021-05-10",
    "close": 17229.0,
    "volume": 126289,
    "contract": "202105"
  },
  {
    "date": "2021-05-11",
    "close": 16561.0,
    "volume": 245767,
    "contract": "202105"
  },
  {
    "date": "2021-05-12",
    "close": 15697.0,
    "volume": 366512,
    "contract": "202105"
  },
  {
    "date": "2021-05-13",
    "close": 15566.0,
    "volume": 234182,
    "contract": "202105"
  },
  {
    "date": "2021-05-14",
    "close": 15766.0,
    "volume": 218712,
    "contract": "202105"
  },
  {
    "date": "2021-05-17",
    "close": 15263.0,
    "volume": 275831,
    "contract": "202105"
  },
  {
    "date": "2021-05-18",
    "close": 16147.0,
    "volume": 220609,
    "contract": "202105"
  },
  {
    "date": "2021-05-19",
    "close": 16138.0,
    "volume": 115944,
    "contract": "202105"
  },
  {
    "date": "2021-05-20",
    "close": 15974.0,
    "volume": 158770,
    "contract": "202106"
  },
  {
    "date": "2021-05-21",
    "close": 16259.0,
    "volume": 185232,
    "contract": "202106"
  },
  {
    "date": "2021-05-24",
    "close": 16291.0,
    "volume": 138416,
    "contract": "202106"
  },
  {
    "date": "2021-05-25",
    "close": 16584.0,
    "volume": 145492,
    "contract": "202106"
  },
  {
    "date": "2021-05-26",
    "close": 16614.0,
    "volume": 104686,
    "contract": "202106"
  },
  {
    "date": "2021-05-27",
    "close": 16533.0,
    "volume": 150465,
    "contract": "202106"
  },
  {
    "date": "2021-05-28",
    "close": 16863.0,
    "volume": 124240,
    "contract": "202106"
  },
  {
    "date": "2021-05-31",
    "close": 17011.0,
    "volume": 144649,
    "contract": "202106"
  },
  {
    "date": "2021-06-01",
    "close": 17131.0,
    "volume": 116773,
    "contract": "202106"
  },
  {
    "date": "2021-06-02",
    "close": 17102.0,
    "volume": 121046,
    "contract": "202106"
  },
  {
    "date": "2021-06-03",
    "close": 17226.0,
    "volume": 130148,
    "contract": "202106"
  },
  {
    "date": "2021-06-04",
    "close": 17103.0,
    "volume": 109068,
    "contract": "202106"
  },
  {
    "date": "2021-06-07",
    "close": 17090.0,
    "volume": 176148,
    "contract": "202106"
  },
  {
    "date": "2021-06-08",
    "close": 17090.0,
    "volume": 102605,
    "contract": "202106"
  },
  {
    "date": "2021-06-09",
    "close": 16959.0,
    "volume": 120368,
    "contract": "202106"
  },
  {
    "date": "2021-06-10",
    "close": 17157.0,
    "volume": 127407,
    "contract": "202106"
  },
  {
    "date": "2021-06-11",
    "close": 17217.0,
    "volume": 120701,
    "contract": "202106"
  },
  {
    "date": "2021-06-15",
    "close": 17397.0,
    "volume": 118150,
    "contract": "202106"
  },
  {
    "date": "2021-06-16",
    "close": 17345.0,
    "volume": 71397,
    "contract": "202106"
  },
  {
    "date": "2021-06-17",
    "close": 17295.0,
    "volume": 102114,
    "contract": "202107"
  },
  {
    "date": "2021-06-18",
    "close": 17254.0,
    "volume": 96349,
    "contract": "202107"
  },
  {
    "date": "2021-06-21",
    "close": 16963.0,
    "volume": 143363,
    "contract": "202107"
  },
  {
    "date": "2021-06-22",
    "close": 17026.0,
    "volume": 101124,
    "contract": "202107"
  },
  {
    "date": "2021-06-23",
    "close": 17267.0,
    "volume": 127143,
    "contract": "202107"
  },
  {
    "date": "2021-06-24",
    "close": 17338.0,
    "volume": 92809,
    "contract": "202107"
  },
  {
    "date": "2021-06-25",
    "close": 17423.0,
    "volume": 113764,
    "contract": "202107"
  },
  {
    "date": "2021-06-28",
    "close": 17533.0,
    "volume": 82055,
    "contract": "202107"
  },
  {
    "date": "2021-06-29",
    "close": 17530.0,
    "volume": 115306,
    "contract": "202107"
  },
  {
    "date": "2021-06-30",
    "close": 17712.0,
    "volume": 104462,
    "contract": "202107"
  },
  {
    "date": "2021-07-01",
    "close": 17646.0,
    "volume": 122682,
    "contract": "202107"
  },
  {
    "date": "2021-07-02",
    "close": 17649.0,
    "volume": 101454,
    "contract": "202107"
  },
  {
    "date": "2021-07-05",
    "close": 17896.0,
    "volume": 107714,
    "contract": "202107"
  },
  {
    "date": "2021-07-06",
    "close": 17875.0,
    "volume": 84492,
    "contract": "202107"
  },
  {
    "date": "2021-07-07",
    "close": 17826.0,
    "volume": 109544,
    "contract": "202107"
  },
  {
    "date": "2021-07-08",
    "close": 17823.0,
    "volume": 116445,
    "contract": "202107"
  },
  {
    "date": "2021-07-09",
    "close": 17661.0,
    "volume": 138093,
    "contract": "202107"
  },
  {
    "date": "2021-07-12",
    "close": 17826.0,
    "volume": 127781,
    "contract": "202107"
  },
  {
    "date": "2021-07-13",
    "close": 17869.0,
    "volume": 123418,
    "contract": "202107"
  },
  {
    "date": "2021-07-14",
    "close": 17871.0,
    "volume": 120033,
    "contract": "202107"
  },
  {
    "date": "2021-07-15",
    "close": 18021.0,
    "volume": 103184,
    "contract": "202107"
  },
  {
    "date": "2021-07-16",
    "close": 17924.0,
    "volume": 109949,
    "contract": "202107"
  },
  {
    "date": "2021-07-19",
    "close": 17793.0,
    "volume": 144969,
    "contract": "202107"
  },
  {
    "date": "2021-07-20",
    "close": 17558.0,
    "volume": 147968,
    "contract": "202107"
  },
  {
    "date": "2021-07-21",
    "close": 17430.0,
    "volume": 86527,
    "contract": "202107"
  },
  {
    "date": "2021-07-22",
    "close": 17406.0,
    "volume": 125712,
    "contract": "202108"
  },
  {
    "date": "2021-07-23",
    "close": 17406.0,
    "volume": 115875,
    "contract": "202108"
  },
  {
    "date": "2021-07-26",
    "close": 17203.0,
    "volume": 108704,
    "contract": "202108"
  },
  {
    "date": "2021-07-27",
    "close": 17168.0,
    "volume": 118319,
    "contract": "202108"
  },
  {
    "date": "2021-07-28",
    "close": 16965.0,
    "volume": 203426,
    "contract": "202108"
  },
  {
    "date": "2021-07-29",
    "close": 17327.0,
    "volume": 123218,
    "contract": "202108"
  },
  {
    "date": "2021-07-30",
    "close": 17174.0,
    "volume": 117560,
    "contract": "202108"
  },
  {
    "date": "2021-08-02",
    "close": 17467.0,
    "volume": 131605,
    "contract": "202108"
  },
  {
    "date": "2021-08-03",
    "close": 17482.0,
    "volume": 95199,
    "contract": "202108"
  },
  {
    "date": "2021-08-04",
    "close": 17571.0,
    "volume": 89232,
    "contract": "202108"
  },
  {
    "date": "2021-08-05",
    "close": 17544.0,
    "volume": 65647,
    "contract": "202108"
  },
  {
    "date": "2021-08-06",
    "close": 17439.0,
    "volume": 110731,
    "contract": "202108"
  },
  {
    "date": "2021-08-09",
    "close": 17406.0,
    "volume": 124689,
    "contract": "202108"
  },
  {
    "date": "2021-08-10",
    "close": 17295.0,
    "volume": 109191,
    "contract": "202108"
  },
  {
    "date": "2021-08-11",
    "close": 17170.0,
    "volume": 141084,
    "contract": "202108"
  },
  {
    "date": "2021-08-12",
    "close": 17158.0,
    "volume": 91671,
    "contract": "202108"
  },
  {
    "date": "2021-08-13",
    "close": 16936.0,
    "volume": 150070,
    "contract": "202108"
  },
  {
    "date": "2021-08-16",
    "close": 16774.0,
    "volume": 150977,
    "contract": "202108"
  },
  {
    "date": "2021-08-17",
    "close": 16578.0,
    "volume": 132669,
    "contract": "202108"
  },
  {
    "date": "2021-08-18",
    "close": 16784.0,
    "volume": 102422,
    "contract": "202108"
  },
  {
    "date": "2021-08-19",
    "close": 16328.0,
    "volume": 196641,
    "contract": "202109"
  },
  {
    "date": "2021-08-20",
    "close": 16188.0,
    "volume": 175910,
    "contract": "202109"
  },
  {
    "date": "2021-08-23",
    "close": 16679.0,
    "volume": 127852,
    "contract": "202109"
  },
  {
    "date": "2021-08-24",
    "close": 16781.0,
    "volume": 90436,
    "contract": "202109"
  },
  {
    "date": "2021-08-25",
    "close": 16962.0,
    "volume": 109545,
    "contract": "202109"
  },
  {
    "date": "2021-08-26",
    "close": 16993.0,
    "volume": 127120,
    "contract": "202109"
  },
  {
    "date": "2021-08-27",
    "close": 17172.0,
    "volume": 122558,
    "contract": "202109"
  },
  {
    "date": "2021-08-30",
    "close": 17335.0,
    "volume": 95679,
    "contract": "202109"
  },
  {
    "date": "2021-08-31",
    "close": 17455.0,
    "volume": 138468,
    "contract": "202109"
  },
  {
    "date": "2021-09-01",
    "close": 17474.0,
    "volume": 111022,
    "contract": "202109"
  },
  {
    "date": "2021-09-02",
    "close": 17319.0,
    "volume": 137473,
    "contract": "202109"
  },
  {
    "date": "2021-09-03",
    "close": 17508.0,
    "volume": 114430,
    "contract": "202109"
  },
  {
    "date": "2021-09-06",
    "close": 17493.0,
    "volume": 120721,
    "contract": "202109"
  },
  {
    "date": "2021-09-07",
    "close": 17424.0,
    "volume": 125371,
    "contract": "202109"
  },
  {
    "date": "2021-09-08",
    "close": 17260.0,
    "volume": 151809,
    "contract": "202109"
  },
  {
    "date": "2021-09-09",
    "close": 17238.0,
    "volume": 125037,
    "contract": "202109"
  },
  {
    "date": "2021-09-10",
    "close": 17473.0,
    "volume": 111079,
    "contract": "202109"
  },
  {
    "date": "2021-09-13",
    "close": 17441.0,
    "volume": 120401,
    "contract": "202109"
  },
  {
    "date": "2021-09-14",
    "close": 17462.0,
    "volume": 108843,
    "contract": "202109"
  },
  {
    "date": "2021-09-15",
    "close": 17382.0,
    "volume": 74105,
    "contract": "202109"
  },
  {
    "date": "2021-09-16",
    "close": 17247.0,
    "volume": 93340,
    "contract": "202110"
  },
  {
    "date": "2021-09-17",
    "close": 17294.0,
    "volume": 117752,
    "contract": "202110"
  },
  {
    "date": "2021-09-22",
    "close": 16900.0,
    "volume": 134553,
    "contract": "202110"
  },
  {
    "date": "2021-09-23",
    "close": 17080.0,
    "volume": 99807,
    "contract": "202110"
  },
  {
    "date": "2021-09-24",
    "close": 17248.0,
    "volume": 94226,
    "contract": "202110"
  },
  {
    "date": "2021-09-27",
    "close": 17292.0,
    "volume": 94562,
    "contract": "202110"
  },
  {
    "date": "2021-09-28",
    "close": 17170.0,
    "volume": 103595,
    "contract": "202110"
  },
  {
    "date": "2021-09-29",
    "close": 16818.0,
    "volume": 148685,
    "contract": "202110"
  },
  {
    "date": "2021-09-30",
    "close": 16919.0,
    "volume": 129398,
    "contract": "202110"
  },
  {
    "date": "2021-10-01",
    "close": 16518.0,
    "volume": 162836,
    "contract": "202110"
  },
  {
    "date": "2021-10-04",
    "close": 16361.0,
    "volume": 140802,
    "contract": "202110"
  },
  {
    "date": "2021-10-05",
    "close": 16395.0,
    "volume": 151416,
    "contract": "202110"
  },
  {
    "date": "2021-10-06",
    "close": 16362.0,
    "volume": 136018,
    "contract": "202110"
  },
  {
    "date": "2021-10-07",
    "close": 16699.0,
    "volume": 123808,
    "contract": "202110"
  },
  {
    "date": "2021-10-08",
    "close": 16625.0,
    "volume": 101077,
    "contract": "202110"
  },
  {
    "date": "2021-10-12",
    "close": 16419.0,
    "volume": 138434,
    "contract": "202110"
  },
  {
    "date": "2021-10-13",
    "close": 16321.0,
    "volume": 114897,
    "contract": "202110"
  },
  {
    "date": "2021-10-14",
    "close": 16402.0,
    "volume": 104604,
    "contract": "202110"
  },
  {
    "date": "2021-10-15",
    "close": 16780.0,
    "volume": 109050,
    "contract": "202110"
  },
  {
    "date": "2021-10-18",
    "close": 16721.0,
    "volume": 109628,
    "contract": "202110"
  },
  {
    "date": "2021-10-19",
    "close": 16903.0,
    "volume": 97333,
    "contract": "202110"
  },
  {
    "date": "2021-10-20",
    "close": 16882.0,
    "volume": 56080,
    "contract": "202110"
  },
  {
    "date": "2021-10-21",
    "close": 16815.0,
    "volume": 117754,
    "contract": "202111"
  },
  {
    "date": "2021-10-22",
    "close": 16853.0,
    "volume": 98819,
    "contract": "202111"
  },
  {
    "date": "2021-10-25",
    "close": 16891.0,
    "volume": 97221,
    "contract": "202111"
  },
  {
    "date": "2021-10-26",
    "close": 17044.0,
    "volume": 92092,
    "contract": "202111"
  },
  {
    "date": "2021-10-27",
    "close": 17068.0,
    "volume": 85950,
    "contract": "202111"
  },
  {
    "date": "2021-10-28",
    "close": 17039.0,
    "volume": 85288,
    "contract": "202111"
  },
  {
    "date": "2021-10-29",
    "close": 16946.0,
    "volume": 111444,
    "contract": "202111"
  },
  {
    "date": "2021-11-01",
    "close": 17080.0,
    "volume": 79806,
    "contract": "202111"
  },
  {
    "date": "2021-11-02",
    "close": 17047.0,
    "volume": 109134,
    "contract": "202111"
  },
  {
    "date": "2021-11-03",
    "close": 17091.0,
    "volume": 72076,
    "contract": "202111"
  },
  {
    "date": "2021-11-04",
    "close": 17073.0,
    "volume": 90112,
    "contract": "202111"
  },
  {
    "date": "2021-11-05",
    "close": 17269.0,
    "volume": 90064,
    "contract": "202111"
  },
  {
    "date": "2021-11-08",
    "close": 17423.0,
    "volume": 77522,
    "contract": "202111"
  },
  {
    "date": "2021-11-09",
    "close": 17551.0,
    "volume": 80924,
    "contract": "202111"
  },
  {
    "date": "2021-11-10",
    "close": 17554.0,
    "volume": 75931,
    "contract": "202111"
  },
  {
    "date": "2021-11-11",
    "close": 17473.0,
    "volume": 84466,
    "contract": "202111"
  },
  {
    "date": "2021-11-12",
    "close": 17544.0,
    "volume": 91259,
    "contract": "202111"
  },
  {
    "date": "2021-11-15",
    "close": 17664.0,
    "volume": 102421,
    "contract": "202111"
  },
  {
    "date": "2021-11-16",
    "close": 17698.0,
    "volume": 78291,
    "contract": "202111"
  },
  {
    "date": "2021-11-17",
    "close": 17722.0,
    "volume": 52589,
    "contract": "202111"
  },
  {
    "date": "2021-11-18",
    "close": 17859.0,
    "volume": 87837,
    "contract": "202112"
  },
  {
    "date": "2021-11-19",
    "close": 17852.0,
    "volume": 82761,
    "contract": "202112"
  },
  {
    "date": "2021-11-22",
    "close": 17836.0,
    "volume": 58435,
    "contract": "202112"
  },
  {
    "date": "2021-11-23",
    "close": 17659.0,
    "volume": 102784,
    "contract": "202112"
  },
  {
    "date": "2021-11-24",
    "close": 17680.0,
    "volume": 76818,
    "contract": "202112"
  },
  {
    "date": "2021-11-25",
    "close": 17673.0,
    "volume": 66753,
    "contract": "202112"
  },
  {
    "date": "2021-11-26",
    "close": 17342.0,
    "volume": 129988,
    "contract": "202112"
  },
  {
    "date": "2021-11-29",
    "close": 17311.0,
    "volume": 120115,
    "contract": "202112"
  },
  {
    "date": "2021-11-30",
    "close": 17330.0,
    "volume": 111906,
    "contract": "202112"
  },
  {
    "date": "2021-12-01",
    "close": 17584.0,
    "volume": 103548,
    "contract": "202112"
  },
  {
    "date": "2021-12-02",
    "close": 17704.0,
    "volume": 108997,
    "contract": "202112"
  },
  {
    "date": "2021-12-03",
    "close": 17706.0,
    "volume": 79145,
    "contract": "202112"
  },
  {
    "date": "2021-12-06",
    "close": 17692.0,
    "volume": 91121,
    "contract": "202112"
  },
  {
    "date": "2021-12-07",
    "close": 17795.0,
    "volume": 94771,
    "contract": "202112"
  },
  {
    "date": "2021-12-08",
    "close": 17853.0,
    "volume": 94293,
    "contract": "202112"
  },
  {
    "date": "2021-12-09",
    "close": 17910.0,
    "volume": 79412,
    "contract": "202112"
  },
  {
    "date": "2021-12-10",
    "close": 17818.0,
    "volume": 73341,
    "contract": "202112"
  },
  {
    "date": "2021-12-13",
    "close": 17753.0,
    "volume": 102639,
    "contract": "202112"
  },
  {
    "date": "2021-12-14",
    "close": 17602.0,
    "volume": 109694,
    "contract": "202112"
  },
  {
    "date": "2021-12-15",
    "close": 17630.0,
    "volume": 53677,
    "contract": "202112"
  },
  {
    "date": "2021-12-16",
    "close": 17804.0,
    "volume": 84101,
    "contract": "202201"
  },
  {
    "date": "2021-12-17",
    "close": 17785.0,
    "volume": 78566,
    "contract": "202201"
  },
  {
    "date": "2021-12-20",
    "close": 17582.0,
    "volume": 103831,
    "contract": "202201"
  },
  {
    "date": "2021-12-21",
    "close": 17796.0,
    "volume": 87917,
    "contract": "202201"
  },
  {
    "date": "2021-12-22",
    "close": 17832.0,
    "volume": 54102,
    "contract": "202201"
  },
  {
    "date": "2021-12-23",
    "close": 17951.0,
    "volume": 66061,
    "contract": "202201"
  },
  {
    "date": "2021-12-24",
    "close": 17957.0,
    "volume": 50035,
    "contract": "202201"
  },
  {
    "date": "2021-12-27",
    "close": 18070.0,
    "volume": 58096,
    "contract": "202201"
  },
  {
    "date": "2021-12-28",
    "close": 18206.0,
    "volume": 60973,
    "contract": "202201"
  },
  {
    "date": "2021-12-29",
    "close": 18274.0,
    "volume": 57011,
    "contract": "202201"
  },
  {
    "date": "2021-12-30",
    "close": 18209.0,
    "volume": 56933,
    "contract": "202201"
  },
  {
    "date": "2022-01-03",
    "close": 18272.0,
    "volume": 96972,
    "contract": "202201"
  },
  {
    "date": "2022-01-04",
    "close": 18514.0,
    "volume": 90796,
    "contract": "202201"
  },
  {
    "date": "2022-01-05",
    "close": 18480.0,
    "volume": 82044,
    "contract": "202201"
  },
  {
    "date": "2022-01-06",
    "close": 18337.0,
    "volume": 119801,
    "contract": "202201"
  },
  {
    "date": "2022-01-07",
    "close": 18146.0,
    "volume": 137788,
    "contract": "202201"
  },
  {
    "date": "2022-01-10",
    "close": 18260.0,
    "volume": 96625,
    "contract": "202201"
  },
  {
    "date": "2022-01-11",
    "close": 18279.0,
    "volume": 119585,
    "contract": "202201"
  },
  {
    "date": "2022-01-12",
    "close": 18376.0,
    "volume": 90837,
    "contract": "202201"
  },
  {
    "date": "2022-01-13",
    "close": 18425.0,
    "volume": 95326,
    "contract": "202201"
  },
  {
    "date": "2022-01-14",
    "close": 18360.0,
    "volume": 158202,
    "contract": "202201"
  },
  {
    "date": "2022-01-17",
    "close": 18508.0,
    "volume": 117616,
    "contract": "202201"
  },
  {
    "date": "2022-01-18",
    "close": 18350.0,
    "volume": 129157,
    "contract": "202201"
  },
  {
    "date": "2022-01-19",
    "close": 18218.0,
    "volume": 72718,
    "contract": "202201"
  },
  {
    "date": "2022-01-20",
    "close": 18224.0,
    "volume": 119191,
    "contract": "202202"
  },
  {
    "date": "2022-01-21",
    "close": 17896.0,
    "volume": 157754,
    "contract": "202202"
  },
  {
    "date": "2022-01-24",
    "close": 17957.0,
    "volume": 133779,
    "contract": "202202"
  },
  {
    "date": "2022-01-25",
    "close": 17674.0,
    "volume": 158896,
    "contract": "202202"
  },
  {
    "date": "2022-01-26",
    "close": 17624.0,
    "volume": 96254,
    "contract": "202202"
  },
  {
    "date": "2022-02-07",
    "close": 17896.0,
    "volume": 113464,
    "contract": "202202"
  },
  {
    "date": "2022-02-08",
    "close": 17942.0,
    "volume": 89700,
    "contract": "202202"
  },
  {
    "date": "2022-02-09",
    "close": 18164.0,
    "volume": 72278,
    "contract": "202202"
  },
  {
    "date": "2022-02-10",
    "close": 18334.0,
    "volume": 95136,
    "contract": "202202"
  },
  {
    "date": "2022-02-11",
    "close": 18273.0,
    "volume": 87617,
    "contract": "202202"
  },
  {
    "date": "2022-02-14",
    "close": 17977.0,
    "volume": 137955,
    "contract": "202202"
  },
  {
    "date": "2022-02-15",
    "close": 17955.0,
    "volume": 114065,
    "contract": "202202"
  },
  {
    "date": "2022-02-16",
    "close": 18207.0,
    "volume": 63453,
    "contract": "202202"
  },
  {
    "date": "2022-02-17",
    "close": 18244.0,
    "volume": 110179,
    "contract": "202203"
  },
  {
    "date": "2022-02-18",
    "close": 18227.0,
    "volume": 96351,
    "contract": "202203"
  },
  {
    "date": "2022-02-21",
    "close": 18212.0,
    "volume": 95874,
    "contract": "202203"
  },
  {
    "date": "2022-02-22",
    "close": 17880.0,
    "volume": 144406,
    "contract": "202203"
  },
  {
    "date": "2022-02-23",
    "close": 18042.0,
    "volume": 83991,
    "contract": "202203"
  },
  {
    "date": "2022-02-24",
    "close": 17513.0,
    "volume": 187058,
    "contract": "202203"
  },
  {
    "date": "2022-02-25",
    "close": 17610.0,
    "volume": 129514,
    "contract": "202203"
  },
  {
    "date": "2022-03-01",
    "close": 17912.0,
    "volume": 109687,
    "contract": "202203"
  },
  {
    "date": "2022-03-02",
    "close": 17838.0,
    "volume": 94806,
    "contract": "202203"
  },
  {
    "date": "2022-03-03",
    "close": 17929.0,
    "volume": 77058,
    "contract": "202203"
  },
  {
    "date": "2022-03-04",
    "close": 17668.0,
    "volume": 118785,
    "contract": "202203"
  },
  {
    "date": "2022-03-07",
    "close": 17058.0,
    "volume": 157085,
    "contract": "202203"
  },
  {
    "date": "2022-03-08",
    "close": 16707.0,
    "volume": 160675,
    "contract": "202203"
  },
  {
    "date": "2022-03-09",
    "close": 16949.0,
    "volume": 115509,
    "contract": "202203"
  },
  {
    "date": "2022-03-10",
    "close": 17436.0,
    "volume": 102545,
    "contract": "202203"
  },
  {
    "date": "2022-03-11",
    "close": 17226.0,
    "volume": 95875,
    "contract": "202203"
  },
  {
    "date": "2022-03-14",
    "close": 17240.0,
    "volume": 120161,
    "contract": "202203"
  },
  {
    "date": "2022-03-15",
    "close": 16885.0,
    "volume": 141872,
    "contract": "202203"
  },
  {
    "date": "2022-03-16",
    "close": 16937.0,
    "volume": 76060,
    "contract": "202203"
  },
  {
    "date": "2022-03-17",
    "close": 17444.0,
    "volume": 129146,
    "contract": "202204"
  },
  {
    "date": "2022-03-18",
    "close": 17393.0,
    "volume": 96826,
    "contract": "202204"
  },
  {
    "date": "2022-03-21",
    "close": 17491.0,
    "volume": 93353,
    "contract": "202204"
  },
  {
    "date": "2022-03-22",
    "close": 17522.0,
    "volume": 68446,
    "contract": "202204"
  },
  {
    "date": "2022-03-23",
    "close": 17699.0,
    "volume": 88805,
    "contract": "202204"
  },
  {
    "date": "2022-03-24",
    "close": 17669.0,
    "volume": 80125,
    "contract": "202204"
  },
  {
    "date": "2022-03-25",
    "close": 17621.0,
    "volume": 83085,
    "contract": "202204"
  },
  {
    "date": "2022-03-28",
    "close": 17437.0,
    "volume": 117571,
    "contract": "202204"
  },
  {
    "date": "2022-03-29",
    "close": 17546.0,
    "volume": 76398,
    "contract": "202204"
  },
  {
    "date": "2022-03-30",
    "close": 17740.0,
    "volume": 89839,
    "contract": "202204"
  },
  {
    "date": "2022-03-31",
    "close": 17634.0,
    "volume": 78029,
    "contract": "202204"
  },
  {
    "date": "2022-04-01",
    "close": 17557.0,
    "volume": 82047,
    "contract": "202204"
  },
  {
    "date": "2022-04-06",
    "close": 17505.0,
    "volume": 86927,
    "contract": "202204"
  },
  {
    "date": "2022-04-07",
    "close": 17142.0,
    "volume": 114893,
    "contract": "202204"
  },
  {
    "date": "2022-04-08",
    "close": 17304.0,
    "volume": 84229,
    "contract": "202204"
  },
  {
    "date": "2022-04-11",
    "close": 17037.0,
    "volume": 128637,
    "contract": "202204"
  },
  {
    "date": "2022-04-12",
    "close": 17000.0,
    "volume": 107948,
    "contract": "202204"
  },
  {
    "date": "2022-04-13",
    "close": 17316.0,
    "volume": 107841,
    "contract": "202204"
  },
  {
    "date": "2022-04-14",
    "close": 17295.0,
    "volume": 73517,
    "contract": "202204"
  },
  {
    "date": "2022-04-15",
    "close": 16980.0,
    "volume": 97455,
    "contract": "202204"
  },
  {
    "date": "2022-04-18",
    "close": 16884.0,
    "volume": 122230,
    "contract": "202204"
  },
  {
    "date": "2022-04-19",
    "close": 17004.0,
    "volume": 106177,
    "contract": "202204"
  },
  {
    "date": "2022-04-20",
    "close": 17125.0,
    "volume": 57157,
    "contract": "202204"
  },
  {
    "date": "2022-04-21",
    "close": 17126.0,
    "volume": 86180,
    "contract": "202205"
  },
  {
    "date": "2022-04-22",
    "close": 16992.0,
    "volume": 96385,
    "contract": "202205"
  },
  {
    "date": "2022-04-25",
    "close": 16572.0,
    "volume": 123324,
    "contract": "202205"
  },
  {
    "date": "2022-04-26",
    "close": 16585.0,
    "volume": 82214,
    "contract": "202205"
  },
  {
    "date": "2022-04-27",
    "close": 16287.0,
    "volume": 141144,
    "contract": "202205"
  },
  {
    "date": "2022-04-28",
    "close": 16388.0,
    "volume": 103728,
    "contract": "202205"
  },
  {
    "date": "2022-04-29",
    "close": 16581.0,
    "volume": 103887,
    "contract": "202205"
  },
  {
    "date": "2022-05-03",
    "close": 16472.0,
    "volume": 90193,
    "contract": "202205"
  },
  {
    "date": "2022-05-04",
    "close": 16519.0,
    "volume": 69459,
    "contract": "202205"
  },
  {
    "date": "2022-05-05",
    "close": 16685.0,
    "volume": 78883,
    "contract": "202205"
  },
  {
    "date": "2022-05-06",
    "close": 16356.0,
    "volume": 96310,
    "contract": "202205"
  },
  {
    "date": "2022-05-09",
    "close": 16027.0,
    "volume": 99474,
    "contract": "202205"
  },
  {
    "date": "2022-05-10",
    "close": 16038.0,
    "volume": 127562,
    "contract": "202205"
  },
  {
    "date": "2022-05-11",
    "close": 16007.0,
    "volume": 88276,
    "contract": "202205"
  },
  {
    "date": "2022-05-12",
    "close": 15630.0,
    "volume": 118642,
    "contract": "202205"
  },
  {
    "date": "2022-05-13",
    "close": 15849.0,
    "volume": 96199,
    "contract": "202205"
  },
  {
    "date": "2022-05-16",
    "close": 15922.0,
    "volume": 120555,
    "contract": "202205"
  },
  {
    "date": "2022-05-17",
    "close": 16075.0,
    "volume": 95655,
    "contract": "202205"
  },
  {
    "date": "2022-05-18",
    "close": 16302.0,
    "volume": 54930,
    "contract": "202205"
  },
  {
    "date": "2022-05-19",
    "close": 15911.0,
    "volume": 109266,
    "contract": "202206"
  },
  {
    "date": "2022-05-20",
    "close": 16136.0,
    "volume": 85765,
    "contract": "202206"
  },
  {
    "date": "2022-05-23",
    "close": 16143.0,
    "volume": 99214,
    "contract": "202206"
  },
  {
    "date": "2022-05-24",
    "close": 15926.0,
    "volume": 98160,
    "contract": "202206"
  },
  {
    "date": "2022-05-25",
    "close": 16061.0,
    "volume": 98499,
    "contract": "202206"
  },
  {
    "date": "2022-05-26",
    "close": 16110.0,
    "volume": 96418,
    "contract": "202206"
  },
  {
    "date": "2022-05-27",
    "close": 16229.0,
    "volume": 83346,
    "contract": "202206"
  },
  {
    "date": "2022-05-30",
    "close": 16559.0,
    "volume": 81262,
    "contract": "202206"
  },
  {
    "date": "2022-05-31",
    "close": 16681.0,
    "volume": 108041,
    "contract": "202206"
  },
  {
    "date": "2022-06-01",
    "close": 16608.0,
    "volume": 95150,
    "contract": "202206"
  },
  {
    "date": "2022-06-02",
    "close": 16533.0,
    "volume": 80160,
    "contract": "202206"
  },
  {
    "date": "2022-06-06",
    "close": 16600.0,
    "volume": 98914,
    "contract": "202206"
  },
  {
    "date": "2022-06-07",
    "close": 16461.0,
    "volume": 101451,
    "contract": "202206"
  },
  {
    "date": "2022-06-08",
    "close": 16641.0,
    "volume": 80944,
    "contract": "202206"
  },
  {
    "date": "2022-06-09",
    "close": 16577.0,
    "volume": 67567,
    "contract": "202206"
  },
  {
    "date": "2022-06-10",
    "close": 16474.0,
    "volume": 85493,
    "contract": "202206"
  },
  {
    "date": "2022-06-13",
    "close": 16050.0,
    "volume": 129042,
    "contract": "202206"
  },
  {
    "date": "2022-06-14",
    "close": 16052.0,
    "volume": 125318,
    "contract": "202206"
  },
  {
    "date": "2022-06-15",
    "close": 16062.0,
    "volume": 62610,
    "contract": "202206"
  },
  {
    "date": "2022-06-16",
    "close": 15411.0,
    "volume": 127119,
    "contract": "202207"
  },
  {
    "date": "2022-06-17",
    "close": 15202.0,
    "volume": 124040,
    "contract": "202207"
  },
  {
    "date": "2022-06-20",
    "close": 15031.0,
    "volume": 129690,
    "contract": "202207"
  },
  {
    "date": "2022-06-21",
    "close": 15346.0,
    "volume": 115396,
    "contract": "202207"
  },
  {
    "date": "2022-06-22",
    "close": 15015.0,
    "volume": 128332,
    "contract": "202207"
  },
  {
    "date": "2022-06-23",
    "close": 14939.0,
    "volume": 164479,
    "contract": "202207"
  },
  {
    "date": "2022-06-24",
    "close": 15053.0,
    "volume": 119812,
    "contract": "202207"
  },
  {
    "date": "2022-06-27",
    "close": 15277.0,
    "volume": 98695,
    "contract": "202207"
  },
  {
    "date": "2022-06-28",
    "close": 15194.0,
    "volume": 96034,
    "contract": "202207"
  },
  {
    "date": "2022-06-29",
    "close": 15016.0,
    "volume": 100640,
    "contract": "202207"
  },
  {
    "date": "2022-06-30",
    "close": 14624.0,
    "volume": 131995,
    "contract": "202207"
  },
  {
    "date": "2022-07-01",
    "close": 14175.0,
    "volume": 183609,
    "contract": "202207"
  },
  {
    "date": "2022-07-04",
    "close": 14152.0,
    "volume": 143173,
    "contract": "202207"
  },
  {
    "date": "2022-07-05",
    "close": 14209.0,
    "volume": 175274,
    "contract": "202207"
  },
  {
    "date": "2022-07-06",
    "close": 13879.0,
    "volume": 150712,
    "contract": "202207"
  },
  {
    "date": "2022-07-07",
    "close": 14187.0,
    "volume": 158050,
    "contract": "202207"
  },
  {
    "date": "2022-07-08",
    "close": 14332.0,
    "volume": 139319,
    "contract": "202207"
  },
  {
    "date": "2022-07-11",
    "close": 14278.0,
    "volume": 120320,
    "contract": "202207"
  },
  {
    "date": "2022-07-12",
    "close": 13914.0,
    "volume": 127127,
    "contract": "202207"
  },
  {
    "date": "2022-07-13",
    "close": 14281.0,
    "volume": 112460,
    "contract": "202207"
  },
  {
    "date": "2022-07-14",
    "close": 14386.0,
    "volume": 128248,
    "contract": "202207"
  },
  {
    "date": "2022-07-15",
    "close": 14479.0,
    "volume": 118876,
    "contract": "202207"
  },
  {
    "date": "2022-07-18",
    "close": 14647.0,
    "volume": 122938,
    "contract": "202207"
  },
  {
    "date": "2022-07-19",
    "close": 14678.0,
    "volume": 92176,
    "contract": "202207"
  },
  {
    "date": "2022-07-20",
    "close": 14712.0,
    "volume": 63694,
    "contract": "202207"
  },
  {
    "date": "2022-07-21",
    "close": 14747.0,
    "volume": 90902,
    "contract": "202208"
  },
  {
    "date": "2022-07-22",
    "close": 14755.0,
    "volume": 93026,
    "contract": "202208"
  },
  {
    "date": "2022-07-25",
    "close": 14793.0,
    "volume": 82637,
    "contract": "202208"
  },
  {
    "date": "2022-07-26",
    "close": 14707.0,
    "volume": 92221,
    "contract": "202208"
  },
  {
    "date": "2022-07-27",
    "close": 14791.0,
    "volume": 104597,
    "contract": "202208"
  },
  {
    "date": "2022-07-28",
    "close": 14833.0,
    "volume": 94963,
    "contract": "202208"
  },
  {
    "date": "2022-07-29",
    "close": 14940.0,
    "volume": 94106,
    "contract": "202208"
  },
  {
    "date": "2022-08-01",
    "close": 14870.0,
    "volume": 89819,
    "contract": "202208"
  },
  {
    "date": "2022-08-02",
    "close": 14645.0,
    "volume": 108928,
    "contract": "202208"
  },
  {
    "date": "2022-08-03",
    "close": 14672.0,
    "volume": 97984,
    "contract": "202208"
  },
  {
    "date": "2022-08-04",
    "close": 14654.0,
    "volume": 139696,
    "contract": "202208"
  },
  {
    "date": "2022-08-05",
    "close": 15011.0,
    "volume": 95193,
    "contract": "202208"
  },
  {
    "date": "2022-08-08",
    "close": 14961.0,
    "volume": 74401,
    "contract": "202208"
  },
  {
    "date": "2022-08-09",
    "close": 15016.0,
    "volume": 89703,
    "contract": "202208"
  },
  {
    "date": "2022-08-10",
    "close": 14878.0,
    "volume": 77738,
    "contract": "202208"
  },
  {
    "date": "2022-08-11",
    "close": 15184.0,
    "volume": 79733,
    "contract": "202208"
  },
  {
    "date": "2022-08-12",
    "close": 15274.0,
    "volume": 66960,
    "contract": "202208"
  },
  {
    "date": "2022-08-15",
    "close": 15385.0,
    "volume": 89978,
    "contract": "202208"
  },
  {
    "date": "2022-08-16",
    "close": 15425.0,
    "volume": 73097,
    "contract": "202208"
  },
  {
    "date": "2022-08-17",
    "close": 15452.0,
    "volume": 48353,
    "contract": "202208"
  },
  {
    "date": "2022-08-18",
    "close": 15317.0,
    "volume": 69333,
    "contract": "202209"
  },
  {
    "date": "2022-08-19",
    "close": 15354.0,
    "volume": 72613,
    "contract": "202209"
  },
  {
    "date": "2022-08-22",
    "close": 15179.0,
    "volume": 63929,
    "contract": "202209"
  },
  {
    "date": "2022-08-23",
    "close": 15028.0,
    "volume": 68886,
    "contract": "202209"
  },
  {
    "date": "2022-08-24",
    "close": 15035.0,
    "volume": 70377,
    "contract": "202209"
  },
  {
    "date": "2022-08-25",
    "close": 15170.0,
    "volume": 81719,
    "contract": "202209"
  },
  {
    "date": "2022-08-26",
    "close": 15241.0,
    "volume": 62646,
    "contract": "202209"
  },
  {
    "date": "2022-08-29",
    "close": 14820.0,
    "volume": 103087,
    "contract": "202209"
  },
  {
    "date": "2022-08-30",
    "close": 14949.0,
    "volume": 86047,
    "contract": "202209"
  },
  {
    "date": "2022-08-31",
    "close": 15042.0,
    "volume": 108620,
    "contract": "202209"
  },
  {
    "date": "2022-09-01",
    "close": 14737.0,
    "volume": 118005,
    "contract": "202209"
  },
  {
    "date": "2022-09-02",
    "close": 14598.0,
    "volume": 92325,
    "contract": "202209"
  },
  {
    "date": "2022-09-05",
    "close": 14613.0,
    "volume": 92682,
    "contract": "202209"
  },
  {
    "date": "2022-09-06",
    "close": 14635.0,
    "volume": 93184,
    "contract": "202209"
  },
  {
    "date": "2022-09-07",
    "close": 14357.0,
    "volume": 99373,
    "contract": "202209"
  },
  {
    "date": "2022-09-08",
    "close": 14545.0,
    "volume": 88563,
    "contract": "202209"
  },
  {
    "date": "2022-09-12",
    "close": 14797.0,
    "volume": 73967,
    "contract": "202209"
  },
  {
    "date": "2022-09-13",
    "close": 14875.0,
    "volume": 64810,
    "contract": "202209"
  },
  {
    "date": "2022-09-14",
    "close": 14578.0,
    "volume": 88778,
    "contract": "202209"
  },
  {
    "date": "2022-09-15",
    "close": 14642.0,
    "volume": 77473,
    "contract": "202209"
  },
  {
    "date": "2022-09-16",
    "close": 14485.0,
    "volume": 75293,
    "contract": "202209"
  },
  {
    "date": "2022-09-19",
    "close": 14420.0,
    "volume": 96859,
    "contract": "202209"
  },
  {
    "date": "2022-09-20",
    "close": 14558.0,
    "volume": 83214,
    "contract": "202209"
  },
  {
    "date": "2022-09-21",
    "close": 14402.0,
    "volume": 47622,
    "contract": "202209"
  },
  {
    "date": "2022-09-22",
    "close": 14239.0,
    "volume": 104178,
    "contract": "202210"
  },
  {
    "date": "2022-09-23",
    "close": 14118.0,
    "volume": 87010,
    "contract": "202210"
  },
  {
    "date": "2022-09-26",
    "close": 13762.0,
    "volume": 114988,
    "contract": "202210"
  },
  {
    "date": "2022-09-27",
    "close": 13815.0,
    "volume": 94792,
    "contract": "202210"
  },
  {
    "date": "2022-09-28",
    "close": 13515.0,
    "volume": 144383,
    "contract": "202210"
  },
  {
    "date": "2022-09-29",
    "close": 13523.0,
    "volume": 115038,
    "contract": "202210"
  },
  {
    "date": "2022-09-30",
    "close": 13394.0,
    "volume": 120030,
    "contract": "202210"
  },
  {
    "date": "2022-10-03",
    "close": 13303.0,
    "volume": 110724,
    "contract": "202210"
  },
  {
    "date": "2022-10-04",
    "close": 13593.0,
    "volume": 91521,
    "contract": "202210"
  },
  {
    "date": "2022-10-05",
    "close": 13814.0,
    "volume": 116457,
    "contract": "202210"
  },
  {
    "date": "2022-10-06",
    "close": 13871.0,
    "volume": 89623,
    "contract": "202210"
  },
  {
    "date": "2022-10-07",
    "close": 13688.0,
    "volume": 81120,
    "contract": "202210"
  },
  {
    "date": "2022-10-11",
    "close": 13090.0,
    "volume": 132727,
    "contract": "202210"
  },
  {
    "date": "2022-10-12",
    "close": 13072.0,
    "volume": 111132,
    "contract": "202210"
  },
  {
    "date": "2022-10-13",
    "close": 12869.0,
    "volume": 125033,
    "contract": "202210"
  },
  {
    "date": "2022-10-14",
    "close": 13168.0,
    "volume": 101646,
    "contract": "202210"
  },
  {
    "date": "2022-10-17",
    "close": 12978.0,
    "volume": 138854,
    "contract": "202210"
  },
  {
    "date": "2022-10-18",
    "close": 13100.0,
    "volume": 125759,
    "contract": "202210"
  },
  {
    "date": "2022-10-19",
    "close": 12998.0,
    "volume": 69733,
    "contract": "202210"
  },
  {
    "date": "2022-10-20",
    "close": 12898.0,
    "volume": 137538,
    "contract": "202211"
  },
  {
    "date": "2022-10-21",
    "close": 12805.0,
    "volume": 107939,
    "contract": "202211"
  },
  {
    "date": "2022-10-24",
    "close": 12884.0,
    "volume": 120336,
    "contract": "202211"
  },
  {
    "date": "2022-10-25",
    "close": 12685.0,
    "volume": 146455,
    "contract": "202211"
  },
  {
    "date": "2022-10-26",
    "close": 12741.0,
    "volume": 108896,
    "contract": "202211"
  },
  {
    "date": "2022-10-27",
    "close": 12956.0,
    "volume": 97666,
    "contract": "202211"
  },
  {
    "date": "2022-10-28",
    "close": 12767.0,
    "volume": 97431,
    "contract": "202211"
  },
  {
    "date": "2022-10-31",
    "close": 12943.0,
    "volume": 88369,
    "contract": "202211"
  },
  {
    "date": "2022-11-01",
    "close": 13033.0,
    "volume": 91434,
    "contract": "202211"
  },
  {
    "date": "2022-11-02",
    "close": 13084.0,
    "volume": 66189,
    "contract": "202211"
  },
  {
    "date": "2022-11-03",
    "close": 12957.0,
    "volume": 74133,
    "contract": "202211"
  },
  {
    "date": "2022-11-04",
    "close": 13029.0,
    "volume": 82593,
    "contract": "202211"
  },
  {
    "date": "2022-11-07",
    "close": 13225.0,
    "volume": 95613,
    "contract": "202211"
  },
  {
    "date": "2022-11-08",
    "close": 13333.0,
    "volume": 74647,
    "contract": "202211"
  },
  {
    "date": "2022-11-09",
    "close": 13593.0,
    "volume": 87870,
    "contract": "202211"
  },
  {
    "date": "2022-11-10",
    "close": 13486.0,
    "volume": 71235,
    "contract": "202211"
  },
  {
    "date": "2022-11-11",
    "close": 14054.0,
    "volume": 115281,
    "contract": "202211"
  },
  {
    "date": "2022-11-14",
    "close": 14125.0,
    "volume": 114862,
    "contract": "202211"
  },
  {
    "date": "2022-11-15",
    "close": 14524.0,
    "volume": 140937,
    "contract": "202211"
  },
  {
    "date": "2022-11-16",
    "close": 14499.0,
    "volume": 75223,
    "contract": "202211"
  },
  {
    "date": "2022-11-17",
    "close": 14511.0,
    "volume": 88530,
    "contract": "202212"
  },
  {
    "date": "2022-11-18",
    "close": 14465.0,
    "volume": 114375,
    "contract": "202212"
  },
  {
    "date": "2022-11-21",
    "close": 14431.0,
    "volume": 80224,
    "contract": "202212"
  },
  {
    "date": "2022-11-22",
    "close": 14504.0,
    "volume": 88314,
    "contract": "202212"
  },
  {
    "date": "2022-11-23",
    "close": 14599.0,
    "volume": 76990,
    "contract": "202212"
  },
  {
    "date": "2022-11-24",
    "close": 14774.0,
    "volume": 77474,
    "contract": "202212"
  },
  {
    "date": "2022-11-25",
    "close": 14710.0,
    "volume": 68961,
    "contract": "202212"
  },
  {
    "date": "2022-11-28",
    "close": 14474.0,
    "volume": 106570,
    "contract": "202212"
  },
  {
    "date": "2022-11-29",
    "close": 14660.0,
    "volume": 92020,
    "contract": "202212"
  },
  {
    "date": "2022-11-30",
    "close": 14802.0,
    "volume": 101856,
    "contract": "202212"
  },
  {
    "date": "2022-12-01",
    "close": 14980.0,
    "volume": 109793,
    "contract": "202212"
  },
  {
    "date": "2022-12-02",
    "close": 14884.0,
    "volume": 70239,
    "contract": "202212"
  },
  {
    "date": "2022-12-05",
    "close": 14930.0,
    "volume": 79795,
    "contract": "202212"
  },
  {
    "date": "2022-12-06",
    "close": 14679.0,
    "volume": 92759,
    "contract": "202212"
  },
  {
    "date": "2022-12-07",
    "close": 14625.0,
    "volume": 106919,
    "contract": "202212"
  },
  {
    "date": "2022-12-08",
    "close": 14495.0,
    "volume": 99806,
    "contract": "202212"
  },
  {
    "date": "2022-12-09",
    "close": 14709.0,
    "volume": 88022,
    "contract": "202212"
  },
  {
    "date": "2022-12-12",
    "close": 14583.0,
    "volume": 87221,
    "contract": "202212"
  },
  {
    "date": "2022-12-13",
    "close": 14518.0,
    "volume": 86066,
    "contract": "202212"
  },
  {
    "date": "2022-12-14",
    "close": 14710.0,
    "volume": 88287,
    "contract": "202212"
  },
  {
    "date": "2022-12-15",
    "close": 14713.0,
    "volume": 88235,
    "contract": "202212"
  },
  {
    "date": "2022-12-16",
    "close": 14463.0,
    "volume": 104255,
    "contract": "202212"
  },
  {
    "date": "2022-12-19",
    "close": 14407.0,
    "volume": 98774,
    "contract": "202212"
  },
  {
    "date": "2022-12-20",
    "close": 14153.0,
    "volume": 131280,
    "contract": "202212"
  },
  {
    "date": "2022-12-21",
    "close": 14219.0,
    "volume": 48935,
    "contract": "202212"
  },
  {
    "date": "2022-12-22",
    "close": 14374.0,
    "volume": 71964,
    "contract": "202301"
  },
  {
    "date": "2022-12-23",
    "close": 14189.0,
    "volume": 72919,
    "contract": "202301"
  },
  {
    "date": "2022-12-26",
    "close": 14243.0,
    "volume": 35315,
    "contract": "202301"
  },
  {
    "date": "2022-12-27",
    "close": 14305.0,
    "volume": 65334,
    "contract": "202301"
  },
  {
    "date": "2022-12-28",
    "close": 14112.0,
    "volume": 84583,
    "contract": "202301"
  },
  {
    "date": "2022-12-29",
    "close": 14034.0,
    "volume": 78436,
    "contract": "202301"
  },
  {
    "date": "2022-12-30",
    "close": 14135.0,
    "volume": 61365,
    "contract": "202301"
  },
  {
    "date": "2023-01-03",
    "close": 14230.0,
    "volume": 114614,
    "contract": "202301"
  },
  {
    "date": "2023-01-04",
    "close": 14209.0,
    "volume": 69531,
    "contract": "202301"
  },
  {
    "date": "2023-01-05",
    "close": 14289.0,
    "volume": 77650,
    "contract": "202301"
  },
  {
    "date": "2023-01-06",
    "close": 14366.0,
    "volume": 78727,
    "contract": "202301"
  },
  {
    "date": "2023-01-09",
    "close": 14765.0,
    "volume": 80242,
    "contract": "202301"
  },
  {
    "date": "2023-01-10",
    "close": 14810.0,
    "volume": 69053,
    "contract": "202301"
  },
  {
    "date": "2023-01-11",
    "close": 14791.0,
    "volume": 62375,
    "contract": "202301"
  },
  {
    "date": "2023-01-12",
    "close": 14766.0,
    "volume": 68357,
    "contract": "202301"
  },
  {
    "date": "2023-01-13",
    "close": 14834.0,
    "volume": 83193,
    "contract": "202301"
  },
  {
    "date": "2023-01-16",
    "close": 14938.0,
    "volume": 84845,
    "contract": "202301"
  },
  {
    "date": "2023-01-17",
    "close": 14925.0,
    "volume": 68548,
    "contract": "202301"
  },
  {
    "date": "2023-01-30",
    "close": 15451.0,
    "volume": 45946,
    "contract": "202301"
  },
  {
    "date": "2023-01-31",
    "close": 15268.0,
    "volume": 72954,
    "contract": "202302"
  },
  {
    "date": "2023-02-01",
    "close": 15382.0,
    "volume": 61365,
    "contract": "202302"
  },
  {
    "date": "2023-02-02",
    "close": 15580.0,
    "volume": 75910,
    "contract": "202302"
  },
  {
    "date": "2023-02-03",
    "close": 15581.0,
    "volume": 71763,
    "contract": "202302"
  },
  {
    "date": "2023-02-06",
    "close": 15407.0,
    "volume": 75333,
    "contract": "202302"
  },
  {
    "date": "2023-02-07",
    "close": 15397.0,
    "volume": 65134,
    "contract": "202302"
  },
  {
    "date": "2023-02-08",
    "close": 15604.0,
    "volume": 72141,
    "contract": "202302"
  },
  {
    "date": "2023-02-09",
    "close": 15523.0,
    "volume": 43979,
    "contract": "202302"
  },
  {
    "date": "2023-02-10",
    "close": 15577.0,
    "volume": 87442,
    "contract": "202302"
  },
  {
    "date": "2023-02-13",
    "close": 15532.0,
    "volume": 100940,
    "contract": "202302"
  },
  {
    "date": "2023-02-14",
    "close": 15658.0,
    "volume": 76846,
    "contract": "202302"
  },
  {
    "date": "2023-02-15",
    "close": 15398.0,
    "volume": 60917,
    "contract": "202302"
  },
  {
    "date": "2023-02-16",
    "close": 15543.0,
    "volume": 81731,
    "contract": "202303"
  },
  {
    "date": "2023-02-17",
    "close": 15436.0,
    "volume": 71212,
    "contract": "202303"
  },
  {
    "date": "2023-02-20",
    "close": 15524.0,
    "volume": 70776,
    "contract": "202303"
  },
  {
    "date": "2023-02-21",
    "close": 15528.0,
    "volume": 57221,
    "contract": "202303"
  },
  {
    "date": "2023-02-22",
    "close": 15375.0,
    "volume": 80471,
    "contract": "202303"
  },
  {
    "date": "2023-02-23",
    "close": 15600.0,
    "volume": 92289,
    "contract": "202303"
  },
  {
    "date": "2023-02-24",
    "close": 15541.0,
    "volume": 76672,
    "contract": "202303"
  },
  {
    "date": "2023-03-01",
    "close": 15546.0,
    "volume": 82601,
    "contract": "202303"
  },
  {
    "date": "2023-03-02",
    "close": 15542.0,
    "volume": 81548,
    "contract": "202303"
  },
  {
    "date": "2023-03-03",
    "close": 15615.0,
    "volume": 81464,
    "contract": "202303"
  },
  {
    "date": "2023-03-06",
    "close": 15772.0,
    "volume": 88661,
    "contract": "202303"
  },
  {
    "date": "2023-03-07",
    "close": 15873.0,
    "volume": 66075,
    "contract": "202303"
  },
  {
    "date": "2023-03-08",
    "close": 15785.0,
    "volume": 75396,
    "contract": "202303"
  },
  {
    "date": "2023-03-09",
    "close": 15766.0,
    "volume": 63471,
    "contract": "202303"
  },
  {
    "date": "2023-03-10",
    "close": 15481.0,
    "volume": 100898,
    "contract": "202303"
  },
  {
    "date": "2023-03-13",
    "close": 15519.0,
    "volume": 137218,
    "contract": "202303"
  },
  {
    "date": "2023-03-14",
    "close": 15354.0,
    "volume": 103551,
    "contract": "202303"
  },
  {
    "date": "2023-03-15",
    "close": 15404.0,
    "volume": 54171,
    "contract": "202303"
  },
  {
    "date": "2023-03-16",
    "close": 15226.0,
    "volume": 115384,
    "contract": "202304"
  },
  {
    "date": "2023-03-17",
    "close": 15405.0,
    "volume": 91820,
    "contract": "202304"
  },
  {
    "date": "2023-03-20",
    "close": 15370.0,
    "volume": 79652,
    "contract": "202304"
  },
  {
    "date": "2023-03-21",
    "close": 15455.0,
    "volume": 73240,
    "contract": "202304"
  },
  {
    "date": "2023-03-22",
    "close": 15715.0,
    "volume": 79375,
    "contract": "202304"
  },
  {
    "date": "2023-03-23",
    "close": 15836.0,
    "volume": 87831,
    "contract": "202304"
  },
  {
    "date": "2023-03-24",
    "close": 15917.0,
    "volume": 72534,
    "contract": "202304"
  },
  {
    "date": "2023-03-27",
    "close": 15829.0,
    "volume": 72250,
    "contract": "202304"
  },
  {
    "date": "2023-03-28",
    "close": 15689.0,
    "volume": 84158,
    "contract": "202304"
  },
  {
    "date": "2023-03-29",
    "close": 15738.0,
    "volume": 77212,
    "contract": "202304"
  },
  {
    "date": "2023-03-30",
    "close": 15819.0,
    "volume": 78724,
    "contract": "202304"
  },
  {
    "date": "2023-03-31",
    "close": 15864.0,
    "volume": 82044,
    "contract": "202304"
  },
  {
    "date": "2023-04-06",
    "close": 15762.0,
    "volume": 71495,
    "contract": "202304"
  },
  {
    "date": "2023-04-07",
    "close": 15818.0,
    "volume": 52583,
    "contract": "202304"
  },
  {
    "date": "2023-04-10",
    "close": 15851.0,
    "volume": 61327,
    "contract": "202304"
  },
  {
    "date": "2023-04-11",
    "close": 15924.0,
    "volume": 81532,
    "contract": "202304"
  },
  {
    "date": "2023-04-12",
    "close": 15925.0,
    "volume": 57123,
    "contract": "202304"
  },
  {
    "date": "2023-04-13",
    "close": 15816.0,
    "volume": 79548,
    "contract": "202304"
  },
  {
    "date": "2023-04-14",
    "close": 15948.0,
    "volume": 88415,
    "contract": "202304"
  },
  {
    "date": "2023-04-17",
    "close": 15970.0,
    "volume": 84803,
    "contract": "202304"
  },
  {
    "date": "2023-04-18",
    "close": 15891.0,
    "volume": 90958,
    "contract": "202304"
  },
  {
    "date": "2023-04-19",
    "close": 15775.0,
    "volume": 53512,
    "contract": "202304"
  },
  {
    "date": "2023-04-20",
    "close": 15731.0,
    "volume": 95145,
    "contract": "202305"
  },
  {
    "date": "2023-04-21",
    "close": 15614.0,
    "volume": 101724,
    "contract": "202305"
  },
  {
    "date": "2023-04-24",
    "close": 15620.0,
    "volume": 74865,
    "contract": "202305"
  },
  {
    "date": "2023-04-25",
    "close": 15389.0,
    "volume": 117880,
    "contract": "202305"
  },
  {
    "date": "2023-04-26",
    "close": 15376.0,
    "volume": 96433,
    "contract": "202305"
  },
  {
    "date": "2023-04-27",
    "close": 15426.0,
    "volume": 85853,
    "contract": "202305"
  },
  {
    "date": "2023-04-28",
    "close": 15572.0,
    "volume": 84556,
    "contract": "202305"
  },
  {
    "date": "2023-05-02",
    "close": 15635.0,
    "volume": 78993,
    "contract": "202305"
  },
  {
    "date": "2023-05-03",
    "close": 15549.0,
    "volume": 67779,
    "contract": "202305"
  },
  {
    "date": "2023-05-04",
    "close": 15607.0,
    "volume": 70601,
    "contract": "202305"
  },
  {
    "date": "2023-05-05",
    "close": 15642.0,
    "volume": 79097,
    "contract": "202305"
  },
  {
    "date": "2023-05-08",
    "close": 15723.0,
    "volume": 67383,
    "contract": "202305"
  },
  {
    "date": "2023-05-09",
    "close": 15736.0,
    "volume": 73221,
    "contract": "202305"
  },
  {
    "date": "2023-05-10",
    "close": 15610.0,
    "volume": 79948,
    "contract": "202305"
  },
  {
    "date": "2023-05-11",
    "close": 15519.0,
    "volume": 92649,
    "contract": "202305"
  },
  {
    "date": "2023-05-12",
    "close": 15506.0,
    "volume": 89636,
    "contract": "202305"
  },
  {
    "date": "2023-05-15",
    "close": 15510.0,
    "volume": 98204,
    "contract": "202305"
  },
  {
    "date": "2023-05-16",
    "close": 15690.0,
    "volume": 86477,
    "contract": "202305"
  },
  {
    "date": "2023-05-17",
    "close": 15954.0,
    "volume": 67413,
    "contract": "202305"
  },
  {
    "date": "2023-05-18",
    "close": 16069.0,
    "volume": 86157,
    "contract": "202306"
  },
  {
    "date": "2023-05-19",
    "close": 16127.0,
    "volume": 72580,
    "contract": "202306"
  },
  {
    "date": "2023-05-22",
    "close": 16115.0,
    "volume": 57628,
    "contract": "202306"
  },
  {
    "date": "2023-05-23",
    "close": 16135.0,
    "volume": 82150,
    "contract": "202306"
  },
  {
    "date": "2023-05-24",
    "close": 16069.0,
    "volume": 76889,
    "contract": "202306"
  },
  {
    "date": "2023-05-25",
    "close": 16205.0,
    "volume": 98367,
    "contract": "202306"
  },
  {
    "date": "2023-05-26",
    "close": 16438.0,
    "volume": 89892,
    "contract": "202306"
  },
  {
    "date": "2023-05-29",
    "close": 16578.0,
    "volume": 73815,
    "contract": "202306"
  },
  {
    "date": "2023-05-30",
    "close": 16573.0,
    "volume": 66386,
    "contract": "202306"
  },
  {
    "date": "2023-05-31",
    "close": 16488.0,
    "volume": 97967,
    "contract": "202306"
  },
  {
    "date": "2023-06-01",
    "close": 16469.0,
    "volume": 70078,
    "contract": "202306"
  },
  {
    "date": "2023-06-02",
    "close": 16711.0,
    "volume": 81950,
    "contract": "202306"
  },
  {
    "date": "2023-06-05",
    "close": 16683.0,
    "volume": 67739,
    "contract": "202306"
  },
  {
    "date": "2023-06-06",
    "close": 16746.0,
    "volume": 76480,
    "contract": "202306"
  },
  {
    "date": "2023-06-07",
    "close": 16890.0,
    "volume": 75944,
    "contract": "202306"
  },
  {
    "date": "2023-06-08",
    "close": 16717.0,
    "volume": 86320,
    "contract": "202306"
  },
  {
    "date": "2023-06-09",
    "close": 16886.0,
    "volume": 68556,
    "contract": "202306"
  },
  {
    "date": "2023-06-12",
    "close": 16942.0,
    "volume": 62748,
    "contract": "202306"
  },
  {
    "date": "2023-06-13",
    "close": 17218.0,
    "volume": 89364,
    "contract": "202306"
  },
  {
    "date": "2023-06-14",
    "close": 17199.0,
    "volume": 70092,
    "contract": "202306"
  },
  {
    "date": "2023-06-15",
    "close": 17336.0,
    "volume": 73605,
    "contract": "202306"
  },
  {
    "date": "2023-06-16",
    "close": 17269.0,
    "volume": 89295,
    "contract": "202306"
  },
  {
    "date": "2023-06-19",
    "close": 17253.0,
    "volume": 89130,
    "contract": "202306"
  },
  {
    "date": "2023-06-20",
    "close": 17189.0,
    "volume": 99173,
    "contract": "202306"
  },
  {
    "date": "2023-06-21",
    "close": 17229.0,
    "volume": 45409,
    "contract": "202306"
  },
  {
    "date": "2023-06-26",
    "close": 16919.0,
    "volume": 33073,
    "contract": "202307"
  },
  {
    "date": "2023-06-27",
    "close": 16794.0,
    "volume": 34002,
    "contract": "202307"
  },
  {
    "date": "2023-06-28",
    "close": 16775.0,
    "volume": 75639,
    "contract": "202307"
  },
  {
    "date": "2023-06-29",
    "close": 16762.0,
    "volume": 111710,
    "contract": "202307"
  },
  {
    "date": "2023-06-30",
    "close": 16787.0,
    "volume": 76943,
    "contract": "202307"
  },
  {
    "date": "2023-07-03",
    "close": 17035.0,
    "volume": 75504,
    "contract": "202307"
  },
  {
    "date": "2023-07-04",
    "close": 17103.0,
    "volume": 67409,
    "contract": "202307"
  },
  {
    "date": "2023-07-05",
    "close": 17005.0,
    "volume": 72937,
    "contract": "202307"
  },
  {
    "date": "2023-07-06",
    "close": 16689.0,
    "volume": 108783,
    "contract": "202307"
  },
  {
    "date": "2023-07-07",
    "close": 16624.0,
    "volume": 96841,
    "contract": "202307"
  },
  {
    "date": "2023-07-10",
    "close": 16553.0,
    "volume": 99315,
    "contract": "202307"
  },
  {
    "date": "2023-07-11",
    "close": 16866.0,
    "volume": 83593,
    "contract": "202307"
  },
  {
    "date": "2023-07-12",
    "close": 16922.0,
    "volume": 78402,
    "contract": "202307"
  },
  {
    "date": "2023-07-13",
    "close": 17086.0,
    "volume": 107250,
    "contract": "202307"
  },
  {
    "date": "2023-07-14",
    "close": 17291.0,
    "volume": 88668,
    "contract": "202307"
  },
  {
    "date": "2023-07-17",
    "close": 17287.0,
    "volume": 94891,
    "contract": "202307"
  },
  {
    "date": "2023-07-18",
    "close": 17220.0,
    "volume": 119145,
    "contract": "202307"
  },
  {
    "date": "2023-07-19",
    "close": 17102.0,
    "volume": 67858,
    "contract": "202307"
  },
  {
    "date": "2023-07-20",
    "close": 17126.0,
    "volume": 88053,
    "contract": "202308"
  },
  {
    "date": "2023-07-21",
    "close": 16947.0,
    "volume": 99103,
    "contract": "202308"
  },
  {
    "date": "2023-07-24",
    "close": 16979.0,
    "volume": 94583,
    "contract": "202308"
  },
  {
    "date": "2023-07-25",
    "close": 17182.0,
    "volume": 92668,
    "contract": "202308"
  },
  {
    "date": "2023-07-26",
    "close": 17100.0,
    "volume": 92561,
    "contract": "202308"
  },
  {
    "date": "2023-07-27",
    "close": 17223.0,
    "volume": 91001,
    "contract": "202308"
  },
  {
    "date": "2023-07-28",
    "close": 17262.0,
    "volume": 105980,
    "contract": "202308"
  },
  {
    "date": "2023-07-31",
    "close": 17103.0,
    "volume": 130814,
    "contract": "202308"
  },
  {
    "date": "2023-08-01",
    "close": 17178.0,
    "volume": 92003,
    "contract": "202308"
  },
  {
    "date": "2023-08-02",
    "close": 16820.0,
    "volume": 136576,
    "contract": "202308"
  },
  {
    "date": "2023-08-03",
    "close": 16666.0,
    "volume": 66447,
    "contract": "202308"
  },
  {
    "date": "2023-08-04",
    "close": 16823.0,
    "volume": 96586,
    "contract": "202308"
  },
  {
    "date": "2023-08-07",
    "close": 17000.0,
    "volume": 93476,
    "contract": "202308"
  },
  {
    "date": "2023-08-08",
    "close": 16852.0,
    "volume": 114678,
    "contract": "202308"
  },
  {
    "date": "2023-08-09",
    "close": 16853.0,
    "volume": 99083,
    "contract": "202308"
  },
  {
    "date": "2023-08-10",
    "close": 16656.0,
    "volume": 115276,
    "contract": "202308"
  },
  {
    "date": "2023-08-11",
    "close": 16625.0,
    "volume": 96858,
    "contract": "202308"
  },
  {
    "date": "2023-08-14",
    "close": 16377.0,
    "volume": 142754,
    "contract": "202308"
  },
  {
    "date": "2023-08-15",
    "close": 16423.0,
    "volume": 89792,
    "contract": "202308"
  },
  {
    "date": "2023-08-16",
    "close": 16364.0,
    "volume": 58199,
    "contract": "202308"
  },
  {
    "date": "2023-08-17",
    "close": 16456.0,
    "volume": 124759,
    "contract": "202309"
  },
  {
    "date": "2023-08-18",
    "close": 16353.0,
    "volume": 118197,
    "contract": "202309"
  },
  {
    "date": "2023-08-21",
    "close": 16348.0,
    "volume": 91744,
    "contract": "202309"
  },
  {
    "date": "2023-08-22",
    "close": 16400.0,
    "volume": 86244,
    "contract": "202309"
  },
  {
    "date": "2023-08-23",
    "close": 16558.0,
    "volume": 97878,
    "contract": "202309"
  },
  {
    "date": "2023-08-24",
    "close": 16756.0,
    "volume": 108492,
    "contract": "202309"
  },
  {
    "date": "2023-08-25",
    "close": 16426.0,
    "volume": 99877,
    "contract": "202309"
  },
  {
    "date": "2023-08-28",
    "close": 16492.0,
    "volume": 83055,
    "contract": "202309"
  },
  {
    "date": "2023-08-29",
    "close": 16624.0,
    "volume": 84833,
    "contract": "202309"
  },
  {
    "date": "2023-08-30",
    "close": 16723.0,
    "volume": 69975,
    "contract": "202309"
  },
  {
    "date": "2023-08-31",
    "close": 16620.0,
    "volume": 89842,
    "contract": "202309"
  },
  {
    "date": "2023-09-01",
    "close": 16651.0,
    "volume": 78439,
    "contract": "202309"
  },
  {
    "date": "2023-09-04",
    "close": 16778.0,
    "volume": 84928,
    "contract": "202309"
  },
  {
    "date": "2023-09-05",
    "close": 16752.0,
    "volume": 57012,
    "contract": "202309"
  },
  {
    "date": "2023-09-06",
    "close": 16713.0,
    "volume": 70796,
    "contract": "202309"
  },
  {
    "date": "2023-09-07",
    "close": 16563.0,
    "volume": 78366,
    "contract": "202309"
  },
  {
    "date": "2023-09-08",
    "close": 16562.0,
    "volume": 74559,
    "contract": "202309"
  },
  {
    "date": "2023-09-11",
    "close": 16425.0,
    "volume": 104377,
    "contract": "202309"
  },
  {
    "date": "2023-09-12",
    "close": 16570.0,
    "volume": 94566,
    "contract": "202309"
  },
  {
    "date": "2023-09-13",
    "close": 16579.0,
    "volume": 79200,
    "contract": "202309"
  },
  {
    "date": "2023-09-14",
    "close": 16836.0,
    "volume": 83243,
    "contract": "202309"
  },
  {
    "date": "2023-09-15",
    "close": 16904.0,
    "volume": 76226,
    "contract": "202309"
  },
  {
    "date": "2023-09-18",
    "close": 16712.0,
    "volume": 99184,
    "contract": "202309"
  },
  {
    "date": "2023-09-19",
    "close": 16606.0,
    "volume": 87209,
    "contract": "202309"
  },
  {
    "date": "2023-09-20",
    "close": 16537.0,
    "volume": 47771,
    "contract": "202309"
  },
  {
    "date": "2023-09-21",
    "close": 16311.0,
    "volume": 104132,
    "contract": "202310"
  },
  {
    "date": "2023-09-22",
    "close": 16344.0,
    "volume": 77457,
    "contract": "202310"
  },
  {
    "date": "2023-09-25",
    "close": 16465.0,
    "volume": 69416,
    "contract": "202310"
  },
  {
    "date": "2023-09-26",
    "close": 16305.0,
    "volume": 88022,
    "contract": "202310"
  },
  {
    "date": "2023-09-27",
    "close": 16311.0,
    "volume": 76137,
    "contract": "202310"
  },
  {
    "date": "2023-09-28",
    "close": 16367.0,
    "volume": 90613,
    "contract": "202310"
  },
  {
    "date": "2023-10-02",
    "close": 16556.0,
    "volume": 76695,
    "contract": "202310"
  },
  {
    "date": "2023-10-03",
    "close": 16411.0,
    "volume": 84437,
    "contract": "202310"
  },
  {
    "date": "2023-10-04",
    "close": 16245.0,
    "volume": 105815,
    "contract": "202310"
  },
  {
    "date": "2023-10-05",
    "close": 16457.0,
    "volume": 88286,
    "contract": "202310"
  },
  {
    "date": "2023-10-06",
    "close": 16528.0,
    "volume": 67779,
    "contract": "202310"
  },
  {
    "date": "2023-10-11",
    "close": 16714.0,
    "volume": 83064,
    "contract": "202310"
  },
  {
    "date": "2023-10-12",
    "close": 16848.0,
    "volume": 76196,
    "contract": "202310"
  },
  {
    "date": "2023-10-13",
    "close": 16771.0,
    "volume": 67885,
    "contract": "202310"
  },
  {
    "date": "2023-10-16",
    "close": 16649.0,
    "volume": 101143,
    "contract": "202310"
  },
  {
    "date": "2023-10-17",
    "close": 16650.0,
    "volume": 82744,
    "contract": "202310"
  },
  {
    "date": "2023-10-18",
    "close": 16426.0,
    "volume": 62045,
    "contract": "202310"
  },
  {
    "date": "2023-10-19",
    "close": 16461.0,
    "volume": 83646,
    "contract": "202311"
  },
  {
    "date": "2023-10-20",
    "close": 16493.0,
    "volume": 80661,
    "contract": "202311"
  },
  {
    "date": "2023-10-23",
    "close": 16300.0,
    "volume": 62160,
    "contract": "202311"
  },
  {
    "date": "2023-10-24",
    "close": 16298.0,
    "volume": 72625,
    "contract": "202311"
  },
  {
    "date": "2023-10-25",
    "close": 16393.0,
    "volume": 61621,
    "contract": "202311"
  },
  {
    "date": "2023-10-26",
    "close": 16213.0,
    "volume": 72944,
    "contract": "202311"
  },
  {
    "date": "2023-10-27",
    "close": 16081.0,
    "volume": 75377,
    "contract": "202311"
  },
  {
    "date": "2023-10-30",
    "close": 16160.0,
    "volume": 88685,
    "contract": "202311"
  },
  {
    "date": "2023-10-31",
    "close": 16200.0,
    "volume": 52886,
    "contract": "202311"
  },
  {
    "date": "2023-11-01",
    "close": 16061.0,
    "volume": 56324,
    "contract": "202311"
  },
  {
    "date": "2023-11-02",
    "close": 16203.0,
    "volume": 55992,
    "contract": "202311"
  },
  {
    "date": "2023-11-03",
    "close": 16505.0,
    "volume": 50200,
    "contract": "202311"
  },
  {
    "date": "2023-11-06",
    "close": 16616.0,
    "volume": 51809,
    "contract": "202311"
  },
  {
    "date": "2023-11-07",
    "close": 16682.0,
    "volume": 38210,
    "contract": "202311"
  },
  {
    "date": "2023-11-08",
    "close": 16762.0,
    "volume": 41448,
    "contract": "202311"
  },
  {
    "date": "2023-11-09",
    "close": 16729.0,
    "volume": 38237,
    "contract": "202311"
  },
  {
    "date": "2023-11-10",
    "close": 16715.0,
    "volume": 52457,
    "contract": "202311"
  },
  {
    "date": "2023-11-13",
    "close": 17019.0,
    "volume": 59390,
    "contract": "202311"
  },
  {
    "date": "2023-11-14",
    "close": 16911.0,
    "volume": 33441,
    "contract": "202311"
  },
  {
    "date": "2023-11-15",
    "close": 17161.0,
    "volume": 50490,
    "contract": "202311"
  },
  {
    "date": "2023-11-16",
    "close": 17195.0,
    "volume": 61670,
    "contract": "202312"
  },
  {
    "date": "2023-11-17",
    "close": 17158.0,
    "volume": 55444,
    "contract": "202312"
  },
  {
    "date": "2023-11-20",
    "close": 17211.0,
    "volume": 36633,
    "contract": "202312"
  },
  {
    "date": "2023-11-21",
    "close": 17273.0,
    "volume": 32148,
    "contract": "202312"
  },
  {
    "date": "2023-11-22",
    "close": 17331.0,
    "volume": 41362,
    "contract": "202312"
  },
  {
    "date": "2023-11-23",
    "close": 17306.0,
    "volume": 57624,
    "contract": "202312"
  },
  {
    "date": "2023-11-24",
    "close": 17319.0,
    "volume": 26862,
    "contract": "202312"
  },
  {
    "date": "2023-11-27",
    "close": 17294.0,
    "volume": 21317,
    "contract": "202312"
  },
  {
    "date": "2023-11-28",
    "close": 17221.0,
    "volume": 30516,
    "contract": "202312"
  },
  {
    "date": "2023-11-29",
    "close": 17360.0,
    "volume": 34606,
    "contract": "202312"
  },
  {
    "date": "2023-11-30",
    "close": 17378.0,
    "volume": 41954,
    "contract": "202312"
  },
  {
    "date": "2023-12-01",
    "close": 17345.0,
    "volume": 55842,
    "contract": "202312"
  },
  {
    "date": "2023-12-04",
    "close": 17493.0,
    "volume": 57183,
    "contract": "202312"
  },
  {
    "date": "2023-12-05",
    "close": 17319.0,
    "volume": 46940,
    "contract": "202312"
  },
  {
    "date": "2023-12-06",
    "close": 17335.0,
    "volume": 40891,
    "contract": "202312"
  },
  {
    "date": "2023-12-07",
    "close": 17312.0,
    "volume": 43539,
    "contract": "202312"
  },
  {
    "date": "2023-12-08",
    "close": 17401.0,
    "volume": 46376,
    "contract": "202312"
  },
  {
    "date": "2023-12-11",
    "close": 17422.0,
    "volume": 50722,
    "contract": "202312"
  },
  {
    "date": "2023-12-12",
    "close": 17510.0,
    "volume": 34732,
    "contract": "202312"
  },
  {
    "date": "2023-12-13",
    "close": 17488.0,
    "volume": 47084,
    "contract": "202312"
  },
  {
    "date": "2023-12-14",
    "close": 17567.0,
    "volume": 47729,
    "contract": "202312"
  },
  {
    "date": "2023-12-15",
    "close": 17742.0,
    "volume": 53416,
    "contract": "202312"
  },
  {
    "date": "2023-12-18",
    "close": 17639.0,
    "volume": 35608,
    "contract": "202312"
  },
  {
    "date": "2023-12-19",
    "close": 17621.0,
    "volume": 28214,
    "contract": "202312"
  },
  {
    "date": "2023-12-20",
    "close": 17589.0,
    "volume": 26207,
    "contract": "202312"
  },
  {
    "date": "2023-12-21",
    "close": 17396.0,
    "volume": 50371,
    "contract": "202401"
  },
  {
    "date": "2023-12-22",
    "close": 17606.0,
    "volume": 49608,
    "contract": "202401"
  },
  {
    "date": "2023-12-25",
    "close": 17608.0,
    "volume": 34559,
    "contract": "202401"
  },
  {
    "date": "2023-12-26",
    "close": 17632.0,
    "volume": 8324,
    "contract": "202401"
  },
  {
    "date": "2023-12-27",
    "close": 17749.0,
    "volume": 21220,
    "contract": "202401"
  },
  {
    "date": "2023-12-28",
    "close": 17842.0,
    "volume": 33337,
    "contract": "202401"
  },
  {
    "date": "2023-12-29",
    "close": 17841.0,
    "volume": 22091,
    "contract": "202401"
  },
  {
    "date": "2024-01-02",
    "close": 17826.0,
    "volume": 33681,
    "contract": "202401"
  },
  {
    "date": "2024-01-03",
    "close": 17674.0,
    "volume": 51826,
    "contract": "202401"
  },
  {
    "date": "2024-01-04",
    "close": 17536.0,
    "volume": 51903,
    "contract": "202401"
  },
  {
    "date": "2024-01-05",
    "close": 17555.0,
    "volume": 43221,
    "contract": "202401"
  },
  {
    "date": "2024-01-08",
    "close": 17547.0,
    "volume": 67315,
    "contract": "202401"
  },
  {
    "date": "2024-01-09",
    "close": 17767.0,
    "volume": 55350,
    "contract": "202401"
  },
  {
    "date": "2024-01-10",
    "close": 17507.0,
    "volume": 65943,
    "contract": "202401"
  },
  {
    "date": "2024-01-11",
    "close": 17469.0,
    "volume": 49521,
    "contract": "202401"
  },
  {
    "date": "2024-01-12",
    "close": 17485.0,
    "volume": 77602,
    "contract": "202401"
  },
  {
    "date": "2024-01-15",
    "close": 17492.0,
    "volume": 58099,
    "contract": "202401"
  },
  {
    "date": "2024-01-16",
    "close": 17572.0,
    "volume": 21544,
    "contract": "202401"
  },
  {
    "date": "2024-01-17",
    "close": 17328.0,
    "volume": 51670,
    "contract": "202401"
  },
  {
    "date": "2024-01-18",
    "close": 17225.0,
    "volume": 50413,
    "contract": "202402"
  },
  {
    "date": "2024-01-19",
    "close": 17515.0,
    "volume": 85732,
    "contract": "202402"
  },
  {
    "date": "2024-01-22",
    "close": 17779.0,
    "volume": 67007,
    "contract": "202402"
  },
  {
    "date": "2024-01-23",
    "close": 17787.0,
    "volume": 39900,
    "contract": "202402"
  },
  {
    "date": "2024-01-24",
    "close": 17926.0,
    "volume": 43514,
    "contract": "202402"
  },
  {
    "date": "2024-01-25",
    "close": 18012.0,
    "volume": 61551,
    "contract": "202402"
  },
  {
    "date": "2024-01-26",
    "close": 18028.0,
    "volume": 49911,
    "contract": "202402"
  },
  {
    "date": "2024-01-29",
    "close": 18018.0,
    "volume": 49342,
    "contract": "202402"
  },
  {
    "date": "2024-01-30",
    "close": 18115.0,
    "volume": 44540,
    "contract": "202402"
  },
  {
    "date": "2024-01-31",
    "close": 18041.0,
    "volume": 41792,
    "contract": "202402"
  },
  {
    "date": "2024-02-01",
    "close": 17898.0,
    "volume": 67540,
    "contract": "202402"
  },
  {
    "date": "2024-02-02",
    "close": 18054.0,
    "volume": 49266,
    "contract": "202402"
  },
  {
    "date": "2024-02-05",
    "close": 18058.0,
    "volume": 53437,
    "contract": "202402"
  },
  {
    "date": "2024-02-15",
    "close": 18104.0,
    "volume": 30127,
    "contract": "202402"
  },
  {
    "date": "2024-02-16",
    "close": 18705.0,
    "volume": 34402,
    "contract": "202402"
  },
  {
    "date": "2024-02-19",
    "close": 18641.0,
    "volume": 34323,
    "contract": "202402"
  },
  {
    "date": "2024-02-20",
    "close": 18656.0,
    "volume": 10352,
    "contract": "202402"
  },
  {
    "date": "2024-02-21",
    "close": 18756.0,
    "volume": 36954,
    "contract": "202402"
  },
  {
    "date": "2024-02-22",
    "close": 18715.0,
    "volume": 34096,
    "contract": "202403"
  },
  {
    "date": "2024-02-23",
    "close": 19003.0,
    "volume": 45956,
    "contract": "202403"
  },
  {
    "date": "2024-02-26",
    "close": 18926.0,
    "volume": 38104,
    "contract": "202403"
  },
  {
    "date": "2024-02-27",
    "close": 18968.0,
    "volume": 27970,
    "contract": "202403"
  },
  {
    "date": "2024-02-29",
    "close": 18881.0,
    "volume": 29799,
    "contract": "202403"
  },
  {
    "date": "2024-03-01",
    "close": 18954.0,
    "volume": 52330,
    "contract": "202403"
  },
  {
    "date": "2024-03-04",
    "close": 19124.0,
    "volume": 65005,
    "contract": "202403"
  },
  {
    "date": "2024-03-05",
    "close": 19377.0,
    "volume": 54617,
    "contract": "202403"
  },
  {
    "date": "2024-03-06",
    "close": 19267.0,
    "volume": 54051,
    "contract": "202403"
  },
  {
    "date": "2024-03-07",
    "close": 19695.0,
    "volume": 77534,
    "contract": "202403"
  },
  {
    "date": "2024-03-08",
    "close": 19949.0,
    "volume": 84320,
    "contract": "202403"
  },
  {
    "date": "2024-03-11",
    "close": 19719.0,
    "volume": 125394,
    "contract": "202403"
  },
  {
    "date": "2024-03-12",
    "close": 19678.0,
    "volume": 59671,
    "contract": "202403"
  },
  {
    "date": "2024-03-13",
    "close": 19991.0,
    "volume": 80635,
    "contract": "202403"
  },
  {
    "date": "2024-03-14",
    "close": 19883.0,
    "volume": 42778,
    "contract": "202403"
  },
  {
    "date": "2024-03-15",
    "close": 19859.0,
    "volume": 48254,
    "contract": "202403"
  },
  {
    "date": "2024-03-18",
    "close": 19754.0,
    "volume": 46939,
    "contract": "202403"
  },
  {
    "date": "2024-03-19",
    "close": 19869.0,
    "volume": 43370,
    "contract": "202403"
  },
  {
    "date": "2024-03-20",
    "close": 19857.0,
    "volume": 41095,
    "contract": "202403"
  },
  {
    "date": "2024-03-21",
    "close": 19982.0,
    "volume": 53748,
    "contract": "202404"
  },
  {
    "date": "2024-03-22",
    "close": 20206.0,
    "volume": 70467,
    "contract": "202404"
  },
  {
    "date": "2024-03-25",
    "close": 20232.0,
    "volume": 41670,
    "contract": "202404"
  },
  {
    "date": "2024-03-26",
    "close": 20238.0,
    "volume": 39919,
    "contract": "202404"
  },
  {
    "date": "2024-03-27",
    "close": 20140.0,
    "volume": 41156,
    "contract": "202404"
  },
  {
    "date": "2024-03-28",
    "close": 20242.0,
    "volume": 46943,
    "contract": "202404"
  },
  {
    "date": "2024-03-29",
    "close": 20211.0,
    "volume": 44704,
    "contract": "202404"
  },
  {
    "date": "2024-04-01",
    "close": 20343.0,
    "volume": 30217,
    "contract": "202404"
  },
  {
    "date": "2024-04-02",
    "close": 20367.0,
    "volume": 47377,
    "contract": "202404"
  },
  {
    "date": "2024-04-03",
    "close": 20451.0,
    "volume": 52891,
    "contract": "202404"
  },
  {
    "date": "2024-04-08",
    "close": 20453.0,
    "volume": 45681,
    "contract": "202404"
  },
  {
    "date": "2024-04-09",
    "close": 20505.0,
    "volume": 46219,
    "contract": "202404"
  },
  {
    "date": "2024-04-10",
    "close": 20822.0,
    "volume": 60251,
    "contract": "202404"
  },
  {
    "date": "2024-04-11",
    "close": 20713.0,
    "volume": 72161,
    "contract": "202404"
  },
  {
    "date": "2024-04-12",
    "close": 20768.0,
    "volume": 62321,
    "contract": "202404"
  },
  {
    "date": "2024-04-15",
    "close": 20492.0,
    "volume": 70538,
    "contract": "202404"
  },
  {
    "date": "2024-04-16",
    "close": 20290.0,
    "volume": 71781,
    "contract": "202404"
  },
  {
    "date": "2024-04-17",
    "close": 19924.0,
    "volume": 61058,
    "contract": "202404"
  },
  {
    "date": "2024-04-18",
    "close": 20019.0,
    "volume": 78254,
    "contract": "202405"
  },
  {
    "date": "2024-04-19",
    "close": 19998.0,
    "volume": 130556,
    "contract": "202405"
  },
  {
    "date": "2024-04-22",
    "close": 19585.0,
    "volume": 92446,
    "contract": "202405"
  },
  {
    "date": "2024-04-23",
    "close": 19684.0,
    "volume": 54991,
    "contract": "202405"
  },
  {
    "date": "2024-04-24",
    "close": 19882.0,
    "volume": 56818,
    "contract": "202405"
  },
  {
    "date": "2024-04-25",
    "close": 19970.0,
    "volume": 81449,
    "contract": "202405"
  },
  {
    "date": "2024-04-26",
    "close": 20130.0,
    "volume": 124035,
    "contract": "202405"
  },
  {
    "date": "2024-04-29",
    "close": 20252.0,
    "volume": 66992,
    "contract": "202405"
  },
  {
    "date": "2024-04-30",
    "close": 20505.0,
    "volume": 53184,
    "contract": "202405"
  },
  {
    "date": "2024-05-02",
    "close": 20271.0,
    "volume": 68790,
    "contract": "202405"
  },
  {
    "date": "2024-05-03",
    "close": 20513.0,
    "volume": 79386,
    "contract": "202405"
  },
  {
    "date": "2024-05-06",
    "close": 20682.0,
    "volume": 79907,
    "contract": "202405"
  },
  {
    "date": "2024-05-07",
    "close": 20743.0,
    "volume": 41046,
    "contract": "202405"
  },
  {
    "date": "2024-05-08",
    "close": 20627.0,
    "volume": 36969,
    "contract": "202405"
  },
  {
    "date": "2024-05-09",
    "close": 20722.0,
    "volume": 52248,
    "contract": "202405"
  },
  {
    "date": "2024-05-10",
    "close": 20700.0,
    "volume": 50064,
    "contract": "202405"
  },
  {
    "date": "2024-05-13",
    "close": 20948.0,
    "volume": 61960,
    "contract": "202405"
  },
  {
    "date": "2024-05-14",
    "close": 20883.0,
    "volume": 30091,
    "contract": "202405"
  },
  {
    "date": "2024-05-15",
    "close": 21170.0,
    "volume": 44716,
    "contract": "202405"
  },
  {
    "date": "2024-05-16",
    "close": 21453.0,
    "volume": 62347,
    "contract": "202406"
  },
  {
    "date": "2024-05-17",
    "close": 21285.0,
    "volume": 48216,
    "contract": "202406"
  },
  {
    "date": "2024-05-20",
    "close": 21388.0,
    "volume": 41838,
    "contract": "202406"
  },
  {
    "date": "2024-05-21",
    "close": 21363.0,
    "volume": 42056,
    "contract": "202406"
  },
  {
    "date": "2024-05-22",
    "close": 21311.0,
    "volume": 33101,
    "contract": "202406"
  },
  {
    "date": "2024-05-23",
    "close": 21549.0,
    "volume": 48873,
    "contract": "202406"
  },
  {
    "date": "2024-05-24",
    "close": 21421.0,
    "volume": 79324,
    "contract": "202406"
  },
  {
    "date": "2024-05-27",
    "close": 21655.0,
    "volume": 48736,
    "contract": "202406"
  },
  {
    "date": "2024-05-28",
    "close": 21900.0,
    "volume": 20920,
    "contract": "202406"
  },
  {
    "date": "2024-05-29",
    "close": 21919.0,
    "volume": 43209,
    "contract": "202406"
  },
  {
    "date": "2024-05-30",
    "close": 21556.0,
    "volume": 59709,
    "contract": "202406"
  },
  {
    "date": "2024-05-31",
    "close": 21563.0,
    "volume": 67887,
    "contract": "202406"
  },
  {
    "date": "2024-06-03",
    "close": 21353.0,
    "volume": 95267,
    "contract": "202406"
  },
  {
    "date": "2024-06-04",
    "close": 21559.0,
    "volume": 71733,
    "contract": "202406"
  },
  {
    "date": "2024-06-05",
    "close": 21302.0,
    "volume": 81620,
    "contract": "202406"
  },
  {
    "date": "2024-06-06",
    "close": 21787.0,
    "volume": 78334,
    "contract": "202406"
  },
  {
    "date": "2024-06-07",
    "close": 21814.0,
    "volume": 65022,
    "contract": "202406"
  },
  {
    "date": "2024-06-11",
    "close": 21793.0,
    "volume": 69468,
    "contract": "202406"
  },
  {
    "date": "2024-06-12",
    "close": 21837.0,
    "volume": 56673,
    "contract": "202406"
  },
  {
    "date": "2024-06-13",
    "close": 22286.0,
    "volume": 76415,
    "contract": "202406"
  },
  {
    "date": "2024-06-14",
    "close": 22270.0,
    "volume": 67383,
    "contract": "202406"
  },
  {
    "date": "2024-06-17",
    "close": 22457.0,
    "volume": 55879,
    "contract": "202406"
  },
  {
    "date": "2024-06-18",
    "close": 22734.0,
    "volume": 56101,
    "contract": "202406"
  },
  {
    "date": "2024-06-19",
    "close": 22947.0,
    "volume": 57576,
    "contract": "202406"
  },
  {
    "date": "2024-06-20",
    "close": 23144.0,
    "volume": 40683,
    "contract": "202407"
  },
  {
    "date": "2024-06-21",
    "close": 23058.0,
    "volume": 93075,
    "contract": "202407"
  },
  {
    "date": "2024-06-24",
    "close": 23030.0,
    "volume": 95856,
    "contract": "202407"
  },
  {
    "date": "2024-06-25",
    "close": 22590.0,
    "volume": 76947,
    "contract": "202407"
  },
  {
    "date": "2024-06-26",
    "close": 22816.0,
    "volume": 57595,
    "contract": "202407"
  },
  {
    "date": "2024-06-27",
    "close": 22685.0,
    "volume": 77898,
    "contract": "202407"
  },
  {
    "date": "2024-06-28",
    "close": 22858.0,
    "volume": 72131,
    "contract": "202407"
  },
  {
    "date": "2024-07-01",
    "close": 22945.0,
    "volume": 69865,
    "contract": "202407"
  },
  {
    "date": "2024-07-02",
    "close": 22917.0,
    "volume": 66816,
    "contract": "202407"
  },
  {
    "date": "2024-07-03",
    "close": 23051.0,
    "volume": 64970,
    "contract": "202407"
  },
  {
    "date": "2024-07-04",
    "close": 23470.0,
    "volume": 62182,
    "contract": "202407"
  },
  {
    "date": "2024-07-05",
    "close": 23608.0,
    "volume": 33364,
    "contract": "202407"
  },
  {
    "date": "2024-07-08",
    "close": 23563.0,
    "volume": 53890,
    "contract": "202407"
  },
  {
    "date": "2024-07-09",
    "close": 23868.0,
    "volume": 59905,
    "contract": "202407"
  },
  {
    "date": "2024-07-10",
    "close": 23766.0,
    "volume": 48746,
    "contract": "202407"
  },
  {
    "date": "2024-07-11",
    "close": 24251.0,
    "volume": 60251,
    "contract": "202407"
  },
  {
    "date": "2024-07-12",
    "close": 24049.0,
    "volume": 100023,
    "contract": "202407"
  },
  {
    "date": "2024-07-15",
    "close": 24055.0,
    "volume": 84470,
    "contract": "202407"
  },
  {
    "date": "2024-07-16",
    "close": 23780.0,
    "volume": 76267,
    "contract": "202407"
  },
  {
    "date": "2024-07-17",
    "close": 24064.0,
    "volume": 56544,
    "contract": "202407"
  },
  {
    "date": "2024-07-18",
    "close": 23238.0,
    "volume": 98066,
    "contract": "202408"
  },
  {
    "date": "2024-07-19",
    "close": 23050.0,
    "volume": 169050,
    "contract": "202408"
  },
  {
    "date": "2024-07-22",
    "close": 22785.0,
    "volume": 106983,
    "contract": "202408"
  },
  {
    "date": "2024-07-23",
    "close": 22647.0,
    "volume": 72294,
    "contract": "202408"
  },
  {
    "date": "2024-07-24",
    "close": 22720.0,
    "volume": 70956,
    "contract": "202408"
  },
  {
    "date": "2024-07-25",
    "close": 22720.0,
    "volume": 70956,
    "contract": "202408"
  },
  {
    "date": "2024-07-26",
    "close": 22720.0,
    "volume": 70956,
    "contract": "202408"
  },
  {
    "date": "2024-07-29",
    "close": 22253.0,
    "volume": 74534,
    "contract": "202408"
  },
  {
    "date": "2024-07-30",
    "close": 22001.0,
    "volume": 74452,
    "contract": "202408"
  },
  {
    "date": "2024-07-31",
    "close": 21898.0,
    "volume": 91579,
    "contract": "202408"
  },
  {
    "date": "2024-08-01",
    "close": 22687.0,
    "volume": 78971,
    "contract": "202408"
  },
  {
    "date": "2024-08-02",
    "close": 22128.0,
    "volume": 114543,
    "contract": "202408"
  },
  {
    "date": "2024-08-05",
    "close": 21097.0,
    "volume": 132785,
    "contract": "202408"
  },
  {
    "date": "2024-08-06",
    "close": 20223.0,
    "volume": 168624,
    "contract": "202408"
  },
  {
    "date": "2024-08-07",
    "close": 20320.0,
    "volume": 130921,
    "contract": "202408"
  },
  {
    "date": "2024-08-08",
    "close": 20725.0,
    "volume": 122940,
    "contract": "202408"
  },
  {
    "date": "2024-08-09",
    "close": 21429.0,
    "volume": 113437,
    "contract": "202408"
  },
  {
    "date": "2024-08-12",
    "close": 21561.0,
    "volume": 105407,
    "contract": "202408"
  },
  {
    "date": "2024-08-13",
    "close": 21771.0,
    "volume": 68585,
    "contract": "202408"
  },
  {
    "date": "2024-08-14",
    "close": 22113.0,
    "volume": 66253,
    "contract": "202408"
  },
  {
    "date": "2024-08-15",
    "close": 21954.0,
    "volume": 92122,
    "contract": "202408"
  },
  {
    "date": "2024-08-16",
    "close": 22357.0,
    "volume": 78240,
    "contract": "202408"
  },
  {
    "date": "2024-08-19",
    "close": 22343.0,
    "volume": 63139,
    "contract": "202408"
  },
  {
    "date": "2024-08-20",
    "close": 22555.0,
    "volume": 51466,
    "contract": "202408"
  },
  {
    "date": "2024-08-21",
    "close": 22313.0,
    "volume": 46391,
    "contract": "202408"
  },
  {
    "date": "2024-08-22",
    "close": 22254.0,
    "volume": 70802,
    "contract": "202409"
  },
  {
    "date": "2024-08-23",
    "close": 21833.0,
    "volume": 92821,
    "contract": "202409"
  },
  {
    "date": "2024-08-26",
    "close": 22290.0,
    "volume": 85430,
    "contract": "202409"
  },
  {
    "date": "2024-08-27",
    "close": 22085.0,
    "volume": 56362,
    "contract": "202409"
  },
  {
    "date": "2024-08-28",
    "close": 22238.0,
    "volume": 63385,
    "contract": "202409"
  },
  {
    "date": "2024-08-29",
    "close": 22150.0,
    "volume": 81462,
    "contract": "202409"
  },
  {
    "date": "2024-08-30",
    "close": 22281.0,
    "volume": 76830,
    "contract": "202409"
  },
  {
    "date": "2024-09-02",
    "close": 22300.0,
    "volume": 67766,
    "contract": "202409"
  },
  {
    "date": "2024-09-03",
    "close": 22220.0,
    "volume": 32432,
    "contract": "202409"
  },
  {
    "date": "2024-09-04",
    "close": 21364.0,
    "volume": 98691,
    "contract": "202409"
  },
  {
    "date": "2024-09-05",
    "close": 21236.0,
    "volume": 89889,
    "contract": "202409"
  },
  {
    "date": "2024-09-06",
    "close": 21362.0,
    "volume": 85570,
    "contract": "202409"
  },
  {
    "date": "2024-09-09",
    "close": 20560.0,
    "volume": 139419,
    "contract": "202409"
  },
  {
    "date": "2024-09-10",
    "close": 21310.0,
    "volume": 70473,
    "contract": "202409"
  },
  {
    "date": "2024-09-11",
    "close": 21145.0,
    "volume": 84605,
    "contract": "202409"
  },
  {
    "date": "2024-09-12",
    "close": 21517.0,
    "volume": 117032,
    "contract": "202409"
  },
  {
    "date": "2024-09-13",
    "close": 21802.0,
    "volume": 72640,
    "contract": "202409"
  },
  {
    "date": "2024-09-16",
    "close": 21839.0,
    "volume": 42886,
    "contract": "202409"
  },
  {
    "date": "2024-09-18",
    "close": 21739.0,
    "volume": 44021,
    "contract": "202409"
  },
  {
    "date": "2024-09-19",
    "close": 21651.0,
    "volume": 73900,
    "contract": "202410"
  },
  {
    "date": "2024-09-20",
    "close": 22353.0,
    "volume": 62929,
    "contract": "202410"
  },
  {
    "date": "2024-09-23",
    "close": 22194.0,
    "volume": 51196,
    "contract": "202410"
  },
  {
    "date": "2024-09-24",
    "close": 22318.0,
    "volume": 47069,
    "contract": "202410"
  },
  {
    "date": "2024-09-25",
    "close": 22825.0,
    "volume": 72211,
    "contract": "202410"
  },
  {
    "date": "2024-09-26",
    "close": 22939.0,
    "volume": 56816,
    "contract": "202410"
  },
  {
    "date": "2024-09-27",
    "close": 23211.0,
    "volume": 89033,
    "contract": "202410"
  },
  {
    "date": "2024-09-30",
    "close": 22651.0,
    "volume": 80351,
    "contract": "202410"
  },
  {
    "date": "2024-10-01",
    "close": 22210.0,
    "volume": 72570,
    "contract": "202410"
  },
  {
    "date": "2024-10-02",
    "close": 22100.0,
    "volume": 90035,
    "contract": "202410"
  },
  {
    "date": "2024-10-03",
    "close": 22100.0,
    "volume": 90035,
    "contract": "202410"
  },
  {
    "date": "2024-10-04",
    "close": 22100.0,
    "volume": 90035,
    "contract": "202410"
  },
  {
    "date": "2024-10-07",
    "close": 22522.0,
    "volume": 77852,
    "contract": "202410"
  },
  {
    "date": "2024-10-08",
    "close": 22560.0,
    "volume": 57793,
    "contract": "202410"
  },
  {
    "date": "2024-10-09",
    "close": 22791.0,
    "volume": 53356,
    "contract": "202410"
  },
  {
    "date": "2024-10-11",
    "close": 22789.0,
    "volume": 51693,
    "contract": "202410"
  },
  {
    "date": "2024-10-14",
    "close": 23040.0,
    "volume": 40044,
    "contract": "202410"
  },
  {
    "date": "2024-10-15",
    "close": 23160.0,
    "volume": 36452,
    "contract": "202410"
  },
  {
    "date": "2024-10-16",
    "close": 22870.0,
    "volume": 63237,
    "contract": "202410"
  },
  {
    "date": "2024-10-17",
    "close": 23175.0,
    "volume": 43348,
    "contract": "202411"
  },
  {
    "date": "2024-10-18",
    "close": 23884.0,
    "volume": 90663,
    "contract": "202411"
  },
  {
    "date": "2024-10-21",
    "close": 23725.0,
    "volume": 47207,
    "contract": "202411"
  },
  {
    "date": "2024-10-22",
    "close": 23660.0,
    "volume": 56166,
    "contract": "202411"
  },
  {
    "date": "2024-10-23",
    "close": 23561.0,
    "volume": 46553,
    "contract": "202411"
  },
  {
    "date": "2024-10-24",
    "close": 23300.0,
    "volume": 68271,
    "contract": "202411"
  },
  {
    "date": "2024-10-25",
    "close": 23287.0,
    "volume": 45408,
    "contract": "202411"
  },
  {
    "date": "2024-10-28",
    "close": 23551.0,
    "volume": 52029,
    "contract": "202411"
  },
  {
    "date": "2024-10-29",
    "close": 23168.0,
    "volume": 48705,
    "contract": "202411"
  },
  {
    "date": "2024-10-30",
    "close": 23055.0,
    "volume": 48737,
    "contract": "202411"
  },
  {
    "date": "2024-10-31",
    "close": 22700.0,
    "volume": 63036,
    "contract": "202411"
  },
  {
    "date": "2024-11-01",
    "close": 22700.0,
    "volume": 63036,
    "contract": "202411"
  },
  {
    "date": "2024-11-04",
    "close": 22781.0,
    "volume": 51790,
    "contract": "202411"
  },
  {
    "date": "2024-11-05",
    "close": 22848.0,
    "volume": 49475,
    "contract": "202411"
  },
  {
    "date": "2024-11-06",
    "close": 23250.0,
    "volume": 46978,
    "contract": "202411"
  },
  {
    "date": "2024-11-07",
    "close": 23241.0,
    "volume": 81016,
    "contract": "202411"
  },
  {
    "date": "2024-11-08",
    "close": 23741.0,
    "volume": 40523,
    "contract": "202411"
  },
  {
    "date": "2024-11-11",
    "close": 23564.0,
    "volume": 61076,
    "contract": "202411"
  },
  {
    "date": "2024-11-12",
    "close": 23114.0,
    "volume": 63036,
    "contract": "202411"
  },
  {
    "date": "2024-11-13",
    "close": 22835.0,
    "volume": 72717,
    "contract": "202411"
  },
  {
    "date": "2024-11-14",
    "close": 22805.0,
    "volume": 73131,
    "contract": "202411"
  },
  {
    "date": "2024-11-15",
    "close": 22708.0,
    "volume": 53368,
    "contract": "202411"
  },
  {
    "date": "2024-11-18",
    "close": 22550.0,
    "volume": 55490,
    "contract": "202411"
  },
  {
    "date": "2024-11-19",
    "close": 22622.0,
    "volume": 53649,
    "contract": "202411"
  },
  {
    "date": "2024-11-20",
    "close": 22858.0,
    "volume": 56943,
    "contract": "202411"
  },
  {
    "date": "2024-11-21",
    "close": 22746.0,
    "volume": 55520,
    "contract": "202412"
  },
  {
    "date": "2024-11-22",
    "close": 22801.0,
    "volume": 91974,
    "contract": "202412"
  },
  {
    "date": "2024-11-25",
    "close": 23052.0,
    "volume": 46783,
    "contract": "202412"
  },
  {
    "date": "2024-11-26",
    "close": 22855.0,
    "volume": 48363,
    "contract": "202412"
  },
  {
    "date": "2024-11-27",
    "close": 22651.0,
    "volume": 50607,
    "contract": "202412"
  },
  {
    "date": "2024-11-28",
    "close": 22268.0,
    "volume": 62298,
    "contract": "202412"
  },
  {
    "date": "2024-11-29",
    "close": 22277.0,
    "volume": 21722,
    "contract": "202412"
  },
  {
    "date": "2024-12-02",
    "close": 22548.0,
    "volume": 55241,
    "contract": "202412"
  },
  {
    "date": "2024-12-03",
    "close": 23102.0,
    "volume": 41164,
    "contract": "202412"
  },
  {
    "date": "2024-12-04",
    "close": 23166.0,
    "volume": 55006,
    "contract": "202412"
  },
  {
    "date": "2024-12-05",
    "close": 23317.0,
    "volume": 38809,
    "contract": "202412"
  },
  {
    "date": "2024-12-06",
    "close": 23346.0,
    "volume": 32696,
    "contract": "202412"
  },
  {
    "date": "2024-12-09",
    "close": 23252.0,
    "volume": 36462,
    "contract": "202412"
  },
  {
    "date": "2024-12-10",
    "close": 23219.0,
    "volume": 47438,
    "contract": "202412"
  },
  {
    "date": "2024-12-11",
    "close": 22850.0,
    "volume": 47047,
    "contract": "202412"
  },
  {
    "date": "2024-12-12",
    "close": 23044.0,
    "volume": 39846,
    "contract": "202412"
  },
  {
    "date": "2024-12-13",
    "close": 22899.0,
    "volume": 45772,
    "contract": "202412"
  },
  {
    "date": "2024-12-16",
    "close": 23148.0,
    "volume": 50098,
    "contract": "202412"
  },
  {
    "date": "2024-12-17",
    "close": 23113.0,
    "volume": 36868,
    "contract": "202412"
  },
  {
    "date": "2024-12-18",
    "close": 22961.0,
    "volume": 42129,
    "contract": "202412"
  },
  {
    "date": "2024-12-19",
    "close": 22698.0,
    "volume": 63190,
    "contract": "202501"
  },
  {
    "date": "2024-12-20",
    "close": 22808.0,
    "volume": 52480,
    "contract": "202501"
  },
  {
    "date": "2024-12-23",
    "close": 22893.0,
    "volume": 67657,
    "contract": "202501"
  },
  {
    "date": "2024-12-24",
    "close": 23444.0,
    "volume": 49944,
    "contract": "202501"
  },
  {
    "date": "2024-12-25",
    "close": 23352.0,
    "volume": 25579,
    "contract": "202501"
  },
  {
    "date": "2024-12-26",
    "close": 23327.0,
    "volume": 10266,
    "contract": "202501"
  },
  {
    "date": "2024-12-27",
    "close": 23255.0,
    "volume": 30690,
    "contract": "202501"
  },
  {
    "date": "2024-12-30",
    "close": 23214.0,
    "volume": 47822,
    "contract": "202501"
  },
  {
    "date": "2024-12-31",
    "close": 23046.0,
    "volume": 46961,
    "contract": "202501"
  },
  {
    "date": "2025-01-02",
    "close": 22986.0,
    "volume": 37987,
    "contract": "202501"
  },
  {
    "date": "2025-01-03",
    "close": 22847.0,
    "volume": 56505,
    "contract": "202501"
  },
  {
    "date": "2025-01-06",
    "close": 23226.0,
    "volume": 41262,
    "contract": "202501"
  },
  {
    "date": "2025-01-07",
    "close": 23874.0,
    "volume": 52316,
    "contract": "202501"
  },
  {
    "date": "2025-01-08",
    "close": 23477.0,
    "volume": 56158,
    "contract": "202501"
  },
  {
    "date": "2025-01-09",
    "close": 23338.0,
    "volume": 57168,
    "contract": "202501"
  },
  {
    "date": "2025-01-10",
    "close": 23155.0,
    "volume": 24909,
    "contract": "202501"
  },
  {
    "date": "2025-01-13",
    "close": 22928.0,
    "volume": 68009,
    "contract": "202501"
  },
  {
    "date": "2025-01-14",
    "close": 22477.0,
    "volume": 50666,
    "contract": "202501"
  },
  {
    "date": "2025-01-15",
    "close": 22689.0,
    "volume": 45459,
    "contract": "202501"
  },
  {
    "date": "2025-01-16",
    "close": 22973.0,
    "volume": 52613,
    "contract": "202502"
  },
  {
    "date": "2025-01-17",
    "close": 23283.0,
    "volume": 77970,
    "contract": "202502"
  },
  {
    "date": "2025-01-20",
    "close": 23245.0,
    "volume": 41909,
    "contract": "202502"
  },
  {
    "date": "2025-01-21",
    "close": 23332.0,
    "volume": 37589,
    "contract": "202502"
  },
  {
    "date": "2025-01-22",
    "close": 23574.0,
    "volume": 42343,
    "contract": "202502"
  },
  {
    "date": "2025-02-03",
    "close": 23802.0,
    "volume": 28582,
    "contract": "202502"
  },
  {
    "date": "2025-02-04",
    "close": 22795.0,
    "volume": 45550,
    "contract": "202502"
  },
  {
    "date": "2025-02-05",
    "close": 23082.0,
    "volume": 33756,
    "contract": "202502"
  },
  {
    "date": "2025-02-06",
    "close": 23318.0,
    "volume": 33996,
    "contract": "202502"
  },
  {
    "date": "2025-02-07",
    "close": 23333.0,
    "volume": 26180,
    "contract": "202502"
  },
  {
    "date": "2025-02-10",
    "close": 23246.0,
    "volume": 51325,
    "contract": "202502"
  },
  {
    "date": "2025-02-11",
    "close": 23402.0,
    "volume": 27279,
    "contract": "202502"
  },
  {
    "date": "2025-02-12",
    "close": 23408.0,
    "volume": 34405,
    "contract": "202502"
  },
  {
    "date": "2025-02-13",
    "close": 23379.0,
    "volume": 49382,
    "contract": "202502"
  },
  {
    "date": "2025-02-14",
    "close": 23370.0,
    "volume": 42069,
    "contract": "202502"
  },
  {
    "date": "2025-02-17",
    "close": 23309.0,
    "volume": 40964,
    "contract": "202502"
  },
  {
    "date": "2025-02-18",
    "close": 23519.0,
    "volume": 13880,
    "contract": "202502"
  },
  {
    "date": "2025-02-19",
    "close": 23581.0,
    "volume": 31114,
    "contract": "202502"
  },
  {
    "date": "2025-02-20",
    "close": 23566.0,
    "volume": 25862,
    "contract": "202503"
  },
  {
    "date": "2025-02-21",
    "close": 23542.0,
    "volume": 36278,
    "contract": "202503"
  },
  {
    "date": "2025-02-24",
    "close": 23488.0,
    "volume": 41285,
    "contract": "202503"
  },
  {
    "date": "2025-02-25",
    "close": 23269.0,
    "volume": 46618,
    "contract": "202503"
  },
  {
    "date": "2025-02-26",
    "close": 23127.0,
    "volume": 58333,
    "contract": "202503"
  },
  {
    "date": "2025-02-27",
    "close": 23416.0,
    "volume": 50095,
    "contract": "202503"
  },
  {
    "date": "2025-03-03",
    "close": 22610.0,
    "volume": 66493,
    "contract": "202503"
  },
  {
    "date": "2025-03-04",
    "close": 22193.0,
    "volume": 81778,
    "contract": "202503"
  },
  {
    "date": "2025-03-05",
    "close": 22552.0,
    "volume": 89307,
    "contract": "202503"
  },
  {
    "date": "2025-03-06",
    "close": 23003.0,
    "volume": 70222,
    "contract": "202503"
  },
  {
    "date": "2025-03-07",
    "close": 22419.0,
    "volume": 71921,
    "contract": "202503"
  },
  {
    "date": "2025-03-10",
    "close": 22566.0,
    "volume": 84112,
    "contract": "202503"
  },
  {
    "date": "2025-03-11",
    "close": 22020.0,
    "volume": 75779,
    "contract": "202503"
  },
  {
    "date": "2025-03-12",
    "close": 22018.0,
    "volume": 79011,
    "contract": "202503"
  },
  {
    "date": "2025-03-13",
    "close": 22386.0,
    "volume": 65467,
    "contract": "202503"
  },
  {
    "date": "2025-03-14",
    "close": 22002.0,
    "volume": 64096,
    "contract": "202503"
  },
  {
    "date": "2025-03-17",
    "close": 22200.0,
    "volume": 42843,
    "contract": "202503"
  },
  {
    "date": "2025-03-18",
    "close": 22385.0,
    "volume": 43494,
    "contract": "202503"
  },
  {
    "date": "2025-03-19",
    "close": 22147.0,
    "volume": 41948,
    "contract": "202503"
  },
  {
    "date": "2025-03-20",
    "close": 22170.0,
    "volume": 46665,
    "contract": "202504"
  },
  {
    "date": "2025-03-21",
    "close": 22300.0,
    "volume": 56234,
    "contract": "202504"
  },
  {
    "date": "2025-03-24",
    "close": 22201.0,
    "volume": 49387,
    "contract": "202504"
  },
  {
    "date": "2025-03-25",
    "close": 22335.0,
    "volume": 35730,
    "contract": "202504"
  },
  {
    "date": "2025-03-26",
    "close": 22304.0,
    "volume": 53992,
    "contract": "202504"
  },
  {
    "date": "2025-03-27",
    "close": 22045.0,
    "volume": 50049,
    "contract": "202504"
  },
  {
    "date": "2025-03-28",
    "close": 21827.0,
    "volume": 59482,
    "contract": "202504"
  },
  {
    "date": "2025-03-31",
    "close": 21141.0,
    "volume": 72895,
    "contract": "202504"
  },
  {
    "date": "2025-04-01",
    "close": 21088.0,
    "volume": 72112,
    "contract": "202504"
  },
  {
    "date": "2025-04-02",
    "close": 21334.0,
    "volume": 72967,
    "contract": "202504"
  },
  {
    "date": "2025-04-07",
    "close": 20859.0,
    "volume": 91512,
    "contract": "202504"
  },
  {
    "date": "2025-04-08",
    "close": 18406.0,
    "volume": 201617,
    "contract": "202504"
  },
  {
    "date": "2025-04-09",
    "close": 18050.0,
    "volume": 160852,
    "contract": "202504"
  },
  {
    "date": "2025-04-10",
    "close": 18902.0,
    "volume": 174279,
    "contract": "202504"
  },
  {
    "date": "2025-04-11",
    "close": 18838.0,
    "volume": 164261,
    "contract": "202504"
  },
  {
    "date": "2025-04-14",
    "close": 19527.0,
    "volume": 105876,
    "contract": "202504"
  },
  {
    "date": "2025-04-15",
    "close": 19504.0,
    "volume": 63425,
    "contract": "202504"
  },
  {
    "date": "2025-04-16",
    "close": 19818.0,
    "volume": 46864,
    "contract": "202504"
  },
  {
    "date": "2025-04-17",
    "close": 19148.0,
    "volume": 78147,
    "contract": "202505"
  },
  {
    "date": "2025-04-18",
    "close": 19365.0,
    "volume": 78532,
    "contract": "202505"
  },
  {
    "date": "2025-04-21",
    "close": 19368.0,
    "volume": 6679,
    "contract": "202505"
  },
  {
    "date": "2025-04-22",
    "close": 18870.0,
    "volume": 49645,
    "contract": "202505"
  },
  {
    "date": "2025-04-23",
    "close": 19056.0,
    "volume": 58608,
    "contract": "202505"
  },
  {
    "date": "2025-04-24",
    "close": 19648.0,
    "volume": 75577,
    "contract": "202505"
  },
  {
    "date": "2025-04-25",
    "close": 19945.0,
    "volume": 65347,
    "contract": "202505"
  },
  {
    "date": "2025-04-28",
    "close": 20052.0,
    "volume": 63385,
    "contract": "202505"
  },
  {
    "date": "2025-04-29",
    "close": 19970.0,
    "volume": 45463,
    "contract": "202505"
  },
  {
    "date": "2025-04-30",
    "close": 20154.0,
    "volume": 43475,
    "contract": "202505"
  },
  {
    "date": "2025-05-02",
    "close": 20430.0,
    "volume": 71430,
    "contract": "202505"
  },
  {
    "date": "2025-05-05",
    "close": 20840.0,
    "volume": 52582,
    "contract": "202505"
  },
  {
    "date": "2025-05-06",
    "close": 20198.0,
    "volume": 51234,
    "contract": "202505"
  },
  {
    "date": "2025-05-07",
    "close": 20247.0,
    "volume": 56440,
    "contract": "202505"
  },
  {
    "date": "2025-05-08",
    "close": 20512.0,
    "volume": 62834,
    "contract": "202505"
  },
  {
    "date": "2025-05-09",
    "close": 20680.0,
    "volume": 56186,
    "contract": "202505"
  },
  {
    "date": "2025-05-12",
    "close": 20794.0,
    "volume": 39918,
    "contract": "202505"
  },
  {
    "date": "2025-05-13",
    "close": 21485.0,
    "volume": 62018,
    "contract": "202505"
  },
  {
    "date": "2025-05-14",
    "close": 21677.0,
    "volume": 51630,
    "contract": "202505"
  },
  {
    "date": "2025-05-15",
    "close": 21818.0,
    "volume": 45510,
    "contract": "202505"
  },
  {
    "date": "2025-05-16",
    "close": 21775.0,
    "volume": 39315,
    "contract": "202505"
  },
  {
    "date": "2025-05-19",
    "close": 21828.0,
    "volume": 35258,
    "contract": "202505"
  },
  {
    "date": "2025-05-20",
    "close": 21750.0,
    "volume": 35514,
    "contract": "202505"
  },
  {
    "date": "2025-05-21",
    "close": 21575.0,
    "volume": 23915,
    "contract": "202505"
  },
  {
    "date": "2025-05-22",
    "close": 21478.0,
    "volume": 47319,
    "contract": "202506"
  },
  {
    "date": "2025-05-23",
    "close": 21531.0,
    "volume": 44296,
    "contract": "202506"
  },
  {
    "date": "2025-05-26",
    "close": 21250.0,
    "volume": 65610,
    "contract": "202506"
  },
  {
    "date": "2025-05-27",
    "close": 21399.0,
    "volume": 14162,
    "contract": "202506"
  },
  {
    "date": "2025-05-28",
    "close": 21404.0,
    "volume": 35176,
    "contract": "202506"
  },
  {
    "date": "2025-05-29",
    "close": 21315.0,
    "volume": 31412,
    "contract": "202506"
  },
  {
    "date": "2025-06-02",
    "close": 21060.0,
    "volume": 56079,
    "contract": "202506"
  },
  {
    "date": "2025-06-03",
    "close": 21082.0,
    "volume": 37198,
    "contract": "202506"
  },
  {
    "date": "2025-06-04",
    "close": 21217.0,
    "volume": 35014,
    "contract": "202506"
  },
  {
    "date": "2025-06-05",
    "close": 21548.0,
    "volume": 32913,
    "contract": "202506"
  },
  {
    "date": "2025-06-06",
    "close": 21530.0,
    "volume": 55509,
    "contract": "202506"
  },
  {
    "date": "2025-06-09",
    "close": 21660.0,
    "volume": 29760,
    "contract": "202506"
  },
  {
    "date": "2025-06-10",
    "close": 21846.0,
    "volume": 25973,
    "contract": "202506"
  },
  {
    "date": "2025-06-11",
    "close": 22312.0,
    "volume": 36796,
    "contract": "202506"
  },
  {
    "date": "2025-06-12",
    "close": 22353.0,
    "volume": 41912,
    "contract": "202506"
  },
  {
    "date": "2025-06-13",
    "close": 22309.0,
    "volume": 36808,
    "contract": "202506"
  },
  {
    "date": "2025-06-16",
    "close": 21991.0,
    "volume": 42610,
    "contract": "202506"
  },
  {
    "date": "2025-06-17",
    "close": 22221.0,
    "volume": 30885,
    "contract": "202506"
  },
  {
    "date": "2025-06-18",
    "close": 22070.0,
    "volume": 29346,
    "contract": "202506"
  },
  {
    "date": "2025-06-19",
    "close": 21853.0,
    "volume": 45988,
    "contract": "202507"
  },
  {
    "date": "2025-06-20",
    "close": 21572.0,
    "volume": 27187,
    "contract": "202507"
  },
  {
    "date": "2025-06-23",
    "close": 21460.0,
    "volume": 62363,
    "contract": "202507"
  },
  {
    "date": "2025-06-24",
    "close": 21612.0,
    "volume": 54388,
    "contract": "202507"
  },
  {
    "date": "2025-06-25",
    "close": 22155.0,
    "volume": 37730,
    "contract": "202507"
  },
  {
    "date": "2025-06-26",
    "close": 22175.0,
    "volume": 31203,
    "contract": "202507"
  },
  {
    "date": "2025-06-27",
    "close": 22172.0,
    "volume": 38185,
    "contract": "202507"
  },
  {
    "date": "2025-06-30",
    "close": 22132.0,
    "volume": 42296,
    "contract": "202507"
  },
  {
    "date": "2025-07-01",
    "close": 22160.0,
    "volume": 28118,
    "contract": "202507"
  },
  {
    "date": "2025-07-02",
    "close": 22293.0,
    "volume": 36231,
    "contract": "202507"
  },
  {
    "date": "2025-07-03",
    "close": 22570.0,
    "volume": 35769,
    "contract": "202507"
  },
  {
    "date": "2025-07-04",
    "close": 22793.0,
    "volume": 31762,
    "contract": "202507"
  },
  {
    "date": "2025-07-07",
    "close": 22355.0,
    "volume": 26711,
    "contract": "202507"
  },
  {
    "date": "2025-07-08",
    "close": 22222.0,
    "volume": 45003,
    "contract": "202507"
  },
  {
    "date": "2025-07-09",
    "close": 22268.0,
    "volume": 26901,
    "contract": "202507"
  },
  {
    "date": "2025-07-10",
    "close": 22468.0,
    "volume": 37216,
    "contract": "202507"
  },
  {
    "date": "2025-07-11",
    "close": 22583.0,
    "volume": 32123,
    "contract": "202507"
  },
  {
    "date": "2025-07-14",
    "close": 22637.0,
    "volume": 30173,
    "contract": "202507"
  },
  {
    "date": "2025-07-15",
    "close": 22560.0,
    "volume": 29607,
    "contract": "202507"
  },
  {
    "date": "2025-07-16",
    "close": 22866.0,
    "volume": 28974,
    "contract": "202507"
  },
  {
    "date": "2025-07-17",
    "close": 22964.0,
    "volume": 42648,
    "contract": "202508"
  },
  {
    "date": "2025-07-18",
    "close": 23374.0,
    "volume": 44722,
    "contract": "202508"
  },
  {
    "date": "2025-07-21",
    "close": 23191.0,
    "volume": 27791,
    "contract": "202508"
  },
  {
    "date": "2025-07-22",
    "close": 23253.0,
    "volume": 28374,
    "contract": "202508"
  },
  {
    "date": "2025-07-23",
    "close": 22987.0,
    "volume": 35298,
    "contract": "202508"
  },
  {
    "date": "2025-07-24",
    "close": 23332.0,
    "volume": 29784,
    "contract": "202508"
  },
  {
    "date": "2025-07-25",
    "close": 23260.0,
    "volume": 24397,
    "contract": "202508"
  },
  {
    "date": "2025-07-28",
    "close": 23344.0,
    "volume": 30534,
    "contract": "202508"
  },
  {
    "date": "2025-07-29",
    "close": 23317.0,
    "volume": 26385,
    "contract": "202508"
  },
  {
    "date": "2025-07-30",
    "close": 23193.0,
    "volume": 33296,
    "contract": "202508"
  },
  {
    "date": "2025-07-31",
    "close": 23417.0,
    "volume": 36140,
    "contract": "202508"
  },
  {
    "date": "2025-08-01",
    "close": 23344.0,
    "volume": 50109,
    "contract": "202508"
  },
  {
    "date": "2025-08-04",
    "close": 23085.0,
    "volume": 58950,
    "contract": "202508"
  },
  {
    "date": "2025-08-05",
    "close": 23420.0,
    "volume": 24455,
    "contract": "202508"
  },
  {
    "date": "2025-08-06",
    "close": 23398.0,
    "volume": 41998,
    "contract": "202508"
  },
  {
    "date": "2025-08-07",
    "close": 23475.0,
    "volume": 39614,
    "contract": "202508"
  },
  {
    "date": "2025-08-08",
    "close": 24022.0,
    "volume": 43307,
    "contract": "202508"
  },
  {
    "date": "2025-08-11",
    "close": 24013.0,
    "volume": 26734,
    "contract": "202508"
  },
  {
    "date": "2025-08-12",
    "close": 24088.0,
    "volume": 24885,
    "contract": "202508"
  },
  {
    "date": "2025-08-13",
    "close": 24315.0,
    "volume": 33192,
    "contract": "202508"
  },
  {
    "date": "2025-08-14",
    "close": 24344.0,
    "volume": 28958,
    "contract": "202508"
  },
  {
    "date": "2025-08-15",
    "close": 24296.0,
    "volume": 29305,
    "contract": "202508"
  },
  {
    "date": "2025-08-18",
    "close": 24155.0,
    "volume": 30632,
    "contract": "202508"
  },
  {
    "date": "2025-08-19",
    "close": 24415.0,
    "volume": 19464,
    "contract": "202508"
  },
  {
    "date": "2025-08-20",
    "close": 24217.0,
    "volume": 24035,
    "contract": "202508"
  },
  {
    "date": "2025-08-21",
    "close": 23715.0,
    "volume": 50480,
    "contract": "202509"
  },
  {
    "date": "2025-08-22",
    "close": 23800.0,
    "volume": 39496,
    "contract": "202509"
  },
  {
    "date": "2025-08-25",
    "close": 24115.0,
    "volume": 54602,
    "contract": "202509"
  },
  {
    "date": "2025-08-26",
    "close": 24180.0,
    "volume": 27709,
    "contract": "202509"
  },
  {
    "date": "2025-08-27",
    "close": 24356.0,
    "volume": 27700,
    "contract": "202509"
  },
  {
    "date": "2025-08-28",
    "close": 24351.0,
    "volume": 36367,
    "contract": "202509"
  },
  {
    "date": "2025-08-29",
    "close": 24414.0,
    "volume": 37140,
    "contract": "202509"
  },
  {
    "date": "2025-09-01",
    "close": 24061.0,
    "volume": 47988,
    "contract": "202509"
  },
  {
    "date": "2025-09-02",
    "close": 24085.0,
    "volume": 14381,
    "contract": "202509"
  },
  {
    "date": "2025-09-03",
    "close": 23940.0,
    "volume": 69586,
    "contract": "202509"
  },
  {
    "date": "2025-09-04",
    "close": 24129.0,
    "volume": 46166,
    "contract": "202509"
  },
  {
    "date": "2025-09-05",
    "close": 24335.0,
    "volume": 34319,
    "contract": "202509"
  },
  {
    "date": "2025-09-08",
    "close": 24478.0,
    "volume": 61197,
    "contract": "202509"
  },
  {
    "date": "2025-09-09",
    "close": 24712.0,
    "volume": 25001,
    "contract": "202509"
  },
  {
    "date": "2025-09-10",
    "close": 24977.0,
    "volume": 40441,
    "contract": "202509"
  },
  {
    "date": "2025-09-11",
    "close": 25361.0,
    "volume": 50263,
    "contract": "202509"
  },
  {
    "date": "2025-09-12",
    "close": 25409.0,
    "volume": 39455,
    "contract": "202509"
  },
  {
    "date": "2025-09-15",
    "close": 25378.0,
    "volume": 29673,
    "contract": "202509"
  },
  {
    "date": "2025-09-16",
    "close": 25428.0,
    "volume": 26734,
    "contract": "202509"
  },
  {
    "date": "2025-09-17",
    "close": 25554.0,
    "volume": 28457,
    "contract": "202509"
  },
  {
    "date": "2025-09-18",
    "close": 25553.0,
    "volume": 57597,
    "contract": "202510"
  },
  {
    "date": "2025-09-19",
    "close": 25841.0,
    "volume": 68868,
    "contract": "202510"
  },
  {
    "date": "2025-09-22",
    "close": 25737.0,
    "volume": 29239,
    "contract": "202510"
  },
  {
    "date": "2025-09-23",
    "close": 26070.0,
    "volume": 40600,
    "contract": "202510"
  },
  {
    "date": "2025-09-24",
    "close": 26416.0,
    "volume": 58787,
    "contract": "202510"
  },
  {
    "date": "2025-09-25",
    "close": 26198.0,
    "volume": 37964,
    "contract": "202510"
  },
  {
    "date": "2025-09-26",
    "close": 26012.0,
    "volume": 58688,
    "contract": "202510"
  },
  {
    "date": "2025-09-30",
    "close": 25742.0,
    "volume": 45532,
    "contract": "202510"
  },
  {
    "date": "2025-10-01",
    "close": 26130.0,
    "volume": 35252,
    "contract": "202510"
  },
  {
    "date": "2025-10-02",
    "close": 26421.0,
    "volume": 51865,
    "contract": "202510"
  },
  {
    "date": "2025-10-03",
    "close": 26427.0,
    "volume": 49045,
    "contract": "202510"
  },
  {
    "date": "2025-10-07",
    "close": 26680.0,
    "volume": 42343,
    "contract": "202510"
  },
  {
    "date": "2025-10-08",
    "close": 27040.0,
    "volume": 52105,
    "contract": "202510"
  },
  {
    "date": "2025-10-09",
    "close": 27420.0,
    "volume": 48451,
    "contract": "202510"
  },
  {
    "date": "2025-10-13",
    "close": 27108.0,
    "volume": 44466,
    "contract": "202510"
  },
  {
    "date": "2025-10-14",
    "close": 27250.0,
    "volume": 54312,
    "contract": "202510"
  },
  {
    "date": "2025-10-15",
    "close": 26783.0,
    "volume": 69414,
    "contract": "202510"
  },
  {
    "date": "2025-10-16",
    "close": 27478.0,
    "volume": 81199,
    "contract": "202511"
  },
  {
    "date": "2025-10-17",
    "close": 27492.0,
    "volume": 93383,
    "contract": "202511"
  },
  {
    "date": "2025-10-20",
    "close": 27453.0,
    "volume": 96819,
    "contract": "202511"
  },
  {
    "date": "2025-10-21",
    "close": 27847.0,
    "volume": 49528,
    "contract": "202511"
  },
  {
    "date": "2025-10-22",
    "close": 27733.0,
    "volume": 52045,
    "contract": "202511"
  },
  {
    "date": "2025-10-23",
    "close": 27399.0,
    "volume": 73909,
    "contract": "202511"
  },
  {
    "date": "2025-10-27",
    "close": 27742.0,
    "volume": 51456,
    "contract": "202511"
  },
  {
    "date": "2025-10-28",
    "close": 28310.0,
    "volume": 40411,
    "contract": "202511"
  },
  {
    "date": "2025-10-29",
    "close": 28215.0,
    "volume": 41261,
    "contract": "202511"
  },
  {
    "date": "2025-10-30",
    "close": 28365.0,
    "volume": 52869,
    "contract": "202511"
  },
  {
    "date": "2025-10-31",
    "close": 28290.0,
    "volume": 47452,
    "contract": "202511"
  },
  {
    "date": "2025-11-03",
    "close": 28265.0,
    "volume": 52159,
    "contract": "202511"
  },
  {
    "date": "2025-11-04",
    "close": 28496.0,
    "volume": 43702,
    "contract": "202511"
  },
  {
    "date": "2025-11-05",
    "close": 27912.0,
    "volume": 61678,
    "contract": "202511"
  },
  {
    "date": "2025-11-06",
    "close": 28052.0,
    "volume": 50350,
    "contract": "202511"
  },
  {
    "date": "2025-11-07",
    "close": 27665.0,
    "volume": 77027,
    "contract": "202511"
  },
  {
    "date": "2025-11-10",
    "close": 27561.0,
    "volume": 84438,
    "contract": "202511"
  },
  {
    "date": "2025-11-11",
    "close": 28106.0,
    "volume": 51161,
    "contract": "202511"
  },
  {
    "date": "2025-11-12",
    "close": 27903.0,
    "volume": 52412,
    "contract": "202511"
  },
  {
    "date": "2025-11-13",
    "close": 28065.0,
    "volume": 48074,
    "contract": "202511"
  },
  {
    "date": "2025-11-14",
    "close": 27467.0,
    "volume": 73383,
    "contract": "202511"
  },
  {
    "date": "2025-11-17",
    "close": 27490.0,
    "volume": 100597,
    "contract": "202511"
  },
  {
    "date": "2025-11-18",
    "close": 27175.0,
    "volume": 76490,
    "contract": "202511"
  },
  {
    "date": "2025-11-19",
    "close": 26906.0,
    "volume": 65594,
    "contract": "202511"
  },
  {
    "date": "2025-11-20",
    "close": 26979.0,
    "volume": 64692,
    "contract": "202512"
  },
  {
    "date": "2025-11-21",
    "close": 26690.0,
    "volume": 95818,
    "contract": "202512"
  },
  {
    "date": "2025-11-24",
    "close": 26673.0,
    "volume": 109092,
    "contract": "202512"
  },
  {
    "date": "2025-11-25",
    "close": 27052.0,
    "volume": 60050,
    "contract": "202512"
  },
  {
    "date": "2025-11-26",
    "close": 27180.0,
    "volume": 70439,
    "contract": "202512"
  },
  {
    "date": "2025-11-27",
    "close": 27447.0,
    "volume": 52347,
    "contract": "202512"
  },
  {
    "date": "2025-11-28",
    "close": 27555.0,
    "volume": 12632,
    "contract": "202512"
  },
  {
    "date": "2025-12-01",
    "close": 27784.0,
    "volume": 28406,
    "contract": "202512"
  },
  {
    "date": "2025-12-02",
    "close": 27602.0,
    "volume": 48974,
    "contract": "202512"
  },
  {
    "date": "2025-12-03",
    "close": 27800.0,
    "volume": 51103,
    "contract": "202512"
  },
  {
    "date": "2025-12-04",
    "close": 27856.0,
    "volume": 48539,
    "contract": "202512"
  },
  {
    "date": "2025-12-05",
    "close": 27766.0,
    "volume": 33319,
    "contract": "202512"
  },
  {
    "date": "2025-12-08",
    "close": 28045.0,
    "volume": 43555,
    "contract": "202512"
  },
  {
    "date": "2025-12-09",
    "close": 28252.0,
    "volume": 34107,
    "contract": "202512"
  },
  {
    "date": "2025-12-10",
    "close": 28289.0,
    "volume": 29792,
    "contract": "202512"
  },
  {
    "date": "2025-12-11",
    "close": 28672.0,
    "volume": 38058,
    "contract": "202512"
  },
  {
    "date": "2025-12-12",
    "close": 28322.0,
    "volume": 47712,
    "contract": "202512"
  },
  {
    "date": "2025-12-15",
    "close": 27729.0,
    "volume": 68804,
    "contract": "202512"
  },
  {
    "date": "2025-12-16",
    "close": 27675.0,
    "volume": 45859,
    "contract": "202512"
  },
  {
    "date": "2025-12-17",
    "close": 27683.0,
    "volume": 40047,
    "contract": "202512"
  },
  {
    "date": "2025-12-18",
    "close": 27410.0,
    "volume": 77414,
    "contract": "202601"
  },
  {
    "date": "2025-12-19",
    "close": 27815.0,
    "volume": 58823,
    "contract": "202601"
  },
  {
    "date": "2025-12-22",
    "close": 28120.0,
    "volume": 46171,
    "contract": "202601"
  },
  {
    "date": "2025-12-23",
    "close": 28343.0,
    "volume": 26638,
    "contract": "202601"
  },
  {
    "date": "2025-12-24",
    "close": 28562.0,
    "volume": 31924,
    "contract": "202601"
  },
  {
    "date": "2025-12-26",
    "close": 28531.0,
    "volume": 16258,
    "contract": "202601"
  },
  {
    "date": "2025-12-29",
    "close": 28708.0,
    "volume": 22207,
    "contract": "202601"
  },
  {
    "date": "2025-12-30",
    "close": 28786.0,
    "volume": 31880,
    "contract": "202601"
  },
  {
    "date": "2025-12-31",
    "close": 28879.0,
    "volume": 25932,
    "contract": "202601"
  },
  {
    "date": "2026-01-02",
    "close": 29009.0,
    "volume": 24132,
    "contract": "202601"
  },
  {
    "date": "2026-01-05",
    "close": 29776.0,
    "volume": 58378,
    "contract": "202601"
  },
  {
    "date": "2026-01-06",
    "close": 30290.0,
    "volume": 37930,
    "contract": "202601"
  },
  {
    "date": "2026-01-07",
    "close": 30603.0,
    "volume": 38491,
    "contract": "202601"
  },
  {
    "date": "2026-01-08",
    "close": 30306.0,
    "volume": 34258,
    "contract": "202601"
  },
  {
    "date": "2026-01-09",
    "close": 30458.0,
    "volume": 38418,
    "contract": "202601"
  },
  {
    "date": "2026-01-12",
    "close": 30826.0,
    "volume": 45074,
    "contract": "202601"
  },
  {
    "date": "2026-01-13",
    "close": 31071.0,
    "volume": 46616,
    "contract": "202601"
  },
  {
    "date": "2026-01-14",
    "close": 30956.0,
    "volume": 52649,
    "contract": "202601"
  },
  {
    "date": "2026-01-15",
    "close": 30841.0,
    "volume": 52310,
    "contract": "202601"
  },
  {
    "date": "2026-01-16",
    "close": 31335.0,
    "volume": 65948,
    "contract": "202601"
  },
  {
    "date": "2026-01-19",
    "close": 31342.0,
    "volume": 35778,
    "contract": "202601"
  },
  {
    "date": "2026-01-20",
    "close": 31558.0,
    "volume": 24067,
    "contract": "202601"
  },
  {
    "date": "2026-01-21",
    "close": 31231.0,
    "volume": 50056,
    "contract": "202601"
  },
  {
    "date": "2026-01-22",
    "close": 31726.0,
    "volume": 80848,
    "contract": "202602"
  },
  {
    "date": "2026-01-23",
    "close": 32012.0,
    "volume": 48858,
    "contract": "202602"
  },
  {
    "date": "2026-01-26",
    "close": 32238.0,
    "volume": 51696,
    "contract": "202602"
  },
  {
    "date": "2026-01-27",
    "close": 32288.0,
    "volume": 43161,
    "contract": "202602"
  },
  {
    "date": "2026-01-28",
    "close": 32696.0,
    "volume": 35434,
    "contract": "202602"
  },
  {
    "date": "2026-01-29",
    "close": 33015.0,
    "volume": 55311,
    "contract": "202602"
  },
  {
    "date": "2026-01-30",
    "close": 32443.0,
    "volume": 84868,
    "contract": "202602"
  },
  {
    "date": "2026-02-02",
    "close": 31889.0,
    "volume": 98563,
    "contract": "202602"
  },
  {
    "date": "2026-02-03",
    "close": 32241.0,
    "volume": 57292,
    "contract": "202602"
  },
  {
    "date": "2026-02-04",
    "close": 32105.0,
    "volume": 82423,
    "contract": "202602"
  },
  {
    "date": "2026-02-05",
    "close": 31903.0,
    "volume": 91481,
    "contract": "202602"
  },
  {
    "date": "2026-02-06",
    "close": 31760.0,
    "volume": 109716,
    "contract": "202602"
  },
  {
    "date": "2026-02-09",
    "close": 32639.0,
    "volume": 68572,
    "contract": "202602"
  },
  {
    "date": "2026-02-10",
    "close": 32912.0,
    "volume": 52449,
    "contract": "202602"
  },
  {
    "date": "2026-02-11",
    "close": 33262.0,
    "volume": 55540,
    "contract": "202602"
  },
  {
    "date": "2026-02-23",
    "close": 33969.0,
    "volume": 47486,
    "contract": "202602"
  },
  {
    "date": "2026-02-24",
    "close": 34027.0,
    "volume": 48895,
    "contract": "202603"
  },
  {
    "date": "2026-02-25",
    "close": 35215.0,
    "volume": 55412,
    "contract": "202603"
  },
  {
    "date": "2026-02-26",
    "close": 35655.0,
    "volume": 40395,
    "contract": "202603"
  },
  {
    "date": "2026-03-02",
    "close": 35086.0,
    "volume": 82188,
    "contract": "202603"
  },
  {
    "date": "2026-03-03",
    "close": 35175.0,
    "volume": 93330,
    "contract": "202603"
  },
  {
    "date": "2026-03-04",
    "close": 33548.0,
    "volume": 148908,
    "contract": "202603"
  },
  {
    "date": "2026-03-05",
    "close": 33735.0,
    "volume": 90497,
    "contract": "202603"
  },
  {
    "date": "2026-03-06",
    "close": 33288.0,
    "volume": 135936,
    "contract": "202603"
  },
  {
    "date": "2026-03-09",
    "close": 32673.0,
    "volume": 118813,
    "contract": "202603"
  },
  {
    "date": "2026-03-10",
    "close": 33414.0,
    "volume": 90480,
    "contract": "202603"
  },
  {
    "date": "2026-03-11",
    "close": 33105.0,
    "volume": 104350,
    "contract": "202603"
  },
  {
    "date": "2026-03-12",
    "close": 33707.0,
    "volume": 87152,
    "contract": "202603"
  },
  {
    "date": "2026-03-13",
    "close": 32442.0,
    "volume": 98937,
    "contract": "202603"
  },
  {
    "date": "2026-03-16",
    "close": 32815.0,
    "volume": 105955,
    "contract": "202603"
  },
  {
    "date": "2026-03-17",
    "close": 33685.0,
    "volume": 57485,
    "contract": "202603"
  },
  {
    "date": "2026-03-18",
    "close": 34101.0,
    "volume": 46685,
    "contract": "202603"
  },
  {
    "date": "2026-03-19",
    "close": 33897.0,
    "volume": 76539,
    "contract": "202604"
  },
  {
    "date": "2026-03-20",
    "close": 33782.0,
    "volume": 100009,
    "contract": "202604"
  },
  {
    "date": "2026-03-23",
    "close": 32737.0,
    "volume": 88226,
    "contract": "202604"
  },
  {
    "date": "2026-03-24",
    "close": 33618.0,
    "volume": 117893,
    "contract": "202604"
  },
  {
    "date": "2026-03-25",
    "close": 33459.0,
    "volume": 85273,
    "contract": "202604"
  },
  {
    "date": "2026-03-26",
    "close": 33800.0,
    "volume": 72885,
    "contract": "202604"
  },
  {
    "date": "2026-03-27",
    "close": 32807.0,
    "volume": 68139,
    "contract": "202604"
  },
  {
    "date": "2026-03-30",
    "close": 32244.0,
    "volume": 71462,
    "contract": "202604"
  },
  {
    "date": "2026-03-31",
    "close": 32031.0,
    "volume": 66958,
    "contract": "202604"
  },
  {
    "date": "2026-04-01",
    "close": 33084.0,
    "volume": 86828,
    "contract": "202604"
  },
  {
    "date": "2026-04-02",
    "close": 33567.0,
    "volume": 70566,
    "contract": "202604"
  },
  {
    "date": "2026-04-07",
    "close": 32877.0,
    "volume": 69057,
    "contract": "202604"
  },
  {
    "date": "2026-04-08",
    "close": 33495.0,
    "volume": 79836,
    "contract": "202604"
  },
  {
    "date": "2026-04-09",
    "close": 35208.0,
    "volume": 57379,
    "contract": "202604"
  },
  {
    "date": "2026-04-10",
    "close": 35222.0,
    "volume": 47030,
    "contract": "202604"
  },
  {
    "date": "2026-04-13",
    "close": 35589.0,
    "volume": 38073,
    "contract": "202604"
  },
  {
    "date": "2026-04-14",
    "close": 36027.0,
    "volume": 33269,
    "contract": "202604"
  },
  {
    "date": "2026-04-15",
    "close": 36725.0,
    "volume": 27131,
    "contract": "202604"
  },
  {
    "date": "2026-04-16",
    "close": 37226.0,
    "volume": 35783,
    "contract": "202605"
  },
  {
    "date": "2026-04-17",
    "close": 37143.0,
    "volume": 60989,
    "contract": "202605"
  },
  {
    "date": "2026-04-20",
    "close": 37742.0,
    "volume": 52411,
    "contract": "202605"
  },
  {
    "date": "2026-04-21",
    "close": 37621.0,
    "volume": 43889,
    "contract": "202605"
  },
  {
    "date": "2026-04-22",
    "close": 37904.0,
    "volume": 56956,
    "contract": "202605"
  },
  {
    "date": "2026-04-23",
    "close": 38746.0,
    "volume": 38492,
    "contract": "202605"
  },
  {
    "date": "2026-04-24",
    "close": 38047.0,
    "volume": 66531,
    "contract": "202605"
  },
  {
    "date": "2026-04-27",
    "close": 39766.0,
    "volume": 57240,
    "contract": "202605"
  },
  {
    "date": "2026-04-28",
    "close": 39719.0,
    "volume": 42663,
    "contract": "202605"
  },
  {
    "date": "2026-04-29",
    "close": 39461.0,
    "volume": 55589,
    "contract": "202605"
  },
  {
    "date": "2026-04-30",
    "close": 39337.0,
    "volume": 48696,
    "contract": "202605"
  },
  {
    "date": "2026-05-04",
    "close": 40103.0,
    "volume": 56389,
    "contract": "202605"
  },
  {
    "date": "2026-05-05",
    "close": 40788.0,
    "volume": 58129,
    "contract": "202605"
  },
  {
    "date": "2026-05-06",
    "close": 41555.0,
    "volume": 45799,
    "contract": "202605"
  },
  {
    "date": "2026-05-07",
    "close": 42320.0,
    "volume": 56177,
    "contract": "202605"
  },
  {
    "date": "2026-05-08",
    "close": 41941.0,
    "volume": 54697,
    "contract": "202605"
  },
  {
    "date": "2026-05-11",
    "close": 42292.0,
    "volume": 41908,
    "contract": "202605"
  },
  {
    "date": "2026-05-12",
    "close": 42278.0,
    "volume": 46025,
    "contract": "202605"
  },
  {
    "date": "2026-05-13",
    "close": 41136.0,
    "volume": 73828,
    "contract": "202605"
  },
  {
    "date": "2026-05-14",
    "close": 41756.0,
    "volume": 52114,
    "contract": "202605"
  },
  {
    "date": "2026-05-15",
    "close": 42359.0,
    "volume": 52326,
    "contract": "202605"
  },
  {
    "date": "2026-05-18",
    "close": 40511.0,
    "volume": 71082,
    "contract": "202605"
  },
  {
    "date": "2026-05-19",
    "close": 40878.0,
    "volume": 65991,
    "contract": "202605"
  },
  {
    "date": "2026-05-20",
    "close": 40140.0,
    "volume": 54823,
    "contract": "202605"
  },
  {
    "date": "2026-05-21",
    "close": 40990.0,
    "volume": 49228,
    "contract": "202606"
  },
  {
    "date": "2026-05-22",
    "close": 41791.0,
    "volume": 61852,
    "contract": "202606"
  },
  {
    "date": "2026-05-25",
    "close": 42634.0,
    "volume": 41417,
    "contract": "202606"
  },
  {
    "date": "2026-05-26",
    "close": 44389.0,
    "volume": 24420,
    "contract": "202606"
  },
  {
    "date": "2026-05-27",
    "close": 44438.0,
    "volume": 42235,
    "contract": "202606"
  },
  {
    "date": "2026-05-28",
    "close": 45239.0,
    "volume": 78853,
    "contract": "202606"
  },
  {
    "date": "2026-05-29",
    "close": 44789.0,
    "volume": 60558,
    "contract": "202606"
  },
  {
    "date": "2026-06-01",
    "close": 45069.0,
    "volume": 54773,
    "contract": "202606"
  },
  {
    "date": "2026-06-02",
    "close": 46546.0,
    "volume": 60755,
    "contract": "202606"
  },
  {
    "date": "2026-06-03",
    "close": 46686.0,
    "volume": 43443,
    "contract": "202606"
  },
  {
    "date": "2026-06-04",
    "close": 46537.0,
    "volume": 52774,
    "contract": "202606"
  },
  {
    "date": "2026-06-05",
    "close": 46342.0,
    "volume": 73586,
    "contract": "202606"
  },
  {
    "date": "2026-06-08",
    "close": 42220.0,
    "volume": 107378,
    "contract": "202606"
  },
  {
    "date": "2026-06-09",
    "close": 43999.0,
    "volume": 73636,
    "contract": "202606"
  },
  {
    "date": "2026-06-10",
    "close": 43878.0,
    "volume": 121791,
    "contract": "202606"
  },
  {
    "date": "2026-06-11",
    "close": 42615.0,
    "volume": 117269,
    "contract": "202606"
  },
  {
    "date": "2026-06-12",
    "close": 44382.0,
    "volume": 88271,
    "contract": "202606"
  },
  {
    "date": "2026-06-15",
    "close": 44704.0,
    "volume": 67536,
    "contract": "202606"
  },
  {
    "date": "2026-06-16",
    "close": 46246.0,
    "volume": 35755,
    "contract": "202606"
  },
  {
    "date": "2026-06-17",
    "close": 45020.0,
    "volume": 43078,
    "contract": "202606"
  },
  {
    "date": "2026-06-18",
    "close": 46036.0,
    "volume": 58875,
    "contract": "202607"
  },
  {
    "date": "2026-06-22",
    "close": 47565.0,
    "volume": 40750,
    "contract": "202607"
  },
  {
    "date": "2026-06-23",
    "close": 48883.0,
    "volume": 44537,
    "contract": "202607"
  },
  {
    "date": "2026-06-24",
    "close": 46207.0,
    "volume": 73379,
    "contract": "202607"
  },
  {
    "date": "2026-06-25",
    "close": 46910.0,
    "volume": 84895,
    "contract": "202607"
  },
  {
    "date": "2026-06-26",
    "close": 45805.0,
    "volume": 93096,
    "contract": "202607"
  },
  {
    "date": "2026-06-29",
    "close": 44995.0,
    "volume": 68847,
    "contract": "202607"
  },
  {
    "date": "2026-06-30",
    "close": 46361.0,
    "volume": 58478,
    "contract": "202607"
  },
  {
    "date": "2026-07-01",
    "close": 47428.0,
    "volume": 39982,
    "contract": "202607"
  },
  {
    "date": "2026-07-02",
    "close": 46354.0,
    "volume": 58217,
    "contract": "202607"
  },
  {
    "date": "2026-07-03",
    "close": 45668.0,
    "volume": 86249,
    "contract": "202607"
  },
  {
    "date": "2026-07-06",
    "close": 47116.0,
    "volume": 23741,
    "contract": "202607"
  },
  {
    "date": "2026-07-07",
    "close": 47340.0,
    "volume": 35769,
    "contract": "202607"
  },
  {
    "date": "2026-07-08",
    "close": 45207.0,
    "volume": 61514,
    "contract": "202607"
  },
  {
    "date": "2026-07-09",
    "close": 45727.0,
    "volume": 72702,
    "contract": "202607"
  },
  {
    "date": "2026-07-10",
    "close": 46281.0,
    "volume": 45509,
    "contract": "202607"
  }
]
;
